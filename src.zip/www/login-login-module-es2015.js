(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login-login-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.page.html":
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.page.html ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<!--ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>signup</ion-title>\r\n  </ion-toolbar>\r\n</ion-header-->\r\n\r\n<ion-content bg-white>\r\n\t<h2 class=\"vrt_txt\">Login</h2>\r\n\t<div class=\"top-img-str\"></div>\r\n\t<div class=\"cont-login\">\t\t\r\n\t\t<div class=\"logo-top-al\">\r\n\t\t\t<img src=\"assets/images/logonew.png\">\r\n\t\t</div>\r\n\t\t<div class=\"main-ttl\">\r\n\t\t\t<h3> Login </h3>\r\n\t\t\t<p> Fill Email Address to Login </p>\r\n\t\t</div>\r\n\t\t<div class=\"flds-login\">\r\n\t\t\t<div formfield>\r\n\t\t\t\t<label>Email Address</label>\r\n\t\t\t\t<ion-item lines=\"none\" class=\"fls\"> \r\n\t\t\t\t\t<ion-input placeholder=\"Enter email address\" [(ngModel)]=\"login_email\" name=\"login_email\" type=\"email\"></ion-input>\r\n\t\t\t\t\t\r\n\t\t\t\t</ion-item>\r\n\t\t\t\t<span error *ngIf=\"errors.indexOf(login_email) >= 0 && is_submit_login == true\">Please enter your email address</span>\r\n\t\t\t\t    <span error *ngIf=\"errors.indexOf(login_email) == -1 && is_submit_login == true && !reg_exp.test(login_email.toLowerCase())\">Please enter valid email address</span>\r\n\t\t\t</div>\r\n\t\t\t<div formfield>\r\n\t\t\t\t<label>Password</label>\r\n\t\t\t\t<ion-item lines=\"none\" class=\"fls\"> \r\n\t\t\t\t\t<ion-input placeholder=\"Enter password\" [(ngModel)]=\"login_password\" name=\"login_password\" type=\"password\" ></ion-input>\r\n\t\t\t\t\r\n\t\t\t\t</ion-item>\r\n\t\t\t\t\t<span error *ngIf=\"errors.indexOf(login_password) >= 0 && is_submit_login == true\">Please enter your password</span>\r\n\t\t\t</div>\r\n\t\t\t<ion-button (click)=\"login()\"  type=\"submit\" expand=\"full\" shape=\"round\" class=\"btn-losns\">Login</ion-button>\r\n\t\t\t<div class=\"social_signup\">\r\n\t\t\t\t<h5>Or Sign In With</h5>\r\n\t\t\t\t<div sociallink>\r\n\t\t\t\t<ion-buttons facebook  (click)=\"facebookLogin()\">\r\n\t\t\t\t<ion-icon name=\"logo-facebook\"></ion-icon>\r\n\t\t\t\t</ion-buttons>\r\n\t\t\t\t<ion-buttons google (click)=\"googleLogin()\">\r\n\t\t\t\t<ion-icon name=\"logo-google\"></ion-icon>\r\n\t\t\t\t</ion-buttons>\r\n\t\t\t</div>\r\n\t\t\t<p>Don't have an account? <a href=\"javascript:void(0)\" routerLink=\"/signup\">Sign Up Here</a></p>\r\n\t\t\t</div>\r\n\t\t</div>\t\r\n\t</div>\r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/login/login-routing.module.ts":
/*!***********************************************!*\
  !*** ./src/app/login/login-routing.module.ts ***!
  \***********************************************/
/*! exports provided: LoginPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageRoutingModule", function() { return LoginPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./login.page */ "./src/app/login/login.page.ts");




const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_3__["LoginPage"]
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], LoginPageRoutingModule);



/***/ }),

/***/ "./src/app/login/login.module.ts":
/*!***************************************!*\
  !*** ./src/app/login/login.module.ts ***!
  \***************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./login-routing.module */ "./src/app/login/login-routing.module.ts");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login.page */ "./src/app/login/login.page.ts");







let LoginPageModule = class LoginPageModule {
};
LoginPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _login_routing_module__WEBPACK_IMPORTED_MODULE_5__["LoginPageRoutingModule"]
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]]
    })
], LoginPageModule);



/***/ }),

/***/ "./src/app/login/login.page.scss":
/*!***************************************!*\
  !*** ./src/app/login/login.page.scss ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content[bg-white] {\n  background: var(--ion-color-white);\n  --background:var( --ion-color-white);\n}\nion-content[bg-white] h2.vrt_txt {\n  transform: rotate(-90deg);\n  transform-origin: left;\n  bottom: 0;\n  text-align: left;\n  white-space: nowrap;\n  position: absolute;\n  font-size: 60px;\n  left: 48px;\n  text-transform: uppercase;\n  font-weight: 900;\n  color: rgba(239, 160, 7, 0.1);\n  z-index: 1;\n}\nion-content[bg-white] .top-img-str {\n  background: url('krishnadasHaiti.jpg');\n  height: 150px;\n  position: relative;\n  background-size: cover;\n  z-index: 0;\n  background-position: center;\n}\nion-content[bg-white] .top-img-str:after {\n  content: \"\";\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  background: var(--ion-color-black);\n  opacity: 0.35;\n}\nion-content[bg-white] .cont-login {\n  position: relative;\n  padding: 25px;\n  background: var(--ion-color-white);\n  border-radius: 30px;\n  margin-top: -30px;\n}\nion-content[bg-white] .cont-login .logo-top-al {\n  width: 110px;\n  height: 110px;\n  display: block;\n  margin: 0 auto;\n  text-align: center;\n  margin-top: -70px;\n  background: var(--ion-color-white);\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  box-shadow: 0px 2px 24px rgba(0, 0, 0, 0.1);\n  padding-top: 5px;\n  margin-bottom: 35px;\n}\nion-content[bg-white] .cont-login .logo-top-al img {\n  width: 56px;\n  height: auto;\n}\nion-content[bg-white] .cont-login .main-ttl {\n  text-align: center;\n  margin-bottom: 40px;\n}\nion-content[bg-white] .cont-login .main-ttl h3 {\n  margin: 0px;\n  font-size: 25px;\n  font-weight: 700;\n  color: #272727;\n}\nion-content[bg-white] .cont-login .main-ttl p {\n  margin: 0px;\n  font-size: 13px;\n  color: #9d9d9d;\n  margin-top: 7px;\n  font-weight: 500;\n  letter-spacing: 0.3px;\n}\nion-content[bg-white] .cont-login .flds-login {\n  position: relative;\n  z-index: 1;\n}\nion-content[bg-white] .cont-login .flds-login [formfield] {\n  position: relative;\n  border: 1px solid #e8e8e8;\n  height: 52px;\n  margin-bottom: 30px;\n  border-radius: 50px;\n  background: var(--ion-color-white);\n  padding: 0 16px;\n}\nion-content[bg-white] .cont-login .flds-login [formfield] label {\n  position: absolute;\n  top: -10px;\n  z-index: 111;\n  background: var(--ion-color-white);\n  left: 29px;\n  padding: 0 3px;\n  font-size: 12px;\n  font-weight: 700;\n  color: #3a3a3a;\n}\nion-content[bg-white] .cont-login .flds-login [formfield] ion-input {\n  padding: 0px;\n  --padding-start: 0px;\n  --padding-end: 0px;\n  font-size: 14px;\n  --placeholder-color: #9a9a9a;\n  --placeholder-opacity: 1;\n  font-family: \"Poppins\", sans-serif !important;\n  color: #222;\n}\nion-content[bg-white] .cont-login .flds-login .btn-losns {\n  --background:var( --ion-color-primary);\n  margin-top: 20px;\n  --box-shadow: none;\n  min-height: 48px;\n  margin-bottom: 15px;\n  text-transform: uppercase;\n  letter-spacing: 1px;\n}\nion-content[bg-white] .cont-login .flds-login .warning {\n  color: #c2c2c2;\n  text-align: center;\n  margin: 0 4px;\n  font-size: 13px;\n}\nion-content[bg-white] .cont-login .flds-login .social_signup {\n  text-align: center;\n  margin-top: 40px;\n}\nion-content[bg-white] .cont-login .flds-login .social_signup [sociallink] {\n  justify-content: center;\n  display: flex;\n  align-items: center;\n  margin-top: 10px;\n}\nion-content[bg-white] .cont-login .flds-login .social_signup [sociallink] ion-buttons {\n  curspor: pointer;\n}\nion-content[bg-white] .cont-login .flds-login .social_signup [sociallink] ion-buttons[facebook] {\n  width: 40px;\n  height: 40px;\n  background: #3c5a98;\n  color: var(--ion-color-white);\n  border-radius: 50%;\n  text-align: center;\n  justify-content: center;\n  margin-right: 10px;\n}\nion-content[bg-white] .cont-login .flds-login .social_signup [sociallink] ion-buttons[google] {\n  width: 40px;\n  height: 40px;\n  background: #d2412c;\n  color: var(--ion-color-white);\n  border-radius: 50%;\n  text-align: center;\n  justify-content: center;\n}\nion-content[bg-white] .cont-login .flds-login .social_signup h5 {\n  font-size: 14px;\n  text-align: center;\n  display: inline-block;\n  position: relative;\n  color: #878686;\n}\nion-content[bg-white] .cont-login .flds-login .social_signup h5:after {\n  content: \"\";\n  display: block;\n  height: 1px;\n  width: 30px;\n  background: #878686;\n  position: absolute;\n  right: -40px;\n  top: 10px;\n}\nion-content[bg-white] .cont-login .flds-login .social_signup h5:before {\n  content: \"\";\n  display: block;\n  height: 1px;\n  width: 30px;\n  background: #878686;\n  position: absolute;\n  left: -40px;\n  top: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW4vbG9naW4ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0Msa0NBQUE7RUFDQSxvQ0FBQTtBQUNEO0FBQ0M7RUFDQyx5QkFBQTtFQUNNLHNCQUFBO0VBQ0EsU0FBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxVQUFBO0VBQ0EseUJBQUE7RUFDQSxnQkFBQTtFQUNBLDZCQUFBO0VBQ0EsVUFBQTtBQUNSO0FBQ0M7RUFDQyxzQ0FBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtFQUNBLHNCQUFBO0VBQ0EsVUFBQTtFQUNBLDJCQUFBO0FBQ0Y7QUFBRTtFQUNDLFdBQUE7RUFDQSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsTUFBQTtFQUNBLFNBQUE7RUFDQSxrQ0FBQTtFQUNBLGFBQUE7QUFFSDtBQUNDO0VBQ0Msa0JBQUE7RUFDQSxhQUFBO0VBQ0Esa0NBQUE7RUFDQSxtQkFBQTtFQUNBLGlCQUFBO0FBQ0Y7QUFBRTtFQUNDLFlBQUE7RUFDQSxhQUFBO0VBQ0EsY0FBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0NBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsMkNBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FBRUg7QUFERztFQUNDLFdBQUE7RUFDQSxZQUFBO0FBR0o7QUFBRTtFQUNDLGtCQUFBO0VBQ0EsbUJBQUE7QUFFSDtBQURHO0VBQ0MsV0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFHSjtBQURHO0VBQ0MsV0FBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EscUJBQUE7QUFHSjtBQUFFO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0FBRUY7QUFERTtFQUNDLGtCQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtDQUFBO0VBQ0EsZUFBQTtBQUdIO0FBRkc7RUFDQyxrQkFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0VBQ0Esa0NBQUE7RUFDQSxVQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFJSjtBQUZHO0VBQ0MsWUFBQTtFQUNBLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsNEJBQUE7RUFDQSx3QkFBQTtFQUNBLDZDQUFBO0VBQ0EsV0FBQTtBQUlKO0FBREU7RUFDQyxzQ0FBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDUyxnQkFBQTtFQUNULG1CQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtBQUdIO0FBREU7RUFDQyxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtBQUdIO0FBREU7RUFDQyxrQkFBQTtFQUNBLGdCQUFBO0FBR0g7QUFGRztFQUNDLHVCQUFBO0VBQ0QsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUFJSDtBQUhHO0VBQ0MsZ0JBQUE7QUFLSjtBQUpJO0VBRUEsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7QUFLSjtBQUpLO0VBRUQsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0FBS0o7QUFERztFQUFHLGVBQUE7RUFDRixrQkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FBSUo7QUFISTtFQUNDLFdBQUE7RUFDQSxjQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFNBQUE7QUFLTDtBQUhJO0VBQ0MsV0FBQTtFQUNBLGNBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtBQUtMIiwiZmlsZSI6InNyYy9hcHAvbG9naW4vbG9naW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnRbYmctd2hpdGVdIHtcclxuXHRiYWNrZ3JvdW5kOnZhciggLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdC0tYmFja2dyb3VuZDp2YXIoIC0taW9uLWNvbG9yLXdoaXRlKTtcclxuXHJcblx0aDIudnJ0X3R4dCB7XHJcblx0XHR0cmFuc2Zvcm06IHJvdGF0ZSgtOTBkZWcpO1xyXG4gICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGxlZnQ7XHJcbiAgICAgICAgYm90dG9tOiAwO1xyXG4gICAgICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICAgICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgZm9udC1zaXplOiA2MHB4O1xyXG4gICAgICAgIGxlZnQ6IDQ4cHg7XHJcbiAgICAgICAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuICAgICAgICBmb250LXdlaWdodDogOTAwO1xyXG4gICAgICAgIGNvbG9yOiByZ2JhKDIzOSwgMTYwLCA3LCAwLjEpO1xyXG4gICAgICAgIHotaW5kZXg6IDE7XHJcblx0fVxyXG5cdC50b3AtaW1nLXN0ciB7XHJcblx0XHRiYWNrZ3JvdW5kOnVybChcIi4uLy4uL2Fzc2V0cy9pbWFnZXMva3Jpc2huYWRhc0hhaXRpLmpwZ1wiKTtcclxuXHRcdGhlaWdodDoxNTBweDtcclxuXHRcdHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHRcdGJhY2tncm91bmQtc2l6ZTogY292ZXI7XHJcblx0XHR6LWluZGV4OiAwO1xyXG5cdFx0YmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xyXG5cdFx0JjphZnRlciB7XHJcblx0XHRcdGNvbnRlbnQ6IFwiXCI7XHJcblx0XHRcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRcdFx0bGVmdDogMDtcclxuXHRcdFx0cmlnaHQ6IDA7XHJcblx0XHRcdHRvcDogMDtcclxuXHRcdFx0Ym90dG9tOiAwO1xyXG5cdFx0XHRiYWNrZ3JvdW5kOiB2YXIoIC0taW9uLWNvbG9yLWJsYWNrKTtcclxuXHRcdFx0b3BhY2l0eTogMC4zNTtcclxuXHRcdH1cclxuXHR9XHJcblx0LmNvbnQtbG9naW4ge1xyXG5cdFx0cG9zaXRpb246IHJlbGF0aXZlO1xyXG5cdFx0cGFkZGluZzogMjVweDtcclxuXHRcdGJhY2tncm91bmQ6IHZhciggLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdFx0Ym9yZGVyLXJhZGl1czogMzBweDtcclxuXHRcdG1hcmdpbi10b3A6IC0zMHB4O1xyXG5cdFx0LmxvZ28tdG9wLWFsIHtcclxuXHRcdFx0d2lkdGg6IDExMHB4O1xyXG5cdFx0XHRoZWlnaHQ6IDExMHB4O1xyXG5cdFx0XHRkaXNwbGF5OiBibG9jaztcclxuXHRcdFx0bWFyZ2luOiAwIGF1dG87XHJcblx0XHRcdHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHRcdFx0bWFyZ2luLXRvcDogLTcwcHg7XHJcblx0XHRcdGJhY2tncm91bmQ6dmFyKCAtLWlvbi1jb2xvci13aGl0ZSk7XHJcblx0XHRcdGJvcmRlci1yYWRpdXM6IDUwJTtcclxuXHRcdFx0ZGlzcGxheTogZmxleDtcclxuXHRcdFx0YWxpZ24taXRlbXM6IGNlbnRlcjtcclxuXHRcdFx0anVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblx0XHRcdGJveC1zaGFkb3c6IDBweCAycHggMjRweCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcblx0XHRcdHBhZGRpbmctdG9wOiA1cHg7XHJcblx0XHRcdG1hcmdpbi1ib3R0b206IDM1cHg7XHJcblx0XHRcdGltZyB7XHJcblx0XHRcdFx0d2lkdGg6IDU2cHg7XHJcblx0XHRcdFx0aGVpZ2h0OiBhdXRvO1xyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0XHQubWFpbi10dGwge1xyXG5cdFx0XHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblx0XHRcdG1hcmdpbi1ib3R0b206IDQwcHg7XHJcblx0XHRcdGgzIHtcclxuXHRcdFx0XHRtYXJnaW46IDBweDtcclxuXHRcdFx0XHRmb250LXNpemU6IDI1cHg7XHJcblx0XHRcdFx0Zm9udC13ZWlnaHQ6IDcwMDtcclxuXHRcdFx0XHRjb2xvcjogIzI3MjcyNztcclxuXHRcdFx0fVxyXG5cdFx0XHRwIHtcclxuXHRcdFx0XHRtYXJnaW46IDBweDtcclxuXHRcdFx0XHRmb250LXNpemU6IDEzcHg7XHJcblx0XHRcdFx0Y29sb3I6ICM5ZDlkOWQ7XHJcblx0XHRcdFx0bWFyZ2luLXRvcDogN3B4O1xyXG5cdFx0XHRcdGZvbnQtd2VpZ2h0OiA1MDA7XHJcblx0XHRcdFx0bGV0dGVyLXNwYWNpbmc6IDAuM3B4O1xyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0XHQuZmxkcy1sb2dpbntcdFx0XHJcblx0XHRwb3NpdGlvbjogcmVsYXRpdmU7XHJcblx0XHR6LWluZGV4OiAxO1xyXG5cdFx0W2Zvcm1maWVsZF0ge1xyXG5cdFx0XHRwb3NpdGlvbjogcmVsYXRpdmU7XHJcblx0XHRcdGJvcmRlcjogMXB4IHNvbGlkICNlOGU4ZTg7XHJcblx0XHRcdGhlaWdodDogNTJweDtcclxuXHRcdFx0bWFyZ2luLWJvdHRvbTogMzBweDtcclxuXHRcdFx0Ym9yZGVyLXJhZGl1czogNTBweDtcclxuXHRcdFx0YmFja2dyb3VuZDp2YXIoIC0taW9uLWNvbG9yLXdoaXRlKTtcclxuXHRcdFx0cGFkZGluZzogMCAxNnB4O1xyXG5cdFx0XHRsYWJlbCB7XHJcblx0XHRcdFx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdFx0XHRcdHRvcDogLTEwcHg7XHJcblx0XHRcdFx0ei1pbmRleDogMTExO1xyXG5cdFx0XHRcdGJhY2tncm91bmQ6IHZhciggLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdFx0XHRcdGxlZnQ6IDI5cHg7XHJcblx0XHRcdFx0cGFkZGluZzogMCAzcHg7XHJcblx0XHRcdFx0Zm9udC1zaXplOiAxMnB4O1xyXG5cdFx0XHRcdGZvbnQtd2VpZ2h0OiA3MDA7XHJcblx0XHRcdFx0Y29sb3I6ICMzYTNhM2E7XHJcblx0XHRcdH1cclxuXHRcdFx0aW9uLWlucHV0ICB7XHJcblx0XHRcdFx0cGFkZGluZzogMHB4O1xyXG5cdFx0XHRcdC0tcGFkZGluZy1zdGFydDogMHB4O1xyXG5cdFx0XHRcdC0tcGFkZGluZy1lbmQ6IDBweDtcclxuXHRcdFx0XHRmb250LXNpemU6IDE0cHg7XHJcblx0XHRcdFx0LS1wbGFjZWhvbGRlci1jb2xvcjogIzlhOWE5YTtcclxuXHRcdFx0XHQtLXBsYWNlaG9sZGVyLW9wYWNpdHk6IDE7XHJcblx0XHRcdFx0Zm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xyXG5cdFx0XHRcdGNvbG9yOiAjMjIyO1xyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0XHQuYnRuLWxvc25ze1xyXG5cdFx0XHQtLWJhY2tncm91bmQ6dmFyKCAtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuXHRcdFx0bWFyZ2luLXRvcDogMjBweDtcclxuXHRcdFx0LS1ib3gtc2hhZG93OiBub25lO1xyXG4gICAgICAgICAgICBtaW4taGVpZ2h0OiA0OHB4O1xyXG5cdFx0XHRtYXJnaW4tYm90dG9tOiAxNXB4O1xyXG5cdFx0XHR0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG5cdFx0XHRsZXR0ZXItc3BhY2luZzogMXB4O1xyXG5cdFx0fVxyXG5cdFx0Lndhcm5pbmd7XHJcblx0XHRcdGNvbG9yOiAjYzJjMmMyO1xyXG5cdFx0XHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblx0XHRcdG1hcmdpbjogMCA0cHg7XHJcblx0XHRcdGZvbnQtc2l6ZTogMTNweDtcclxuXHRcdH1cclxuXHRcdC5zb2NpYWxfc2lnbnVwe1xyXG5cdFx0XHR0ZXh0LWFsaWduOmNlbnRlcjtcclxuXHRcdFx0bWFyZ2luLXRvcDo0MHB4O1xyXG5cdFx0XHRbc29jaWFsbGlua11cclxuXHRcdFx0e2p1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cdFx0XHRkaXNwbGF5OmZsZXg7XHJcblx0XHRcdGFsaWduLWl0ZW1zOmNlbnRlcjtcclxuXHRcdFx0bWFyZ2luLXRvcDoxMHB4O1xyXG5cdFx0XHRpb24tYnV0dG9uc1xyXG5cdFx0XHR7Y3Vyc3Bvcjpwb2ludGVyO1xyXG5cdFx0XHQgJltmYWNlYm9va11cclxuXHRcdFx0IHtcclxuXHRcdFx0XHR3aWR0aDogNDBweDtcclxuXHRcdFx0XHRoZWlnaHQ6IDQwcHg7XHJcblx0XHRcdFx0YmFja2dyb3VuZDogIzNjNWE5ODtcclxuXHRcdFx0XHRjb2xvcjp2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdFx0XHRcdGJvcmRlci1yYWRpdXM6IDUwJTtcclxuXHRcdFx0XHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblx0XHRcdFx0anVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblx0XHRcdFx0bWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG5cdFx0XHR9ICZbZ29vZ2xlXVxyXG5cdFx0XHQge1xyXG5cdFx0XHRcdHdpZHRoOiA0MHB4O1xyXG5cdFx0XHRcdGhlaWdodDogNDBweDtcclxuXHRcdFx0XHRiYWNrZ3JvdW5kOiAjZDI0MTJjO1xyXG5cdFx0XHRcdGNvbG9yOnZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcblx0XHRcdFx0Ym9yZGVyLXJhZGl1czogNTAlO1xyXG5cdFx0XHRcdHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHRcdFx0XHRqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHRcdFx0fVxyXG5cdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdFx0aDV7Zm9udC1zaXplOiAxNHB4O1xyXG5cdFx0XHRcdHRleHQtYWxpZ246Y2VudGVyO1xyXG5cdFx0XHRcdGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuXHRcdFx0XHRwb3NpdGlvbjpyZWxhdGl2ZTtcclxuXHRcdFx0XHRjb2xvcjojODc4Njg2O1xyXG5cdFx0XHRcdCY6YWZ0ZXJ7XHJcblx0XHRcdFx0XHRjb250ZW50OiBcIlwiO1xyXG5cdFx0XHRcdFx0ZGlzcGxheTogYmxvY2s7XHJcblx0XHRcdFx0XHRoZWlnaHQ6IDFweDtcclxuXHRcdFx0XHRcdHdpZHRoOiAzMHB4O1xyXG5cdFx0XHRcdFx0YmFja2dyb3VuZDogIzg3ODY4NjtcclxuXHRcdFx0XHRcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRcdFx0XHRcdHJpZ2h0OiAtNDBweDtcclxuXHRcdFx0XHRcdHRvcDogMTBweDtcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0JjpiZWZvcmV7XHJcblx0XHRcdFx0XHRjb250ZW50OiBcIlwiO1xyXG5cdFx0XHRcdFx0ZGlzcGxheTogYmxvY2s7XHJcblx0XHRcdFx0XHRoZWlnaHQ6IDFweDtcclxuXHRcdFx0XHRcdHdpZHRoOiAzMHB4O1xyXG5cdFx0XHRcdFx0YmFja2dyb3VuZDogIzg3ODY4NjtcclxuXHRcdFx0XHRcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRcdFx0XHRcdGxlZnQ6IC00MHB4O1xyXG5cdFx0XHRcdFx0dG9wOiAxMHB4O1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cdH1cclxuXHRcdFxyXG5cdH1cclxufSJdfQ== */");

/***/ }),

/***/ "./src/app/login/login.page.ts":
/*!*************************************!*\
  !*** ./src/app/login/login.page.ts ***!
  \*************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/api/api.service */ "./src/app/services/api/api.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../config */ "./src/app/config.ts");
/* harmony import */ var _common_common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../common/common.service */ "./src/app/common/common.service.ts");
/* harmony import */ var _services_globalFooService_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/globalFooService.service */ "./src/app/services/globalFooService.service.ts");
/* harmony import */ var _ionic_native_facebook_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/facebook/ngx */ "./node_modules/@ionic-native/facebook/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/google-plus/ngx */ "./node_modules/@ionic-native/google-plus/__ivy_ngcc__/ngx/index.js");









let LoginPage = class LoginPage {
    constructor(fb, googlePlus, globalFooService, api, router, common) {
        this.fb = fb;
        this.googlePlus = googlePlus;
        this.globalFooService = globalFooService;
        this.api = api;
        this.router = router;
        this.common = common;
        this.is_submit = false;
        this.is_submit_login = false;
        this.errors = ['', null, undefined];
        this.reg_exp = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    }
    ionViewDidEnter() {
        this.type_login = localStorage.getItem('type_login');
    }
    ngOnInit() {
    }
    facebookLogin() {
        this.fb.login(['public_profile', 'email']).then((res) => this.fb.api('me?fields=id,name,email,first_name,last_name,picture.width(720).height(720).as(picture_large)', []).then(profile => {
            console.log('profile', profile);
            if (this.errors.indexOf(profile) == -1) {
                let dict = {
                    first_name: profile['first_name'],
                    //last_name: profile['last_name'],
                    email: profile['email'],
                    password: '',
                    medium: 'facebook',
                    social_id: profile['id'],
                    image: profile['picture_large']['data']['url'],
                    type: this.type_login
                };
                console.log('dict', dict);
                this.finalSignup(dict);
            }
            else {
                this.common.presentToast('Error,Please try after some time', 'danger');
            }
        })).catch(e => {
            this.common.presentToast('Error,Please try after some time', 'danger');
            console.log(e);
        });
    }
    ;
    //Google social login 
    googleLogin() {
        console.log(this.googlePlus);
        this.googlePlus.login({ 'scopes': 'profile' })
            .then(profile => {
            console.log(profile);
            if (this.errors.indexOf(profile) == -1) {
                let dict = {
                    first_name: profile['displayName'],
                    email: profile['email'],
                    password: '',
                    medium: 'google',
                    social_id: profile['userId'],
                    image: !profile['imageUrl'] ? '' : profile['imageUrl'],
                    type: this.type_login
                };
                console.log('dict', dict);
                this.finalSignup(dict);
            }
        })
            .catch(err => {
            console.error(err);
            this.common.presentToast('Error,Please try after some time', 'danger');
        });
    }
    ;
    finalSignup(dict) {
        this.common.presentLoading();
        // this.fcm.getToken().then(token => {
        this.api.post('social_login', dict, '').subscribe((result) => {
            this.common.stopLoading();
            var res;
            res = result;
            if (res.status == 1) {
                var userId = this.api.encryptData(res.data.id, _config__WEBPACK_IMPORTED_MODULE_4__["config"].ENC_SALT);
                localStorage.setItem('userid', res.data.id);
                localStorage.setItem('is_logged_in_user', 'true');
                localStorage.setItem('food_token', userId);
                localStorage.setItem('food_first_name', res.data.first_name);
                localStorage.setItem('food_last_name', res.data.last_name);
                localStorage.setItem('food_email', res.data.email);
                localStorage.setItem('food_type', res.data.type);
                localStorage.setItem('profile_pic', res.data.image);
                this.globalFooService.publishSomeData({
                    foo: { 'data': res.data }
                });
                this.common.presentToast('Login successfully!', 'success');
                this.api.navCtrl.navigateRoot('tabs/home');
            }
            else {
                this.common.presentToast('Error while signing up! Please try later', 'danger');
            }
        }, err => {
            this.common.stopLoading();
            this.common.presentToast('Technical error,Please try after some time', 'danger');
        });
        // });
    }
    ;
    login() {
        this.is_submit_login = true;
        if (this.errors.indexOf(this.login_email) >= 0 || !this.reg_exp.test(String(this.login_email).toLowerCase()) || this.errors.indexOf(this.login_password) >= 0) {
            return false;
        }
        let dict = {
            email: this.login_email,
            password: this.login_password,
        };
        this.common.presentLoading();
        this.api.post('loginUser', dict, '').subscribe((result) => {
            this.is_submit_login = false;
            this.common.stopLoading();
            this.login_email = '';
            this.login_password = '';
            var res;
            res = result;
            if (res.status == 1) {
                var userId = this.api.encryptData(res.data.id, _config__WEBPACK_IMPORTED_MODULE_4__["config"].ENC_SALT);
                localStorage.setItem('userid', res.data.id);
                localStorage.setItem('food_token', userId);
                localStorage.setItem('food_first_name', res.data.first_name);
                localStorage.setItem('food_last_name', res.data.last_name);
                localStorage.setItem('food_email', res.data.email);
                localStorage.setItem('food_type', res.data.type);
                localStorage.setItem('profile_pic', res.data.image);
                this.globalFooService.publishSomeData({
                    foo: { 'data': res.data }
                });
                //this.router.navigate(['/tabs/home']);
                this.api.navCtrl.navigateRoot('tabs/home');
                this.common.presentToast('Logged in successfully !.', 'success');
            }
            else {
                this.common.presentToast(res.message, 'danger');
            }
        }, err => {
        });
    }
};
LoginPage.ctorParameters = () => [
    { type: _ionic_native_facebook_ngx__WEBPACK_IMPORTED_MODULE_7__["Facebook"] },
    { type: _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_8__["GooglePlus"] },
    { type: _services_globalFooService_service__WEBPACK_IMPORTED_MODULE_6__["GlobalFooService"] },
    { type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _common_common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"] }
];
LoginPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-login',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./login.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./login.page.scss */ "./src/app/login/login.page.scss")).default]
    })
], LoginPage);



/***/ })

}]);
//# sourceMappingURL=login-login-module-es2015.js.map