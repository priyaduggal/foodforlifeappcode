(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["settings-settings-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/settings/settings.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/settings/settings.page.html ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("   <ion-header>\r\n      <ion-toolbar color=\"primary\">\r\n        <ion-buttons slot=\"start\">\r\n          <ion-menu-button></ion-menu-button>\r\n        </ion-buttons>\r\n        <ion-title>Settings</ion-title>\r\n\t\t<ion-buttons (click)=\"logout()\" slot=\"end\">\r\n\t\t<ion-icon name=\"log-out-outline\"></ion-icon>\r\n\t\t</ion-buttons>\r\n      </ion-toolbar>\r\n\t  </ion-header>\r\n\r\n<ion-content class=\"ion-padding\">\r\n<div settinglist>\r\n\t<div class=\"ocid-s\">\r\n\t\t<span class=\"ich-d\"> <ion-icon name=\"shield-checkmark-outline\"></ion-icon> </span>\r\n\t\t<h2 heading>\r\n\t\tPayment Details\r\n\t\t</h2>\r\n\t\t<p>You Saved Payment Methods</p>\r\n\t</div>\r\n\r\n<div *ngFor=\"let pay of paymentlist\" class=\"paymentlist\">\r\n<p>{{pay?.card_number}} {{pay?.card_holder_name}}</p>\r\n<div>\r\n<ion-buttons   edit-btn routerLink=\"/edit_payment/{{pay?.id}}\">\r\n<ion-icon name=\"pencil-outline\"></ion-icon>\r\n</ion-buttons>\r\n<ion-buttons  delete-btn (click)=\"delete(pay?.id)\">\r\n<ion-icon name=\"trash-outline\"></ion-icon>\r\n</ion-buttons>\r\n</div>\r\n</div>\r\n<ion-button  expand=\"full\" shape=\"round\" routerLink=\"/addpayment\">Add Payment Method</ion-button>\r\n</div>\r\n<div settinglist>\r\n <ion-item lines=\"none\">\r\n    <ion-label>Set Reminder</ion-label>\r\n    <ion-toggle [ngModel]=\"SetRemainder\" (ngModelChange)=\"notifyAndUpdateIsToggled($event)\"></ion-toggle>\r\n  </ion-item>\r\n  <h3 subhead>\r\nHow Often\r\n</h3>\r\n<ion-radio-group value=\"{{how_often}}\">\r\n    <ion-item lines=\"none\">\r\n      <ion-label>Once a day</ion-label>\r\n      <ion-radio value=\"day\"  (click)=\"howoften('day')\"></ion-radio>\r\n    </ion-item>\r\n    <ion-item lines=\"none\">\r\n      <ion-label>Once a week</ion-label>\r\n      <ion-radio value=\"week\"   (click)=\"howoften('week')\"></ion-radio>\r\n    </ion-item>\r\n    <ion-item lines=\"none\">\r\n      <ion-label>Once a month</ion-label>\r\n      <ion-radio value=\"month\"  (click)=\"howoften('month')\"></ion-radio>\r\n    </ion-item>\r\n</ion-radio-group>\t\r\n  <h3 subhead>\r\nAt What Time\r\n</h3>\r\n<ion-radio-group value=\"{{what_time}}\">\r\n    <ion-item lines=\"none\">\r\n      <ion-label>Breakfast(8am)</ion-label>\r\n      <ion-radio value=\"day\" (click)=\"whattime('day')\"></ion-radio>\r\n    </ion-item>\r\n    <ion-item lines=\"none\">\r\n      <ion-label>Lunch (12pm)</ion-label>\r\n      <ion-radio value=\"week\"(click)=\"whattime('week')\" ></ion-radio>\r\n    </ion-item>\r\n    <ion-item lines=\"none\">\r\n      <ion-label>Dinner (7pm)</ion-label>\r\n      <ion-radio value=\"month\" (click)=\"whattime('month')\"></ion-radio>\r\n    </ion-item>\r\n</ion-radio-group>\r\n</div>\r\n\r\n<div settinglist>\r\n <ion-item lines=\"none\">\r\n    <ion-label>Push Notifications</ion-label>\r\n    <ion-toggle [ngModel]=\"PushNotification\" (ngModelChange)=\"PushNotificationfun($event)\"></ion-toggle>\r\n  </ion-item>\r\n \r\n</div>\r\n<div settinglist>\r\n<h2 heading>\r\nPrivacy\r\n</h2>\r\n<p>Control who can see your activities on FoodForLife</p>\r\n  <h3 subhead>\r\nWhen I Donate\r\n</h3>\r\n<ion-radio-group value=\"{{what_donate}}\">\r\n    <ion-item lines=\"none\">\r\n      <ion-label>Everybody</ion-label>\r\n      <ion-radio value=\"everybody\"(click)=\"whatdonate('everybody')\"></ion-radio>\r\n    </ion-item>\r\n    <ion-item lines=\"none\">\r\n      <ion-label>My Friends</ion-label>\r\n      <ion-radio value=\"friends\" (click)=\"whatdonate('friends')\"></ion-radio>\r\n    </ion-item>\r\n    <ion-item lines=\"none\">\r\n      <ion-label>Only Me</ion-label>\r\n      <ion-radio value=\"onlyme\" (click)=\"whatdonate('onlyme')\"></ion-radio>\r\n    </ion-item>\r\n</ion-radio-group>\t\r\n  <h3 subhead>\r\nThe Number Of Meals I Donate\r\n</h3>\r\n<ion-radio-group value=\"{{no_meals}}\">\r\n    <ion-item lines=\"none\">\r\n      <ion-label>Everybody</ion-label>\r\n      <ion-radio value=\"everybody\" (click)=\"noofmeals('everybody')\"></ion-radio>\r\n    </ion-item>\r\n    <ion-item lines=\"none\">\r\n      <ion-label>My Friends</ion-label>\r\n      <ion-radio value=\"friends\"(click)=\"noofmeals('friends')\"></ion-radio>\r\n    </ion-item>\r\n    <ion-item lines=\"none\">\r\n      <ion-label>Only Me</ion-label>\r\n      <ion-radio value=\"onlyme\" (click)=\"noofmeals('onlyme')\"></ion-radio>\r\n    </ion-item>\r\n</ion-radio-group>\t\r\n\r\n  <h3 subhead>\r\nMy Profile\r\n</h3>\r\n<ion-radio-group value=\"{{my_profile}}\">\r\n    <ion-item lines=\"none\">\r\n      <ion-label>Everybody</ion-label>\r\n      <ion-radio value=\"everybody\" (click)=\"myprofile('everybody')\"></ion-radio>\r\n    </ion-item>\r\n    <ion-item lines=\"none\">\r\n      <ion-label>My Friends</ion-label>\r\n      <ion-radio value=\"friends\"(click)=\"myprofile('friends')\"></ion-radio>\r\n    </ion-item>\r\n    <ion-item lines=\"none\">\r\n      <ion-label>Only Me</ion-label>\r\n      <ion-radio value=\"onlyme\"(click)=\"myprofile('onlyme')\"></ion-radio>\r\n    </ion-item>\r\n</ion-radio-group>\t\r\n\r\n</div>\r\n<div settinglist settinglinks>\r\n    <ion-item lines=\"none\">\r\n\t<ion-icon iconleft name=\"star-outline\" slot=\"start\"></ion-icon>\r\n      <ion-label>Rate Us</ion-label>\r\n\t  <ion-buttons slot=\"end\">\r\n\t  <ion-icon name=\"chevron-forward\"></ion-icon>\r\n\t  </ion-buttons>\r\n\t   </ion-item>\r\n\t   <ion-item lines=\"none\" routerLink=\"/contactus\">\r\n\t  <ion-icon iconleft name=\"call-outline\" slot=\"start\"></ion-icon>\r\n      <ion-label>Contact Us</ion-label>\r\n\t  <ion-buttons slot=\"end\">\r\n\t  <ion-icon name=\"chevron-forward\"></ion-icon>\r\n\t  </ion-buttons>\r\n\t   </ion-item>\r\n\t  <ion-item lines=\"none\" routerLink=\"/faq\">\r\n\t  <ion-icon iconleft name=\"help-circle-outline\" slot=\"start\"></ion-icon>\r\n      <ion-label>FAQ</ion-label>\r\n\t  <ion-buttons slot=\"end\">\r\n\t  <ion-icon name=\"chevron-forward\"></ion-icon>\r\n\t  </ion-buttons>\r\n\t   </ion-item>\r\n\t  <ion-item lines=\"none\" routerLink=\"/terms\">\r\n\t\t<ion-icon iconleft name=\"pricetags-outline\" slot=\"start\"></ion-icon>\r\n      <ion-label>Terms Of Use</ion-label>\r\n\t  <ion-buttons slot=\"end\">\r\n\t  <ion-icon name=\"chevron-forward\"></ion-icon>\r\n\t  </ion-buttons>\r\n\t   </ion-item>\r\n\t   \t   <ion-item lines=\"none\" routerLink=\"/about\">\r\n\t  <ion-icon iconleft name=\"information-circle-outline\" slot=\"start\"></ion-icon>\r\n      <ion-label>About Us</ion-label>\r\n\t  <ion-buttons slot=\"end\">\r\n\t  <ion-icon name=\"chevron-forward\"></ion-icon>\r\n\t  </ion-buttons>\r\n\t   </ion-item>\r\n\t   \t   <ion-item lines=\"none\" routerLink=\"/privacy\">\r\n\t \t<ion-icon iconleft name=\"pricetags-outline\" slot=\"start\"></ion-icon>\r\n      <ion-label>Privacy Policy</ion-label>\r\n\t  <ion-buttons slot=\"end\">\r\n\t  <ion-icon name=\"chevron-forward\"></ion-icon>\r\n\t  </ion-buttons>\r\n\t   </ion-item>\r\n</div>\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/settings/settings-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/settings/settings-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: SettingsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsPageRoutingModule", function() { return SettingsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _settings_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./settings.page */ "./src/app/settings/settings.page.ts");




const routes = [
    {
        path: '',
        component: _settings_page__WEBPACK_IMPORTED_MODULE_3__["SettingsPage"]
    }
];
let SettingsPageRoutingModule = class SettingsPageRoutingModule {
};
SettingsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SettingsPageRoutingModule);



/***/ }),

/***/ "./src/app/settings/settings.module.ts":
/*!*********************************************!*\
  !*** ./src/app/settings/settings.module.ts ***!
  \*********************************************/
/*! exports provided: SettingsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsPageModule", function() { return SettingsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _settings_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./settings-routing.module */ "./src/app/settings/settings-routing.module.ts");
/* harmony import */ var _settings_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./settings.page */ "./src/app/settings/settings.page.ts");







let SettingsPageModule = class SettingsPageModule {
};
SettingsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _settings_routing_module__WEBPACK_IMPORTED_MODULE_5__["SettingsPageRoutingModule"]
        ],
        declarations: [_settings_page__WEBPACK_IMPORTED_MODULE_6__["SettingsPage"]]
    })
], SettingsPageModule);



/***/ }),

/***/ "./src/app/settings/settings.page.scss":
/*!*********************************************!*\
  !*** ./src/app/settings/settings.page.scss ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-toolbar {\n  --ion-color-base: var(--ion-color-bggradient)!important;\n  --border-width: 0;\n}\nion-header ion-toolbar ion-buttons {\n  font-size: 22px;\n}\nion-header ion-toolbar ion-title {\n  color: var(--ion-color-white);\n  text-align: center;\n  font-style: normal;\n  font-family: \"Poppins\", sans-serif !important;\n}\nion-header::after {\n  display: none;\n}\nion-content {\n  --background: #f7f7f7;\n}\nion-content .paymentlist {\n  display: flex;\n  align-items: center;\n  flex-direction: row;\n  justify-content: space-between;\n}\nion-content .paymentlist > div {\n  display: flex;\n}\nion-content .paymentlist ion-buttons {\n  width: 30px;\n  height: 30px;\n  margin-left: 3px;\n  line-height: 30px;\n  color: var(--ion-color-white);\n  border-radius: 50%;\n  text-align: center;\n  justify-content: center;\n}\nion-content .paymentlist ion-buttons[edit-btn] {\n  background: var(--ion-color-primary);\n}\nion-content .paymentlist ion-buttons[delete-btn] {\n  background: var(--ion-color-primary);\n}\nion-content [settinglist] {\n  margin-bottom: 20px;\n  padding: 10px 15px;\n  background: var(--ion-color-white);\n  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.15);\n  border-radius: 10px;\n}\nion-content [settinglist][settinglinks] ion-item {\n  font-size: 14px;\n  border-bottom: 1px solid #f7f7f7;\n}\nion-content [settinglist] ion-toggle {\n  padding-right: 0;\n}\nion-content [settinglist] ion-button {\n  --background:var( --ion-color-primary);\n  margin-top: 20px;\n  --box-shadow: none;\n  min-height: 48px;\n  margin-bottom: 15px;\n  text-transform: uppercase;\n  letter-spacing: 1px;\n}\nion-content [settinglist] ion-item {\n  --inner-padding-end: 0;\n  --padding-start: 0;\n}\nion-content [settinglist] ion-item [iconleft] {\n  color: var(--ion-color-primary);\n  margin-right: 15px;\n}\nion-content [settinglist] h2[heading] {\n  font-size: 20px;\n  margin-top: 0px;\n  position: relative;\n  z-index: 1;\n  font-weight: 600;\n}\nion-content [settinglist] h2[heading]:after {\n  /*opacity: .5;*/\n  content: \"\";\n  background: var(--ion-color-softgreen);\n  height: 9px;\n  width: 70px;\n  position: absolute;\n  bottom: 0px;\n  left: 0px;\n  z-index: -1;\n}\nion-content [settinglist] [subhead] {\n  margin: 4px 0px 10px 0px;\n  font-size: 15px;\n  position: relative;\n  z-index: 1;\n  padding-left: 7px;\n}\nion-content [settinglist] [subhead]:after {\n  content: \"\";\n  position: absolute;\n  left: 0;\n  width: 30px;\n  height: 30px;\n  background: var(--ion-color-softgreen);\n  border-radius: 50%;\n  z-index: -1;\n  /*opacity: 0.5;*/\n  top: -6px;\n}\nion-content [settinglist] ion-radio-group {\n  display: inline-block;\n  width: 100%;\n  margin-bottom: 11px;\n}\nion-content [settinglist] ion-radio-group ion-item {\n  --min-height: 20px;\n  font-size: 14px;\n}\nion-content .ocid-s {\n  position: relative;\n  margin: -10px -15px 0;\n  padding: 15px 15px;\n  background: #fff6e6;\n  border-bottom: 1px solid #f9e4ba;\n  border-radius: 10px 10px 0 0;\n  padding-left: 80px;\n}\nion-content .ocid-s span.ich-d {\n  position: absolute;\n  left: 15px;\n  width: 50px;\n  height: 50px;\n  background: #f8aa12;\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  font-size: 26px;\n  color: #fff;\n}\nion-content .ocid-s h2 {\n  font-size: 17px;\n  margin-bottom: 2px;\n  margin-top: 8px;\n}\nion-content .ocid-s p {\n  margin: 0px;\n  font-size: 12px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2V0dGluZ3Mvc2V0dGluZ3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdHO0VBQ0MsdURBQUE7RUFDRCxpQkFBQTtBQUZIO0FBR0U7RUFFQSxlQUFBO0FBRkY7QUFJSTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7RUFDUSxrQkFBQTtFQUNBLDZDQUFBO0FBRlo7QUFLQztFQUVBLGFBQUE7QUFKRDtBQU9BO0VBRUEscUJBQUE7QUFMQTtBQU1BO0VBQ0ksYUFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSw4QkFBQTtBQUpKO0FBS0M7RUFFQSxhQUFBO0FBSkQ7QUFNQztFQUNJLFdBQUE7RUFDRCxZQUFBO0VBQ0gsZ0JBQUE7RUFDRyxpQkFBQTtFQUNKLDZCQUFBO0VBQ0ksa0JBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0FBSko7QUFLQztFQUVHLG9DQUFBO0FBSko7QUFRQTtFQUVFLG9DQUFBO0FBUEY7QUFZQztFQUVHLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQ0FBQTtFQUNBLDRDQUFBO0VBQ0EsbUJBQUE7QUFYSjtBQWFFO0VBQ0EsZUFBQTtFQUNELGdDQUFBO0FBWEQ7QUFhRTtFQUVHLGdCQUFBO0FBWkw7QUFjQztFQUdFLHNDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNTLGdCQUFBO0VBQ1QsbUJBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0FBZEg7QUFpQkM7RUFDQyxzQkFBQTtFQUNHLGtCQUFBO0FBZkw7QUFnQkU7RUFFQSwrQkFBQTtFQUNBLGtCQUFBO0FBZkY7QUFvQkU7RUFDQyxlQUFBO0VBQ0QsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLGdCQUFBO0FBbEJGO0FBbUJFO0VBQ0ksZUFBQTtFQUNILFdBQUE7RUFDQSxzQ0FBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7QUFqQkg7QUFxQkU7RUFDQyx3QkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxpQkFBQTtBQW5CSDtBQW9CRztFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHNDQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxTQUFBO0FBbEJIO0FBcUJFO0VBRUEscUJBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7QUFwQkY7QUFxQkc7RUFDQyxrQkFBQTtFQUNELGVBQUE7QUFuQkg7QUF1QkM7RUFDQyxrQkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGdDQUFBO0VBQ0EsNEJBQUE7RUFDQSxrQkFBQTtBQXJCRjtBQXNCRTtFQUNDLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtFQUNBLFdBQUE7QUFwQkg7QUFzQkU7RUFDQyxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBcEJIO0FBc0JFO0VBQ0MsV0FBQTtFQUNBLGVBQUE7QUFwQkgiLCJmaWxlIjoic3JjL2FwcC9zZXR0aW5ncy9zZXR0aW5ncy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyXHJcbntcclxuXHJcblx0ICBpb24tdG9vbGJhclxyXG5cdCAgey0taW9uLWNvbG9yLWJhc2U6IHZhcigtLWlvbi1jb2xvci1iZ2dyYWRpZW50KSFpbXBvcnRhbnQ7XHJcblx0ICAtLWJvcmRlci13aWR0aDogMDtcclxuXHQgaW9uLWJ1dHRvbnNcclxuXHQge1xyXG5cdCBmb250LXNpemU6IDIycHg7XHJcblx0IH1cclxuXHRcdCAgaW9uLXRpdGxle1xyXG5cdFx0ICBjb2xvcjp2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdFx0ICB0ZXh0LWFsaWduOmNlbnRlcjtcclxuICAgICAgICAgICAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gICAgICAgICAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgfVxyXG5cdH1cclxuXHQmOjphZnRlclxyXG5cdHtcclxuXHRkaXNwbGF5Om5vbmU7XHJcblx0fVxyXG59XHJcbmlvbi1jb250ZW50XHJcbntcclxuLS1iYWNrZ3JvdW5kOiAjZjdmN2Y3O1xyXG4ucGF5bWVudGxpc3Qge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG5cdCYgID4gZGl2XHJcblx0e1xyXG5cdGRpc3BsYXk6IGZsZXg7XHJcblx0fVxyXG5cdGlvbi1idXR0b25ze1x0XHJcblx0ICAgIHdpZHRoOiAzMHB4O1xyXG4gICAgaGVpZ2h0OiAzMHB4O1xyXG5cdG1hcmdpbi1sZWZ0OjNweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAzMHB4O1xyXG5jb2xvcjp2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblx0JltlZGl0LWJ0bl0ge1xyXG5cclxuICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuICAgIFxyXG5cdFxyXG59XHJcbiZbZGVsZXRlLWJ0bl0ge1xyXG4gICAgXHJcbiAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgXHJcbn1cclxufVxyXG59XHJcbiBbc2V0dGluZ2xpc3RdXHJcbiB7ICAgIFxyXG4gICAgbWFyZ2luLWJvdHRvbTogMjBweDtcclxuICAgIHBhZGRpbmc6IDEwcHggMTVweDtcclxuICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcbiAgICBib3gtc2hhZG93OiAwcHggMHB4IDEwcHggcmdiYSgwLCAwLCAwLCAwLjE1KTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcblx0JltzZXR0aW5nbGlua3NdXHJcblx0e2lvbi1pdGVtXHJcblx0e2ZvbnQtc2l6ZTogMTRweDtcclxuXHRib3JkZXItYm90dG9tOjFweCBzb2xpZCAjZjdmN2Y3O1xyXG5cdH1cclxuXHR9aW9uLXRvZ2dsZVxyXG5cdHtcclxuXHQgICAgcGFkZGluZy1yaWdodDogMDtcclxuXHR9XHJcblx0aW9uLWJ1dHRvblxyXG5cdHtcclxuXHRcclxuXHRcdFx0LS1iYWNrZ3JvdW5kOnZhciggLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcblx0XHRcdG1hcmdpbi10b3A6IDIwcHg7XHJcblx0XHRcdC0tYm94LXNoYWRvdzogbm9uZTtcclxuICAgICAgICAgICAgbWluLWhlaWdodDogNDhweDtcclxuXHRcdFx0bWFyZ2luLWJvdHRvbTogMTVweDtcclxuXHRcdFx0dGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuXHRcdFx0bGV0dGVyLXNwYWNpbmc6IDFweDtcclxuXHRcdFxyXG5cdH1cclxuXHRpb24taXRlbVxyXG5cdHstLWlubmVyLXBhZGRpbmctZW5kOiAwO1xyXG5cdCAgICAtLXBhZGRpbmctc3RhcnQ6IDA7XHJcblx0XHRbaWNvbmxlZnRdXHJcblx0XHR7XHJcblx0XHRjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG5cdFx0bWFyZ2luLXJpZ2h0OiAxNXB4O1xyXG5cdFx0fVxyXG5cdH1cclxuXHQgICBoMlxyXG5cdFx0e1xyXG5cdFx0JltoZWFkaW5nXVxyXG5cdFx0e2ZvbnQtc2l6ZTogMjBweDtcclxuXHRcdG1hcmdpbi10b3A6IDBweDtcclxuXHRcdHBvc2l0aW9uOnJlbGF0aXZlO1xyXG5cdFx0ei1pbmRleDogMTtcclxuXHRcdGZvbnQtd2VpZ2h0OjYwMDtcclxuXHRcdCY6YWZ0ZXIge1xyXG5cdFx0ICAgIC8qb3BhY2l0eTogLjU7Ki9cclxuXHRcdFx0Y29udGVudDogJyc7XHJcblx0XHRcdGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1zb2Z0Z3JlZW4pO1xyXG5cdFx0XHRoZWlnaHQ6IDlweDtcclxuXHRcdFx0d2lkdGg6IDcwcHg7XHJcblx0XHRcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRcdFx0Ym90dG9tOiAwcHg7XHJcblx0XHRcdGxlZnQ6IDBweDtcclxuXHRcdFx0ei1pbmRleDogLTE7XHJcblx0XHR9XHJcblx0XHR9XHJcblx0XHR9XHJcblx0XHRbc3ViaGVhZF0ge1xyXG5cdFx0XHRtYXJnaW46IDRweCAwcHggMTBweCAgMHB4O1xyXG5cdFx0XHRmb250LXNpemU6IDE1cHg7XHJcblx0XHRcdHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHRcdFx0ei1pbmRleDogMTtcclxuXHRcdFx0cGFkZGluZy1sZWZ0OiA3cHg7XHJcblx0XHRcdCY6YWZ0ZXIge1xyXG5cdFx0XHRjb250ZW50OiAnJztcclxuXHRcdFx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdFx0XHRsZWZ0OiAwO1xyXG5cdFx0XHR3aWR0aDogMzBweDtcclxuXHRcdFx0aGVpZ2h0OiAzMHB4O1xyXG5cdFx0XHRiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itc29mdGdyZWVuKTtcclxuXHRcdFx0Ym9yZGVyLXJhZGl1czogNTAlO1xyXG5cdFx0XHR6LWluZGV4OiAtMTtcclxuXHRcdFx0LypvcGFjaXR5OiAwLjU7Ki9cclxuXHRcdFx0dG9wOiAtNnB4O1xyXG5cdFx0fVxyXG5cdFx0fVxyXG5cdFx0aW9uLXJhZGlvLWdyb3VwXHJcblx0XHR7IFxyXG5cdFx0ZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG5cdFx0d2lkdGg6IDEwMCU7XHJcblx0XHRtYXJnaW4tYm90dG9tOiAxMXB4O1xyXG5cdFx0IGlvbi1pdGVtXHJcblx0XHQgey0tbWluLWhlaWdodDogMjBweDtcclxuXHRcdCBmb250LXNpemU6IDE0cHg7XHJcblx0XHQgfVxyXG5cdFx0fVxyXG5cdH1cclxuXHQub2NpZC1zIHtcclxuXHRcdHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHRcdG1hcmdpbjogLTEwcHggLTE1cHggMDtcclxuXHRcdHBhZGRpbmc6IDE1cHggMTVweDtcclxuXHRcdGJhY2tncm91bmQ6ICNmZmY2ZTY7XHJcblx0XHRib3JkZXItYm90dG9tOiAxcHggc29saWQgI2Y5ZTRiYTtcclxuXHRcdGJvcmRlci1yYWRpdXM6IDEwcHggMTBweCAwIDA7XHJcblx0XHRwYWRkaW5nLWxlZnQ6IDgwcHg7XHJcblx0XHRzcGFuLmljaC1kIHtcclxuXHRcdFx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdFx0XHRsZWZ0OiAxNXB4O1xyXG5cdFx0XHR3aWR0aDogNTBweDtcclxuXHRcdFx0aGVpZ2h0OiA1MHB4O1xyXG5cdFx0XHRiYWNrZ3JvdW5kOiAjZjhhYTEyO1xyXG5cdFx0XHRib3JkZXItcmFkaXVzOiA1MCU7XHJcblx0XHRcdGRpc3BsYXk6IGZsZXg7XHJcblx0XHRcdGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblx0XHRcdGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cdFx0XHRmb250LXNpemU6IDI2cHg7XHJcblx0XHRcdGNvbG9yOiAjZmZmO1xyXG5cdFx0fVxyXG5cdFx0aDIge1xyXG5cdFx0XHRmb250LXNpemU6IDE3cHg7XHJcblx0XHRcdG1hcmdpbi1ib3R0b206IDJweDtcclxuXHRcdFx0bWFyZ2luLXRvcDogOHB4O1xyXG5cdFx0fVxyXG5cdFx0cCB7XHJcblx0XHRcdG1hcmdpbjogMHB4O1xyXG5cdFx0XHRmb250LXNpemU6IDEycHg7XHJcblx0XHR9XHJcblx0fVxyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ "./src/app/settings/settings.page.ts":
/*!*******************************************!*\
  !*** ./src/app/settings/settings.page.ts ***!
  \*******************************************/
/*! exports provided: SettingsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsPage", function() { return SettingsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/api/api.service */ "./src/app/services/api/api.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _common_common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../common/common.service */ "./src/app/common/common.service.ts");
/* harmony import */ var _services_globalFooService_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/globalFooService.service */ "./src/app/services/globalFooService.service.ts");
/* harmony import */ var _deleteconfirm_deleteconfirm_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../deleteconfirm/deleteconfirm.page */ "./src/app/deleteconfirm/deleteconfirm.page.ts");








let SettingsPage = class SettingsPage {
    constructor(modalController, globalFooService, api, router, common) {
        this.modalController = modalController;
        this.globalFooService = globalFooService;
        this.api = api;
        this.router = router;
        this.common = common;
        this.paymentlist = [];
        this.errors = ['', null, undefined];
        this.SetRemainder = false;
        this.globalFooService.getObservable().subscribe((data) => {
            if (this.errors.indexOf(data.set) == -1) {
                //this.listpayment();
                this.listpayment();
                this.getsettings();
            }
        });
    }
    delete(id) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _deleteconfirm_deleteconfirm_page__WEBPACK_IMPORTED_MODULE_7__["DeleteconfirmPage"],
                cssClass: 'deleteconfirm',
                componentProps: {
                    paymentid: id
                }
            });
            modal.onDidDismiss().then((detail) => {
                if (this.errors.indexOf(detail.data) == -1) {
                    this.listpayment();
                }
            });
            return yield modal.present();
        });
    }
    ngOnInit() {
    }
    PushNotificationfun(event) {
        this.PushNotification = event;
        this.save();
    }
    notifyAndUpdateIsToggled(event) {
        this.SetRemainder = event;
        this.save();
    }
    myprofile(type) {
        this.my_profile = type;
        this.save();
    }
    whatdonate(type) {
        this.what_donate = type;
        this.save();
    }
    whattime(type) {
        this.what_time = type;
        this.save();
    }
    noofmeals(type) {
        this.no_meals = type;
        this.save();
    }
    howoften(type) {
        this.how_often = type;
        this.save();
    }
    logout() {
        localStorage.clear();
        this.router.navigate(["/"]);
    }
    save() {
        if (this.errors.indexOf(this.userid) >= 0) {
            this.common.presentToast('Please login first!.', 'danger');
            return false;
        }
        let dict = {
            userid: this.userid,
            set_remainder: this.SetRemainder,
            how_often: this.how_often,
            what_time: this.what_time,
            push_notification: this.PushNotification,
            when_i_donate: this.what_donate,
            no_of_meals: this.no_meals,
            my_profile: this.my_profile,
        };
        this.api.post('saveSettings', dict, '').subscribe((result) => {
            var res;
            res = result;
            if (res.status == 1) {
                //this.common.presentToast(res.message,'success');
            }
            else {
                this.common.presentToast(res.message, 'danger');
            }
        }, err => {
        });
    }
    ionViewDidEnter() {
        this.userid = localStorage.getItem('userid');
        this.listpayment();
        this.getsettings();
    }
    getsettings() {
        if (this.errors.indexOf(this.userid) >= 0) {
            this.common.presentToast('Please login first!.', 'danger');
            return false;
        }
        let dict = {
            userid: this.userid,
        };
        this.api.post('Getsettings', dict, '').subscribe((result) => {
            var res;
            res = result;
            if (res.status == 1) {
                this.settings = res.data;
                if (this.errors.indexOf(this.settings) == -1) {
                    this.SetRemainder = this.settings.set_remainder;
                    this.PushNotification = this.settings.push_notification;
                    this.how_often = this.settings.how_often;
                    this.what_time = this.settings.what_time;
                    this.what_donate = this.settings.when_i_donate;
                    this.no_meals = this.settings.no_of_meals;
                    this.my_profile = this.settings.my_profile;
                }
            }
            else {
                this.common.presentToast(res.message, 'danger');
            }
        }, err => {
        });
    }
    listpayment() {
        if (this.errors.indexOf(this.userid) >= 0) {
            this.common.presentToast('Please login first!.', 'danger');
            return false;
        }
        let dict = {
            userid: this.userid,
        };
        this.common.presentLoading();
        this.api.post('ListPayment', dict, '').subscribe((result) => {
            this.common.stopLoading();
            var res;
            res = result;
            if (res.status == 1) {
                this.paymentlist = res.data;
            }
            else {
                this.common.presentToast(res.message, 'danger');
            }
        }, err => {
        });
    }
};
SettingsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _services_globalFooService_service__WEBPACK_IMPORTED_MODULE_6__["GlobalFooService"] },
    { type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _common_common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"] }
];
SettingsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-settings',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./settings.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/settings/settings.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./settings.page.scss */ "./src/app/settings/settings.page.scss")).default]
    })
], SettingsPage);



/***/ })

}]);
//# sourceMappingURL=settings-settings-module-es2015.js.map