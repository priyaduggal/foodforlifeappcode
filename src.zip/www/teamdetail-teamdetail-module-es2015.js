(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["teamdetail-teamdetail-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/teamdetail/teamdetail.page.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/teamdetail/teamdetail.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (" <ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n\t<ion-back-button defaultHref=\"/searchteam\" slot=\"start\">\r\n\t</ion-back-button>\r\n\t<ion-title class=\"ion-text-center\">Team Detail</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n<div profileinfo>\r\n<div profileimg>\r\n  <img src=\"assets/images/krishnadasHaiti.jpg\"/>\r\n  <div userinner>\r\n\r\n<img src=\"assets/images/createteam.png\"  *ngIf=\"errors.indexOf(team?.image)>=0\">\r\n<img src=\"{{IMAGES_URL}}/{{team?.image}}\"  *ngIf=\"errors.indexOf(team?.image)==-1\">\r\n</div>\r\n</div>\r\n<div userimg>\r\n\r\n<h2>{{team?.name}}</h2>\r\n<ion-row>\r\n<ion-col size=\"6\">\r\n<div teammeal>\r\n<span>\r\n<ion-icon name=\"heart\"></ion-icon>\r\n</span>\r\n<div mealright>\r\n<h4>{{team?.meals}}</h4>\r\n<p>meals</p>\r\n</div>\r\n</div>\r\n</ion-col>\r\n<ion-col size=\"6\">\r\n<div teammeal>\r\n<span>\r\n<ion-icon name=\"people\"></ion-icon>\r\n</span>\r\n<div mealright>\r\n<h4>{{team?.joins}}</h4>\r\n<p>members</p>\r\n</div>\r\n</div>\r\n</ion-col>\r\n</ion-row>\r\n</div>\r\n</div>\r\n<div teaminner>\r\n<h2 heading>\r\nDetail\r\n</h2>\r\n<p>{{team?.description}} </p>\r\n <ion-button shape=\"round\" expand=\"full\" *ngIf=\"userid!=team?.userid && joined?.indexOf(team?.id)>=0\"(click)=\"give(team?.id)\" >Give for this team</ion-button>\r\n  <ion-button shape=\"round\" expand=\"full\" *ngIf=\"userid!=team?.userid && joined?.indexOf(team?.id)==-1\" (click)=\"join_team()\">Join team</ion-button>\r\n   <ion-button shape=\"round\" expand=\"full\" *ngIf=\"userid!=team?.userid && joined?.indexOf(team?.id)>=0\" (click)=\"leave_team()\">Leave Team</ion-button>\r\n</div>\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/teamdetail/teamdetail-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/teamdetail/teamdetail-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: TeamdetailPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TeamdetailPageRoutingModule", function() { return TeamdetailPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _teamdetail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./teamdetail.page */ "./src/app/teamdetail/teamdetail.page.ts");




const routes = [
    {
        path: '',
        component: _teamdetail_page__WEBPACK_IMPORTED_MODULE_3__["TeamdetailPage"]
    }
];
let TeamdetailPageRoutingModule = class TeamdetailPageRoutingModule {
};
TeamdetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], TeamdetailPageRoutingModule);



/***/ }),

/***/ "./src/app/teamdetail/teamdetail.module.ts":
/*!*************************************************!*\
  !*** ./src/app/teamdetail/teamdetail.module.ts ***!
  \*************************************************/
/*! exports provided: TeamdetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TeamdetailPageModule", function() { return TeamdetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _teamdetail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./teamdetail-routing.module */ "./src/app/teamdetail/teamdetail-routing.module.ts");
/* harmony import */ var _teamdetail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./teamdetail.page */ "./src/app/teamdetail/teamdetail.page.ts");







let TeamdetailPageModule = class TeamdetailPageModule {
};
TeamdetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _teamdetail_routing_module__WEBPACK_IMPORTED_MODULE_5__["TeamdetailPageRoutingModule"]
        ],
        declarations: [_teamdetail_page__WEBPACK_IMPORTED_MODULE_6__["TeamdetailPage"]]
    })
], TeamdetailPageModule);



/***/ }),

/***/ "./src/app/teamdetail/teamdetail.page.scss":
/*!*************************************************!*\
  !*** ./src/app/teamdetail/teamdetail.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-toolbar {\n  --ion-color-base: var(--ion-color-bggradient)!important;\n  --border-width: 0;\n}\nion-header ion-toolbar ion-buttons {\n  font-size: 22px;\n}\nion-header ion-toolbar ion-title {\n  color: var(--ion-color-white);\n  text-align: center;\n  font-style: normal;\n  font-family: \"Poppins\", sans-serif !important;\n}\nion-header::after {\n  display: none;\n}\nion-content [profileinfo] [userimg] {\n  padding: 60px 15px 0;\n  margin-top: -20px;\n  background: var(--ion-color-white);\n  position: relative;\n  border-radius: 15px 15px 0 0;\n}\nion-content [profileinfo] [userimg] [btnaccount] {\n  display: block;\n  text-align: center;\n  font-size: 13px;\n}\nion-content [profileinfo] [userimg] h2 {\n  margin-top: 5px;\n  margin-bottom: 5px;\n  font-size: 14px;\n  font-weight: 500;\n  text-align: center;\n}\nion-content [profileinfo] [userimg] ion-row {\n  max-width: 276px;\n  margin: 0 auto;\n}\nion-content [profileinfo] [userimg] ion-row [teammeal] {\n  margin-top: 10px;\n  display: flex;\n  align-items: center;\n}\nion-content [profileinfo] [userimg] ion-row [teammeal] span {\n  width: 35px;\n  height: 35px;\n  background: rgba(251, 173, 21, 0.18);\n  border-radius: 50%;\n  text-align: center;\n  line-height: 41px;\n  color: var(--ion-color-primary);\n  margin-right: 10px;\n}\nion-content [profileinfo] [userimg] ion-row [teammeal] [mealright] h4 {\n  text-align: left;\n  margin: 0;\n  font-size: 14px;\n}\nion-content [profileinfo] [userimg] ion-row [teammeal] [mealright] p {\n  color: #9d9d9d;\n  font-size: 13px;\n  margin: 0;\n}\nion-content [profileinfo] [profileimg] {\n  position: relative;\n  height: 160px;\n}\nion-content [profileinfo] [profileimg] img {\n  max-width: 100%;\n  max-height: 100%;\n  width: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n  -o-object-position: bottom;\n     object-position: bottom;\n}\nion-content [profileinfo] [profileimg] [userinner] {\n  position: relative;\n  text-align: center;\n  margin-top: -62px;\n  z-index: 1;\n}\nion-content [profileinfo] [profileimg] [userinner] img {\n  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.25);\n  width: 80px;\n  height: 80px;\n  border-radius: 50%;\n  border: 2px solid var(--ion-color-white);\n  margin: 0 auto;\n  text-align: center;\n}\nion-content [teaminner] {\n  padding: 15px;\n}\nion-content [teaminner] ion-button {\n  --box-shadow: none;\n  min-height: 42px;\n}\nion-content [teaminner] h2[heading] {\n  font-size: 20px;\n  margin-top: 0px;\n  position: relative;\n  z-index: 1;\n  font-weight: 600;\n}\nion-content [teaminner] h2[heading]:after {\n  /*opacity: .5;*/\n  content: \"\";\n  background: var(--ion-color-softgreen);\n  height: 9px;\n  width: 50px;\n  position: absolute;\n  bottom: 0px;\n  left: 0px;\n  z-index: -1;\n}\nion-content [teaminner] p {\n  color: #9d9d9d;\n  font-size: 14px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGVhbWRldGFpbC90ZWFtZGV0YWlsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHRztFQUNDLHVEQUFBO0VBQ0QsaUJBQUE7QUFGSDtBQUdDO0VBRUMsZUFBQTtBQUZGO0FBSUk7RUFDQSw2QkFBQTtFQUNBLGtCQUFBO0VBQ1Esa0JBQUE7RUFDQSw2Q0FBQTtBQUZaO0FBS0M7RUFFQSxhQUFBO0FBSkQ7QUFXQztFQUNNLG9CQUFBO0VBQ0gsaUJBQUE7RUFDQSxrQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsNEJBQUE7QUFSSjtBQVNDO0VBQ0csY0FBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQVBKO0FBU0M7RUFDSyxlQUFBO0VBQ0Ysa0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBQVBKO0FBU0E7RUFFQSxnQkFBQTtFQUNJLGNBQUE7QUFSSjtBQVNBO0VBQVksZ0JBQUE7RUFDUixhQUFBO0VBQ0EsbUJBQUE7QUFOSjtBQU9DO0VBRUEsV0FBQTtFQUNHLFlBQUE7RUFDQSxvQ0FBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLCtCQUFBO0VBQ0Esa0JBQUE7QUFOSjtBQVVDO0VBQ0csZ0JBQUE7RUFDQSxTQUFBO0VBQ0EsZUFBQTtBQVJKO0FBU0M7RUFFRCxjQUFBO0VBQ0EsZUFBQTtFQUNDLFNBQUE7QUFSRDtBQWNDO0VBQ0ssa0JBQUE7RUFFSCxhQUFBO0FBYkg7QUFjRztFQUVFLGVBQUE7RUFDRCxnQkFBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtLQUFBLGlCQUFBO0VBQ0EsMEJBQUE7S0FBQSx1QkFBQTtBQWJKO0FBZUc7RUFFQyxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxVQUFBO0FBZEo7QUFpQkU7RUFDRyw0Q0FBQTtFQUNELFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSx3Q0FBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQWZKO0FBb0JFO0VBQ0MsYUFBQTtBQWxCSDtBQW1CRTtFQUVHLGtCQUFBO0VBQ0QsZ0JBQUE7QUFsQko7QUFzQkE7RUFDQyxlQUFBO0VBQ0QsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLGdCQUFBO0FBcEJBO0FBcUJBO0VBQ0ksZUFBQTtFQUNBLFdBQUE7RUFDQSxzQ0FBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7QUFuQko7QUFzQkM7RUFFRCxjQUFBO0VBQ0EsZUFBQTtBQXJCQSIsImZpbGUiOiJzcmMvYXBwL3RlYW1kZXRhaWwvdGVhbWRldGFpbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyXHJcblx0e1xyXG5cdFxyXG5cdCAgaW9uLXRvb2xiYXJcclxuXHQgIHstLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1pb24tY29sb3ItYmdncmFkaWVudCkhaW1wb3J0YW50O1xyXG5cdCAgLS1ib3JkZXItd2lkdGg6IDA7XHJcblx0aW9uLWJ1dHRvbnNcclxuXHQge1xyXG5cdCBmb250LXNpemU6IDIycHg7XHJcblx0IH1cclxuXHRcdCAgaW9uLXRpdGxle1xyXG5cdFx0ICBjb2xvcjp2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdFx0ICB0ZXh0LWFsaWduOmNlbnRlcjtcclxuICAgICAgICAgICAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gICAgICAgICAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgfVxyXG5cdH1cclxuXHQmOjphZnRlclxyXG5cdHtcclxuXHRkaXNwbGF5Om5vbmU7XHJcblx0fVxyXG5cdH1cclxuXHRpb24tY29udGVudFxyXG5cdHtcclxuXHRbcHJvZmlsZWluZm9dXHJcbiB7XHJcbiBbdXNlcmltZ11cclxuIHsgICAgIHBhZGRpbmc6IDYwcHggMTVweCAwO1xyXG4gICAgbWFyZ2luLXRvcDogLTIwcHg7XHJcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTVweCAxNXB4IDAgMDtcclxuIFtidG5hY2NvdW50XSB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMTNweDtcclxufVxyXG5cdGgyIHtcclxuICAgICAgbWFyZ2luLXRvcDogNXB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogNXB4O1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5pb24tcm93XHJcbntcclxubWF4LXdpZHRoOiAyNzZweDtcclxuICAgIG1hcmdpbjogMCBhdXRvO1xyXG5bdGVhbW1lYWxdIHttYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblx0c3BhblxyXG5cdHtcclxuXHR3aWR0aDogMzVweDtcclxuICAgIGhlaWdodDogMzVweDtcclxuICAgIGJhY2tncm91bmQ6IHJnYmEoMjUxLCAxNzMsIDIxICwgLjE4KTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGxpbmUtaGVpZ2h0OiA0MXB4O1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuICAgIG1hcmdpbi1yaWdodDogMTBweDtcclxuXHR9XHJcblx0W21lYWxyaWdodF1cclxue1xyXG5cdGg0IHtcclxuICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICBtYXJnaW46IDA7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbn1wXHJcbntcclxuY29sb3I6ICM5ZDlkOWQ7XHJcbmZvbnQtc2l6ZTogMTNweDtcclxuIG1hcmdpbjogMDtcclxufVxyXG59XHJcbn1cdCBcclxufVx0IFxyXG4gfVxyXG4gW3Byb2ZpbGVpbWddXHJcbiB7ICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHJcbiAgIGhlaWdodDoxNjBweDtcclxuICAgaW1nXHJcbiAgIHtcclxuICAgICBtYXgtd2lkdGg6IDEwMCU7XHJcbiAgICBtYXgtaGVpZ2h0OiAxMDAlO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBvYmplY3QtZml0OiBjb3ZlcjtcclxuICAgIG9iamVjdC1wb3NpdGlvbjpib3R0b207XHJcbiAgIH1cclxuICAgW3VzZXJpbm5lcl1cclxuIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIG1hcmdpbi10b3A6IC02MnB4O1xyXG4gICAgei1pbmRleDogMTtcclxuICBcclxuXHJcbiAgaW1nXHJcblx0ICAge2JveC1zaGFkb3c6IDBweCAwcHggMTBweCByZ2JhKDAsIDAsIDAsIDAuMjUpO1xyXG5cdCAgIHdpZHRoOiA4MHB4O1xyXG4gICAgaGVpZ2h0OiA4MHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgYm9yZGVyOiAycHggc29saWQgdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgIG1hcmdpbjogMCBhdXRvO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG5cdCAgIH1cclxufVxyXG4gfVxyXG4gfVxyXG4gIFt0ZWFtaW5uZXJdXHJcbiAge3BhZGRpbmc6MTVweDtcclxuICBpb24tYnV0dG9uXHJcblx0e1xyXG5cdCAgICAtLWJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICBtaW4taGVpZ2h0OiA0MnB4O1xyXG5cdH1cclxuICAgaDJcclxue1xyXG4mW2hlYWRpbmddXHJcbntmb250LXNpemU6IDIwcHg7XHJcbm1hcmdpbi10b3A6IDBweDtcclxucG9zaXRpb246cmVsYXRpdmU7XHJcbnotaW5kZXg6IDE7XHJcbmZvbnQtd2VpZ2h0OjYwMDtcclxuJjphZnRlciB7XHJcbiAgICAvKm9wYWNpdHk6IC41OyovXHJcbiAgICBjb250ZW50OiAnJztcclxuICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1zb2Z0Z3JlZW4pO1xyXG4gICAgaGVpZ2h0OiA5cHg7XHJcbiAgICB3aWR0aDogNTBweDtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGJvdHRvbTogMHB4O1xyXG4gICAgbGVmdDogMHB4O1xyXG4gICAgei1pbmRleDogLTE7XHJcbn1cclxufVxyXG59cFxyXG57XHJcbmNvbG9yOiAjOWQ5ZDlkO1xyXG5mb250LXNpemU6IDE0cHg7XHJcbn1cclxuICB9XHJcblx0fSJdfQ== */");

/***/ }),

/***/ "./src/app/teamdetail/teamdetail.page.ts":
/*!***********************************************!*\
  !*** ./src/app/teamdetail/teamdetail.page.ts ***!
  \***********************************************/
/*! exports provided: TeamdetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TeamdetailPage", function() { return TeamdetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/api/api.service */ "./src/app/services/api/api.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../config */ "./src/app/config.ts");
/* harmony import */ var _common_common_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../common/common.service */ "./src/app/common/common.service.ts");
/* harmony import */ var _jointeamconfirm_jointeamconfirm_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../jointeamconfirm/jointeamconfirm.page */ "./src/app/jointeamconfirm/jointeamconfirm.page.ts");
/* harmony import */ var _leaveteamconfirm_leaveteamconfirm_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../leaveteamconfirm/leaveteamconfirm.page */ "./src/app/leaveteamconfirm/leaveteamconfirm.page.ts");
/* harmony import */ var _addamount_addamount_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../addamount/addamount.page */ "./src/app/addamount/addamount.page.ts");
/* harmony import */ var _services_globalFooService_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../services/globalFooService.service */ "./src/app/services/globalFooService.service.ts");











let TeamdetailPage = class TeamdetailPage {
    constructor(globalFooService, modalController, activatedRoute, api, router, common) {
        this.globalFooService = globalFooService;
        this.modalController = modalController;
        this.activatedRoute = activatedRoute;
        this.api = api;
        this.router = router;
        this.common = common;
        this.IMAGES_URL = _config__WEBPACK_IMPORTED_MODULE_5__["config"].IMAGES_URL;
        this.errors = ['', null, undefined];
        this.joined = [];
        this.teamid = activatedRoute.snapshot.paramMap.get('id');
        this.globalFooService.getObservable().subscribe((data) => {
            if (this.errors.indexOf(data.paydata1) == -1) {
                console.log('ssssss');
                this.userid = localStorage.getItem('userid');
                this.getteamdetails();
                this.getuserteams();
            }
        });
    }
    ngOnInit() {
    }
    give(id) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _addamount_addamount_page__WEBPACK_IMPORTED_MODULE_9__["AddamountPage"],
                cssClass: 'leaveteam',
                componentProps: {
                    teamid: id,
                }
            });
            modal.onDidDismiss().then((detail) => {
                if (this.errors.indexOf(detail.data) == -1) {
                }
            });
            return yield modal.present();
        });
    }
    ionViewDidEnter() {
        this.userid = localStorage.getItem('userid');
        this.getteamdetails();
        this.getuserteams();
    }
    leave_team() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _leaveteamconfirm_leaveteamconfirm_page__WEBPACK_IMPORTED_MODULE_8__["LeaveteamconfirmPage"],
                cssClass: 'leaveteam',
                componentProps: {
                    userid: this.userid,
                    teamid: this.team.id,
                }
            });
            modal.onDidDismiss().then((detail) => {
                if (this.errors.indexOf(detail.data) == -1) {
                    this.team.joins = this.team.joins - 1;
                    this.getuserteams();
                }
            });
            return yield modal.present();
        });
    }
    join_team() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _jointeamconfirm_jointeamconfirm_page__WEBPACK_IMPORTED_MODULE_7__["JointeamconfirmPage"],
                cssClass: 'jointeamconfirm',
                componentProps: {
                    userid: this.userid,
                    teamid: this.team.id,
                }
            });
            modal.onDidDismiss().then((detail) => {
                if (this.errors.indexOf(detail.data) == -1) {
                    this.team.joins = this.team.joins + 1;
                    this.getuserteams();
                }
            });
            return yield modal.present();
        });
    }
    getuserteams() {
        let dict = {
            userid: this.userid,
        };
        console.log(dict);
        this.api.post('UserJoinedTeams', dict, '').subscribe((result) => {
            var res;
            res = result;
            if (res.status == 1) {
                var array2 = [];
                if (res.data.length > 0) {
                    res.data.forEach(function (o) {
                        array2.push(o.teamid);
                    });
                }
                this.joined = array2;
            }
            else {
                this.joined = [];
            }
        }, err => {
        });
    }
    getteamdetails() {
        let dict = {
            id: this.teamid,
        };
        this.common.presentLoading();
        this.api.post('teamdetail', dict, '').subscribe((result) => {
            this.common.stopLoading();
            var res;
            res = result;
            if (res.status == 1) {
                this.team = res.data;
            }
            else {
            }
        }, err => {
        });
    }
};
TeamdetailPage.ctorParameters = () => [
    { type: _services_globalFooService_service__WEBPACK_IMPORTED_MODULE_10__["GlobalFooService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _common_common_service__WEBPACK_IMPORTED_MODULE_6__["CommonService"] }
];
TeamdetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-teamdetail',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./teamdetail.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/teamdetail/teamdetail.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./teamdetail.page.scss */ "./src/app/teamdetail/teamdetail.page.scss")).default]
    })
], TeamdetailPage);



/***/ })

}]);
//# sourceMappingURL=teamdetail-teamdetail-module-es2015.js.map