(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["thetable-thetable-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/thetable/thetable.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/thetable/thetable.page.html ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n\t        <ion-buttons slot=\"start\">\r\n          <ion-menu-button></ion-menu-button>\r\n        </ion-buttons>\r\n\t<ion-title class=\"ion-text-center\">FFL Monthly Sponsor</ion-title>\r\n  </ion-toolbar>\r\n  </ion-header>\r\n\r\n<ion-content>\r\n  <ion-slides slidetable  #slideWithNav [options]=\"slideOptsOne\"  (ionSlideWillChange)=\"onSlideChangeStart($event)\" (ionSlideDidChange)=\"onSlideChanged($event)\" pager=\"false\" class=\"home-slider\">\r\n    \r\n    <ion-slide   hm-slider>\r\n      <img src=\"assets/images/sliderimg1.jpg\" style=\"width:100%;\"/>\r\n      <div class=\"sld_cnt\">\r\n      <div class=\"sld_cntinner\">\r\n\t\t<div class=\"logo-top-al\">\r\n\t\t\t<img src=\"assets/images/images.png\">\r\n\t\t</div>\r\n        <p>Start giving in a whole new way. Be matched with a children every month, in one of the World's most vulnerable countries</p>\r\n        <ion-button routerLink=\"/thetabledetail\"  shape=\"round\" expand=\"full\">Give Monthly</ion-button>\r\n      </div>\r\n      </div>\r\n    </ion-slide>\r\n\t \r\n    <!--ion-slide  hm-slider>\r\n      <img src=\"assets/images/lady.jpg\" style=\"width:100%;\"/>\r\n      <div class=\"sld_cnt\">\r\n      <div class=\"sld_cntinner\">\r\n\t\t<div class=\"logo-top-al\">\r\n\t\t\t<img src=\"assets/images/logo.png\">\r\n\t\t</div>\r\n        <p>Start giving in a whole new way. Be matched with a children every month, in one of the World's most vulnerable countries</p>\r\n        <ion-button routerLink=\"/thetabledetail\" shape=\"round\" expand=\"full\">Give Monthly</ion-button>\r\n      </div>\r\n      </div>\r\n    </ion-slide-->\r\n</ion-slides>\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/thetable/thetable-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/thetable/thetable-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: ThetablePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ThetablePageRoutingModule", function() { return ThetablePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _thetable_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./thetable.page */ "./src/app/thetable/thetable.page.ts");




const routes = [
    {
        path: '',
        component: _thetable_page__WEBPACK_IMPORTED_MODULE_3__["ThetablePage"]
    }
];
let ThetablePageRoutingModule = class ThetablePageRoutingModule {
};
ThetablePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ThetablePageRoutingModule);



/***/ }),

/***/ "./src/app/thetable/thetable.module.ts":
/*!*********************************************!*\
  !*** ./src/app/thetable/thetable.module.ts ***!
  \*********************************************/
/*! exports provided: ThetablePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ThetablePageModule", function() { return ThetablePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _thetable_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./thetable-routing.module */ "./src/app/thetable/thetable-routing.module.ts");
/* harmony import */ var _thetable_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./thetable.page */ "./src/app/thetable/thetable.page.ts");







let ThetablePageModule = class ThetablePageModule {
};
ThetablePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _thetable_routing_module__WEBPACK_IMPORTED_MODULE_5__["ThetablePageRoutingModule"]
        ],
        declarations: [_thetable_page__WEBPACK_IMPORTED_MODULE_6__["ThetablePage"]]
    })
], ThetablePageModule);



/***/ }),

/***/ "./src/app/thetable/thetable.page.scss":
/*!*********************************************!*\
  !*** ./src/app/thetable/thetable.page.scss ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-toolbar {\n  --ion-color-base: var(--ion-color-bggradient)!important;\n  --border-width: 0;\n}\nion-header ion-toolbar ion-buttons {\n  font-size: 22px;\n}\nion-header ion-toolbar ion-title {\n  color: var(--ion-color-white);\n  text-align: center;\n  font-style: normal;\n  font-family: \"Poppins\", sans-serif !important;\n}\nion-header::after {\n  display: none;\n}\nion-content [hm-slider] {\n  display: flex;\n  flex-direction: column;\n}\nion-content [hm-slider] img {\n  height: 45vh;\n  width: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\nion-content [hm-slider] .sld_cnt {\n  border-radius: 15px;\n  margin-top: -20px;\n  position: relative;\n  z-index: 1;\n  background: var(--ion-color-white);\n}\nion-content [hm-slider] .sld_cnt .sld_cntinner {\n  padding: 15px;\n  /*img\n  {\n  width: 140px;\n     height: 140px;\n     object-fit: contain;\n     box-shadow: 0px 0px 10px rgb(0 0 0 / 28%);\n     border-radius: 50%;\n     margin-top: -80px;\n     background: #f8f1fd;\n  }*/\n}\nion-content [hm-slider] .sld_cnt .sld_cntinner .logo-top-al {\n  width: 110px;\n  height: 110px;\n  display: block;\n  margin: 0 auto;\n  text-align: center;\n  margin-top: -70px;\n  background: var(--ion-color-white);\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  box-shadow: 0px 2px 24px rgba(0, 0, 0, 0.1);\n  padding-top: 5px;\n  margin-bottom: 0px;\n}\nion-content [hm-slider] .sld_cnt .sld_cntinner .logo-top-al img {\n  width: 76px;\n  height: auto;\n}\nion-content [hm-slider] .sld_cnt .sld_cntinner p {\n  font-size: 13px;\n  color: #999;\n}\nion-content [hm-slider] .sld_cnt .sld_cntinner ion-button {\n  --box-shadow: none;\n  min-height: 42px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGhldGFibGUvdGhldGFibGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdHO0VBQ0MsdURBQUE7RUFDRCxpQkFBQTtBQUZIO0FBR0M7RUFFQyxlQUFBO0FBRkY7QUFJSTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7RUFDUSxrQkFBQTtFQUNBLDZDQUFBO0FBRlo7QUFLQztFQUVBLGFBQUE7QUFKRDtBQVVDO0VBRUcsYUFBQTtFQUNBLHNCQUFBO0FBUko7QUFTQztFQUVBLFlBQUE7RUFDRyxXQUFBO0VBQ0Esb0JBQUE7S0FBQSxpQkFBQTtBQVJKO0FBVUM7RUFDRyxtQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0Esa0NBQUE7QUFSSjtBQVNDO0VBQ0csYUFBQTtFQXFCSDs7Ozs7Ozs7O0lBQUE7QUFsQkQ7QUFGRTtFQUNDLFlBQUE7RUFDQSxhQUFBO0VBQ0EsY0FBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0NBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsMkNBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0FBSUg7QUFIRztFQUNDLFdBQUE7RUFDQSxZQUFBO0FBS0o7QUFRQztFQUVBLGVBQUE7RUFDRyxXQUFBO0FBUEo7QUFTQztFQUVJLGtCQUFBO0VBQ0QsZ0JBQUE7QUFSSiIsImZpbGUiOiJzcmMvYXBwL3RoZXRhYmxlL3RoZXRhYmxlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXJcclxuXHR7XHJcblx0XHJcblx0ICBpb24tdG9vbGJhclxyXG5cdCAgey0taW9uLWNvbG9yLWJhc2U6IHZhcigtLWlvbi1jb2xvci1iZ2dyYWRpZW50KSFpbXBvcnRhbnQ7XHJcblx0ICAtLWJvcmRlci13aWR0aDogMDtcclxuXHRpb24tYnV0dG9uc1xyXG5cdCB7XHJcblx0IGZvbnQtc2l6ZTogMjJweDtcclxuXHQgfVxyXG5cdFx0ICBpb24tdGl0bGV7XHJcblx0XHQgIGNvbG9yOnZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcblx0XHQgIHRleHQtYWxpZ246Y2VudGVyO1xyXG4gICAgICAgICAgICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcclxuICAgICAgICB9XHJcblx0fVxyXG5cdCY6OmFmdGVyXHJcblx0e1xyXG5cdGRpc3BsYXk6bm9uZTtcclxuXHR9XHJcblx0fVxyXG5cdGlvbi1jb250ZW50XHJcblx0e1xyXG5cdFxyXG5cdFtobS1zbGlkZXJdXHJcblx0e1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcblx0aW1nXHJcblx0e1xyXG5cdGhlaWdodDogNDV2aDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgb2JqZWN0LWZpdDogY292ZXI7XHJcblx0fVxyXG5cdC5zbGRfY250IHtcclxuICAgIGJvcmRlci1yYWRpdXM6IDE1cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAtMjBweDtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHotaW5kZXg6IDE7XHJcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdC5zbGRfY250aW5uZXIge1xyXG4gICAgcGFkZGluZzogMTVweDtcclxuXHRcdC5sb2dvLXRvcC1hbCB7XHJcblx0XHRcdHdpZHRoOiAxMTBweDtcclxuXHRcdFx0aGVpZ2h0OiAxMTBweDtcclxuXHRcdFx0ZGlzcGxheTogYmxvY2s7XHJcblx0XHRcdG1hcmdpbjogMCBhdXRvO1xyXG5cdFx0XHR0ZXh0LWFsaWduOiBjZW50ZXI7XHJcblx0XHRcdG1hcmdpbi10b3A6IC03MHB4O1xyXG5cdFx0XHRiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdFx0XHRib3JkZXItcmFkaXVzOiA1MCU7XHJcblx0XHRcdGRpc3BsYXk6IGZsZXg7XHJcblx0XHRcdGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcblx0XHRcdGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cdFx0XHRib3gtc2hhZG93OiAwcHggMnB4IDI0cHggcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG5cdFx0XHRwYWRkaW5nLXRvcDogNXB4O1xyXG5cdFx0XHRtYXJnaW4tYm90dG9tOiAwcHg7XHJcblx0XHRcdGltZyB7XHJcblx0XHRcdFx0d2lkdGg6IDc2cHg7XHJcblx0XHRcdFx0aGVpZ2h0OiBhdXRvO1xyXG5cdFx0XHR9XHJcblx0XHR9XHRcclxuXHQvKmltZ1xyXG5cdHtcclxuXHR3aWR0aDogMTQwcHg7XHJcbiAgICBoZWlnaHQ6IDE0MHB4O1xyXG4gICAgb2JqZWN0LWZpdDogY29udGFpbjtcclxuICAgIGJveC1zaGFkb3c6IDBweCAwcHggMTBweCByZ2IoMCAwIDAgLyAyOCUpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgbWFyZ2luLXRvcDogLTgwcHg7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZjhmMWZkO1xyXG5cdH0qL1xyXG5cdHBcclxuXHR7XHJcblx0Zm9udC1zaXplOiAxM3B4O1xyXG4gICAgY29sb3I6ICM5OTk7XHJcblx0fVxyXG5cdGlvbi1idXR0b25cclxuXHR7XHJcblx0ICAgIC0tYm94LXNoYWRvdzogbm9uZTtcclxuICAgIG1pbi1oZWlnaHQ6IDQycHg7XHJcblx0fVxyXG59XHJcbn1cclxuXHR9XHJcblx0fSJdfQ== */");

/***/ }),

/***/ "./src/app/thetable/thetable.page.ts":
/*!*******************************************!*\
  !*** ./src/app/thetable/thetable.page.ts ***!
  \*******************************************/
/*! exports provided: ThetablePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ThetablePage", function() { return ThetablePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let ThetablePage = class ThetablePage {
    constructor() { }
    ngOnInit() {
    }
};
ThetablePage.ctorParameters = () => [];
ThetablePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-thetable',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./thetable.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/thetable/thetable.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./thetable.page.scss */ "./src/app/thetable/thetable.page.scss")).default]
    })
], ThetablePage);



/***/ })

}]);
//# sourceMappingURL=thetable-thetable-module-es2015.js.map