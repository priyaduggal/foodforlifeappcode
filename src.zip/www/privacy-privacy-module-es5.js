(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["privacy-privacy-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/privacy/privacy.page.html":
    /*!*********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/privacy/privacy.page.html ***!
      \*********************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPrivacyPrivacyPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n\t<ion-back-button defaultHref=\"/tabs/settings\" slot=\"start\">\r\n\t</ion-back-button>\r\n\t<ion-title class=\"ion-text-center\">Privacy Policy</ion-title>\r\n  </ion-toolbar>\r\n  </ion-header>\r\n\r\n<ion-content class=\"ion-padding\">\r\n<div class=\"content-terms privacy_description\" [innerHTML]=\"privacy?.description\">\r\n</div>\r\n<!--div class=\"content-terms\" >\r\n        <p>www.ffl.org is committed to protecting and respecting your privacy, and we’ll only use your personal information to administer your account and to provide the products and services you requested from us. From time to time, we would like to contact you about our products and services, as well as other content that may be of interest to you. By clicking submit you consent to us contacting you for this purpose and allow www.ffl.org to store and process the personal information submitted above to provide you the content requested.</p>\r\n\t\t<p>You may unsubscribe from these communications at any time. For more information on how to unsubscribe, our privacy practices, and how we are committed to protecting and respecting your privacy, please review our Privacy Policy.</p>\r\n\t\t<h4 subhead> Introduction</h4>\r\n\t\t<p> We are committed to safeguarding the privacy of our website visitors, volunteers and donors.</p>\r\n\t\t<p> This policy applies where we are acting as a data controller with respect to the personal data of our website visitors and service users; in other words, where we determine the purposes and means of the processing of that personal data.</p>\r\n\t\t<p> We use cookies on our website. Insofar as those cookies are not strictly necessary for the provision of our website and services, we will ask you to consent to our use of cookies when you first visit our website.</p>\r\n\t\t<p> In this policy, “we”, “us” and “our” refer to Food for Life Global – Americas Inc.. For more information about us, see Section 12.</p>\r\n\t\t\r\n\t\t<h4 subhead> How we use your personal data </h4>\r\n\t\t<p> In this Section 2 we have set out</p>\r\n\t\t<ul>\r\n\t\t      <li>The general categories of personal data that we may process;</li>\r\n\t\t\t  <li>In the case of personal data that we did not obtain directly from you, the source and specific categories of that data;</li>\r\n\t\t\t  <li>The purposes for which we may process personal data; and</li>\r\n\t\t\t  <li>The legal bases of the processing.</li>\r\n\t\t</ul>\r\n\t\t<p>We may process data about your use of our website and services (“usage data“). The usage data may include your IP address, geographical location, browser type and version, operating system, referral source, length of visit, page views and website navigation paths, as well as information about the timing, frequency and pattern of your service use. The source of the usage data is our analytics tracking system. This usage data may be processed for the purposes of analysing the use of the website and services. The legal basis for this processing is our legitimate interests, namely monitoring and improving our website and the users experience.</p>\r\n\t\t<p>We may process your account data (“account data“). The account data may include your name and email address. The source of the account data is you or your employer. The account data may be processed for the purposes of operating our website, providing our services, ensuring the security of our website and services, maintaining back-ups of our databases and communicating with you. The legal basis for this processing is our legitimate interests, namely the proper administration of our website and business.</p>\r\n\t\t<p>We may process your information included in your personal profile on our website (“profile data“). The profile data may include your name, address, telephone number, and email address. The profile data may be processed for the purposes of enabling and monitoring your use of our website and services. The legal basis for this processing is our legitimate interests, namely the proper administration of our website and business.</p>\r\n\t\t<p>We may process your personal data that are provided in the course of the use of our services (“service data“). The service data may be processed for the purposes of operating our website, providing our services, ensuring the security of our website and services, maintaining back-ups of our databases and communicating with you. The legal basis for this processing is our legitimate interests, namely the proper administration of our website and business.</p>\r\n\t\t<p>We may process information contained in any enquiry you submit to us regarding goods and/or services (“enquiry data“). The enquiry data may be processed for the purposes of offering, marketing and selling relevant goods and/or services to you. The legal basis for this processing is consent.</p>\r\n\t\t<p>We may process information relating to transactions, including purchases of goods and services, that you enter into with us and/or through our website (“transaction data“). The transaction data may include your contact details, your card details and the transaction details. The transaction data may be processed for the purpose of supplying the purchased goods and services and keeping proper records of those transactions. The legal basis for this processing is the performance of a contract between you and us and/or taking steps, at your request, to enter into such a contract and our legitimate interests, namely the proper administration of our website and business.</p>\r\n\t\t<p>We may process information that you provide to us for the purpose of subscribing to our email notifications and/or newsletters (“notification data“). The notification data may be processed for the purposes of sending you the relevant notifications and/or newsletters. The legal basis for this processing is consent.</p>\r\n\t</div---->\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "./src/app/privacy/privacy-routing.module.ts":
    /*!***************************************************!*\
      !*** ./src/app/privacy/privacy-routing.module.ts ***!
      \***************************************************/

    /*! exports provided: PrivacyPageRoutingModule */

    /***/
    function srcAppPrivacyPrivacyRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PrivacyPageRoutingModule", function () {
        return PrivacyPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _privacy_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./privacy.page */
      "./src/app/privacy/privacy.page.ts");

      var routes = [{
        path: '',
        component: _privacy_page__WEBPACK_IMPORTED_MODULE_3__["PrivacyPage"]
      }];

      var PrivacyPageRoutingModule = function PrivacyPageRoutingModule() {
        _classCallCheck(this, PrivacyPageRoutingModule);
      };

      PrivacyPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], PrivacyPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/privacy/privacy.module.ts":
    /*!*******************************************!*\
      !*** ./src/app/privacy/privacy.module.ts ***!
      \*******************************************/

    /*! exports provided: PrivacyPageModule */

    /***/
    function srcAppPrivacyPrivacyModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PrivacyPageModule", function () {
        return PrivacyPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _privacy_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./privacy-routing.module */
      "./src/app/privacy/privacy-routing.module.ts");
      /* harmony import */


      var _privacy_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./privacy.page */
      "./src/app/privacy/privacy.page.ts");

      var PrivacyPageModule = function PrivacyPageModule() {
        _classCallCheck(this, PrivacyPageModule);
      };

      PrivacyPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _privacy_routing_module__WEBPACK_IMPORTED_MODULE_5__["PrivacyPageRoutingModule"]],
        declarations: [_privacy_page__WEBPACK_IMPORTED_MODULE_6__["PrivacyPage"]]
      })], PrivacyPageModule);
      /***/
    },

    /***/
    "./src/app/privacy/privacy.page.scss":
    /*!*******************************************!*\
      !*** ./src/app/privacy/privacy.page.scss ***!
      \*******************************************/

    /*! exports provided: default */

    /***/
    function srcAppPrivacyPrivacyPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-header ion-toolbar {\n  --ion-color-base: var(--ion-color-bggradient)!important;\n  --border-width: 0;\n}\nion-header ion-toolbar ion-title {\n  color: var(--ion-color-white);\n  text-align: center;\n  font-style: normal;\n  font-family: \"Poppins\", sans-serif !important;\n}\nion-header::after {\n  display: none;\n}\nion-content .content-terms [subhead] {\n  margin: 15px 0px 10px 0px;\n  font-size: 18px;\n  position: relative;\n  z-index: 1;\n  padding-left: 7px;\n}\nion-content .content-terms [subhead]:after {\n  content: \"\";\n  position: absolute;\n  left: 0;\n  width: 30px;\n  height: 30px;\n  background: var(--ion-color-softgreen);\n  border-radius: 50%;\n  z-index: -1;\n  /*opacity: 0.5;*/\n  top: -6px;\n}\nion-content .content-terms p {\n  margin-top: 0px;\n  margin-bottom: 7px;\n  font-size: 14px;\n  line-height: 24px;\n  color: #999;\n  font-weight: 400;\n}\nion-content .content-terms ul {\n  list-style-type: none;\n  padding: 0px 0px 0px 15px;\n  margin: 0px;\n}\nion-content .content-terms ul li {\n  display: block;\n  margin-bottom: 7px;\n  font-size: 14px;\n  line-height: 24px;\n  color: #999;\n  font-weight: 400;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJpdmFjeS9wcml2YWN5LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHRztFQUNDLHVEQUFBO0VBQ0QsaUJBQUE7QUFGSDtBQUlJO0VBQ0EsNkJBQUE7RUFDQSxrQkFBQTtFQUNRLGtCQUFBO0VBQ0EsNkNBQUE7QUFGWjtBQUtDO0VBRUEsYUFBQTtBQUpEO0FBVUU7RUFDQyx5QkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxpQkFBQTtBQVBIO0FBUUc7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxPQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxzQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsU0FBQTtBQU5IO0FBVUU7RUFDQyxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7QUFSSDtBQVVFO0VBRUkscUJBQUE7RUFDSCx5QkFBQTtFQUNBLFdBQUE7QUFUSDtBQVVHO0VBRUssY0FBQTtFQUNKLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0FBVEoiLCJmaWxlIjoic3JjL2FwcC9wcml2YWN5L3ByaXZhY3kucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlclxyXG57XHJcblx0XHJcblx0ICBpb24tdG9vbGJhclxyXG5cdCAgey0taW9uLWNvbG9yLWJhc2U6IHZhcigtLWlvbi1jb2xvci1iZ2dyYWRpZW50KSFpbXBvcnRhbnQ7XHJcblx0ICAtLWJvcmRlci13aWR0aDogMDtcclxuXHRcclxuXHRcdCAgaW9uLXRpdGxle1xyXG5cdFx0ICBjb2xvcjp2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdFx0ICB0ZXh0LWFsaWduOmNlbnRlcjtcclxuICAgICAgICAgICAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gICAgICAgICAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgfVxyXG5cdH1cclxuXHQmOjphZnRlclxyXG5cdHtcclxuXHRkaXNwbGF5Om5vbmU7XHJcblx0fVxyXG59XHJcbmlvbi1jb250ZW50XHJcbntcdFxyXG5cdC5jb250ZW50LXRlcm1zIHtcclxuXHRcdFtzdWJoZWFkXSB7XHJcblx0XHRcdG1hcmdpbjogMTVweCAwcHggMTBweCAgMHB4O1xyXG5cdFx0XHRmb250LXNpemU6IDE4cHg7XHJcblx0XHRcdHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHRcdFx0ei1pbmRleDogMTtcclxuXHRcdFx0cGFkZGluZy1sZWZ0OiA3cHg7XHJcblx0XHRcdCY6YWZ0ZXIge1xyXG5cdFx0XHRjb250ZW50OiAnJztcclxuXHRcdFx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdFx0XHRsZWZ0OiAwO1xyXG5cdFx0XHR3aWR0aDogMzBweDtcclxuXHRcdFx0aGVpZ2h0OiAzMHB4O1xyXG5cdFx0XHRiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itc29mdGdyZWVuKTtcclxuXHRcdFx0Ym9yZGVyLXJhZGl1czogNTAlO1xyXG5cdFx0XHR6LWluZGV4OiAtMTtcclxuXHRcdFx0LypvcGFjaXR5OiAwLjU7Ki9cclxuXHRcdFx0dG9wOiAtNnB4O1xyXG5cdFx0fVxyXG5cdFx0fVxyXG5cclxuXHRcdHAge1xyXG5cdFx0XHRtYXJnaW4tdG9wOiAwcHg7IFxyXG5cdFx0XHRtYXJnaW4tYm90dG9tOiA3cHg7XHJcblx0XHRcdGZvbnQtc2l6ZTogMTRweDtcclxuXHRcdFx0bGluZS1oZWlnaHQ6IDI0cHg7XHJcblx0XHRcdGNvbG9yOiAgIzk5OTtcclxuXHRcdFx0Zm9udC13ZWlnaHQ6IDQwMDtcclxuXHRcdH1cclxuXHRcdHVsXHJcblx0XHR7XHJcblx0XHQgICAgbGlzdC1zdHlsZS10eXBlOm5vbmU7XHJcblx0XHRcdHBhZGRpbmc6MHB4IDBweCAwcHggMTVweDtcclxuXHRcdFx0bWFyZ2luOjBweDtcclxuXHRcdFx0bGlcclxuXHRcdFx0e1xyXG5cdFx0XHQgICAgIGRpc3BsYXk6YmxvY2s7XHJcblx0XHRcdFx0bWFyZ2luLWJvdHRvbTogN3B4O1xyXG5cdFx0XHRcdGZvbnQtc2l6ZTogMTRweDtcclxuXHRcdFx0XHRsaW5lLWhlaWdodDogMjRweDtcclxuXHRcdFx0XHRjb2xvcjogICM5OTk7XHJcblx0XHRcdFx0Zm9udC13ZWlnaHQ6IDQwMDtcdFx0XHRcdCBcclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cdH1cclxufSJdfQ== */";
      /***/
    },

    /***/
    "./src/app/privacy/privacy.page.ts":
    /*!*****************************************!*\
      !*** ./src/app/privacy/privacy.page.ts ***!
      \*****************************************/

    /*! exports provided: PrivacyPage */

    /***/
    function srcAppPrivacyPrivacyPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PrivacyPage", function () {
        return PrivacyPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../services/api/api.service */
      "./src/app/services/api/api.service.ts");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _common_common_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../common/common.service */
      "./src/app/common/common.service.ts");

      var PrivacyPage = /*#__PURE__*/function () {
        function PrivacyPage(api, router, common) {
          _classCallCheck(this, PrivacyPage);

          this.api = api;
          this.router = router;
          this.common = common;
        }

        _createClass(PrivacyPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "ionViewDidEnter",
          value: function ionViewDidEnter() {
            this.getprivacydetails();
          }
        }, {
          key: "getprivacydetails",
          value: function getprivacydetails() {
            var _this = this;

            this.common.presentLoading();
            this.api.post('getprivacypolicy', '', '').subscribe(function (result) {
              _this.common.stopLoading();

              var res;
              res = result;

              if (res.status == 1) {
                _this.privacy = res.data; //this.common.presentToast('FAQ fetched successfully !.','success');
              } else {
                //this.common.presentToast(res.message,'danger');
                _this.privacy = '';
              }
            }, function (err) {});
          }
        }]);

        return PrivacyPage;
      }();

      PrivacyPage.ctorParameters = function () {
        return [{
          type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
        }, {
          type: _common_common_service__WEBPACK_IMPORTED_MODULE_4__["CommonService"]
        }];
      };

      PrivacyPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-privacy',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./privacy.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/privacy/privacy.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./privacy.page.scss */
        "./src/app/privacy/privacy.page.scss"))["default"]]
      })], PrivacyPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=privacy-privacy-module-es5.js.map