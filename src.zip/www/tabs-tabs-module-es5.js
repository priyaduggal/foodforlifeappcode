(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tabs-tabs-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/tabs.page.html":
    /*!***************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/tabs.page.html ***!
      \***************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppTabsTabsPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-tabs>\r\n\r\n  <ion-tab-bar slot=\"bottom\">\r\n    \r\n\r\n    \r\n <ion-tab-button tab=\"home\" home>\r\n      <ion-icon src='data:image/svg+xml;utf8,<svg enable-background=\"new 0 0 512 512\" height=\"512\" viewBox=\"0 0 512 512\" width=\"512\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"m316 76c0-33.084-26.916-60-60-60s-60 26.916-60 60 26.916 60 60 60 60-26.916 60-60zm-60 40c-22.056 0-40-17.944-40-40s17.944-40 40-40 40 17.944 40 40-17.944 40-40 40z\"/><path d=\"m346 266v-40c0-49.626-40.374-90-90-90s-90 40.374-90 90v40c0 5.523 4.478 10 10 10h160c5.522 0 10-4.477 10-10zm-20-10h-140v-30c0-38.598 31.402-70 70-70s70 31.402 70 70z\"/><path d=\"m71.858 408.114 48.142 24.067v53.819c0 5.523 4.478 10 10 10h106c5.522 0 10-4.477 10-10v-127.22c0-31.783-23.452-59.203-53.391-62.423-.795-.15-38.649-2.971-56.948-21.258l-27.38-27.379c-7.556-7.558-17.6-11.72-28.281-11.72v-80c0-22.056-17.944-40-40-40s-40 17.944-40 40v135.84c0 49.212 27.798 94.239 71.858 116.274zm-51.858-252.114c0-11.028 8.972-20 20-20s20 8.972 20 20v85.361c-12.196 7.052-20 20.2-20 34.639 0 10.68 4.162 20.723 11.719 28.28l51.21 51.22c3.903 3.905 10.236 3.907 14.142.001 3.905-3.905 3.906-10.236.001-14.142l-51.21-51.221c-3.78-3.779-5.862-8.8-5.862-14.138 0-8.464 5.357-16.044 13.332-18.861.003-.001.006-.003.009-.004h.001c6.88-2.439 15.066-1.005 20.797 4.726l27.383 27.383c18.65 18.637 45.831 23.879 68.836 26.986.037.004.075.009.113.013 19.923 2.142 35.529 20.827 35.529 42.537v117.22h-86v-50c0-3.788-2.141-7.251-5.528-8.944l-53.669-26.83c-37.504-18.757-60.803-56.456-60.803-98.386z\"/><circle cx=\"459\" cy=\"384\" r=\"10\"/><path d=\"m472 116c-22.056 0-40 17.944-40 40v80c-10.681 0-20.725 4.162-28.281 11.719l-27.377 27.377c-15.96 15.949-41.848 18.608-56.951 21.262-29.939 3.22-53.391 30.639-53.391 62.422v127.22c0 5.523 4.478 10 10 10h106c5.522 0 10-4.477 10-10v-53.819l32.73-16.362c4.939-2.47 6.942-8.476 4.473-13.417-2.469-4.939-8.474-6.942-13.416-4.473l-38.259 19.125c-3.387 1.695-5.528 5.158-5.528 8.946v50h-86v-117.22c0-21.71 15.606-40.395 35.529-42.538.038-.004.076-.008.113-.013 23.361-3.155 50.206-8.368 68.839-26.988l27.38-27.38c5.724-5.724 13.913-7.166 20.797-4.726h.001c.003.001.006.003.009.004 7.975 2.817 13.332 10.397 13.332 18.861 0 5.338-2.082 10.359-5.861 14.14l-51.21 51.22c-3.905 3.906-3.904 10.237.001 14.142 3.904 3.904 10.237 3.905 14.142-.001l51.21-51.22c7.556-7.558 11.718-17.601 11.718-28.281 0-14.439-7.804-27.587-20-34.639v-85.361c0-11.028 8.972-20 20-20s20 8.972 20 20v135.84c0 18.296-4.617 36.46-13.353 52.528-2.639 4.852-.844 10.924 4.009 13.562 4.851 2.637 10.924.843 13.562-4.009 10.325-18.99 15.782-40.458 15.782-62.081v-135.84c0-22.056-17.944-40-40-40z\"/></svg>'></ion-icon>\r\n\r\n    </ion-tab-button>\r\n    <ion-tab-button tab=\"tribes\" >\r\n      <ion-icon src='data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\" width=\"512\" height=\"512\"><path d=\"M56,488a8.00008,8.00008,0,0,0,8,8h96a8.00008,8.00008,0,0,0,8-8V384a56.07915,56.07915,0,0,0-48-55.41943V304h8a8.00008,8.00008,0,0,0,8-8V285.63745l96-34.28577V256a8.00008,8.00008,0,0,0,8,8h8v64.1156a26.45479,26.45479,0,0,0-24,26.30676V392a31.79794,31.79794,0,0,0,3.81567,15.13855l-8.61547,6.46155A48.22938,48.22938,0,0,0,200,452v36a8.00008,8.00008,0,0,0,8,8h96a8.00008,8.00008,0,0,0,8-8V452a48.22938,48.22938,0,0,0-19.2002-38.3999l-8.61547-6.46155A31.79794,31.79794,0,0,0,288,392V352a7.99943,7.99943,0,0,0-3.5625-6.65625l-19.3584-12.90527c-.35278-.23523-.71728-.44666-1.0791-.66382V264h8a8.00008,8.00008,0,0,0,8-8v-4.64832l96,34.28577V296a8.00008,8.00008,0,0,0,8,8h8v25.0127A32.0573,32.0573,0,0,0,368,360v32a31.79794,31.79794,0,0,0,3.81567,15.13855l-8.61547,6.46155A48.22938,48.22938,0,0,0,344,452v36a8.00008,8.00008,0,0,0,8,8h96a8.00008,8.00008,0,0,0,8-8V452a48.22938,48.22938,0,0,0-19.2002-38.3999l-8.61547-6.46155A31.79794,31.79794,0,0,0,432,392V360a32.0573,32.0573,0,0,0-24-30.9873V304h8a8.00008,8.00008,0,0,0,8-8V264a8.00008,8.00008,0,0,0-8-8H384a8.00008,8.00008,0,0,0-8,8v4.64832l-96-34.28577V224a8.00008,8.00008,0,0,0-8-8h-8V184h40a8.00008,8.00008,0,0,0,8-8V140a48.22938,48.22938,0,0,0-19.2002-38.3999l-8.61547-6.46155A31.79794,31.79794,0,0,0,288,80V32a16.01833,16.01833,0,0,0-16-16H256a32.03635,32.03635,0,0,0-32,32V80a31.79794,31.79794,0,0,0,3.81567,15.13855l-8.61547,6.46155A48.22938,48.22938,0,0,0,200,140v36a8.00008,8.00008,0,0,0,8,8h40v32h-8a8.00008,8.00008,0,0,0-8,8v10.36255l-96,34.28577V264a8.00008,8.00008,0,0,0-8-8H96a8.00008,8.00008,0,0,0-8,8v32a8.00008,8.00008,0,0,0,8,8h8v24.58057A56.07915,56.07915,0,0,0,56,384Zm200-80a16.01833,16.01833,0,0,1-16-16V376h32v16A16.01833,16.01833,0,0,1,256,408Zm11.05127,14.03137L256,440.45068l-11.05127-18.41931a32.00349,32.00349,0,0,0,22.10254,0ZM296,452v28H216V452a32.15413,32.15413,0,0,1,12.7998-25.6001l.07593-.05688,20.26392,33.77319a8.001,8.001,0,0,0,13.7207,0L283.12427,426.343l.07593.05688A32.15413,32.15413,0,0,1,296,452Zm-24-95.71826V360H240v-5.57764a10.42189,10.42189,0,0,1,16.20312-8.67187ZM400,408a16.01833,16.01833,0,0,1-16-16V376h32v16A16.01833,16.01833,0,0,1,400,408Zm11.05127,14.03137L400,440.45068l-11.05127-18.41931a32.00349,32.00349,0,0,0,22.10254,0ZM440,452v28H360V452a32.15413,32.15413,0,0,1,12.7998-25.6001l.07593-.05688,20.26392,33.77319a8.001,8.001,0,0,0,13.7207,0L427.12427,426.343l.07593.05688A32.15413,32.15413,0,0,1,440,452Zm-24-92H384a16,16,0,0,1,32,0Zm-24-88h16v16H392ZM240,64h32V80a16,16,0,0,1-32,0Zm16,48a31.84714,31.84714,0,0,0,11.05127-1.96863L256,128.45068l-11.05127-18.41931A31.84714,31.84714,0,0,0,256,112Zm0-80h16V48H240A16.01833,16.01833,0,0,1,256,32ZM216,140a32.15413,32.15413,0,0,1,12.7998-25.6001l.07593-.05688,20.26392,33.77319a8.001,8.001,0,0,0,13.7207,0L283.12427,114.343l.07593.05688A32.15413,32.15413,0,0,1,296,140v28H216Zm32,92h16v16H248ZM104,272h16v16H104Zm48,208H72V460a32.15413,32.15413,0,0,1,12.7998-25.6001l.07593-.05688,20.26392,33.77319a8.001,8.001,0,0,0,13.7207,0L139.12427,434.343l.07593.05688A32.15413,32.15413,0,0,1,152,460Zm-24-80a16,16,0,0,1-32,0v-8.00977a46.14416,46.14416,0,0,0,19.57812-4.835A30.05654,30.05654,0,0,1,128,384.01514Zm-4.94873,30.03137L112,448.45068l-11.05127-18.41931a32.00349,32.00349,0,0,0,22.10254,0ZM112,344a40.04552,40.04552,0,0,1,40,40v40.25439c-1.02881-.92334-2.08643-1.81884-3.2002-2.65429l-8.61547-6.46155A31.79794,31.79794,0,0,0,144,400V376a8.00008,8.00008,0,0,0-8-8h-7.05566a46.12363,46.12363,0,0,0-20.52246,4.84473A30.04054,30.04054,0,0,1,95.05566,376H88a8.00008,8.00008,0,0,0-8,8v16a31.79794,31.79794,0,0,0,3.81567,15.13855L75.2002,421.6001c-1.11377.83545-2.17139,1.731-3.2002,2.65429V384A40.04552,40.04552,0,0,1,112,344Z\"/></svg>'></ion-icon>\r\n\r\n    </ion-tab-button>\r\n\r\n    <ion-tab-button tab=\"thetable\">\r\n      <ion-icon src='data:image/svg+xml;utf8,<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\"\r\n\t viewBox=\"0 0 512 512\" style=\"enable-background:new 0 0 512 512;\" xml:space=\"preserve\"><path d=\"M341.476,338.285c54.483-85.493,47.634-74.827,49.204-77.056C410.516,233.251,421,200.322,421,166\r\n\t\t\tC421,74.98,347.139,0,256,0C165.158,0,91,74.832,91,166c0,34.3,10.704,68.091,31.19,96.446l48.332,75.84\r\n\t\t\tC118.847,346.227,31,369.892,31,422c0,18.995,12.398,46.065,71.462,67.159C143.704,503.888,198.231,512,256,512\r\n\t\t\tc108.025,0,225-30.472,225-90C481,369.883,393.256,346.243,341.476,338.285z M147.249,245.945\r\n\t\t\tc-0.165-0.258-0.337-0.51-0.517-0.758C129.685,221.735,121,193.941,121,166c0-75.018,60.406-136,135-136\r\n\t\t\tc74.439,0,135,61.009,135,136c0,27.986-8.521,54.837-24.646,77.671c-1.445,1.906,6.094-9.806-110.354,172.918L147.249,245.945z\r\n\t\t\t M256,482c-117.994,0-195-34.683-195-60c0-17.016,39.568-44.995,127.248-55.901l55.102,86.463\r\n\t\t\tc2.754,4.322,7.524,6.938,12.649,6.938s9.896-2.617,12.649-6.938l55.101-86.463C411.431,377.005,451,404.984,451,422\r\n\t\t\tC451,447.102,374.687,482,256,482z\"/><path d=\"M256,91c-41.355,0-75,33.645-75,75s33.645,75,75,75c41.355,0,75-33.645,75-75S297.355,91,256,91z M256,211\r\n\t\t\tc-24.813,0-45-20.187-45-45s20.187-45,45-45s45,20.187,45,45S280.813,211,256,211z\"/></svg>'></ion-icon>\r\n    </ion-tab-button>\r\n    \r\n\t <ion-tab-button tab=\"profile\">\r\n    <ion-icon src='data:image/svg+xml;utf8,<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\"\r\n    viewBox=\"0 0 482.9 482.9\" style=\"enable-background:new 0 0 482.9 482.9;\" xml:space=\"preserve\"><path d=\"M239.7,260.2c0.5,0,1,0,1.6,0c0.2,0,0.4,0,0.6,0c0.3,0,0.7,0,1,0c29.3-0.5,53-10.8,70.5-30.5\r\n       c38.5-43.4,32.1-117.8,31.4-124.9c-2.5-53.3-27.7-78.8-48.5-90.7C280.8,5.2,262.7,0.4,242.5,0h-0.7c-0.1,0-0.3,0-0.4,0h-0.6\r\n       c-11.1,0-32.9,1.8-53.8,13.7c-21,11.9-46.6,37.4-49.1,91.1c-0.7,7.1-7.1,81.5,31.4,124.9C186.7,249.4,210.4,259.7,239.7,260.2z\r\n        M164.6,107.3c0-0.3,0.1-0.6,0.1-0.8c3.3-71.7,54.2-79.4,76-79.4h0.4c0.2,0,0.5,0,0.8,0c27,0.6,72.9,11.6,76,79.4\r\n       c0,0.3,0,0.6,0.1,0.8c0.1,0.7,7.1,68.7-24.7,104.5c-12.6,14.2-29.4,21.2-51.5,21.4c-0.2,0-0.3,0-0.5,0l0,0c-0.2,0-0.3,0-0.5,0\r\n       c-22-0.2-38.9-7.2-51.4-21.4C157.7,176.2,164.5,107.9,164.6,107.3z\"/>\r\n     <path d=\"M446.8,383.6c0-0.1,0-0.2,0-0.3c0-0.8-0.1-1.6-0.1-2.5c-0.6-19.8-1.9-66.1-45.3-80.9c-0.3-0.1-0.7-0.2-1-0.3\r\n       c-45.1-11.5-82.6-37.5-83-37.8c-6.1-4.3-14.5-2.8-18.8,3.3c-4.3,6.1-2.8,14.5,3.3,18.8c1.7,1.2,41.5,28.9,91.3,41.7\r\n       c23.3,8.3,25.9,33.2,26.6,56c0,0.9,0,1.7,0.1,2.5c0.1,9-0.5,22.9-2.1,30.9c-16.2,9.2-79.7,41-176.3,41\r\n       c-96.2,0-160.1-31.9-176.4-41.1c-1.6-8-2.3-21.9-2.1-30.9c0-0.8,0.1-1.6,0.1-2.5c0.7-22.8,3.3-47.7,26.6-56\r\n       c49.8-12.8,89.6-40.6,91.3-41.7c6.1-4.3,7.6-12.7,3.3-18.8c-4.3-6.1-12.7-7.6-18.8-3.3c-0.4,0.3-37.7,26.3-83,37.8\r\n       c-0.4,0.1-0.7,0.2-1,0.3c-43.4,14.9-44.7,61.2-45.3,80.9c0,0.9,0,1.7-0.1,2.5c0,0.1,0,0.2,0,0.3c-0.1,5.2-0.2,31.9,5.1,45.3\r\n       c1,2.6,2.8,4.8,5.2,6.3c3,2,74.9,47.8,195.2,47.8s192.2-45.9,195.2-47.8c2.3-1.5,4.2-3.7,5.2-6.3\r\n       C447,415.5,446.9,388.8,446.8,383.6z\"/></svg>'></ion-icon>\r\n \r\n      \r\n    </ion-tab-button>\r\n    <ion-tab-button tab=\"settings\">\r\n      <ion-icon src='data:image/svg+xml;utf8,<svg version=\"1.1\"xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" x=\"0px\" y=\"0px\"\r\n\t viewBox=\"0 0 480 480\" style=\"enable-background:new 0 0 480 480;\" xml:space=\"preserve\"><path d=\"M296,280h-8.8c-3.31,0.006-6.271-2.059-7.408-5.168c-0.976-2.56-2.024-5.064-3.152-7.544\r\n\t\t\tc-1.402-3.016-0.762-6.587,1.6-8.928l6.272-6.28c9.311-9.393,9.294-24.541-0.04-33.912l-22.608-22.608\r\n\t\t\tc-9.383-9.328-24.537-9.328-33.92,0l-6.272,6.264c-2.346,2.353-5.911,2.992-8.928,1.6c-2.48-1.128-4.984-2.176-7.552-3.2\r\n\t\t\tc-3.125-1.129-5.204-4.101-5.192-7.424V184c0-13.255-10.745-24-24-24h-32c-13.255,0-24,10.745-24,24v8.8\r\n\t\t\tc0.006,3.31-2.059,6.271-5.168,7.408c-2.56,0.976-5.064,2.024-7.544,3.152c-3.017,1.395-6.583,0.756-8.928-1.6l-6.28-6.272\r\n\t\t\tc-9.382-9.322-24.53-9.322-33.912,0l-22.608,22.68c-9.328,9.383-9.328,24.537,0,33.92l6.264,6.272\r\n\t\t\tc2.362,2.341,3.002,5.912,1.6,8.928c-1.128,2.48-2.176,4.984-3.16,7.552c-1.145,3.127-4.134,5.194-7.464,5.16H24\r\n\t\t\tc-13.255,0-24,10.745-24,24v32c0,13.255,10.745,24,24,24h8.8c3.31-0.006,6.271,2.059,7.408,5.168\r\n\t\t\tc0.976,2.56,2.024,5.064,3.152,7.544c1.402,3.016,0.762,6.587-1.6,8.928l-6.272,6.28c-9.322,9.382-9.322,24.53,0,33.912\r\n\t\t\tl22.608,22.608c9.383,9.328,24.537,9.328,33.92,0l6.272-6.264c2.346-2.353,5.911-2.992,8.928-1.6\r\n\t\t\tc2.48,1.128,4.984,2.176,7.552,3.2c3.141,1.116,5.238,4.091,5.232,7.424v8.8c0,13.255,10.745,24,24,24h32\r\n\t\t\tc13.255,0,24-10.745,24-24v-8.8c-0.006-3.31,2.059-6.271,5.168-7.408c2.56-0.976,5.064-2.024,7.544-3.152\r\n\t\t\tc3.017-1.395,6.583-0.756,8.928,1.6l6.28,6.272c9.395,9.307,24.539,9.289,33.912-0.04l22.608-22.608\r\n\t\t\tc9.328-9.383,9.328-24.537,0-33.92l-6.264-6.272c-2.362-2.341-3.002-5.912-1.6-8.928c1.128-2.48,2.176-4.984,3.2-7.552\r\n\t\t\tc1.129-3.125,4.101-5.204,7.424-5.192h8.8c13.255,0,24-10.745,24-24v-32C320,290.745,309.255,280,296,280z M304,336\r\n\t\t\tc0,4.418-3.582,8-8,8h-8.8c-9.945,0.037-18.845,6.184-22.4,15.472c-0.848,2.24-1.765,4.445-2.752,6.616\r\n\t\t\tc-4.113,9.08-2.205,19.756,4.8,26.848l6.256,6.264c3.126,3.122,3.129,8.188,0.006,11.314c-0.002,0.002-0.004,0.004-0.006,0.006\r\n\t\t\tl-22.608,22.608c-3.124,3.123-8.188,3.123-11.312,0l-6.272-6.264c-7.089-7.011-17.769-8.92-26.848-4.8\r\n\t\t\tc-2.168,0.984-4.376,1.904-6.6,2.752C190.183,428.37,184.04,437.262,184,447.2v8.8c0,4.418-3.582,8-8,8h-32c-4.418,0-8-3.582-8-8\r\n\t\t\tv-8.8c-0.037-9.945-6.184-18.845-15.472-22.4c-2.24-0.848-4.445-1.765-6.616-2.752c-9.08-4.111-19.755-2.202-26.848,4.8\r\n\t\t\tl-6.264,6.256c-3.122,3.126-8.188,3.129-11.314,0.006c-0.002-0.002-0.004-0.004-0.006-0.006L46.872,410.52\r\n\t\t\tc-3.123-3.124-3.123-8.188,0-11.312l6.264-6.272c7.005-7.092,8.913-17.768,4.8-26.848c-0.984-2.168-1.904-4.376-2.752-6.6\r\n\t\t\tC51.638,350.197,42.744,344.044,32.8,344H24c-4.418,0-8-3.582-8-8v-32c0-4.418,3.582-8,8-8h8.8\r\n\t\t\tc9.945-0.037,18.845-6.184,22.4-15.472c0.848-2.24,1.765-4.445,2.752-6.616c4.113-9.08,2.204-19.756-4.8-26.848l-6.288-6.264\r\n\t\t\tc-3.126-3.122-3.129-8.188-0.006-11.314c0.002-0.002,0.004-0.004,0.006-0.006l22.608-22.608c3.124-3.123,8.188-3.123,11.312,0\r\n\t\t\tl6.272,6.264c7.089,7.011,17.769,8.92,26.848,4.8c2.168-0.984,4.376-1.904,6.6-2.752c9.294-3.543,15.451-12.438,15.496-22.384V184\r\n\t\t\tc0-4.418,3.582-8,8-8h32c4.418,0,8,3.582,8,8v8.8c0.037,9.945,6.184,18.845,15.472,22.4c2.24,0.848,4.445,1.765,6.616,2.752\r\n\t\t\tc9.079,4.12,19.759,2.211,26.848-4.8l6.264-6.256c3.136-3.102,8.184-3.102,11.32,0l22.608,22.608\r\n\t\t\tc3.123,3.124,3.123,8.188,0,11.312l-6.264,6.272c-7.004,7.092-8.913,17.768-4.8,26.848c0.984,2.168,1.904,4.376,2.752,6.6\r\n\t\t\tc3.554,9.281,12.446,15.424,22.384,15.464h8.8c4.418,0,8,3.582,8,8V336z\"/><path d=\"M231.84,316.8c-0.08-1.92-0.216-3.832-0.448-5.736c-0.256-2.048-0.56-4.08-0.984-6.072c-0.28-1.304-0.648-2.592-1-3.888\r\n\t\t\tc-0.448-1.648-0.952-3.272-1.512-4.872c-0.392-1.112-0.8-2.216-1.216-3.312c-1.03-2.562-2.208-5.063-3.528-7.488\r\n\t\t\tc-0.104-0.184-0.168-0.384-0.272-0.568c-2.081-3.704-4.491-7.215-7.2-10.488c-0.232-0.288-0.496-0.56-0.736-0.84\r\n\t\t\tc-1.104-1.304-2.24-2.568-3.432-3.776c-0.624-0.648-1.28-1.256-1.936-1.88c-0.8-0.744-1.6-1.48-2.4-2.184\r\n\t\t\tc-0.971-0.843-1.96-1.659-2.968-2.448l-1.312-0.976C190.517,253,175.466,247.992,160,248c-0.8,0-1.6,0.12-2.4,0.152\r\n\t\t\tc-1.704,0.048-3.416,0.144-5.136,0.32c-0.904,0.096-1.816,0.2-2.72,0.328c-2.608,0.343-5.196,0.827-7.752,1.448\r\n\t\t\tc-38.521,9.954-61.679,49.252-51.725,87.773c6.56,25.384,26.392,45.2,51.781,51.739c0.128,0,0.264,0.04,0.4,0.072\r\n\t\t\tc2.763,0.689,5.562,1.224,8.384,1.6c1.864,0.232,3.728,0.28,5.6,0.368c1.248,0.064,2.4,0.248,3.704,0.248\r\n\t\t\tc2.28,0,4.648-0.152,7.064-0.392c0.256,0,0.512-0.072,0.8-0.104c1.944-0.216,3.912-0.504,5.92-0.904\r\n\t\t\tc0.8-0.152,1.544-0.352,2.312-0.528c1.408-0.328,2.808-0.672,4.248-1.096c1.12-0.336,2.208-0.728,3.304-1.112\r\n\t\t\tc1.096-0.384,2.232-0.8,3.368-1.232c1.136-0.432,2.088-0.928,3.12-1.408c1.344-0.616,2.68-1.224,4-1.944h0.048\r\n\t\t\tc7.466-3.997,14.362-8.977,20.504-14.808c1.659-1.548,3.102-3.314,4.288-5.248c6.244-10.01,10.346-21.205,12.048-32.88\r\n\t\t\tc0.224-1.544,0.424-3.088,0.544-4.664c0.112-1.448,0.192-2.888,0.224-4.328c0-0.456,0.064-0.888,0.064-1.344\r\n\t\t\tC232,318.928,231.888,317.888,231.84,316.8z M215.896,322.04c0,0.664-0.056,1.328-0.096,1.984\r\n\t\t\tc-0.144,1.936-0.392,3.872-0.72,5.816c-2.99,16.633-13.317,31.033-28.112,39.2c-0.992,0.52-1.968,1.008-2.944,1.456l-0.664,0.32\r\n\t\t\tc-4.648,2.11-9.554,3.595-14.592,4.416c-0.352,0.056-0.712,0.12-1.072,0.168c-1,0.144-1.984,0.264-2.96,0.352\r\n\t\t\tc-1.288,0.112-2.584,0.176-3.904,0.2c-0.56,0-1.112,0-1.672,0c-1.893-0.022-3.783-0.139-5.664-0.352l-0.96-0.112\r\n\t\t\tc-2.2-0.288-4.382-0.699-6.536-1.232c-29.962-7.669-48.034-38.175-40.366-68.137c5.067-19.798,20.517-35.264,40.31-40.351l0-0.008\r\n\t\t\tc4.596-1.159,9.316-1.751,14.056-1.76c2.287,0.013,4.572,0.168,6.84,0.464c0.608,0.072,1.208,0.184,1.808,0.272\r\n\t\t\tc1.728,0.272,3.44,0.616,5.128,1.048c0.552,0.144,1.104,0.272,1.648,0.424c4.254,1.228,8.349,2.952,12.2,5.136\r\n\t\t\tc0.616,0.36,1.216,0.736,1.824,1.112c1.264,0.8,2.488,1.6,3.696,2.512c0.648,0.472,1.304,0.936,1.928,1.44\r\n\t\t\tc1.57,1.254,3.073,2.589,4.504,4c0.568,0.576,1.088,1.208,1.64,1.808c0.92,1,1.816,2.024,2.672,3.104\r\n\t\t\tc0.592,0.744,1.16,1.512,1.72,2.288c0.8,1.152,1.6,2.352,2.32,3.568c0.4,0.664,0.8,1.312,1.208,1.992\r\n\t\t\tc1.032,1.899,1.951,3.857,2.752,5.864c0.32,0.8,0.592,1.6,0.88,2.4c0.52,1.472,0.968,2.96,1.36,4.464\r\n\t\t\tc0.2,0.8,0.424,1.512,0.592,2.288c0.467,2.162,0.806,4.35,1.016,6.552c0.048,0.584,0.048,1.176,0.088,1.76\r\n\t\t\tC215.936,318.336,215.968,320.184,215.896,322.04z\"/><path d=\"M456,168h-25.16c-3.355,0.034-6.356-2.079-7.456-5.248c-2.481-7.431-5.483-14.679-8.984-21.688\r\n\t\t\tc-1.486-3.027-0.867-6.666,1.536-9.032l17.84-17.864c9.364-9.371,9.364-24.557,0-33.928L399.76,46.28\r\n\t\t\tc-9.371-9.364-24.557-9.364-33.928,0L348,64.104c-2.363,2.402-5.997,3.024-9.024,1.544c-7.01-3.519-14.26-6.537-21.696-9.032\r\n\t\t\tc-3.182-1.089-5.31-4.093-5.28-7.456V24c0-13.255-10.745-24-24-24h-48c-13.255,0-24,10.745-24,24v25.16\r\n\t\t\tc0.034,3.355-2.078,6.356-5.248,7.456c-7.432,2.494-14.68,5.51-21.688,9.024c-3.027,1.491-6.668,0.872-9.032-1.536l-17.864-17.84\r\n\t\t\tc-9.382-9.337-24.546-9.337-33.928,0L94.288,80.216c-9.369,9.372-9.369,24.564,0,33.936l26.232,26.28\r\n\t\t\tc3.173,3.074,8.238,2.994,11.312-0.18c2.999-3.096,3.006-8.012,0.016-11.116L105.6,102.864c-3.123-3.124-3.123-8.188,0-11.312\r\n\t\t\tL139.552,57.6c3.124-3.123,8.188-3.123,11.312,0l17.872,17.84c7.231,7.274,18.311,9.092,27.488,4.512\r\n\t\t\tc6.337-3.173,12.889-5.897,19.608-8.152c9.698-3.283,16.21-12.401,16.168-22.64V24c0-4.418,3.582-8,8-8h48c4.418,0,8,3.582,8,8\r\n\t\t\tv25.16c-0.041,10.237,6.471,19.352,16.168,22.632c6.722,2.256,13.277,4.982,19.616,8.16c9.179,4.556,20.244,2.736,27.48-4.52\r\n\t\t\tL377.136,57.6c3.124-3.123,8.188-3.123,11.312,0L422.4,91.56c3.118,3.123,3.118,8.181,0,11.304l-17.84,17.872\r\n\t\t\tc-7.267,7.235-9.084,18.31-4.512,27.488c3.173,6.337,5.897,12.889,8.152,19.608c3.281,9.7,12.4,16.212,22.64,16.168H456\r\n\t\t\tc4.418,0,8,3.582,8,8v48c0,4.418-3.582,8-8,8h-25.16c-10.237-0.041-19.352,6.471-22.632,16.168\r\n\t\t\tc-2.255,6.722-4.982,13.277-8.16,19.616c-4.564,9.178-2.743,20.247,4.52,27.48l17.84,17.872c3.123,3.124,3.123,8.188,0,11.312\r\n\t\t\tL388.44,374.4c-3.123,3.118-8.181,3.118-11.304,0l-26.288-26.232c-3.074-3.174-8.139-3.254-11.312-0.18\r\n\t\t\tc-3.174,3.074-3.254,8.139-0.18,11.312c0.064,0.066,0.13,0.132,0.196,0.196l26.28,26.232c9.371,9.364,24.557,9.364,33.928,0\r\n\t\t\tl33.952-33.944c9.369-9.372,9.369-24.564,0-33.936L415.896,300c-2.4-2.364-3.021-5.997-1.544-9.024\r\n\t\t\tc3.519-7.01,6.537-14.26,9.032-21.696c1.089-3.182,4.093-5.31,7.456-5.28H456c13.255,0,24-10.745,24-24v-48\r\n\t\t\tC480,178.745,469.255,168,456,168z\"/><path d=\"M337.536,142.464c-40.638-40.553-106.434-40.553-147.072,0c-3.069,3.178-2.981,8.243,0.197,11.312\r\n\t\t\tc3.1,2.994,8.015,2.994,11.115,0c34.135-34.596,89.852-34.969,124.448-0.834c34.596,34.135,34.969,89.852,0.834,124.448\r\n\t\t\tc-0.276,0.28-0.554,0.558-0.834,0.834c-3.178,3.07-3.266,8.134-0.196,11.312c3.07,3.178,8.134,3.266,11.312,0.196\r\n\t\t\tc0.066-0.064,0.132-0.13,0.196-0.196C378.089,248.898,378.089,183.102,337.536,142.464z\"/></svg>'></ion-icon>\r\n\r\n      \r\n    </ion-tab-button>\r\n\r\n    \r\n  </ion-tab-bar>\r\n\r\n</ion-tabs>\r\n";
      /***/
    },

    /***/
    "./src/app/tabs/tabs-routing.module.ts":
    /*!*********************************************!*\
      !*** ./src/app/tabs/tabs-routing.module.ts ***!
      \*********************************************/

    /*! exports provided: TabsPageRoutingModule */

    /***/
    function srcAppTabsTabsRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TabsPageRoutingModule", function () {
        return TabsPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _tabs_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./tabs.page */
      "./src/app/tabs/tabs.page.ts");

      var routes = [{
        path: 'tabs',
        component: _tabs_page__WEBPACK_IMPORTED_MODULE_3__["TabsPage"],
        children: [{
          path: 'home',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | home-home-module */
            [__webpack_require__.e("default~activitydetail-activitydetail-module~addamount-addamount-module~charitydetail-charitydetail-~e01b0d79"), __webpack_require__.e("home-home-module")]).then(__webpack_require__.bind(null,
            /*! ../home/home.module */
            "./src/app/home/home.module.ts")).then(function (m) {
              return m.HomePageModule;
            });
          }
        }, {
          path: 'home2',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | home2-home2-module */
            [__webpack_require__.e("common"), __webpack_require__.e("home2-home2-module")]).then(__webpack_require__.bind(null,
            /*! ../home2/home2.module */
            "./src/app/home2/home2.module.ts")).then(function (m) {
              return m.Home2PageModule;
            });
          }
        }, {
          path: 'profile',
          loadChildren: function loadChildren() {
            return __webpack_require__.e(
            /*! import() | profile-profile-module */
            "profile-profile-module").then(__webpack_require__.bind(null,
            /*! ../profile/profile.module */
            "./src/app/profile/profile.module.ts")).then(function (m) {
              return m.ProfilePageModule;
            });
          }
        }, {
          path: 'settings',
          loadChildren: function loadChildren() {
            return __webpack_require__.e(
            /*! import() | settings-settings-module */
            "settings-settings-module").then(__webpack_require__.bind(null,
            /*! ../settings/settings.module */
            "./src/app/settings/settings.module.ts")).then(function (m) {
              return m.SettingsPageModule;
            });
          }
        }, {
          path: 'settings',
          loadChildren: function loadChildren() {
            return __webpack_require__.e(
            /*! import() | settings-settings-module */
            "settings-settings-module").then(__webpack_require__.bind(null,
            /*! ../settings/settings.module */
            "./src/app/settings/settings.module.ts")).then(function (m) {
              return m.SettingsPageModule;
            });
          }
        }, {
          path: 'thetable',
          loadChildren: function loadChildren() {
            return __webpack_require__.e(
            /*! import() | thetable-thetable-module */
            "thetable-thetable-module").then(__webpack_require__.bind(null,
            /*! ../thetable/thetable.module */
            "./src/app/thetable/thetable.module.ts")).then(function (m) {
              return m.ThetablePageModule;
            });
          }
        }, {
          path: 'tribes',
          loadChildren: function loadChildren() {
            return Promise.all(
            /*! import() | tribes-tribes-module */
            [__webpack_require__.e("default~activitydetail-activitydetail-module~addamount-addamount-module~charitydetail-charitydetail-~e01b0d79"), __webpack_require__.e("tribes-tribes-module")]).then(__webpack_require__.bind(null,
            /*! ../tribes/tribes.module */
            "./src/app/tribes/tribes.module.ts")).then(function (m) {
              return m.TribesPageModule;
            });
          }
        }, {
          path: '',
          redirectTo: '/tabs/home',
          pathMatch: 'full'
        }]
      }, {
        path: '',
        redirectTo: '/tabs/home',
        pathMatch: 'full'
      }];

      var TabsPageRoutingModule = function TabsPageRoutingModule() {
        _classCallCheck(this, TabsPageRoutingModule);
      };

      TabsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], TabsPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/tabs/tabs.module.ts":
    /*!*************************************!*\
      !*** ./src/app/tabs/tabs.module.ts ***!
      \*************************************/

    /*! exports provided: TabsPageModule */

    /***/
    function srcAppTabsTabsModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TabsPageModule", function () {
        return TabsPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _tabs_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./tabs-routing.module */
      "./src/app/tabs/tabs-routing.module.ts");
      /* harmony import */


      var _tabs_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./tabs.page */
      "./src/app/tabs/tabs.page.ts");

      var TabsPageModule = function TabsPageModule() {
        _classCallCheck(this, TabsPageModule);
      };

      TabsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _tabs_routing_module__WEBPACK_IMPORTED_MODULE_5__["TabsPageRoutingModule"]],
        declarations: [_tabs_page__WEBPACK_IMPORTED_MODULE_6__["TabsPage"]]
      })], TabsPageModule);
      /***/
    },

    /***/
    "./src/app/tabs/tabs.page.scss":
    /*!*************************************!*\
      !*** ./src/app/tabs/tabs.page.scss ***!
      \*************************************/

    /*! exports provided: default */

    /***/
    function srcAppTabsTabsPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".tab-selected {\n  border-bottom: 2px solid var(--ion-color-primary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGFicy90YWJzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGlEQUFBO0FBQ0oiLCJmaWxlIjoic3JjL2FwcC90YWJzL3RhYnMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRhYi1zZWxlY3RlZCB7XHJcbiAgICBib3JkZXItYm90dG9tOiAycHggc29saWQgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG59Il19 */";
      /***/
    },

    /***/
    "./src/app/tabs/tabs.page.ts":
    /*!***********************************!*\
      !*** ./src/app/tabs/tabs.page.ts ***!
      \***********************************/

    /*! exports provided: TabsPage */

    /***/
    function srcAppTabsTabsPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TabsPage", function () {
        return TabsPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");

      var TabsPage = /*#__PURE__*/function () {
        function TabsPage() {
          _classCallCheck(this, TabsPage);
        }

        _createClass(TabsPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return TabsPage;
      }();

      TabsPage.ctorParameters = function () {
        return [];
      };

      TabsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-tabs',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./tabs.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/tabs/tabs.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./tabs.page.scss */
        "./src/app/tabs/tabs.page.scss"))["default"]]
      })], TabsPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=tabs-tabs-module-es5.js.map