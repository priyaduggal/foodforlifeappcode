(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["signup-signup-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/signup/signup.page.html":
    /*!*******************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/signup/signup.page.html ***!
      \*******************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppSignupSignupPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<!--ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>signup</ion-title>\r\n  </ion-toolbar>\r\n</ion-header-->\r\n\r\n<ion-content bg-white>\r\n\t<h2 class=\"vrt_txt\">Sign Up</h2>\r\n\t<div class=\"top-img-str\"></div>\r\n\t<div class=\"cont-login\">\t\t\r\n\t\t<div class=\"logo-top-al\">\r\n\t\t\t<img src=\"assets/images/logo.png\">\r\n\t\t</div>\r\n\t\t<div class=\"main-ttl\">\r\n\t\t\t<h3> Create an account </h3>\r\n\t\t\t<p> Fill Email Address to Signup </p>\r\n\t\t</div>\r\n\t\t<div class=\"flds-login\">\r\n\t\t\t<div formfield>\r\n\t\t\t\t<label>Email Address</label>\r\n\t\t\t\t<ion-item lines=\"none\" class=\"fls\"> \r\n\t\t\t\t\t<ion-input placeholder=\"Enter email address\"[(ngModel)]=\"signup_email\" name=\"signup_email\"  ></ion-input>\r\n\t\t\t\t</ion-item>\r\n\t\t\t\t<span error *ngIf=\"errors.indexOf(signup_email) >= 0 && is_submit_register == true\">Please enter your email address</span>\r\n\t\t\t\t<span error *ngIf=\"errors.indexOf(signup_email) == -1 && is_submit_register == true && !reg_exp.test(signup_email.toLowerCase())\">Please enter valid email address</span>\r\n\t\t\t</div>\r\n\t\t\t<div formfield style=\"margin-top:26px;\">\r\n\t\t\t\t<label>Password</label>\r\n\t\t\t\t<ion-item lines=\"none\" class=\"fls\"> \r\n\t\t\t\t\t<ion-input type=\"password\"\tplaceholder=\"Enter password\"[(ngModel)]=\"signup_password\" name=\"signup_password\"  ></ion-input>\r\n\t\t\t\t</ion-item>\r\n\t\t\t\t<span error *ngIf=\"errors.indexOf(signup_password) >= 0 && is_submit_register == true\">Please enter your password</span>\r\n\t\t\t</div>\r\n\t\t\t<ion-button expand=\"full\" shape=\"round\" class=\"btn-losns\" (click)=\"signup()\">Verify</ion-button>\r\n\t\t\t<div class=\"warning\">By signing up, you are agreeing to our Privacy and\r\n\t\t\t\tTerms of Use.</div>\r\n\t\t\t<div class=\"social_signup\">\r\n\t\t\t\t<h5>Or Sign Up With</h5>\r\n\t\t\t\t<div sociallink>\r\n\t\t\t\t<ion-buttons facebook  (click)=\"facebookLogin()\">\r\n\t\t\t\t<ion-icon name=\"logo-facebook\"></ion-icon>\r\n\t\t\t\t</ion-buttons>\r\n\t\t\t\t<ion-buttons google (click)=\"googleLogin()\">\r\n\t\t\t\t<ion-icon name=\"logo-google\"></ion-icon>\r\n\t\t\t\t</ion-buttons>\r\n\t\t\t</div>\r\n\t\t\t<p>Already have an account? <a href=\"javascript:void(0)\" routerLink=\"/login\">Login Here</a></p>\r\n\t\t\t</div>\r\n\t\t</div>\t\r\n\t</div>\r\n\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "./src/app/signup/signup-routing.module.ts":
    /*!*************************************************!*\
      !*** ./src/app/signup/signup-routing.module.ts ***!
      \*************************************************/

    /*! exports provided: SignupPageRoutingModule */

    /***/
    function srcAppSignupSignupRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SignupPageRoutingModule", function () {
        return SignupPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _signup_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./signup.page */
      "./src/app/signup/signup.page.ts");

      var routes = [{
        path: '',
        component: _signup_page__WEBPACK_IMPORTED_MODULE_3__["SignupPage"]
      }];

      var SignupPageRoutingModule = function SignupPageRoutingModule() {
        _classCallCheck(this, SignupPageRoutingModule);
      };

      SignupPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], SignupPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/signup/signup.module.ts":
    /*!*****************************************!*\
      !*** ./src/app/signup/signup.module.ts ***!
      \*****************************************/

    /*! exports provided: SignupPageModule */

    /***/
    function srcAppSignupSignupModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SignupPageModule", function () {
        return SignupPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _signup_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./signup-routing.module */
      "./src/app/signup/signup-routing.module.ts");
      /* harmony import */


      var _signup_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./signup.page */
      "./src/app/signup/signup.page.ts");

      var SignupPageModule = function SignupPageModule() {
        _classCallCheck(this, SignupPageModule);
      };

      SignupPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _signup_routing_module__WEBPACK_IMPORTED_MODULE_5__["SignupPageRoutingModule"]],
        declarations: [_signup_page__WEBPACK_IMPORTED_MODULE_6__["SignupPage"]]
      })], SignupPageModule);
      /***/
    },

    /***/
    "./src/app/signup/signup.page.scss":
    /*!*****************************************!*\
      !*** ./src/app/signup/signup.page.scss ***!
      \*****************************************/

    /*! exports provided: default */

    /***/
    function srcAppSignupSignupPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-content[bg-white] {\n  background: var(--ion-color-white);\n  --background:var( --ion-color-white);\n}\nion-content[bg-white] h2.vrt_txt {\n  transform: rotate(-90deg);\n  transform-origin: left;\n  bottom: 0;\n  text-align: left;\n  white-space: nowrap;\n  position: absolute;\n  font-size: 60px;\n  left: 48px;\n  text-transform: uppercase;\n  font-weight: 900;\n  color: rgba(239, 160, 7, 0.1);\n  z-index: 1;\n}\nion-content[bg-white] .top-img-str {\n  background: url('krishnadasHaiti.jpg');\n  height: 150px;\n  position: relative;\n  background-size: cover;\n  z-index: 0;\n  background-position: center;\n}\nion-content[bg-white] .top-img-str:after {\n  content: \"\";\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  background: var(--ion-color-black);\n  opacity: 0.35;\n}\nion-content[bg-white] .cont-login {\n  position: relative;\n  padding: 25px;\n  background: var(--ion-color-white);\n  border-radius: 30px;\n  margin-top: -30px;\n}\nion-content[bg-white] .cont-login .logo-top-al {\n  width: 110px;\n  height: 110px;\n  display: block;\n  margin: 0 auto;\n  text-align: center;\n  margin-top: -70px;\n  background: var(--ion-color-white);\n  border-radius: 50%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  box-shadow: 0px 2px 24px rgba(0, 0, 0, 0.1);\n  padding-top: 5px;\n  margin-bottom: 35px;\n}\nion-content[bg-white] .cont-login .logo-top-al img {\n  width: 56px;\n  height: auto;\n}\nion-content[bg-white] .cont-login .main-ttl {\n  text-align: center;\n  margin-bottom: 40px;\n}\nion-content[bg-white] .cont-login .main-ttl h3 {\n  margin: 0px;\n  font-size: 25px;\n  font-weight: 700;\n  color: #272727;\n}\nion-content[bg-white] .cont-login .main-ttl p {\n  margin: 0px;\n  font-size: 13px;\n  color: #9d9d9d;\n  margin-top: 7px;\n  font-weight: 500;\n  letter-spacing: 0.3px;\n}\nion-content[bg-white] .cont-login .flds-login {\n  position: relative;\n  z-index: 1;\n}\nion-content[bg-white] .cont-login .flds-login [formfield] {\n  position: relative;\n  border: 1px solid #e8e8e8;\n  height: 52px;\n  border-radius: 50px;\n  background: var(--ion-color-white);\n  padding: 0 16px;\n}\nion-content[bg-white] .cont-login .flds-login [formfield] label {\n  position: absolute;\n  top: -10px;\n  z-index: 111;\n  background: var(--ion-color-white);\n  left: 29px;\n  padding: 0 3px;\n  font-size: 12px;\n  font-weight: 700;\n  color: #3a3a3a;\n}\nion-content[bg-white] .cont-login .flds-login [formfield] ion-input {\n  padding: 0px;\n  --padding-start: 0px;\n  --padding-end: 0px;\n  font-size: 14px;\n  --placeholder-color: #9a9a9a;\n  --placeholder-opacity: 1;\n  font-family: \"Poppins\", sans-serif !important;\n  color: #222;\n}\nion-content[bg-white] .cont-login .flds-login .btn-losns {\n  --background:var( --ion-color-primary);\n  margin-top: 20px;\n  --box-shadow: none;\n  min-height: 48px;\n  margin-bottom: 15px;\n  text-transform: uppercase;\n  letter-spacing: 1px;\n}\nion-content[bg-white] .cont-login .flds-login .warning {\n  color: #c2c2c2;\n  text-align: center;\n  margin: 0 4px;\n  font-size: 13px;\n}\nion-content[bg-white] .cont-login .flds-login .social_signup {\n  text-align: center;\n  margin-top: 40px;\n}\nion-content[bg-white] .cont-login .flds-login .social_signup [sociallink] {\n  justify-content: center;\n  display: flex;\n  align-items: center;\n  margin-top: 10px;\n}\nion-content[bg-white] .cont-login .flds-login .social_signup [sociallink] ion-buttons {\n  curspor: pointer;\n}\nion-content[bg-white] .cont-login .flds-login .social_signup [sociallink] ion-buttons[facebook] {\n  width: 40px;\n  height: 40px;\n  background: #3c5a98;\n  color: var(--ion-color-white);\n  border-radius: 50%;\n  text-align: center;\n  justify-content: center;\n  margin-right: 10px;\n}\nion-content[bg-white] .cont-login .flds-login .social_signup [sociallink] ion-buttons[google] {\n  width: 40px;\n  height: 40px;\n  background: #d2412c;\n  color: var(--ion-color-white);\n  border-radius: 50%;\n  text-align: center;\n  justify-content: center;\n}\nion-content[bg-white] .cont-login .flds-login .social_signup h5 {\n  font-size: 14px;\n  text-align: center;\n  display: inline-block;\n  position: relative;\n  color: #878686;\n}\nion-content[bg-white] .cont-login .flds-login .social_signup h5:after {\n  content: \"\";\n  display: block;\n  height: 1px;\n  width: 30px;\n  background: #878686;\n  position: absolute;\n  right: -40px;\n  top: 10px;\n}\nion-content[bg-white] .cont-login .flds-login .social_signup h5:before {\n  content: \"\";\n  display: block;\n  height: 1px;\n  width: 30px;\n  background: #878686;\n  position: absolute;\n  left: -40px;\n  top: 10px;\n}\n[error] {\n  color: red !important;\n  font-size: 12px;\n  padding-left: 12px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2lnbnVwL3NpZ251cC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQyxrQ0FBQTtFQUNBLG9DQUFBO0FBQ0Q7QUFDQztFQUNDLHlCQUFBO0VBQ00sc0JBQUE7RUFDQSxTQUFBO0VBQ0EsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLFVBQUE7RUFDQSx5QkFBQTtFQUNBLGdCQUFBO0VBQ0EsNkJBQUE7RUFDQSxVQUFBO0FBQ1I7QUFDQztFQUNDLHNDQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7RUFDQSxVQUFBO0VBQ0EsMkJBQUE7QUFDRjtBQUFFO0VBQ0MsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxNQUFBO0VBQ0EsU0FBQTtFQUNBLGtDQUFBO0VBQ0EsYUFBQTtBQUVIO0FBQ0M7RUFDQyxrQkFBQTtFQUNBLGFBQUE7RUFDQSxrQ0FBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7QUFDRjtBQUFFO0VBQ0MsWUFBQTtFQUNBLGFBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSwyQ0FBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUFFSDtBQURHO0VBQ0MsV0FBQTtFQUNBLFlBQUE7QUFHSjtBQUFFO0VBQ0Msa0JBQUE7RUFDQSxtQkFBQTtBQUVIO0FBREc7RUFDQyxXQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQUdKO0FBREc7RUFDQyxXQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxxQkFBQTtBQUdKO0FBQUU7RUFDQSxrQkFBQTtFQUNBLFVBQUE7QUFFRjtBQURFO0VBQ0Msa0JBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGtDQUFBO0VBQ0EsZUFBQTtBQUdIO0FBRkc7RUFDQyxrQkFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0VBQ0Esa0NBQUE7RUFDQSxVQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7QUFJSjtBQUZHO0VBQ0MsWUFBQTtFQUNBLG9CQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsNEJBQUE7RUFDQSx3QkFBQTtFQUNBLDZDQUFBO0VBQ0EsV0FBQTtBQUlKO0FBREU7RUFDQyxzQ0FBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDUyxnQkFBQTtFQUNULG1CQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtBQUdIO0FBREU7RUFDQyxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtBQUdIO0FBREU7RUFDQyxrQkFBQTtFQUNBLGdCQUFBO0FBR0g7QUFGRztFQUNDLHVCQUFBO0VBQ0QsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7QUFJSDtBQUhHO0VBQ0MsZ0JBQUE7QUFLSjtBQUpJO0VBRUEsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0VBQ0Esa0JBQUE7QUFLSjtBQUpLO0VBRUQsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0FBS0o7QUFERztFQUFHLGVBQUE7RUFDRixrQkFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FBSUo7QUFISTtFQUNDLFdBQUE7RUFDQSxjQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFNBQUE7QUFLTDtBQUhJO0VBQ0MsV0FBQTtFQUNBLGNBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtBQUtMO0FBR0E7RUFFQSxxQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtBQURBIiwiZmlsZSI6InNyYy9hcHAvc2lnbnVwL3NpZ251cC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudFtiZy13aGl0ZV0ge1xyXG5cdGJhY2tncm91bmQ6dmFyKCAtLWlvbi1jb2xvci13aGl0ZSk7XHJcblx0LS1iYWNrZ3JvdW5kOnZhciggLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cclxuXHRoMi52cnRfdHh0IHtcclxuXHRcdHRyYW5zZm9ybTogcm90YXRlKC05MGRlZyk7XHJcbiAgICAgICAgdHJhbnNmb3JtLW9yaWdpbjogbGVmdDtcclxuICAgICAgICBib3R0b206IDA7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgICAgICB3aGl0ZS1zcGFjZTogbm93cmFwO1xyXG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICBmb250LXNpemU6IDYwcHg7XHJcbiAgICAgICAgbGVmdDogNDhweDtcclxuICAgICAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiA5MDA7XHJcbiAgICAgICAgY29sb3I6IHJnYmEoMjM5LCAxNjAsIDcsIDAuMSk7XHJcbiAgICAgICAgei1pbmRleDogMTtcclxuXHR9XHJcblx0LnRvcC1pbWctc3RyIHtcclxuXHRcdGJhY2tncm91bmQ6dXJsKFwiLi4vLi4vYXNzZXRzL2ltYWdlcy9rcmlzaG5hZGFzSGFpdGkuanBnXCIpO1xyXG5cdFx0aGVpZ2h0OjE1MHB4O1xyXG5cdFx0cG9zaXRpb246IHJlbGF0aXZlO1xyXG5cdFx0YmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxuXHRcdHotaW5kZXg6IDA7XHJcblx0XHRiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XHJcblx0XHQmOmFmdGVyIHtcclxuXHRcdFx0Y29udGVudDogXCJcIjtcclxuXHRcdFx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdFx0XHRsZWZ0OiAwO1xyXG5cdFx0XHRyaWdodDogMDtcclxuXHRcdFx0dG9wOiAwO1xyXG5cdFx0XHRib3R0b206IDA7XHJcblx0XHRcdGJhY2tncm91bmQ6IHZhciggLS1pb24tY29sb3ItYmxhY2spO1xyXG5cdFx0XHRvcGFjaXR5OiAwLjM1O1xyXG5cdFx0fVxyXG5cdH1cclxuXHQuY29udC1sb2dpbiB7XHJcblx0XHRwb3NpdGlvbjogcmVsYXRpdmU7XHJcblx0XHRwYWRkaW5nOiAyNXB4O1xyXG5cdFx0YmFja2dyb3VuZDogdmFyKCAtLWlvbi1jb2xvci13aGl0ZSk7XHJcblx0XHRib3JkZXItcmFkaXVzOiAzMHB4O1xyXG5cdFx0bWFyZ2luLXRvcDogLTMwcHg7XHJcblx0XHQubG9nby10b3AtYWwge1xyXG5cdFx0XHR3aWR0aDogMTEwcHg7XHJcblx0XHRcdGhlaWdodDogMTEwcHg7XHJcblx0XHRcdGRpc3BsYXk6IGJsb2NrO1xyXG5cdFx0XHRtYXJnaW46IDAgYXV0bztcclxuXHRcdFx0dGV4dC1hbGlnbjogY2VudGVyO1xyXG5cdFx0XHRtYXJnaW4tdG9wOiAtNzBweDtcclxuXHRcdFx0YmFja2dyb3VuZDp2YXIoIC0taW9uLWNvbG9yLXdoaXRlKTtcclxuXHRcdFx0Ym9yZGVyLXJhZGl1czogNTAlO1xyXG5cdFx0XHRkaXNwbGF5OiBmbGV4O1xyXG5cdFx0XHRhbGlnbi1pdGVtczogY2VudGVyO1xyXG5cdFx0XHRqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHRcdFx0Ym94LXNoYWRvdzogMHB4IDJweCAyNHB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuXHRcdFx0cGFkZGluZy10b3A6IDVweDtcclxuXHRcdFx0bWFyZ2luLWJvdHRvbTogMzVweDtcclxuXHRcdFx0aW1nIHtcclxuXHRcdFx0XHR3aWR0aDogNTZweDtcclxuXHRcdFx0XHRoZWlnaHQ6IGF1dG87XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHRcdC5tYWluLXR0bCB7XHJcblx0XHRcdHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHRcdFx0bWFyZ2luLWJvdHRvbTogNDBweDtcclxuXHRcdFx0aDMge1xyXG5cdFx0XHRcdG1hcmdpbjogMHB4O1xyXG5cdFx0XHRcdGZvbnQtc2l6ZTogMjVweDtcclxuXHRcdFx0XHRmb250LXdlaWdodDogNzAwO1xyXG5cdFx0XHRcdGNvbG9yOiAjMjcyNzI3O1xyXG5cdFx0XHR9XHJcblx0XHRcdHAge1xyXG5cdFx0XHRcdG1hcmdpbjogMHB4O1xyXG5cdFx0XHRcdGZvbnQtc2l6ZTogMTNweDtcclxuXHRcdFx0XHRjb2xvcjogIzlkOWQ5ZDtcclxuXHRcdFx0XHRtYXJnaW4tdG9wOiA3cHg7XHJcblx0XHRcdFx0Zm9udC13ZWlnaHQ6IDUwMDtcclxuXHRcdFx0XHRsZXR0ZXItc3BhY2luZzogMC4zcHg7XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHRcdC5mbGRzLWxvZ2lue1x0XHRcclxuXHRcdHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHRcdHotaW5kZXg6IDE7XHJcblx0XHRbZm9ybWZpZWxkXSB7XHJcblx0XHRcdHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHRcdFx0Ym9yZGVyOiAxcHggc29saWQgI2U4ZThlODtcclxuXHRcdFx0aGVpZ2h0OiA1MnB4O1xyXG5cdFx0XHRib3JkZXItcmFkaXVzOiA1MHB4O1xyXG5cdFx0XHRiYWNrZ3JvdW5kOnZhciggLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdFx0XHRwYWRkaW5nOiAwIDE2cHg7XHJcblx0XHRcdGxhYmVsIHtcclxuXHRcdFx0XHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0XHRcdFx0dG9wOiAtMTBweDtcclxuXHRcdFx0XHR6LWluZGV4OiAxMTE7XHJcblx0XHRcdFx0YmFja2dyb3VuZDogdmFyKCAtLWlvbi1jb2xvci13aGl0ZSk7XHJcblx0XHRcdFx0bGVmdDogMjlweDtcclxuXHRcdFx0XHRwYWRkaW5nOiAwIDNweDtcclxuXHRcdFx0XHRmb250LXNpemU6IDEycHg7XHJcblx0XHRcdFx0Zm9udC13ZWlnaHQ6IDcwMDtcclxuXHRcdFx0XHRjb2xvcjogIzNhM2EzYTtcclxuXHRcdFx0fVxyXG5cdFx0XHRpb24taW5wdXQgIHtcclxuXHRcdFx0XHRwYWRkaW5nOiAwcHg7XHJcblx0XHRcdFx0LS1wYWRkaW5nLXN0YXJ0OiAwcHg7XHJcblx0XHRcdFx0LS1wYWRkaW5nLWVuZDogMHB4O1xyXG5cdFx0XHRcdGZvbnQtc2l6ZTogMTRweDtcclxuXHRcdFx0XHQtLXBsYWNlaG9sZGVyLWNvbG9yOiAjOWE5YTlhO1xyXG5cdFx0XHRcdC0tcGxhY2Vob2xkZXItb3BhY2l0eTogMTtcclxuXHRcdFx0XHRmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XHJcblx0XHRcdFx0Y29sb3I6ICMyMjI7XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHRcdC5idG4tbG9zbnN7XHJcblx0XHRcdC0tYmFja2dyb3VuZDp2YXIoIC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG5cdFx0XHRtYXJnaW4tdG9wOiAyMHB4O1xyXG5cdFx0XHQtLWJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICAgICAgICAgIG1pbi1oZWlnaHQ6IDQ4cHg7XHJcblx0XHRcdG1hcmdpbi1ib3R0b206IDE1cHg7XHJcblx0XHRcdHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcblx0XHRcdGxldHRlci1zcGFjaW5nOiAxcHg7XHJcblx0XHR9XHJcblx0XHQud2FybmluZ3tcclxuXHRcdFx0Y29sb3I6ICNjMmMyYzI7XHJcblx0XHRcdHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHRcdFx0bWFyZ2luOiAwIDRweDtcclxuXHRcdFx0Zm9udC1zaXplOiAxM3B4O1xyXG5cdFx0fVxyXG5cdFx0LnNvY2lhbF9zaWdudXB7XHJcblx0XHRcdHRleHQtYWxpZ246Y2VudGVyO1xyXG5cdFx0XHRtYXJnaW4tdG9wOjQwcHg7XHJcblx0XHRcdFtzb2NpYWxsaW5rXVxyXG5cdFx0XHR7anVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcblx0XHRcdGRpc3BsYXk6ZmxleDtcclxuXHRcdFx0YWxpZ24taXRlbXM6Y2VudGVyO1xyXG5cdFx0XHRtYXJnaW4tdG9wOjEwcHg7XHJcblx0XHRcdGlvbi1idXR0b25zXHJcblx0XHRcdHtjdXJzcG9yOnBvaW50ZXI7XHJcblx0XHRcdCAmW2ZhY2Vib29rXVxyXG5cdFx0XHQge1xyXG5cdFx0XHRcdHdpZHRoOiA0MHB4O1xyXG5cdFx0XHRcdGhlaWdodDogNDBweDtcclxuXHRcdFx0XHRiYWNrZ3JvdW5kOiAjM2M1YTk4O1xyXG5cdFx0XHRcdGNvbG9yOnZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcblx0XHRcdFx0Ym9yZGVyLXJhZGl1czogNTAlO1xyXG5cdFx0XHRcdHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHRcdFx0XHRqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuXHRcdFx0XHRtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcblx0XHRcdH0gJltnb29nbGVdXHJcblx0XHRcdCB7XHJcblx0XHRcdFx0d2lkdGg6IDQwcHg7XHJcblx0XHRcdFx0aGVpZ2h0OiA0MHB4O1xyXG5cdFx0XHRcdGJhY2tncm91bmQ6ICNkMjQxMmM7XHJcblx0XHRcdFx0Y29sb3I6dmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuXHRcdFx0XHRib3JkZXItcmFkaXVzOiA1MCU7XHJcblx0XHRcdFx0dGV4dC1hbGlnbjogY2VudGVyO1xyXG5cdFx0XHRcdGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG5cdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0XHRoNXtmb250LXNpemU6IDE0cHg7XHJcblx0XHRcdFx0dGV4dC1hbGlnbjpjZW50ZXI7XHJcblx0XHRcdFx0ZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG5cdFx0XHRcdHBvc2l0aW9uOnJlbGF0aXZlO1xyXG5cdFx0XHRcdGNvbG9yOiM4Nzg2ODY7XHJcblx0XHRcdFx0JjphZnRlcntcclxuXHRcdFx0XHRcdGNvbnRlbnQ6IFwiXCI7XHJcblx0XHRcdFx0XHRkaXNwbGF5OiBibG9jaztcclxuXHRcdFx0XHRcdGhlaWdodDogMXB4O1xyXG5cdFx0XHRcdFx0d2lkdGg6IDMwcHg7XHJcblx0XHRcdFx0XHRiYWNrZ3JvdW5kOiAjODc4Njg2O1xyXG5cdFx0XHRcdFx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdFx0XHRcdFx0cmlnaHQ6IC00MHB4O1xyXG5cdFx0XHRcdFx0dG9wOiAxMHB4O1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0XHQmOmJlZm9yZXtcclxuXHRcdFx0XHRcdGNvbnRlbnQ6IFwiXCI7XHJcblx0XHRcdFx0XHRkaXNwbGF5OiBibG9jaztcclxuXHRcdFx0XHRcdGhlaWdodDogMXB4O1xyXG5cdFx0XHRcdFx0d2lkdGg6IDMwcHg7XHJcblx0XHRcdFx0XHRiYWNrZ3JvdW5kOiAjODc4Njg2O1xyXG5cdFx0XHRcdFx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdFx0XHRcdFx0bGVmdDogLTQwcHg7XHJcblx0XHRcdFx0XHR0b3A6IDEwcHg7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0fVxyXG5cdFx0XHJcblx0fVxyXG59XHJcbltlcnJvcl1cclxue1xyXG5jb2xvcjpyZWQgIWltcG9ydGFudDtcclxuZm9udC1zaXplOjEycHg7XHJcbnBhZGRpbmctbGVmdDoxMnB4O1xyXG59Il19 */";
      /***/
    },

    /***/
    "./src/app/signup/signup.page.ts":
    /*!***************************************!*\
      !*** ./src/app/signup/signup.page.ts ***!
      \***************************************/

    /*! exports provided: SignupPage */

    /***/
    function srcAppSignupSignupPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "SignupPage", function () {
        return SignupPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../services/api/api.service */
      "./src/app/services/api/api.service.ts");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../config */
      "./src/app/config.ts");
      /* harmony import */


      var _common_common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../common/common.service */
      "./src/app/common/common.service.ts");
      /* harmony import */


      var _ionic_native_facebook_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic-native/facebook/ngx */
      "./node_modules/@ionic-native/facebook/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @ionic-native/google-plus/ngx */
      "./node_modules/@ionic-native/google-plus/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _services_globalFooService_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ../services/globalFooService.service */
      "./src/app/services/globalFooService.service.ts");

      var SignupPage = /*#__PURE__*/function () {
        function SignupPage(globalFooService, fb, googlePlus, api, router, common) {
          _classCallCheck(this, SignupPage);

          this.globalFooService = globalFooService;
          this.fb = fb;
          this.googlePlus = googlePlus;
          this.api = api;
          this.router = router;
          this.common = common;
          this.is_submit_register = false;
          this.errors = ['', null, undefined];
          this.reg_exp = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        }

        _createClass(SignupPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "ionViewDidEnter",
          value: function ionViewDidEnter() {
            this.type_login = localStorage.getItem('type_login');
          }
        }, {
          key: "facebookLogin",
          value: function facebookLogin() {
            var _this = this;

            this.fb.login(['public_profile', 'email']).then(function (res) {
              return _this.fb.api('me?fields=id,name,email,first_name,last_name,picture.width(720).height(720).as(picture_large)', []).then(function (profile) {
                console.log('profile', profile);

                if (_this.errors.indexOf(profile) == -1) {
                  var dict = {
                    first_name: profile['first_name'],
                    //last_name: profile['last_name'],
                    email: profile['email'],
                    password: '',
                    medium: 'facebook',
                    type: _this.type_login,
                    social_id: profile['id'],
                    image: profile['picture_large']['data']['url']
                  };
                  console.log('dict', dict);

                  _this.finalSignup(dict);
                } else {
                  _this.common.presentToast('Error,Please try after some time', 'danger');
                }
              });
            })["catch"](function (e) {
              _this.common.presentToast('Error,Please try after some time', 'danger');

              console.log(e);
            });
          }
        }, {
          key: "googleLogin",
          //Google social login 
          value: function googleLogin() {
            var _this2 = this;

            console.log(this.googlePlus);
            this.googlePlus.login({
              'scopes': 'profile'
            }).then(function (profile) {
              console.log(profile);

              if (_this2.errors.indexOf(profile) == -1) {
                var dict = {
                  first_name: profile['displayName'],
                  email: profile['email'],
                  password: '',
                  medium: 'google',
                  social_id: profile['userId'],
                  type: _this2.type_login,
                  image: !profile['imageUrl'] ? '' : profile['imageUrl']
                };
                console.log('dict', dict);

                _this2.finalSignup(dict);
              }
            })["catch"](function (err) {
              console.error(err);

              _this2.common.presentToast('Error,Please try after some time', 'danger');
            });
          }
        }, {
          key: "finalSignup",
          value: function finalSignup(dict) {
            var _this3 = this;

            this.common.presentLoading(); // this.fcm.getToken().then(token => {

            this.api.post('social_login', dict, '').subscribe(function (result) {
              _this3.common.stopLoading();

              var res;
              res = result;

              if (res.status == 1) {
                var userId = _this3.api.encryptData(res.data.id, _config__WEBPACK_IMPORTED_MODULE_4__["config"].ENC_SALT);

                localStorage.setItem('userid', res.data.id);
                localStorage.setItem('food_token', userId);
                localStorage.setItem('food_first_name', res.data.first_name);
                localStorage.setItem('food_last_name', res.data.last_name);
                localStorage.setItem('food_email', res.data.email);
                localStorage.setItem('food_type', res.data.type);
                localStorage.setItem('profile_pic', res.data.image);

                _this3.globalFooService.publishSomeData({
                  foo: {
                    'data': res.data
                  }
                });

                _this3.common.presentToast('Login successfully!', 'success');

                _this3.api.navCtrl.navigateRoot('tabs/home');
              } else {
                _this3.common.presentToast('Error while signing up! Please try later', 'danger');
              }
            }, function (err) {
              _this3.common.stopLoading();

              _this3.common.presentToast('Technical error,Please try after some time', 'danger');
            }); // });
          }
        }, {
          key: "signup",
          value: function signup() {
            var _this4 = this;

            this.is_submit_register = true;

            if (this.errors.indexOf(this.signup_email) >= 0 || this.errors.indexOf(this.signup_password) >= 0 || !this.reg_exp.test(String(this.signup_email).toLowerCase())) {
              return false;
            }

            var dict = {
              email: this.signup_email,
              password: this.signup_password,
              type: this.type_login
            };
            this.common.presentLoading();
            this.api.post('SignupUser', dict, '').subscribe(function (result) {
              _this4.common.stopLoading();

              var res;
              res = result;

              if (res.status == 1) {
                _this4.signup_email = '';
                _this4.signup_password = '';

                _this4.router.navigate(['/otp']);

                localStorage.setItem('otp_verify', res.otp);
                localStorage.setItem('signup_data', res.data.id);

                _this4.common.presentToast('OTP for email confirmation has been sent successfully!.', 'success');
              } else {
                _this4.common.presentToast(res.message, 'danger');
              }
            }, function (err) {});
          }
        }]);

        return SignupPage;
      }();

      SignupPage.ctorParameters = function () {
        return [{
          type: _services_globalFooService_service__WEBPACK_IMPORTED_MODULE_8__["GlobalFooService"]
        }, {
          type: _ionic_native_facebook_ngx__WEBPACK_IMPORTED_MODULE_6__["Facebook"]
        }, {
          type: _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_7__["GooglePlus"]
        }, {
          type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
        }, {
          type: _common_common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"]
        }];
      };

      SignupPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-signup',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./signup.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/signup/signup.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./signup.page.scss */
        "./src/app/signup/signup.page.scss"))["default"]]
      })], SignupPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=signup-signup-module-es5.js.map