(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html":
    /*!***************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
      \***************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppHomeHomePageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<!--ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>home</ion-title>\r\n  </ion-toolbar>\r\n</ion-header-->\r\n<ion-content home-page *ngIf=\"type_login==2\">\r\n     <ion-header>\r\n      <ion-toolbar>\r\n        <ion-buttons slot=\"start\">\r\n          <ion-menu-button></ion-menu-button>\r\n        </ion-buttons>\r\n        <ion-title>Goals</ion-title>\r\n\t\t<!--ion-buttons mr-10 (click)=\"presentModal()\" slot=\"end\">\r\n\t\t  <img height=\"22px\" src=\"assets/images/jar.png\"/>\r\n\t\t</ion-buttons-->\r\n      </ion-toolbar>\r\n\t  </ion-header>\r\n      <ion-slides #slideWithNav [options]=\"slideOptsOne\"   pager=\"true\" class=\"home-slider\">\r\n    \r\n    <ion-slide  hm-slider  *ngFor=\"let charity of list\"  routerLink=\"/charitydetail/{{charity?.id}}\">\r\n      <img src=\"{{IMAGES_URL}}/{{charity?.image}}\" style=\"width:100%;\"/>\r\n      <div class=\"sld_cnt\">\r\n        <div>\r\n        <h3>{{charity?.title}}</h3>\r\n        <p>{{charity?.description.substring(0,100)}}...</p>\r\n\t\t<ion-row>\r\n\t\t<!--><ion-col size=\"6\">\r\n        <ion-button shape=\"round\">Give Now</ion-button>\r\n\t\t</ion-col></-->\r\n\t\t<ion-col size=\"12\" class=\"ion-no-padding\">\r\n\t\t<p class=\"ion-text-left\"><b>{{charity?.meals}} Meals</b></p>\r\n\t\t</ion-col>\r\n\t\t</ion-row>\r\n      </div>\r\n      </div>\r\n    </ion-slide>\r\n    \r\n  </ion-slides>\r\n<ion-row>\r\n\r\n\r\n  <ion-col size=\"12\" class=\"ion-padding-start ion-padding-end\"> \r\n    <div class=\"donationjar\">\r\n      <h3><span>Donation</span> Jar</h3>\r\n  \r\n\t  <div donationimg>\r\n\t   <img src=\"assets/images/don.gif\"/>\r\n\t  </div>\r\n     <!--p>Please press button below to donate 25 cents</p-->\r\n     <p>Click here to feed a child</p>\r\n\t <p>Each meal is only 25 cents</p>\r\n<ion-button  expand=\"full\" shape=\"round\" class=\"btn-losns\" (click)=\"give_in()\">Give Now</ion-button>\r\n<span>To Donate More <a href=\"javasctipt:void(0)\"(click)=\"give_in()\">Click Here</a> </span>     \r\n    </div>\r\n  </ion-col>\r\n</ion-row>\r\n\r\n</ion-content>\r\n\r\n<ion-content home-page    *ngIf=\"type_login==1\">\r\n     <ion-header>\r\n      <ion-toolbar>\r\n        <ion-buttons slot=\"start\">\r\n          <ion-menu-button></ion-menu-button>\r\n        </ion-buttons>\r\n        <ion-title>Goals</ion-title>\r\n\t\t<ion-buttons mr-10 (click)=\"presentModal()\" slot=\"end\">\r\n\t\t  <img height=\"22px\" src=\"assets/images/jar.png\"/>\r\n\t\t</ion-buttons>\r\n      </ion-toolbar>\r\n\t  </ion-header>\r\n      <ion-slides #slideWithNav [options]=\"slideOptsOne\"  (ionSlideWillChange)=\"onSlideChangeStart($event)\" (ionSlideDidChange)=\"onSlideChanged($event)\" pager=\"true\" class=\"home-slider\">\r\n    \r\n    <ion-slide  hm-slider *ngFor=\"let charity of list\">\r\n      <img src=\"{{IMAGES_URL}}/{{charity?.image}}\" style=\"width:100%;\"/>\r\n      <div class=\"sld_cnt\">\r\n        <div>\r\n        <h3 routerLink=\"/charitydetail/{{charity?.id}}\">{{charity?.title}}</h3>\r\n        <p>{{charity?.description.substring(0,100)}}...</p>\r\n\t\t<ion-row>\r\n\t\t<ion-col size=\"6\">\r\n        <ion-button shape=\"round\" (click)=\"give(charity?.id)\">Give Now</ion-button>\r\n\t\t</ion-col>\r\n\t\t<ion-col size=\"6\">\r\n\t\t<p class=\"ion-text-right\"><b>{{charity?.meals}} Meals</b></p>\r\n\t\t</ion-col>\r\n\t\t</ion-row>\r\n      </div>\r\n      </div>\r\n    </ion-slide>\r\n   \r\n  </ion-slides>\r\n<ion-row>\r\n\r\n\r\n  <ion-col size=\"12\" class=\"ion-padding-start ion-padding-end\"> \r\n    <div class=\"service_box home_page\"> \r\n\t<h2 heads>Get Certified For Doing Good</h2>\r\n\t<ion-slides #slideWithNav [options]=\"slideOptsOne\"  (ionSlideWillChange)=\"onSlideChangeStart($event)\" (ionSlideDidChange)=\"onSlideChanged($event)\" pager=\"true\" class=\"home-slider\" loop=\"false\" >\r\n\t<ion-slide>\r\n    <div class=\"width100\"> \r\n      <h3><span>Feed </span>  A Child</h3>\r\n      <!--p>Show that your company cares</p-->\r\n\t  <div omgcertify>\r\n\t   <img src=\"assets/images/omg.png\"/>\r\n\t  </div>\r\n      <ion-button shape=\"round\" fill=\"outline\" href=\"https://omguarantee.com/company-registration/\">Get Certified</ion-button>\r\n    </div>\r\n\t  </ion-slide>\r\n     </ion-slides>\r\n    </div>\r\n  </ion-col>\r\n</ion-row>\r\n<ion-row>\r\n\r\n\r\n  <ion-col size=\"12\" class=\"ion-padding-start ion-padding-end\"> \r\n    <div class=\"donationjar\">\r\n      <h3><span>Donation</span> Jar</h3>\r\n  \r\n\t  <div donationimg>\r\n\t   <img src=\"assets/images/don.gif\"/>\r\n\t  </div>\r\n     <!--p>Please press button below to donate 25 cents</p-->\r\n     <p>Click here to feed a child</p>\r\n\t  <p>Each meal is only 25 cents</p>\r\n<ion-button  expand=\"full\" shape=\"round\" class=\"btn-losns\" (click)=\"give_in()\">Give Now</ion-button>\r\n<span>To Donate More <a href=\"javasctipt:void(0)\"(click)=\"give_in()\">Click Here</a> </span>     \r\n    </div>\r\n  </ion-col>\r\n</ion-row>\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "./src/app/home/home-routing.module.ts":
    /*!*********************************************!*\
      !*** ./src/app/home/home-routing.module.ts ***!
      \*********************************************/

    /*! exports provided: HomePageRoutingModule */

    /***/
    function srcAppHomeHomeRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePageRoutingModule", function () {
        return HomePageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _home_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./home.page */
      "./src/app/home/home.page.ts");

      var routes = [{
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_3__["HomePage"]
      }];

      var HomePageRoutingModule = function HomePageRoutingModule() {
        _classCallCheck(this, HomePageRoutingModule);
      };

      HomePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], HomePageRoutingModule);
      /***/
    },

    /***/
    "./src/app/home/home.module.ts":
    /*!*************************************!*\
      !*** ./src/app/home/home.module.ts ***!
      \*************************************/

    /*! exports provided: HomePageModule */

    /***/
    function srcAppHomeHomeModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePageModule", function () {
        return HomePageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _home_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./home-routing.module */
      "./src/app/home/home-routing.module.ts");
      /* harmony import */


      var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./home.page */
      "./src/app/home/home.page.ts");

      var HomePageModule = function HomePageModule() {
        _classCallCheck(this, HomePageModule);
      };

      HomePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _home_routing_module__WEBPACK_IMPORTED_MODULE_5__["HomePageRoutingModule"]],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
      })], HomePageModule);
      /***/
    },

    /***/
    "./src/app/home/home.page.scss":
    /*!*************************************!*\
      !*** ./src/app/home/home.page.scss ***!
      \*************************************/

    /*! exports provided: default */

    /***/
    function srcAppHomeHomePageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "[home-page] {\n  margin: 0 10px !important;\n  --background: #f3f3f3;\n}\n[home-page] ion-header {\n  position: absolute;\n}\n[home-page] ion-header ion-toolbar {\n  --background: transparent;\n  --border-width: 0;\n}\n[home-page] ion-header ion-toolbar ion-buttons {\n  color: var(--ion-color-white);\n}\n[home-page] ion-header ion-toolbar ion-buttons[mr-10] {\n  margin-right: 10px;\n}\n[home-page] ion-header ion-toolbar ion-title {\n  color: var(--ion-color-white);\n  text-align: center;\n  font-style: normal;\n  font-family: \"Poppins\", sans-serif !important;\n}\n[home-page] ion-header::after {\n  display: none;\n}\n[home-page] .home-slider [hm-slider] {\n  --bullet-background:#dcdcdc;\n  --bullet-background-active:var(--ion-color-primary);\n  display: block;\n  text-align: left;\n  border-radius: 0px 0px 20px 20px;\n  overflow: hidden;\n}\n[home-page] .home-slider [hm-slider] img {\n  border-radius: 0px 0px 20px 20px;\n  height: 65vh;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n[home-page] .home-slider [hm-slider] .sld_cnt {\n  position: absolute;\n  left: 0;\n  right: 0;\n  bottom: 7px;\n  top: 0;\n  background: rgba(0, 0, 0, 0.6);\n  color: var(--ion-color-white);\n  padding: 25px 25px 40px 25px;\n  display: flex;\n  align-items: flex-end;\n  border-radius: 0 0 20px 20px;\n}\n[home-page] .home-slider [hm-slider] .sld_cnt h3 {\n  font-size: 16px;\n}\n[home-page] .home-slider [hm-slider] .sld_cnt p {\n  font-size: 12px;\n  color: var(--ion-color-white);\n  margin: 10px 0;\n}\n[home-page] .home-slider [hm-slider] .sld_cnt ion-button {\n  font-size: 12px;\n  --padding-start: 30px;\n  --padding-end: 25px;\n  letter-spacing: 0.7px;\n  --background:var(--ion-color-primary);\n  margin: 0;\n}\n[home-page] .home-slider .swiper-pagination {\n  --scroll-bar-background: red;\n}\n[home-page] .service_box {\n  padding: 25px 8px 0px;\n  border-radius: 10px;\n  background-color: var(--ion-color-white);\n  position: relative;\n  color: var(--ion-color-black);\n  text-align: center;\n  background-image: url('srt.png'), url('srb.png');\n  background-position: 10px top, right 15px bottom;\n  background-repeat: no-repeat, no-repeat;\n  background-size: 35px;\n  margin-bottom: 10px;\n  width: 100%;\n  /*margin-top: 7px;*/\n}\n[home-page] .service_box [heads] {\n  margin: 0;\n  font-weight: 600;\n  display: inline-block;\n  font-size: 18px;\n  position: relative;\n  z-index: 1;\n}\n[home-page] .service_box [heads]:after {\n  content: \"\";\n  height: 30px;\n  width: 30px;\n  background: var(--ion-color-softgreen);\n  display: inline-block;\n  position: absolute;\n  bottom: -4px;\n  left: -10px;\n  opacity: 0.5;\n  border-radius: 50%;\n  z-index: -1;\n}\n[home-page] .service_box .width100 {\n  width: 100%;\n  padding: 0px 0px 40px;\n}\n[home-page] .service_box .width100 [omgcertify] img {\n  max-width: 90px;\n}\n[home-page] .service_box .width100 h3 {\n  margin: 10px 0px 10px;\n  font-weight: 500;\n  display: inline-block;\n  font-size: 17px;\n  color: #1d1d1d;\n}\n[home-page] .service_box .width100 h3 span {\n  position: relative;\n  z-index: 1;\n}\n[home-page] .service_box .width100 h3 span:after {\n  content: \"\";\n  height: 6px;\n  width: 100%;\n  background: var(--ion-color-softgreen);\n  /*opacity:.5;*/\n  display: inline-block;\n  position: absolute;\n  bottom: 2px;\n  left: 0;\n  z-index: -1;\n}\n[home-page] .service_box .width100 p {\n  margin: 7px 0px 7px;\n  color: rgba(0, 0, 0, 0.5);\n  font-size: 13px;\n}\n[home-page] .service_box .width100 ion-button {\n  font-size: 13px;\n  color: var(--ion-color-black);\n  letter-spacing: initial;\n  width: 85%;\n}\n[home-page] {\n  margin: 0 10px !important;\n  --background: #f3f3f3;\n}\n[home-page] ion-header {\n  position: absolute;\n}\n[home-page] ion-header ion-toolbar {\n  --background: transparent;\n  --border-width: 0;\n}\n[home-page] ion-header ion-toolbar ion-buttons {\n  color: var(--ion-color-white);\n}\n[home-page] ion-header ion-toolbar ion-buttons[mr-10] {\n  margin-right: 10px;\n}\n[home-page] ion-header ion-toolbar ion-title {\n  color: var(--ion-color-white);\n  text-align: center;\n  font-style: normal;\n  font-family: \"Poppins\", sans-serif !important;\n}\n[home-page] ion-header::after {\n  display: none;\n}\n[home-page] .home-slider [hm-slider] {\n  --bullet-background:#dcdcdc;\n  --bullet-background-active:var(--ion-color-primary);\n  display: block;\n  text-align: left;\n  border-radius: 0px 0px 20px 20px;\n  overflow: hidden;\n}\n[home-page] .home-slider [hm-slider] img {\n  border-radius: 0px 0px 20px 20px;\n  height: 43vh;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n[home-page] .home-slider [hm-slider] .sld_cnt {\n  position: absolute;\n  left: 0;\n  right: 0;\n  bottom: 7px;\n  top: 0;\n  background: rgba(0, 0, 0, 0.6);\n  color: var(--ion-color-white);\n  padding: 25px 25px 40px 25px;\n  display: flex;\n  align-items: flex-end;\n  border-radius: 0 0 20px 20px;\n}\n[home-page] .home-slider [hm-slider] .sld_cnt h3 {\n  font-size: 16px;\n}\n[home-page] .home-slider [hm-slider] .sld_cnt p {\n  font-size: 12px;\n  color: var(--ion-color-white);\n  margin: 5px 0px 0px;\n}\n[home-page] .home-slider [hm-slider] .sld_cnt ion-button {\n  font-size: 12px;\n  --padding-start: 30px;\n  --padding-end: 25px;\n  letter-spacing: 0.7px;\n  --background:var(--ion-color-primary);\n  margin: 0;\n}\n[home-page] .home-slider .swiper-pagination {\n  --scroll-bar-background: red;\n}\n[home-page] .donationjar {\n  padding: 10px 10px 5px;\n  border-radius: 10px;\n  background-color: var(--ion-color-white);\n  position: relative;\n  color: var(--ion-color-black);\n  text-align: center;\n  margin-bottom: 0px;\n}\n[home-page] .donationjar [donationimg] {\n  margin: 0px;\n}\n[home-page] .donationjar [donationimg] img {\n  max-width: 132px;\n}\n[home-page] .donationjar h3 {\n  margin: 0;\n  font-weight: 600;\n  display: inline-block;\n  font-size: 18px;\n}\n[home-page] .donationjar h3 span {\n  position: relative;\n  z-index: 1;\n}\n[home-page] .donationjar h3 span:after {\n  content: \"\";\n  height: 4px;\n  width: 100%;\n  background: var(--ion-color-softgreen);\n  /*opacity:.5;*/\n  display: inline-block;\n  position: absolute;\n  bottom: 5px;\n  left: 0;\n  z-index: -1;\n}\n[home-page] .donationjar p {\n  color: rgba(0, 0, 0, 0.5);\n  font-size: 13px;\n  margin: 0;\n}\n[home-page] .donationjar span {\n  font-size: 14px;\n  line-height: 22px;\n  font-weight: 300;\n  color: #adadad;\n  margin-top: 0px;\n  display: block;\n  text-align: center;\n}\n[home-page] .donationjar .btn-losns {\n  --background:var( --ion-color-primary);\n  margin-top: 0px;\n  --box-shadow: none;\n  min-height: 42px;\n  margin-bottom: 0px;\n  text-transform: uppercase;\n  letter-spacing: 1px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9ob21lLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHlCQUFBO0VBQ0EscUJBQUE7QUFDSjtBQUFBO0VBRUcsa0JBQUE7QUFDSDtBQUFHO0VBQ0MseUJBQUE7RUFBMEIsaUJBQUE7QUFHOUI7QUFGRztFQUVDLDZCQUFBO0FBR0o7QUFGSTtFQUVBLGtCQUFBO0FBR0o7QUFBSTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7RUFDUSxrQkFBQTtFQUNBLDZDQUFBO0FBRVo7QUFDQztFQUVBLGFBQUE7QUFBRDtBQU1JO0VBQ0ksMkJBQUE7RUFDQSxtREFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGdDQUFBO0VBQ0EsZ0JBQUE7QUFKUjtBQU1RO0VBQ0gsZ0NBQUE7RUFDRixZQUFBO0VBQ0Esb0JBQUE7S0FBQSxpQkFBQTtBQUpIO0FBTVE7RUFDSSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsV0FBQTtFQUNBLE1BQUE7RUFDQSw4QkFBQTtFQUNBLDZCQUFBO0VBQ0EsNEJBQUE7RUFDQSxhQUFBO0VBQ0EscUJBQUE7RUFDQSw0QkFBQTtBQUpaO0FBS1k7RUFDSSxlQUFBO0FBSGhCO0FBS1k7RUFDSSxlQUFBO0VBQ0EsNkJBQUE7RUFDQSxjQUFBO0FBSGhCO0FBS1k7RUFDSSxlQUFBO0VBQ0EscUJBQUE7RUFDQSxtQkFBQTtFQUNBLHFCQUFBO0VBQ0EscUNBQUE7RUFDQSxTQUFBO0FBSGhCO0FBVUE7RUFDSSw0QkFBQTtBQVJKO0FBVUk7RUFDSSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0Esd0NBQUE7RUFDQSxrQkFBQTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnREFBQTtFQUNBLGdEQUFBO0VBQ04sdUNBQUE7RUFDQSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0csV0FBQTtFQUNILG1CQUFBO0FBUkY7QUFTRTtFQUVDLFNBQUE7RUFDQSxnQkFBQTtFQUNBLHFCQUFBO0VBQ0EsZUFBQTtFQUNHLGtCQUFBO0VBQ0gsVUFBQTtBQVJIO0FBU0k7RUFDRyxXQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxzQ0FBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7QUFQUDtBQVVHO0VBRUEsV0FBQTtFQUNHLHFCQUFBO0FBVE47QUFhRztFQUVDLGVBQUE7QUFaSjtBQWVHO0VBQ0MscUJBQUE7RUFDQSxnQkFBQTtFQUNBLHFCQUFBO0VBQ0EsZUFBQTtFQUVBLGNBQUE7QUFkSjtBQWVJO0VBQ0Msa0JBQUE7RUFDQSxVQUFBO0FBYkw7QUFjSztFQUNDLFdBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtFQUNBLHNDQUFBO0VBQ0EsY0FBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsT0FBQTtFQUNBLFdBQUE7QUFaTjtBQWdCRztFQUFFLG1CQUFBO0VBQ0UseUJBQUE7RUFDSCxlQUFBO0FBYko7QUFlRztFQUNDLGVBQUE7RUFDQSw2QkFBQTtFQUNBLHVCQUFBO0VBQ0EsVUFBQTtBQWJKO0FBa0JBO0VBQ0kseUJBQUE7RUFDQSxxQkFBQTtBQWZKO0FBZ0JBO0VBRUcsa0JBQUE7QUFmSDtBQWdCRztFQUNDLHlCQUFBO0VBQTBCLGlCQUFBO0FBYjlCO0FBY0c7RUFFQyw2QkFBQTtBQWJKO0FBY0k7RUFFQSxrQkFBQTtBQWJKO0FBZ0JJO0VBQ0EsNkJBQUE7RUFDQSxrQkFBQTtFQUNRLGtCQUFBO0VBQ0EsNkNBQUE7QUFkWjtBQWlCQztFQUVBLGFBQUE7QUFoQkQ7QUFzQkk7RUFDSSwyQkFBQTtFQUNBLG1EQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxnQkFBQTtBQXBCUjtBQXNCUTtFQUNILGdDQUFBO0VBQ0YsWUFBQTtFQUNBLG9CQUFBO0tBQUEsaUJBQUE7QUFwQkg7QUFzQlE7RUFDSSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsV0FBQTtFQUNBLE1BQUE7RUFDQSw4QkFBQTtFQUNBLDZCQUFBO0VBQ0EsNEJBQUE7RUFDQSxhQUFBO0VBQ0EscUJBQUE7RUFDQSw0QkFBQTtBQXBCWjtBQXFCWTtFQUNJLGVBQUE7QUFuQmhCO0FBcUJZO0VBQ0ksZUFBQTtFQUNBLDZCQUFBO0VBQ0EsbUJBQUE7QUFuQmhCO0FBcUJZO0VBQ0ksZUFBQTtFQUNBLHFCQUFBO0VBQ0EsbUJBQUE7RUFDQSxxQkFBQTtFQUNBLHFDQUFBO0VBQ0EsU0FBQTtBQW5CaEI7QUEwQkE7RUFDSSw0QkFBQTtBQXhCSjtBQXlCQztFQUNRLHNCQUFBO0VBQ0QsbUJBQUE7RUFDQSx3Q0FBQTtFQUNBLGtCQUFBO0VBQ0EsNkJBQUE7RUFDQSxrQkFBQTtFQUNOLGtCQUFBO0FBdkJGO0FBd0JFO0VBQ0ssV0FBQTtBQXRCUDtBQXVCRTtFQUVDLGdCQUFBO0FBdEJIO0FBeUJRO0VBQ0ksU0FBQTtFQUNBLGdCQUFBO0VBQ0EscUJBQUE7RUFDQSxlQUFBO0FBdkJaO0FBd0JZO0VBQ0ksa0JBQUE7RUFDWixVQUFBO0FBdEJKO0FBdUJnQjtFQUNJLFdBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtFQUNBLHNDQUFBO0VBQ2YsY0FBQTtFQUNlLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsT0FBQTtFQUNBLFdBQUE7QUFyQnBCO0FBeUJRO0VBQ0kseUJBQUE7RUFDQSxlQUFBO0VBQ1QsU0FBQTtBQXZCSDtBQXlCQztFQUNFLGVBQUE7RUFDQyxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUF2Qko7QUEwQkU7RUFDQyxzQ0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNTLGdCQUFBO0VBQ1Qsa0JBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0FBeEJIIiwiZmlsZSI6InNyYy9hcHAvaG9tZS9ob21lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIltob21lLXBhZ2Vde1xyXG4gICAgbWFyZ2luOiAwIDEwcHggIWltcG9ydGFudDtcclxuICAgIC0tYmFja2dyb3VuZDogI2YzZjNmMztcclxuaW9uLWhlYWRlclxyXG5cdHtcclxuXHQgIHBvc2l0aW9uOmFic29sdXRlO1xyXG5cdCAgaW9uLXRvb2xiYXJcclxuXHQgIHstLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50Oy0tYm9yZGVyLXdpZHRoOiAwO1xyXG5cdCAgaW9uLWJ1dHRvbnNcclxuXHQgIHtcclxuXHQgICBjb2xvcjp2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdCAgICZbbXItMTBdXHJcblx0ICAge1xyXG5cdCAgIG1hcmdpbi1yaWdodDoxMHB4O1xyXG5cdCAgIH1cclxuXHQgIH1cclxuXHRcdCAgaW9uLXRpdGxle1xyXG5cdFx0ICBjb2xvcjp2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdFx0ICB0ZXh0LWFsaWduOmNlbnRlcjtcclxuICAgICAgICAgICAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gICAgICAgICAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgfVxyXG5cdH1cclxuXHQmOjphZnRlclxyXG5cdHtcclxuXHRkaXNwbGF5Om5vbmU7XHJcblx0fVxyXG5cdH1cclxuXHJcbiAgICAuaG9tZS1zbGlkZXJ7XHJcbiAgICAgICAgXHJcbiAgICBbaG0tc2xpZGVyXXtcclxuICAgICAgICAtLWJ1bGxldC1iYWNrZ3JvdW5kOiNkY2RjZGM7XHJcbiAgICAgICAgLS1idWxsZXQtYmFja2dyb3VuZC1hY3RpdmU6dmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgICAgIGRpc3BsYXk6YmxvY2s7XHJcbiAgICAgICAgdGV4dC1hbGlnbjpsZWZ0O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDBweCAwcHggMjBweCAyMHB4O1xyXG4gICAgICAgIG92ZXJmbG93OmhpZGRlbjtcclxuICAgICAgICBcclxuICAgICAgICBpbWd7XHJcblx0XHQgICBib3JkZXItcmFkaXVzOiAwcHggMHB4IDIwcHggMjBweDtcclxuXHRcdFx0aGVpZ2h0OiA2NXZoO1xyXG5cdFx0XHRvYmplY3QtZml0OiBjb3ZlcjtcclxuICAgICAgICB9XHJcbiAgICAgICAgLnNsZF9jbnR7XHJcbiAgICAgICAgICAgIHBvc2l0aW9uOmFic29sdXRlO1xyXG4gICAgICAgICAgICBsZWZ0OjA7XHJcbiAgICAgICAgICAgIHJpZ2h0OjA7XHJcbiAgICAgICAgICAgIGJvdHRvbTo3cHg7XHJcbiAgICAgICAgICAgIHRvcDowO1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOnJnYmEoMCwwLDAsMC42MCk7XHJcbiAgICAgICAgICAgIGNvbG9yOnZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6MjVweCAyNXB4IDQwcHggMjVweCA7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6ZmxleDtcclxuICAgICAgICAgICAgYWxpZ24taXRlbXM6ZmxleC1lbmQ7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6MCAwIDIwcHggMjBweDtcclxuICAgICAgICAgICAgaDN7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6MTZweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBwe1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOjEycHg7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjp2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luOiAxMHB4IDA7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaW9uLWJ1dHRvbntcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgICAgICAgICAgICAgIC0tcGFkZGluZy1zdGFydDogMzBweDtcclxuICAgICAgICAgICAgICAgIC0tcGFkZGluZy1lbmQ6IDI1cHg7XHJcbiAgICAgICAgICAgICAgICBsZXR0ZXItc3BhY2luZzogMC43cHg7XHJcbiAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQ6dmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICBcclxufVxyXG4uaG9tZS1zbGlkZXIgLnN3aXBlci1wYWdpbmF0aW9uIHtcclxuICAgIC0tc2Nyb2xsLWJhci1iYWNrZ3JvdW5kOiByZWQ7XHJcbn1cclxuICAgIC5zZXJ2aWNlX2JveHtcclxuICAgICAgICBwYWRkaW5nOjI1cHggOHB4IDBweDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOjEwcHg7XHJcbiAgICAgICAgYmFja2dyb3VuZC1jb2xvcjp2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG4gICAgICAgIHBvc2l0aW9uOnJlbGF0aXZlO1xyXG4gICAgICAgIGNvbG9yOnZhcigtLWlvbi1jb2xvci1ibGFjayk7XHJcbiAgICAgICAgdGV4dC1hbGlnbjpjZW50ZXI7XHJcbiAgICAgICAgYmFja2dyb3VuZC1pbWFnZTp1cmwoXCIuLi8uLi9hc3NldHMvaW1hZ2VzL3NydC5wbmdcIiksIHVybChcIi4uLy4uL2Fzc2V0cy9pbWFnZXMvc3JiLnBuZ1wiKTtcclxuICAgICAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiAxMHB4IHRvcCwgcmlnaHQgMTVweCBib3R0b207XHJcblx0XHRiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0LCBuby1yZXBlYXQ7XHJcblx0XHRiYWNrZ3JvdW5kLXNpemU6IDM1cHg7XHJcblx0XHRtYXJnaW4tYm90dG9tOjEwcHg7XHJcblx0ICAgIHdpZHRoOiAxMDAlO1x0XHJcblx0XHQvKm1hcmdpbi10b3A6IDdweDsqL1xyXG5cdFx0W2hlYWRzXVxyXG5cdFx0e1xyXG5cdFx0XHRtYXJnaW46IDA7XHJcblx0XHRcdGZvbnQtd2VpZ2h0OiA2MDA7XHJcblx0XHRcdGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuXHRcdFx0Zm9udC1zaXplOjE4cHg7XHRcdFxyXG5cdFx0ICAgIHBvc2l0aW9uOnJlbGF0aXZlO1xyXG5cdFx0XHR6LWluZGV4OjE7XHJcblx0XHRcdFx0JjphZnRlcntcclxuXHRcdFx0XHRcdFx0XHRjb250ZW50OiBcIlwiO1xyXG5cdFx0XHRcdFx0XHRcdGhlaWdodDogMzBweDtcclxuXHRcdFx0XHRcdFx0XHR3aWR0aDogMzBweDtcclxuXHRcdFx0XHRcdFx0XHRiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itc29mdGdyZWVuKTtcclxuXHRcdFx0XHRcdFx0XHRkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcblx0XHRcdFx0XHRcdFx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdFx0XHRcdFx0XHRcdGJvdHRvbTogLTRweDtcclxuXHRcdFx0XHRcdFx0XHRsZWZ0OiAtMTBweDtcclxuXHRcdFx0XHRcdFx0XHRvcGFjaXR5OiAwLjU7XHJcblx0XHRcdFx0XHRcdFx0Ym9yZGVyLXJhZGl1czogNTAlO1xyXG5cdFx0XHRcdFx0XHRcdHotaW5kZXg6IC0xO1xyXG5cdFx0XHRcdH1cdFx0XHRcclxuXHRcdH1cclxuXHRcdFx0LndpZHRoMTAwXHJcblx0XHRcdHtcclxuXHRcdFx0d2lkdGg6MTAwJTtcclxuXHRcdCAgICBwYWRkaW5nOiAwcHggMHB4IDQwcHg7XHRcclxuXHRcdFx0XHJcblx0XHRcdFtvbWdjZXJ0aWZ5XVxyXG5cdFx0XHR7XHJcblx0XHRcdGltZ1xyXG5cdFx0XHR7XHJcblx0XHRcdCBtYXgtd2lkdGg6IDkwcHg7XHJcblx0XHRcdH1cclxuXHRcdFx0fVxyXG5cdFx0XHRoM3tcclxuXHRcdFx0XHRtYXJnaW46IDEwcHggMHB4IDEwcHg7XHJcblx0XHRcdFx0Zm9udC13ZWlnaHQ6IDUwMDtcclxuXHRcdFx0XHRkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcblx0XHRcdFx0Zm9udC1zaXplOiAxN3B4O1xyXG5cclxuXHRcdFx0XHRjb2xvcjogIzFkMWQxZDtcclxuXHRcdFx0XHRzcGFue1xyXG5cdFx0XHRcdFx0cG9zaXRpb246cmVsYXRpdmU7XHJcblx0XHRcdFx0XHR6LWluZGV4OjE7XHJcblx0XHRcdFx0XHQmOmFmdGVye1xyXG5cdFx0XHRcdFx0XHRjb250ZW50OiBcIlwiO1xyXG5cdFx0XHRcdFx0XHRoZWlnaHQ6IDZweDtcclxuXHRcdFx0XHRcdFx0d2lkdGg6IDEwMCU7XHJcblx0XHRcdFx0XHRcdGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1zb2Z0Z3JlZW4pO1xyXG5cdFx0XHRcdFx0XHQvKm9wYWNpdHk6LjU7Ki9cclxuXHRcdFx0XHRcdFx0ZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG5cdFx0XHRcdFx0XHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0XHRcdFx0XHRcdGJvdHRvbTogMnB4O1xyXG5cdFx0XHRcdFx0XHRsZWZ0OiAwO1xyXG5cdFx0XHRcdFx0XHR6LWluZGV4OiAtMTtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHR9XHJcblx0XHRcdH1cclxuXHRcdFx0cHttYXJnaW46IDdweCAwcHggN3B4O1xyXG5cdFx0XHRcdCAgIGNvbG9yOiByZ2JhKDAsIDAsIDAgLCAwLjUwKTtcclxuXHRcdFx0XHRmb250LXNpemU6IDEzcHg7XHJcblx0XHRcdH1cclxuXHRcdFx0aW9uLWJ1dHRvbntcclxuXHRcdFx0XHRmb250LXNpemU6IDEzcHg7XHJcblx0XHRcdFx0Y29sb3I6IHZhcigtLWlvbi1jb2xvci1ibGFjayk7XHJcblx0XHRcdFx0bGV0dGVyLXNwYWNpbmc6aW5pdGlhbDtcclxuXHRcdFx0XHR3aWR0aDo4NSU7XHJcblx0XHRcdH1cclxuXHRcdH1cclxuICAgIH1cclxufVxyXG5baG9tZS1wYWdlXXtcclxuICAgIG1hcmdpbjogMCAxMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAtLWJhY2tncm91bmQ6ICNmM2YzZjM7XHJcbmlvbi1oZWFkZXJcclxuXHR7XHJcblx0ICBwb3NpdGlvbjphYnNvbHV0ZTtcclxuXHQgIGlvbi10b29sYmFyXHJcblx0ICB7LS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDstLWJvcmRlci13aWR0aDogMDtcclxuXHQgIGlvbi1idXR0b25zXHJcblx0ICB7XHJcblx0ICAgY29sb3I6dmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuXHQgICAmW21yLTEwXVxyXG5cdCAgIHtcclxuXHQgICBtYXJnaW4tcmlnaHQ6MTBweDtcclxuXHQgICB9XHJcblx0ICB9XHJcblx0XHQgIGlvbi10aXRsZXtcclxuXHRcdCAgY29sb3I6dmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuXHRcdCAgdGV4dC1hbGlnbjpjZW50ZXI7XHJcbiAgICAgICAgICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xyXG4gICAgICAgIH1cclxuXHR9XHJcblx0Jjo6YWZ0ZXJcclxuXHR7XHJcblx0ZGlzcGxheTpub25lO1xyXG5cdH1cclxuXHR9XHJcblxyXG4gICAgLmhvbWUtc2xpZGVye1xyXG4gICAgICAgIFxyXG4gICAgW2htLXNsaWRlcl17XHJcbiAgICAgICAgLS1idWxsZXQtYmFja2dyb3VuZDojZGNkY2RjO1xyXG4gICAgICAgIC0tYnVsbGV0LWJhY2tncm91bmQtYWN0aXZlOnZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuICAgICAgICBkaXNwbGF5OmJsb2NrO1xyXG4gICAgICAgIHRleHQtYWxpZ246bGVmdDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAwcHggMHB4IDIwcHggMjBweDtcclxuICAgICAgICBvdmVyZmxvdzpoaWRkZW47XHJcbiAgICAgICAgXHJcbiAgICAgICAgaW1ne1xyXG5cdFx0ICAgYm9yZGVyLXJhZGl1czogMHB4IDBweCAyMHB4IDIwcHg7XHJcblx0XHRcdGhlaWdodDogNDN2aDtcclxuXHRcdFx0b2JqZWN0LWZpdDogY292ZXI7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5zbGRfY250e1xyXG4gICAgICAgICAgICBwb3NpdGlvbjphYnNvbHV0ZTtcclxuICAgICAgICAgICAgbGVmdDowO1xyXG4gICAgICAgICAgICByaWdodDowO1xyXG4gICAgICAgICAgICBib3R0b206N3B4O1xyXG4gICAgICAgICAgICB0b3A6MDtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDpyZ2JhKDAsMCwwLDAuNjApO1xyXG4gICAgICAgICAgICBjb2xvcjp2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG4gICAgICAgICAgICBwYWRkaW5nOjI1cHggMjVweCA0MHB4IDI1cHggO1xyXG4gICAgICAgICAgICBkaXNwbGF5OmZsZXg7XHJcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOmZsZXgtZW5kO1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOjAgMCAyMHB4IDIwcHg7XHJcbiAgICAgICAgICAgIGgze1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOjE2cHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcHtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZToxMnB4O1xyXG4gICAgICAgICAgICAgICAgY29sb3I6dmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgICAgICAgICAgICAgIG1hcmdpbjogNXB4IDBweCAwcHg7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaW9uLWJ1dHRvbntcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgICAgICAgICAgICAgIC0tcGFkZGluZy1zdGFydDogMzBweDtcclxuICAgICAgICAgICAgICAgIC0tcGFkZGluZy1lbmQ6IDI1cHg7XHJcbiAgICAgICAgICAgICAgICBsZXR0ZXItc3BhY2luZzogMC43cHg7XHJcbiAgICAgICAgICAgICAgICAtLWJhY2tncm91bmQ6dmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICBcclxufVxyXG4uaG9tZS1zbGlkZXIgLnN3aXBlci1wYWdpbmF0aW9uIHtcclxuICAgIC0tc2Nyb2xsLWJhci1iYWNrZ3JvdW5kOiByZWQ7XHJcbn0uZG9uYXRpb25qYXJ7XHJcbiAgICAgICAgIHBhZGRpbmc6MTBweCAxMHB4ICA1cHg7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czoxMHB4O1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6dmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgICAgICBwb3NpdGlvbjpyZWxhdGl2ZTtcclxuICAgICAgICBjb2xvcjp2YXIoLS1pb24tY29sb3ItYmxhY2spO1xyXG4gICAgICAgIHRleHQtYWxpZ246Y2VudGVyO1xyXG5cdFx0bWFyZ2luLWJvdHRvbTowcHg7XHJcblx0XHRbZG9uYXRpb25pbWddXHJcblx0XHR7ICAgIG1hcmdpbjowcHg7XHJcblx0XHRpbWdcclxuXHRcdHtcclxuXHRcdCBtYXgtd2lkdGg6IDEzMnB4O1xyXG5cdFx0fVxyXG5cdFx0fVxyXG4gICAgICAgIGgze1xyXG4gICAgICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgICAgICAgICAgZm9udC1zaXplOjE4cHg7XHJcbiAgICAgICAgICAgIHNwYW57XHJcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjpyZWxhdGl2ZTtcclxuXHRcdFx0XHR6LWluZGV4OjE7XHJcbiAgICAgICAgICAgICAgICAmOmFmdGVye1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnRlbnQ6IFwiXCI7XHJcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiA0cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXNvZnRncmVlbik7XHJcblx0XHRcdFx0XHQvKm9wYWNpdHk6LjU7Ki9cclxuICAgICAgICAgICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICAgICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgICAgICAgICAgICAgIGJvdHRvbTogNXB4O1xyXG4gICAgICAgICAgICAgICAgICAgIGxlZnQ6IDA7XHJcbiAgICAgICAgICAgICAgICAgICAgei1pbmRleDogLTE7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgcHtcclxuICAgICAgICAgICAgY29sb3I6IHJnYmEoMCwgMCwgMCAsIDAuNTApO1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcblx0XHRcdG1hcmdpbjowO1xyXG4gICAgICAgIH1cclxuIHNwYW5cclxuICB7Zm9udC1zaXplOiAxNHB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDIycHg7XHJcbiAgICBmb250LXdlaWdodDogMzAwO1xyXG4gICAgY29sb3I6ICNhZGFkYWQ7XHJcbiAgICBtYXJnaW4tdG9wOiAwcHg7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBcclxuICB9XHJcblx0XHQuYnRuLWxvc25ze1xyXG5cdFx0XHQtLWJhY2tncm91bmQ6dmFyKCAtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuXHRcdFx0bWFyZ2luLXRvcDogMHB4O1xyXG5cdFx0XHQtLWJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICAgICAgICAgIG1pbi1oZWlnaHQ6IDQycHg7XHJcblx0XHRcdG1hcmdpbi1ib3R0b206IDBweDtcclxuXHRcdFx0dGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuXHRcdFx0bGV0dGVyLXNwYWNpbmc6IDFweDtcclxuXHRcdH1cdFx0XHJcbiAgICB9XHJcbn1cclxuIl19 */";
      /***/
    },

    /***/
    "./src/app/home/home.page.ts":
    /*!***********************************!*\
      !*** ./src/app/home/home.page.ts ***!
      \***********************************/

    /*! exports provided: HomePage */

    /***/
    function srcAppHomeHomePageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "HomePage", function () {
        return HomePage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _services_globalFooService_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../services/globalFooService.service */
      "./src/app/services/globalFooService.service.ts");
      /* harmony import */


      var _common_common_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../common/common.service */
      "./src/app/common/common.service.ts");
      /* harmony import */


      var _services_api_api_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../services/api/api.service */
      "./src/app/services/api/api.service.ts");
      /* harmony import */


      var _config__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../config */
      "./src/app/config.ts");
      /* harmony import */


      var _addamount_addamount_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../addamount/addamount.page */
      "./src/app/addamount/addamount.page.ts");

      var HomePage = /*#__PURE__*/function () {
        function HomePage(api, globalFooService, modalController, common) {
          var _this = this;

          _classCallCheck(this, HomePage);

          this.api = api;
          this.globalFooService = globalFooService;
          this.modalController = modalController;
          this.common = common;
          this.IMAGES_URL = _config__WEBPACK_IMPORTED_MODULE_6__["config"].IMAGES_URL;
          this.errors = ['', null, undefined];
          this.list = [];
          this.slideOptsOne = {
            initialSlide: 0,
            slidesPerView: 1,
            autoplay: true,
            speed: 900
          };
          this.globalFooService.getObservable().subscribe(function (data) {
            if (_this.errors.indexOf(data.foo) == -1) {
              _this.type_login = data.foo.data.type;
              localStorage.setItem('type_login', data.foo.data.type);
            }

            console.log(_this.errors.indexOf(data.set));

            if (_this.errors.indexOf(data.set) == -1) {
              _this.type_login = data.set.data;
              localStorage.setItem('type_login', '1');
            }
          });
        }

        _createClass(HomePage, [{
          key: "give_in",
          value: function give_in() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this2 = this;

              var modal;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.modalController.create({
                        component: _addamount_addamount_page__WEBPACK_IMPORTED_MODULE_7__["AddamountPage"],
                        cssClass: 'leaveteam',
                        componentProps: {}
                      });

                    case 2:
                      modal = _context.sent;
                      modal.onDidDismiss().then(function (detail) {
                        if (_this2.errors.indexOf(detail.data) == -1) {//this.team.joins=this.team.joins - 1;
                          //this.getuserteams();
                        }
                      });
                      _context.next = 6;
                      return modal.present();

                    case 6:
                      return _context.abrupt("return", _context.sent);

                    case 7:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "give",
          value: function give(id) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var _this3 = this;

              var modal;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this.modalController.create({
                        component: _addamount_addamount_page__WEBPACK_IMPORTED_MODULE_7__["AddamountPage"],
                        cssClass: 'leaveteam',
                        componentProps: {
                          id: id
                        }
                      });

                    case 2:
                      modal = _context2.sent;
                      modal.onDidDismiss().then(function (detail) {
                        if (_this3.errors.indexOf(detail.data) == -1) {//this.team.joins=this.team.joins - 1;
                          //this.getuserteams();
                        }
                      });
                      _context2.next = 6;
                      return modal.present();

                    case 6:
                      return _context2.abrupt("return", _context2.sent);

                    case 7:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "ionViewDidEnter",
          value: function ionViewDidEnter() {
            this.userid = localStorage.getItem('userid');
            this.type_login = localStorage.getItem('type_login');
            this.Charitylist();
          }
        }, {
          key: "Charitylist",
          value: function Charitylist() {
            var _this4 = this;

            if (this.type_login == '2') {
              this.api.post('tribesProject', '', '').subscribe(function (result) {
                var res;
                res = result;

                if (res.status == 1) {
                  _this4.list = res.data;
                } else {}
              }, function (err) {});
            } else {
              this.api.post('tribesProjectCompany', '', '').subscribe(function (result) {
                var res;
                res = result;

                if (res.status == 1) {
                  _this4.list = res.data;
                } else {}
              }, function (err) {});
            }
          }
        }]);

        return HomePage;
      }();

      HomePage.ctorParameters = function () {
        return [{
          type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_5__["ApiService"]
        }, {
          type: _services_globalFooService_service__WEBPACK_IMPORTED_MODULE_3__["GlobalFooService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
        }, {
          type: _common_common_service__WEBPACK_IMPORTED_MODULE_4__["CommonService"]
        }];
      };

      HomePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-home',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./home.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./home.page.scss */
        "./src/app/home/home.page.scss"))["default"]]
      })], HomePage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=home-home-module-es5.js.map