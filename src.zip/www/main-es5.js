(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"], {
    /***/
    "./$$_lazy_route_resource lazy recursive":
    /*!******************************************************!*\
      !*** ./$$_lazy_route_resource lazy namespace object ***!
      \******************************************************/

    /*! no static exports found */

    /***/
    function $$_lazy_route_resourceLazyRecursive(module, exports, __webpack_require__) {
      var map = {
        "./tabs/tabs.module": ["./src/app/tabs/tabs.module.ts", "tabs-tabs-module"]
      };

      function webpackAsyncContext(req) {
        if (!__webpack_require__.o(map, req)) {
          return Promise.resolve().then(function () {
            var e = new Error("Cannot find module '" + req + "'");
            e.code = 'MODULE_NOT_FOUND';
            throw e;
          });
        }

        var ids = map[req],
            id = ids[0];
        return __webpack_require__.e(ids[1]).then(function () {
          return __webpack_require__(id);
        });
      }

      webpackAsyncContext.keys = function webpackAsyncContextKeys() {
        return Object.keys(map);
      };

      webpackAsyncContext.id = "./$$_lazy_route_resource lazy recursive";
      module.exports = webpackAsyncContext;
      /***/
    },

    /***/
    "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
    /*!*****************************************************************************************************************************************!*\
      !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
      \*****************************************************************************************************************************************/

    /*! no static exports found */

    /***/
    function node_modulesIonicCoreDistEsmLazyRecursiveEntryJs$IncludeEntryJs$ExcludeSystemEntryJs$(module, exports, __webpack_require__) {
      var map = {
        "./ion-action-sheet.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-action-sheet.entry.js", "common", 0],
        "./ion-alert.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-alert.entry.js", "common", 1],
        "./ion-app_8.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-app_8.entry.js", "common", 2],
        "./ion-avatar_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-avatar_3.entry.js", "common", 3],
        "./ion-back-button.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-back-button.entry.js", "common", 4],
        "./ion-backdrop.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-backdrop.entry.js", 5],
        "./ion-button_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-button_2.entry.js", "common", 6],
        "./ion-card_5.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-card_5.entry.js", "common", 7],
        "./ion-checkbox.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-checkbox.entry.js", "common", 8],
        "./ion-chip.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-chip.entry.js", "common", 9],
        "./ion-col_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-col_3.entry.js", 10],
        "./ion-datetime_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-datetime_3.entry.js", "common", 11],
        "./ion-fab_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-fab_3.entry.js", "common", 12],
        "./ion-img.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-img.entry.js", 13],
        "./ion-infinite-scroll_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2.entry.js", 14],
        "./ion-input.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-input.entry.js", "common", 15],
        "./ion-item-option_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item-option_3.entry.js", "common", 16],
        "./ion-item_8.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-item_8.entry.js", "common", 17],
        "./ion-loading.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-loading.entry.js", "common", 18],
        "./ion-menu_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-menu_3.entry.js", "common", 19],
        "./ion-modal.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-modal.entry.js", "common", 20],
        "./ion-nav_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-nav_2.entry.js", "common", 21],
        "./ion-popover.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-popover.entry.js", "common", 22],
        "./ion-progress-bar.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-progress-bar.entry.js", "common", 23],
        "./ion-radio_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-radio_2.entry.js", "common", 24],
        "./ion-range.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-range.entry.js", "common", 25],
        "./ion-refresher_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-refresher_2.entry.js", "common", 26],
        "./ion-reorder_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-reorder_2.entry.js", "common", 27],
        "./ion-ripple-effect.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-ripple-effect.entry.js", 28],
        "./ion-route_4.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-route_4.entry.js", "common", 29],
        "./ion-searchbar.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-searchbar.entry.js", "common", 30],
        "./ion-segment_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-segment_2.entry.js", "common", 31],
        "./ion-select_3.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-select_3.entry.js", "common", 32],
        "./ion-slide_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-slide_2.entry.js", 33],
        "./ion-spinner.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-spinner.entry.js", "common", 34],
        "./ion-split-pane.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-split-pane.entry.js", 35],
        "./ion-tab-bar_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-tab-bar_2.entry.js", "common", 36],
        "./ion-tab_2.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-tab_2.entry.js", "common", 37],
        "./ion-text.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-text.entry.js", "common", 38],
        "./ion-textarea.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-textarea.entry.js", "common", 39],
        "./ion-toast.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toast.entry.js", "common", 40],
        "./ion-toggle.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-toggle.entry.js", "common", 41],
        "./ion-virtual-scroll.entry.js": ["./node_modules/@ionic/core/dist/esm/ion-virtual-scroll.entry.js", 42]
      };

      function webpackAsyncContext(req) {
        if (!__webpack_require__.o(map, req)) {
          return Promise.resolve().then(function () {
            var e = new Error("Cannot find module '" + req + "'");
            e.code = 'MODULE_NOT_FOUND';
            throw e;
          });
        }

        var ids = map[req],
            id = ids[0];
        return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function () {
          return __webpack_require__(id);
        });
      }

      webpackAsyncContext.keys = function webpackAsyncContextKeys() {
        return Object.keys(map);
      };

      webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
      module.exports = webpackAsyncContext;
      /***/
    },

    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
    /*!**************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
      \**************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppAppComponentHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-app   >\r\n <!--ion-split-pane contentId=\"main-content\"-->\r\n    <ion-menu contentId=\"main-content\" type=\"overlay\" *ngIf=\"errors.indexOf(userid)==-1\">\r\n      <ion-content>\r\n        <ion-list menutop>\r\n\t\t<ion-item color=\"primary\" lines=\"none\">\r\n\t\t<ion-avatar>\r\n\t\t  <img src=\"assets/images/user1.jpg\" *ngIf=\"errors.indexOf(profile_pic)>=0\"\r\n\t\t  src=\"{{IMAGES_URL}}/{{profile_pic}}\"/> \r\n\t\t  <img  *ngIf=\"errors.indexOf(profile_pic)==-1\" src=\"{{IMAGES_URL}}/{{profile_pic}}\"/>\r\n\t\t  \r\n\t\t</ion-avatar>\r\n\t\t<ion-label>\r\n\t\t<h2>{{first_name}} {{last_name}}</h2>\r\n\t\t<p>{{email}}</p>\r\n\t\t</ion-label>\r\n\t\t</ion-item>\r\n        </ion-list>\r\n        <ion-list>\r\n    \r\n          <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages; let i = index\">\r\n            <ion-item (click)=\"selectedIndex = i\" routerDirection=\"root\"  (click)=\"logout()\" lines=\"none\" detail=\"false\" [class.selected]=\"selectedIndex == i\">\r\n              <!--ion-icon slot=\"start\" name=\"p.icon + '-outline'\"  [ios]=\"p.icon + '-outline'\" [md]=\"p.icon + '-sharp'\"></ion-icon-->\r\n              <ion-icon slot=\"start\" [name]=\"p.icon\" ></ion-icon>\r\n              <ion-label>{{ p.title }}</ion-label>\r\n            </ion-item>\r\n          </ion-menu-toggle>\r\n        </ion-list>\r\n      </ion-content>\r\n    </ion-menu>\r\n\t\r\n\t\r\n\t <ion-menu contentId=\"main-content\" type=\"overlay\" *ngIf=\"errors.indexOf(userid)>=0\">\r\n      <ion-content>\r\n       \r\n        <ion-list>\r\n    \r\n          <ion-menu-toggle auto-hide=\"false\">\r\n            <ion-item routerDirection=\"root\"  routerLink=\"/login\" lines=\"none\" detail=\"false\" >\r\n              <!--ion-icon slot=\"start\" name=\"p.icon + '-outline'\"  [ios]=\"p.icon + '-outline'\" [md]=\"p.icon + '-sharp'\"></ion-icon-->\r\n\r\n              <ion-label>Login</ion-label>\r\n            </ion-item>\r\n          </ion-menu-toggle>\r\n        </ion-list>\r\n      </ion-content>\r\n    </ion-menu>\r\n    <ion-router-outlet id=\"main-content\"></ion-router-outlet>\r\n  <!--/ion-split-pane-->\r\n</ion-app>\r\n";
      /***/
    },

    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/customamount/customamount.page.html":
    /*!*******************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/customamount/customamount.page.html ***!
      \*******************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppCustomamountCustomamountPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n\t      <ion-buttons (click)=\"dismiss() \" slot=\"end\">\r\n         <ion-icon name=\"close-sharp\"></ion-icon>\r\n        </ion-buttons>\r\n\t<ion-title class=\"ion-text-center\">Your Amount</ion-title>\r\n  </ion-toolbar>\r\n  </ion-header>\r\n\r\n<ion-content class=\"ion-padding\">\r\n<div amountimg class=\"ion-text-center\">\r\n<img src=\"assets/images/mappic6.jpg\"/>\r\n<p>Please enter amount that you would like to donate. Miniumum donation amount is $1 dollar.</p>\r\n<p style=\"color:#1e1e1e;font-weight:500;\" *ngIf=\"errors.indexOf(charityid)==-1\">{{charity?.title}}</p>\r\n<p style=\"color:#1e1e1e;font-weight:500;\" *ngIf=\"errors.indexOf(actid)==-1\">{{act?.title}}</p>\r\n<p style=\"color:#1e1e1e;font-weight:500;\" *ngIf=\"errors.indexOf(teamid)==-1\">{{team?.name}}</p>\r\n</div>\r\n<div formfield dollar-input>\r\n\t\t\t\t<label>Your Amount</label>\r\n\t\t\t\t<ion-item lines=\"none\" class=\"fls\">  \r\n         <img src=\"assets/images/dollar-icon.png\" />\r\n\t\t\t\t\t<ion-input placeholder=\"Enter Your Amount\" type=\"number\"  id=\"amount1\" (keyup)=\"search_keyword($event);\"></ion-input>\r\n\t\t\t\t</ion-item>\r\n\t\t\t\t\r\n</div>\r\n<p style=\"padding-top: 9px; margin: 0px; font-size: 12px; padding-left: 20px;\"><span class=\"no_meals\">0</span> meals</p>\r\n<ion-button  expand=\"full\" shape=\"round\" class=\"btn-losns\" (click)=\"confirm();\">Confirm</ion-button>\r\n\r\n\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/deleteconfirm/deleteconfirm.page.html":
    /*!*********************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/deleteconfirm/deleteconfirm.page.html ***!
      \*********************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppDeleteconfirmDeleteconfirmPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\r\n\r\n<ion-content>\r\n\t<div class=\"popupconfirm\">\r\n\t\t<p>Delete confirm</p>\r\n\t\t<p>Are you sure you want to delete this record ?</p>\r\n\t\t<ion-button shape=\"round\" expand=\"full\" (click)=\"cancel()\">Cancel</ion-button>\r\n\t\t<ion-button shape=\"round\" expand=\"full\" (click)=\"delete()\" >Delete</ion-button>\r\n\t</div>\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/jointeamconfirm/jointeamconfirm.page.html":
    /*!*************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/jointeamconfirm/jointeamconfirm.page.html ***!
      \*************************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppJointeamconfirmJointeamconfirmPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\r\n\r\n<ion-content>\r\n\t<div class=\"popupconfirm\">\r\n\t\t<p>Give for a team </p>\r\n\t\t<p>By Joining a team , all of your future donations will be on behalf of this team. You can switch or leave a team at any time.</p>\r\n\t\t<ion-button shape=\"round\" expand=\"full\" (click)=\"cancel()\">Cancel</ion-button>\r\n\t\t<ion-button shape=\"round\" expand=\"full\" (click)=\"join()\" >Join</ion-button>\r\n\t</div>\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/leaveteamconfirm/leaveteamconfirm.page.html":
    /*!***************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/leaveteamconfirm/leaveteamconfirm.page.html ***!
      \***************************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppLeaveteamconfirmLeaveteamconfirmPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\r\n\r\n<ion-content>\r\n<div class=\"popupconfirm\">\r\n<p>Your team will miss you! </p>\r\n<p>If you leave team  {{team_name}} , your donations will no longer support their team goals </p>\r\n<ion-button shape=\"round\" expand=\"full\" (click)=\"cancel()\">Cancel</ion-button>\r\n<ion-button shape=\"round\" expand=\"full\" (click)=\"join()\" >Leave</ion-button>\r\n</div>\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/paymentlistmodal/paymentlistmodal.page.html":
    /*!***************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/paymentlistmodal/paymentlistmodal.page.html ***!
      \***************************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppPaymentlistmodalPaymentlistmodalPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n\t      <ion-buttons (click)=\"dismiss() \" slot=\"end\">\r\n         <ion-icon name=\"close-sharp\"></ion-icon>\r\n        </ion-buttons>\r\n\t<ion-title class=\"ion-text-center\">Payment Method</ion-title>\r\n  </ion-toolbar>\r\n  </ion-header>\r\n\r\n<ion-content class=\"ion-padding\">\r\n<div amountimg class=\"ion-text-center\">\r\n<img src=\"assets/images/mappic6.jpg\"/>\r\n<p>Please choose payment method or add new card</p>\r\n<p *ngIf=\"paymentlist.length==0\">No records found</p>\r\n\r\n<ion-radio-group value=\"\"class=\"radiobox\">\r\n    <ion-item lines=\"none\" *ngFor=\"let pay of paymentlist\">\r\n      <ion-label>{{pay?.card_number}}</ion-label>\r\n      <ion-radio value=\"{{pay?.id}}\"  (click)=\"cardno(pay?.id)\" class=\"radiobox\"></ion-radio>\r\n    </ion-item>\r\n</ion-radio-group>\t\r\n\r\n<ion-button  expand=\"full\" shape=\"round\" class=\"btn-losns add_new_card_btn\" (click)=\"confirm();\">Add new card</ion-button>\r\n</div>\r\n<div class=\"add_payment\" style=\"display:none\">\r\n<div formfield>\r\n\t\t\t\t<label>Card Holder Name</label>\r\n\t\t\t\t\r\n\t\t\t\t<ion-item lines=\"none\" class=\"fls\"> \r\n\t\t\t\t\t<ion-input placeholder=\"Enter Name\" [(ngModel)]=\"name\" name=\"name\" \r\n\t\t\t\t\t(keyup)=\"search_keyword($event);\" class=\"namee\"></ion-input>\r\n\t\t\t\t</ion-item>\r\n\t\t\t\t<span error *ngIf=\"errors.indexOf(name) >= 0 && is_submit_payment == true\">Please enter card holder name</span>\r\n</div>\r\n<div formfield>\r\n\t\t\t\t<label>Card Number</label>\r\n\t\t\t\t<ion-item lines=\"none\" class=\"fls\"> \r\n\t\t\t\t\t<ion-input placeholder=\"Enter Card Number\" class=\"card_numberr\" (keyup)=\"search_keyword($event);\"[(ngModel)]=\"card_number\" name=\"card_number\"></ion-input>\r\n\t\t\t\t</ion-item>\r\n\t\t\t\t<span error *ngIf=\"errors.indexOf(card_number) >= 0 && is_submit_payment == true\">Please enter card number</span>\r\n</div>\r\n<div formfield>\r\n\t\t\t\t<label>Expiration Date</label>\r\n\t\t\t\t<ion-item lines=\"none\" class=\"fls\"> \r\n\t\t\t\t<ion-datetime displayFormat=\"MM/YYYY\" (keyup)=\"search_keyword($event);\" placeholder=\"Select Date\" display-timezone=\"utc\"\r\n\t\t\t\t [(ngModel)]=\"exp_date\" name=\"exp_date\" min=\"2021\" max=\"2030\" class=\"exp_datee\" ></ion-datetime>\r\n\t\t\t\t</ion-item>\r\n\t\t\t\t <span error *ngIf=\"errors.indexOf(exp_date) >= 0 && is_submit_payment == true\">Please enter expiration date</span>\r\n\t\t\t\t\r\n</div>\r\n<div formfield>\r\n\t\t\t\t<label>CVC</label>\r\n\t\t\t\t<ion-item lines=\"none\" class=\"fls\"> \r\n\t\t\t\t\t<ion-input placeholder=\"Enter CVC\"  class=\"cvcc\"(keyup)=\"search_keyword($event);\" [(ngModel)]=\"cvc\" name=\"cvc\"></ion-input>\r\n\t\t\t\t</ion-item>\r\n\t\t\t\t <span error *ngIf=\"errors.indexOf(cvc) >= 0 && is_submit_payment == true\">Please enter cvc</span>\r\n\t\t\t\r\n</div>\r\n\r\n</div><!--ion-button  expand=\"full\" shape=\"round\" class=\"btn-losns\" (click)=\"addcard()\">Save Payment Method</ion-button-->\r\n\r\n<!--div formfield>\r\n\t\t\t\t<label>Your Amount</label>\r\n\t\t\t\t<ion-item lines=\"none\" class=\"fls\"> \r\n\t\t\t\t\t<ion-input placeholder=\"Enter Your Amount\" id=\"amount\" (keyup)=\"search_keyword($event);\"></ion-input>\r\n\t\t\t\t</ion-item>\r\n\t\t\t\t<p style=\"padding-top: 5px;\r\n    margin: 0px;\r\n    font-size: 12px;\r\n    padding-left: 12px;\"><span class=\"no_meals\">0</span> meals</p>\r\n</div-->\r\n<ion-button  expand=\"full\" shape=\"round\" class=\"btn-losns\" (click)=\"pay();\" >Pay</ion-button>\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "./src/app/app-routing.module.ts":
    /*!***************************************!*\
      !*** ./src/app/app-routing.module.ts ***!
      \***************************************/

    /*! exports provided: AppRoutingModule */

    /***/
    function srcAppAppRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function () {
        return AppRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

      var routes = [{
        path: '',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | welcome-welcome-module */
          "welcome-welcome-module").then(__webpack_require__.bind(null,
          /*! ./welcome/welcome.module */
          "./src/app/welcome/welcome.module.ts")).then(function (m) {
            return m.WelcomePageModule;
          });
        }
      }, {
        path: '',
        loadChildren: './tabs/tabs.module#TabsPageModule'
      }, {
        path: '',
        redirectTo: 'welcome',
        pathMatch: 'full'
      }, {
        path: 'folder/:id',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | folder-folder-module */
          "folder-folder-module").then(__webpack_require__.bind(null,
          /*! ./folder/folder.module */
          "./src/app/folder/folder.module.ts")).then(function (m) {
            return m.FolderPageModule;
          });
        }
      }, {
        path: 'login',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | login-login-module */
          "login-login-module").then(__webpack_require__.bind(null,
          /*! ./login/login.module */
          "./src/app/login/login.module.ts")).then(function (m) {
            return m.LoginPageModule;
          });
        }
      }, {
        path: 'signup',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | signup-signup-module */
          "signup-signup-module").then(__webpack_require__.bind(null,
          /*! ./signup/signup.module */
          "./src/app/signup/signup.module.ts")).then(function (m) {
            return m.SignupPageModule;
          });
        }
      }, {
        path: 'otp',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | otp-otp-module */
          "otp-otp-module").then(__webpack_require__.bind(null,
          /*! ./otp/otp.module */
          "./src/app/otp/otp.module.ts")).then(function (m) {
            return m.OtpPageModule;
          });
        }
      }, {
        path: 'home',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | home-home-module */
          [__webpack_require__.e("default~activitydetail-activitydetail-module~addamount-addamount-module~charitydetail-charitydetail-~e01b0d79"), __webpack_require__.e("home-home-module")]).then(__webpack_require__.bind(null,
          /*! ./home/home.module */
          "./src/app/home/home.module.ts")).then(function (m) {
            return m.HomePageModule;
          });
        }
      }, {
        path: 'home2',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | home2-home2-module */
          [__webpack_require__.e("common"), __webpack_require__.e("home2-home2-module")]).then(__webpack_require__.bind(null,
          /*! ./home2/home2.module */
          "./src/app/home2/home2.module.ts")).then(function (m) {
            return m.Home2PageModule;
          });
        }
      }, {
        path: 'settings',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | settings-settings-module */
          "settings-settings-module").then(__webpack_require__.bind(null,
          /*! ./settings/settings.module */
          "./src/app/settings/settings.module.ts")).then(function (m) {
            return m.SettingsPageModule;
          });
        }
      }, {
        path: 'profile',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | profile-profile-module */
          "profile-profile-module").then(__webpack_require__.bind(null,
          /*! ./profile/profile.module */
          "./src/app/profile/profile.module.ts")).then(function (m) {
            return m.ProfilePageModule;
          });
        }
      }, {
        path: 'editprofile',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | editprofile-editprofile-module */
          [__webpack_require__.e("default~createteam-createteam-module~editprofile-editprofile-module"), __webpack_require__.e("editprofile-editprofile-module")]).then(__webpack_require__.bind(null,
          /*! ./editprofile/editprofile.module */
          "./src/app/editprofile/editprofile.module.ts")).then(function (m) {
            return m.EditprofilePageModule;
          });
        }
      }, {
        path: 'addpayment',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | addpayment-addpayment-module */
          "addpayment-addpayment-module").then(__webpack_require__.bind(null,
          /*! ./addpayment/addpayment.module */
          "./src/app/addpayment/addpayment.module.ts")).then(function (m) {
            return m.AddpaymentPageModule;
          });
        }
      }, {
        path: 'about',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | about-about-module */
          "about-about-module").then(__webpack_require__.bind(null,
          /*! ./about/about.module */
          "./src/app/about/about.module.ts")).then(function (m) {
            return m.AboutPageModule;
          });
        }
      }, {
        path: 'privacy',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | privacy-privacy-module */
          "privacy-privacy-module").then(__webpack_require__.bind(null,
          /*! ./privacy/privacy.module */
          "./src/app/privacy/privacy.module.ts")).then(function (m) {
            return m.PrivacyPageModule;
          });
        }
      }, {
        path: 'terms',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | terms-terms-module */
          "terms-terms-module").then(__webpack_require__.bind(null,
          /*! ./terms/terms.module */
          "./src/app/terms/terms.module.ts")).then(function (m) {
            return m.TermsPageModule;
          });
        }
      }, {
        path: 'faq',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | faq-faq-module */
          "faq-faq-module").then(__webpack_require__.bind(null,
          /*! ./faq/faq.module */
          "./src/app/faq/faq.module.ts")).then(function (m) {
            return m.FaqPageModule;
          });
        }
      }, {
        path: 'tribes',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | tribes-tribes-module */
          [__webpack_require__.e("default~activitydetail-activitydetail-module~addamount-addamount-module~charitydetail-charitydetail-~e01b0d79"), __webpack_require__.e("tribes-tribes-module")]).then(__webpack_require__.bind(null,
          /*! ./tribes/tribes.module */
          "./src/app/tribes/tribes.module.ts")).then(function (m) {
            return m.TribesPageModule;
          });
        }
      }, {
        path: 'thetable',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | thetable-thetable-module */
          "thetable-thetable-module").then(__webpack_require__.bind(null,
          /*! ./thetable/thetable.module */
          "./src/app/thetable/thetable.module.ts")).then(function (m) {
            return m.ThetablePageModule;
          });
        }
      }, {
        path: 'charitydetail/:id',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | charitydetail-charitydetail-module */
          [__webpack_require__.e("default~activitydetail-activitydetail-module~addamount-addamount-module~charitydetail-charitydetail-~e01b0d79"), __webpack_require__.e("charitydetail-charitydetail-module")]).then(__webpack_require__.bind(null,
          /*! ./charitydetail/charitydetail.module */
          "./src/app/charitydetail/charitydetail.module.ts")).then(function (m) {
            return m.CharitydetailPageModule;
          });
        }
      }, {
        path: 'searchteam',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | searchteam-searchteam-module */
          "searchteam-searchteam-module").then(__webpack_require__.bind(null,
          /*! ./searchteam/searchteam.module */
          "./src/app/searchteam/searchteam.module.ts")).then(function (m) {
            return m.SearchteamPageModule;
          });
        }
      }, {
        path: 'activitydetail/:id',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | activitydetail-activitydetail-module */
          [__webpack_require__.e("default~activitydetail-activitydetail-module~addamount-addamount-module~charitydetail-charitydetail-~e01b0d79"), __webpack_require__.e("activitydetail-activitydetail-module")]).then(__webpack_require__.bind(null,
          /*! ./activitydetail/activitydetail.module */
          "./src/app/activitydetail/activitydetail.module.ts")).then(function (m) {
            return m.ActivitydetailPageModule;
          });
        }
      }, {
        path: 'teamdetail/:id',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | teamdetail-teamdetail-module */
          [__webpack_require__.e("default~activitydetail-activitydetail-module~addamount-addamount-module~charitydetail-charitydetail-~e01b0d79"), __webpack_require__.e("teamdetail-teamdetail-module")]).then(__webpack_require__.bind(null,
          /*! ./teamdetail/teamdetail.module */
          "./src/app/teamdetail/teamdetail.module.ts")).then(function (m) {
            return m.TeamdetailPageModule;
          });
        }
      }, {
        path: 'createteam',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | createteam-createteam-module */
          [__webpack_require__.e("default~createteam-createteam-module~editprofile-editprofile-module"), __webpack_require__.e("createteam-createteam-module")]).then(__webpack_require__.bind(null,
          /*! ./createteam/createteam.module */
          "./src/app/createteam/createteam.module.ts")).then(function (m) {
            return m.CreateteamPageModule;
          });
        }
      }, {
        path: 'thetabledetail',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | thetabledetail-thetabledetail-module */
          "thetabledetail-thetabledetail-module").then(__webpack_require__.bind(null,
          /*! ./thetabledetail/thetabledetail.module */
          "./src/app/thetabledetail/thetabledetail.module.ts")).then(function (m) {
            return m.ThetabledetailPageModule;
          });
        }
      }, {
        path: 'addamount',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | addamount-addamount-module */
          [__webpack_require__.e("default~activitydetail-activitydetail-module~addamount-addamount-module~charitydetail-charitydetail-~e01b0d79"), __webpack_require__.e("addamount-addamount-module")]).then(__webpack_require__.bind(null,
          /*! ./addamount/addamount.module */
          "./src/app/addamount/addamount.module.ts")).then(function (m) {
            return m.AddamountPageModule;
          });
        }
      }, {
        path: 'donationjar',
        loadChildren: function loadChildren() {
          return Promise.all(
          /*! import() | donationjar-donationjar-module */
          [__webpack_require__.e("common"), __webpack_require__.e("donationjar-donationjar-module")]).then(__webpack_require__.bind(null,
          /*! ./donationjar/donationjar.module */
          "./src/app/donationjar/donationjar.module.ts")).then(function (m) {
            return m.DonationjarPageModule;
          });
        }
      }, {
        path: 'teamdetails/:id',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | teamdetails-teamdetails-module */
          "teamdetails-teamdetails-module").then(__webpack_require__.bind(null,
          /*! ./teamdetails/teamdetails.module */
          "./src/app/teamdetails/teamdetails.module.ts")).then(function (m) {
            return m.TeamdetailsPageModule;
          });
        }
      }, {
        path: 'jointeamconfirm',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | jointeamconfirm-jointeamconfirm-module */
          "jointeamconfirm-jointeamconfirm-module").then(__webpack_require__.bind(null,
          /*! ./jointeamconfirm/jointeamconfirm.module */
          "./src/app/jointeamconfirm/jointeamconfirm.module.ts")).then(function (m) {
            return m.JointeamconfirmPageModule;
          });
        }
      }, {
        path: 'leaveteamconfirm',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | leaveteamconfirm-leaveteamconfirm-module */
          "leaveteamconfirm-leaveteamconfirm-module").then(__webpack_require__.bind(null,
          /*! ./leaveteamconfirm/leaveteamconfirm.module */
          "./src/app/leaveteamconfirm/leaveteamconfirm.module.ts")).then(function (m) {
            return m.LeaveteamconfirmPageModule;
          });
        }
      }, {
        path: 'edit_payment/:id',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | edit-payment-edit-payment-module */
          "edit-payment-edit-payment-module").then(__webpack_require__.bind(null,
          /*! ./edit-payment/edit-payment.module */
          "./src/app/edit-payment/edit-payment.module.ts")).then(function (m) {
            return m.EditPaymentPageModule;
          });
        }
      }, {
        path: 'deleteconfirm',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | deleteconfirm-deleteconfirm-module */
          "deleteconfirm-deleteconfirm-module").then(__webpack_require__.bind(null,
          /*! ./deleteconfirm/deleteconfirm.module */
          "./src/app/deleteconfirm/deleteconfirm.module.ts")).then(function (m) {
            return m.DeleteconfirmPageModule;
          });
        }
      }, {
        path: 'paymentlistmodal',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | paymentlistmodal-paymentlistmodal-module */
          "paymentlistmodal-paymentlistmodal-module").then(__webpack_require__.bind(null,
          /*! ./paymentlistmodal/paymentlistmodal.module */
          "./src/app/paymentlistmodal/paymentlistmodal.module.ts")).then(function (m) {
            return m.PaymentlistmodalPageModule;
          });
        }
      }, {
        path: 'customamount',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | customamount-customamount-module */
          "customamount-customamount-module").then(__webpack_require__.bind(null,
          /*! ./customamount/customamount.module */
          "./src/app/customamount/customamount.module.ts")).then(function (m) {
            return m.CustomamountPageModule;
          });
        }
      }, {
        path: 'contactus',
        loadChildren: function loadChildren() {
          return __webpack_require__.e(
          /*! import() | contactus-contactus-module */
          "contactus-contactus-module").then(__webpack_require__.bind(null,
          /*! ./contactus/contactus.module */
          "./src/app/contactus/contactus.module.ts")).then(function (m) {
            return m.ContactusPageModule;
          });
        }
      }];

      var AppRoutingModule = function AppRoutingModule() {
        _classCallCheck(this, AppRoutingModule);
      };

      AppRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, {
          preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"]
        })],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], AppRoutingModule);
      /***/
    },

    /***/
    "./src/app/app.component.scss":
    /*!************************************!*\
      !*** ./src/app/app.component.scss ***!
      \************************************/

    /*! exports provided: default */

    /***/
    function srcAppAppComponentScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-list {\n  padding: 0px;\n}\nion-list[menutop] {\n  padding: 0px;\n}\nion-list[menutop] ion-item ion-avatar {\n  height: 70px;\n  width: 70px;\n  border: 2px solid var(--ion-color-white);\n}\nion-list[menutop] ion-item ion-label {\n  margin-left: 20px;\n}\nion-list ion-menu-toggle ion-item {\n  border-bottom: 1px solid #eee;\n  padding: 5px 0px;\n  font-size: 15px;\n}\nion-list ion-menu-toggle ion-item ion-icon {\n  color: var(--ion-color-primary);\n  margin-right: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXBwLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0MsWUFBQTtBQUNEO0FBQUE7RUFFQSxZQUFBO0FBQ0E7QUFFQztFQUVBLFlBQUE7RUFDRyxXQUFBO0VBQ0Esd0NBQUE7QUFESjtBQUdDO0VBRUUsaUJBQUE7QUFGSDtBQU9DO0VBQ0csNkJBQUE7RUFDQSxnQkFBQTtFQUNBLGVBQUE7QUFMSjtBQU1JO0VBRUgsK0JBQUE7RUFDRyxrQkFBQTtBQUxKIiwiZmlsZSI6InNyYy9hcHAvYXBwLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWxpc3Rcclxue3BhZGRpbmc6MHB4O1xyXG4mW21lbnV0b3BdXHJcbntcclxucGFkZGluZzowcHg7XHJcbmlvbi1pdGVtXHJcbntcclxuIGlvbi1hdmF0YXJcclxuIHtcclxuIGhlaWdodDogNzBweDtcclxuICAgIHdpZHRoOiA3MHB4O1xyXG4gICAgYm9yZGVyOiAycHggc29saWQgdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuIH1cclxuIGlvbi1sYWJlbFxyXG4ge1xyXG4gICBtYXJnaW4tbGVmdDoyMHB4O1xyXG4gfVxyXG59XHJcbn1cclxuaW9uLW1lbnUtdG9nZ2xle1xyXG4gaW9uLWl0ZW1cclxuIHsgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZWVlO1xyXG4gICAgcGFkZGluZzogNXB4IDBweDtcclxuICAgIGZvbnQtc2l6ZTogMTVweDsgIFxyXG4gICAgaW9uLWljb25cclxuXHR7XHJcblx0Y29sb3I6ICB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcblx0fVxyXG4gfVxyXG59XHJcbn0iXX0= */";
      /***/
    },

    /***/
    "./src/app/app.component.ts":
    /*!**********************************!*\
      !*** ./src/app/app.component.ts ***!
      \**********************************/

    /*! exports provided: AppComponent */

    /***/
    function srcAppAppComponentTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppComponent", function () {
        return AppComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic-native/splash-screen/ngx */
      "./node_modules/@ionic-native/splash-screen/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic-native/status-bar/ngx */
      "./node_modules/@ionic-native/status-bar/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _config__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./config */
      "./src/app/config.ts");
      /* harmony import */


      var _services_globalFooService_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./services/globalFooService.service */
      "./src/app/services/globalFooService.service.ts"); //import {CommonService} from '../common/common.service';


      var AppComponent = /*#__PURE__*/function () {
        function AppComponent(platform, splashScreen, statusBar, router, globalFooService) {
          var _this = this;

          _classCallCheck(this, AppComponent);

          this.platform = platform;
          this.splashScreen = splashScreen;
          this.statusBar = statusBar;
          this.router = router;
          this.globalFooService = globalFooService;
          this.IMAGES_URL = _config__WEBPACK_IMPORTED_MODULE_6__["config"].IMAGES_URL;
          this.errors = ['', null, undefined];
          this.selectedIndex = 0;
          this.appPages = [{
            title: 'Logout',
            url: '/signup',
            icon: 'log-out-outline'
          }];
          this.globalFooService.getObservable().subscribe(function (data) {
            if (_this.errors.indexOf(data.foo) == -1) {
              _this.userid = data.foo.data.id;
              _this.type_login = data.foo.data.type;
              _this.first_name = localStorage.getItem('food_first_name');
              _this.last_name = localStorage.getItem('food_last_name');
              _this.email = localStorage.getItem('food_email');
              _this.profile_pic = localStorage.getItem('profile_pic');
            }

            console.log(_this.errors.indexOf(data.set));

            if (_this.errors.indexOf(data.set) == -1) {
              _this.type_login = data.set.data;
              localStorage.setItem('type_login', '1');
            }
          });
          this.initializeApp();
        }

        _createClass(AppComponent, [{
          key: "initializeApp",
          value: function initializeApp() {
            var _this2 = this;

            this.platform.ready().then(function () {
              _this2.statusBar.styleDefault();

              _this2.splashScreen.hide();
            });
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {
            var path = window.location.pathname.split('folder/')[1];

            if (path !== undefined) {
              this.selectedIndex = this.appPages.findIndex(function (page) {
                return page.title.toLowerCase() === path.toLowerCase();
              });
            }
          }
        }, {
          key: "ionViewDidEnter",
          value: function ionViewDidEnter() {}
        }, {
          key: "logout",
          value: function logout() {
            localStorage.clear(); //this.events.publish('logged_in:true','');

            this.router.navigate(["/"]);
          }
        }]);

        return AppComponent;
      }();

      AppComponent.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]
        }, {
          type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"]
        }, {
          type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]
        }, {
          type: _services_globalFooService_service__WEBPACK_IMPORTED_MODULE_7__["GlobalFooService"]
        }];
      };

      AppComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-root',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./app.component.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./app.component.scss */
        "./src/app/app.component.scss"))["default"]]
      })], AppComponent);
      /***/
    },

    /***/
    "./src/app/app.module.ts":
    /*!*******************************!*\
      !*** ./src/app/app.module.ts ***!
      \*******************************/

    /*! exports provided: AppModule */

    /***/
    function srcAppAppModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppModule", function () {
        return AppModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/platform-browser */
      "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic-native/splash-screen/ngx */
      "./node_modules/@ionic-native/splash-screen/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic-native/status-bar/ngx */
      "./node_modules/@ionic-native/status-bar/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _app_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./app.component */
      "./src/app/app.component.ts");
      /* harmony import */


      var _app_routing_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ./app-routing.module */
      "./src/app/app-routing.module.ts");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @angular/common/http */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
      /* harmony import */


      var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! @ionic-native/camera/ngx */
      "./node_modules/@ionic-native/camera/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @ionic-native/file/ngx */
      "./node_modules/@ionic-native/file/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! @ionic-native/file-path/ngx */
      "./node_modules/@ionic-native/file-path/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! @ionic-native/file-transfer/ngx */
      "./node_modules/@ionic-native/file-transfer/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _jointeamconfirm_jointeamconfirm_page__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! ./jointeamconfirm/jointeamconfirm.page */
      "./src/app/jointeamconfirm/jointeamconfirm.page.ts");
      /* harmony import */


      var _paymentlistmodal_paymentlistmodal_page__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
      /*! ./paymentlistmodal/paymentlistmodal.page */
      "./src/app/paymentlistmodal/paymentlistmodal.page.ts");
      /* harmony import */


      var _leaveteamconfirm_leaveteamconfirm_page__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
      /*! ./leaveteamconfirm/leaveteamconfirm.page */
      "./src/app/leaveteamconfirm/leaveteamconfirm.page.ts");
      /* harmony import */


      var _customamount_customamount_page__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(
      /*! ./customamount/customamount.page */
      "./src/app/customamount/customamount.page.ts");
      /* harmony import */


      var _deleteconfirm_deleteconfirm_page__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(
      /*! ./deleteconfirm/deleteconfirm.page */
      "./src/app/deleteconfirm/deleteconfirm.page.ts");
      /* harmony import */


      var _ionic_native_facebook_ngx__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(
      /*! @ionic-native/facebook/ngx */
      "./node_modules/@ionic-native/facebook/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(
      /*! @ionic-native/google-plus/ngx */
      "./node_modules/@ionic-native/google-plus/__ivy_ngcc__/ngx/index.js");

      var AppModule = function AppModule() {
        _classCallCheck(this, AppModule);
      };

      AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"], _jointeamconfirm_jointeamconfirm_page__WEBPACK_IMPORTED_MODULE_14__["JointeamconfirmPage"], _leaveteamconfirm_leaveteamconfirm_page__WEBPACK_IMPORTED_MODULE_16__["LeaveteamconfirmPage"], _deleteconfirm_deleteconfirm_page__WEBPACK_IMPORTED_MODULE_18__["DeleteconfirmPage"], _paymentlistmodal_paymentlistmodal_page__WEBPACK_IMPORTED_MODULE_15__["PaymentlistmodalPage"], _customamount_customamount_page__WEBPACK_IMPORTED_MODULE_17__["CustomamountPage"]],
        entryComponents: [_jointeamconfirm_jointeamconfirm_page__WEBPACK_IMPORTED_MODULE_14__["JointeamconfirmPage"], _leaveteamconfirm_leaveteamconfirm_page__WEBPACK_IMPORTED_MODULE_16__["LeaveteamconfirmPage"], _deleteconfirm_deleteconfirm_page__WEBPACK_IMPORTED_MODULE_18__["DeleteconfirmPage"], _paymentlistmodal_paymentlistmodal_page__WEBPACK_IMPORTED_MODULE_15__["PaymentlistmodalPage"], _customamount_customamount_page__WEBPACK_IMPORTED_MODULE_17__["CustomamountPage"]],
        imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_8__["AppRoutingModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_9__["HttpClientModule"]],
        providers: [_ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_6__["StatusBar"], _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_5__["SplashScreen"], _angular_common_http__WEBPACK_IMPORTED_MODULE_9__["HttpClient"], _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_10__["Camera"], _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_11__["File"], _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_12__["FilePath"], _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_13__["FileTransfer"], _ionic_native_facebook_ngx__WEBPACK_IMPORTED_MODULE_19__["Facebook"], _ionic_native_google_plus_ngx__WEBPACK_IMPORTED_MODULE_20__["GooglePlus"], {
          provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"],
          useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicRouteStrategy"]
        }],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_7__["AppComponent"]]
      })], AppModule);
      /***/
    },

    /***/
    "./src/app/common/common.service.ts":
    /*!******************************************!*\
      !*** ./src/app/common/common.service.ts ***!
      \******************************************/

    /*! exports provided: CommonService */

    /***/
    function srcAppCommonCommonServiceTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CommonService", function () {
        return CommonService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

      var CommonService = /*#__PURE__*/function () {
        function CommonService(toastController, loadingController) {
          _classCallCheck(this, CommonService);

          this.toastController = toastController;
          this.loadingController = loadingController;
        }

        _createClass(CommonService, [{
          key: "presentToast",
          value: function presentToast(message, color) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var toast;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.toastController.create({
                        message: message,
                        duration: 5000,
                        position: 'bottom',
                        color: color,
                        //showCloseButton: true,
                        mode: "ios"
                      });

                    case 2:
                      toast = _context.sent;
                      toast.present();

                    case 4:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "presentLoading",
          value: function presentLoading() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this.loadingController.create({
                        mode: "ios"
                      });

                    case 2:
                      this.loading = _context2.sent;
                      _context2.next = 5;
                      return this.loading.present();

                    case 5:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "stopLoading",
          value: function stopLoading() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              var self;
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      if (!(this.loading != undefined)) {
                        _context3.next = 5;
                        break;
                      }

                      _context3.next = 3;
                      return this.loading.dismiss();

                    case 3:
                      _context3.next = 7;
                      break;

                    case 5:
                      self = this;
                      setTimeout(function () {
                        self.stopLoading();
                      }, 1000);

                    case 7:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          }
        }]);

        return CommonService;
      }();

      CommonService.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]
        }];
      };

      CommonService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], CommonService);
      /***/
    },

    /***/
    "./src/app/config.ts":
    /*!***************************!*\
      !*** ./src/app/config.ts ***!
      \***************************/

    /*! exports provided: config, social_config */

    /***/
    function srcAppConfigTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "config", function () {
        return config;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "social_config", function () {
        return social_config;
      });

      var MAIN_URL = 'http://dev.indiit.solutions/foodforlife/api/'; //edit your public ip
      //var MAIN_URL_PORT = '3002/';
      //var SOCKET_URL_PORT = '3001/'; 

      var config = {
        API_URL: MAIN_URL,
        ENC_SALT: 'gd58_N9!ysS',
        errors: ['', null, undefined],
        IMAGES_URL: MAIN_URL + 'public/uploads',
        IMAGE_EXTENSIONS: ['image/png', 'image/jpg', 'image/jpeg', 'image/gif', 'image/bmp', 'image/webp']
      };
      var social_config = {
        FACEBOOK_ID: '956124408469355',
        GOOLGLE_CLIENT_ID: '608339143855-msuu5n847treif8htdsju9kia98nr4ms.apps.googleusercontent.com'
      };
      /* export const socket_config = {
          SOCKET_URL: MAIN_URL+SOCKET_URL_PORT,
      };
       */

      /***/
    },

    /***/
    "./src/app/customamount/customamount.page.scss":
    /*!*****************************************************!*\
      !*** ./src/app/customamount/customamount.page.scss ***!
      \*****************************************************/

    /*! exports provided: default */

    /***/
    function srcAppCustomamountCustomamountPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-header ion-toolbar {\n  --ion-color-base: var(--ion-color-bggradient)!important;\n  --border-width: 0;\n}\nion-header ion-toolbar ion-title {\n  color: var(--ion-color-white);\n  text-align: center;\n  font-style: normal;\n  font-family: \"Poppins\", sans-serif !important;\n}\nion-header ion-toolbar ion-buttons {\n  font-size: 25px;\n  margin-right: 10px;\n}\nion-header::after {\n  display: none;\n}\nion-content [amountimg] img {\n  height: 120px;\n  width: 120px;\n  -o-object-fit: cover;\n     object-fit: cover;\n  border-radius: 50%;\n  border: 5px solid var(--ion-color-softgreen);\n}\nion-content [amountimg] p {\n  font-size: 14px;\n  line-height: 22px;\n  font-weight: 300;\n  color: #adadad;\n  margin-top: 10px;\n}\nion-content [formfield] {\n  position: relative;\n  border: 1px solid #e8e8e8;\n  height: 52px;\n  border-radius: 50px;\n  background: var(--ion-color-white);\n  padding: 0 16px;\n  margin-top: 20px;\n}\nion-content [formfield] label {\n  position: absolute;\n  top: -10px;\n  z-index: 111;\n  background: var(--ion-color-white);\n  left: 29px;\n  padding: 0 3px;\n  font-size: 12px;\n  font-weight: 700;\n  color: #3a3a3a;\n}\nion-content [formfield] ion-input, ion-content [formfield] ion-datetime {\n  padding: 0px;\n  --padding-start: 0px;\n  --padding-end: 0px;\n  font-size: 14px;\n  --placeholder-color: #9a9a9a;\n  --placeholder-opacity: 1;\n  font-family: \"Poppins\", sans-serif !important;\n  color: #222;\n}\nion-content [formfield][dollar-input] img {\n  max-width: 15px;\n  margin-right: 4px;\n}\nion-content [formfield][dollar-input] ion-item {\n  --padding-start:0px;\n}\nion-content .btn-losns {\n  --background:var( --ion-color-primary);\n  margin-top: 10px;\n  --box-shadow: none;\n  min-height: 48px;\n  margin-bottom: 15px;\n  text-transform: uppercase;\n  letter-spacing: 1px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY3VzdG9tYW1vdW50L2N1c3RvbWFtb3VudC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBR0c7RUFDQyx1REFBQTtFQUNELGlCQUFBO0FBRkg7QUFJSTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7RUFDUSxrQkFBQTtFQUNBLDZDQUFBO0FBRlo7QUFJRTtFQUVBLGVBQUE7RUFDRSxrQkFBQTtBQUhKO0FBTUM7RUFFQSxhQUFBO0FBTEQ7QUFXRTtFQUVJLGFBQUE7RUFDQSxZQUFBO0VBQ0Esb0JBQUE7S0FBQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsNENBQUE7QUFUTjtBQVdFO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QUFUSjtBQWFBO0VBQ0csa0JBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGtDQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBWEg7QUFZRztFQUNDLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxrQ0FBQTtFQUNBLFVBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQVZKO0FBWUc7RUFDQyxZQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSw0QkFBQTtFQUNBLHdCQUFBO0VBQ0EsNkNBQUE7RUFDQSxXQUFBO0FBVko7QUFjTztFQUVLLGVBQUE7RUFDQSxpQkFBQTtBQWJaO0FBZVE7RUFFSyxtQkFBQTtBQWRiO0FBa0JFO0VBQ0Msc0NBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ1MsZ0JBQUE7RUFDVCxtQkFBQTtFQUNBLHlCQUFBO0VBQ0EsbUJBQUE7QUFoQkgiLCJmaWxlIjoic3JjL2FwcC9jdXN0b21hbW91bnQvY3VzdG9tYW1vdW50LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXJcclxue1xyXG5cdFxyXG5cdCAgaW9uLXRvb2xiYXJcclxuXHQgIHstLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1pb24tY29sb3ItYmdncmFkaWVudCkhaW1wb3J0YW50O1xyXG5cdCAgLS1ib3JkZXItd2lkdGg6IDA7XHJcblx0XHJcblx0XHQgIGlvbi10aXRsZXtcclxuXHRcdCAgY29sb3I6dmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuXHRcdCAgdGV4dC1hbGlnbjpjZW50ZXI7XHJcbiAgICAgICAgICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xyXG4gICAgICAgIH1cclxuXHRcdGlvbi1idXR0b25zXHJcblx0XHR7XHJcblx0XHRmb250LXNpemU6IDI1cHg7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcblx0XHR9XHJcblx0fVxyXG5cdCY6OmFmdGVyXHJcblx0e1xyXG5cdGRpc3BsYXk6bm9uZTtcclxuXHR9XHJcbn1cclxuaW9uLWNvbnRlbnRcclxue1thbW91bnRpbWddXHJcbntcclxuICBpbWdcclxuICB7XHJcbiAgICAgIGhlaWdodDogMTIwcHg7XHJcbiAgICAgIHdpZHRoOiAxMjBweDtcclxuICAgICAgb2JqZWN0LWZpdDogY292ZXI7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgYm9yZGVyOiA1cHggc29saWQgdmFyKC0taW9uLWNvbG9yLXNvZnRncmVlbik7XHJcbiAgfVxyXG4gIHBcclxuICB7XHRmb250LXNpemU6IDE0cHg7XHJcblx0XHRcdFx0bGluZS1oZWlnaHQ6IDIycHg7XHJcblx0XHRcdFx0Zm9udC13ZWlnaHQ6IDMwMDtcclxuXHRcdFx0XHRjb2xvcjogI2FkYWRhZDtcclxuXHRcdFx0XHRtYXJnaW4tdG9wOiAxMHB4O1xyXG4gIFxyXG4gIH1cclxufVxyXG5bZm9ybWZpZWxkXSB7XHJcblx0XHRcdHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHRcdFx0Ym9yZGVyOiAxcHggc29saWQgI2U4ZThlODtcclxuXHRcdFx0aGVpZ2h0OiA1MnB4O1xyXG5cdFx0XHRib3JkZXItcmFkaXVzOiA1MHB4O1xyXG5cdFx0XHRiYWNrZ3JvdW5kOnZhciggLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdFx0XHRwYWRkaW5nOiAwIDE2cHg7XHJcblx0XHRcdG1hcmdpbi10b3A6MjBweDtcclxuXHRcdFx0bGFiZWwge1xyXG5cdFx0XHRcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRcdFx0XHR0b3A6IC0xMHB4O1xyXG5cdFx0XHRcdHotaW5kZXg6IDExMTtcclxuXHRcdFx0XHRiYWNrZ3JvdW5kOiB2YXIoIC0taW9uLWNvbG9yLXdoaXRlKTtcclxuXHRcdFx0XHRsZWZ0OiAyOXB4O1xyXG5cdFx0XHRcdHBhZGRpbmc6IDAgM3B4O1xyXG5cdFx0XHRcdGZvbnQtc2l6ZTogMTJweDtcclxuXHRcdFx0XHRmb250LXdlaWdodDogNzAwO1xyXG5cdFx0XHRcdGNvbG9yOiAjM2EzYTNhO1xyXG5cdFx0XHR9XHJcblx0XHRcdGlvbi1pbnB1dCAsIGlvbi1kYXRldGltZSAge1xyXG5cdFx0XHRcdHBhZGRpbmc6IDBweDtcclxuXHRcdFx0XHQtLXBhZGRpbmctc3RhcnQ6IDBweDtcclxuXHRcdFx0XHQtLXBhZGRpbmctZW5kOiAwcHg7XHJcblx0XHRcdFx0Zm9udC1zaXplOiAxNHB4O1xyXG5cdFx0XHRcdC0tcGxhY2Vob2xkZXItY29sb3I6ICM5YTlhOWE7XHJcblx0XHRcdFx0LS1wbGFjZWhvbGRlci1vcGFjaXR5OiAxO1xyXG5cdFx0XHRcdGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcclxuXHRcdFx0XHRjb2xvcjogIzIyMjtcclxuXHRcdFx0fVxyXG5cdFx0XHQmW2RvbGxhci1pbnB1dF1cclxuXHRcdFx0e1xyXG5cdFx0XHQgICAgaW1nXHJcblx0XHRcdCAgICB7XHJcblx0XHRcdCAgICAgICAgIG1heC13aWR0aDoxNXB4O1xyXG5cdFx0XHQgICAgICAgICBtYXJnaW4tcmlnaHQ6IDRweDtcclxuXHRcdFx0ICAgIH1cclxuXHRcdFx0ICAgICBpb24taXRlbVxyXG5cdFx0XHQgICAgIHtcclxuXHRcdFx0ICAgICAgICAgIC0tcGFkZGluZy1zdGFydDowcHg7XHJcblx0XHRcdCAgICAgfVxyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0XHQuYnRuLWxvc25ze1xyXG5cdFx0XHQtLWJhY2tncm91bmQ6dmFyKCAtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuXHRcdFx0bWFyZ2luLXRvcDogMTBweDtcclxuXHRcdFx0LS1ib3gtc2hhZG93OiBub25lO1xyXG4gICAgICAgICAgICBtaW4taGVpZ2h0OiA0OHB4O1xyXG5cdFx0XHRtYXJnaW4tYm90dG9tOiAxNXB4O1xyXG5cdFx0XHR0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG5cdFx0XHRsZXR0ZXItc3BhY2luZzogMXB4O1xyXG5cdFx0fVxyXG59Il19 */";
      /***/
    },

    /***/
    "./src/app/customamount/customamount.page.ts":
    /*!***************************************************!*\
      !*** ./src/app/customamount/customamount.page.ts ***!
      \***************************************************/

    /*! exports provided: CustomamountPage */

    /***/
    function srcAppCustomamountCustomamountPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "CustomamountPage", function () {
        return CustomamountPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../services/api/api.service */
      "./src/app/services/api/api.service.ts");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../config */
      "./src/app/config.ts");
      /* harmony import */


      var _common_common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../common/common.service */
      "./src/app/common/common.service.ts");
      /* harmony import */


      var jquery__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! jquery */
      "./node_modules/jquery/dist/jquery.js");
      /* harmony import */


      var jquery__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_6__);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

      var CustomamountPage = /*#__PURE__*/function () {
        function CustomamountPage(navParams, api, router, common, modalController) {
          _classCallCheck(this, CustomamountPage);

          this.navParams = navParams;
          this.api = api;
          this.router = router;
          this.common = common;
          this.modalController = modalController;
          this.IMAGES_URL = _config__WEBPACK_IMPORTED_MODULE_4__["config"].IMAGES_URL;
          this.errors = ['', null, undefined];
          this.timeout = null;
        }

        _createClass(CustomamountPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "search_keyword",
          value: function search_keyword(event) {
            clearTimeout(this.timeout);
            var self = this;
            this.timeout = setTimeout(function () {
              if (self.errors.indexOf(event.target.value) == -1) {
                self.search_text = event.target.value;
                self.minimum = 1;

                if (self.search_text < self.minimum) {
                  self.common.presentToast('Minimum donation is 1 dollar !.', 'danger');
                  self.search_text = '';
                  jquery__WEBPACK_IMPORTED_MODULE_6__('#amount1').val('');
                }

                var tot = self.search_text % self.minimum;

                if (tot == 0) {} else {
                  var min = self.search_text - tot;
                  jquery__WEBPACK_IMPORTED_MODULE_6__('#amount1').val(min);
                  self.common.presentToast('We have rounded the amount entered to the nearest number of meals', 'success');
                }

                var val = jquery__WEBPACK_IMPORTED_MODULE_6__('#amount1').val();
                var tot1 = val * 4;
                jquery__WEBPACK_IMPORTED_MODULE_6__('.no_meals').text(tot1);
                console.log(self.search_text);
              } else {
                self.search_text = event.target.value;
                jquery__WEBPACK_IMPORTED_MODULE_6__('.no_meals').text('0');
              }
            }, 500);
          }
        }, {
          key: "dismiss",
          value: function dismiss() {
            this.modalController.dismiss({
              'dismissed': true
            });
          }
        }, {
          key: "ionViewDidEnter",
          value: function ionViewDidEnter() {
            this.userid = localStorage.getItem('userid');
          }
        }, {
          key: "confirm",
          value: function confirm() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                  switch (_context4.prev = _context4.next) {
                    case 0:
                      if (!(this.errors.indexOf(jquery__WEBPACK_IMPORTED_MODULE_6__('#amount1').val()) >= 0)) {
                        _context4.next = 3;
                        break;
                      }

                      this.common.presentToast('Please enter amount !', 'danger');
                      return _context4.abrupt("return", false);

                    case 3:
                      this.dismiss1('data');

                    case 4:
                    case "end":
                      return _context4.stop();
                  }
                }
              }, _callee4, this);
            }));
          }
        }, {
          key: "dismiss1",
          value: function dismiss1(data) {
            this.modalController.dismiss({
              'data': jquery__WEBPACK_IMPORTED_MODULE_6__('#amount1').val()
            });
          }
        }]);

        return CustomamountPage;
      }();

      CustomamountPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["NavParams"]
        }, {
          type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
        }, {
          type: _common_common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"]
        }];
      };

      CustomamountPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-customamount',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./customamount.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/customamount/customamount.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./customamount.page.scss */
        "./src/app/customamount/customamount.page.scss"))["default"]]
      })], CustomamountPage);
      /***/
    },

    /***/
    "./src/app/deleteconfirm/deleteconfirm.page.scss":
    /*!*******************************************************!*\
      !*** ./src/app/deleteconfirm/deleteconfirm.page.scss ***!
      \*******************************************************/

    /*! exports provided: default */

    /***/
    function srcAppDeleteconfirmDeleteconfirmPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2RlbGV0ZWNvbmZpcm0vZGVsZXRlY29uZmlybS5wYWdlLnNjc3MifQ== */";
      /***/
    },

    /***/
    "./src/app/deleteconfirm/deleteconfirm.page.ts":
    /*!*****************************************************!*\
      !*** ./src/app/deleteconfirm/deleteconfirm.page.ts ***!
      \*****************************************************/

    /*! exports provided: DeleteconfirmPage */

    /***/
    function srcAppDeleteconfirmDeleteconfirmPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "DeleteconfirmPage", function () {
        return DeleteconfirmPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../services/api/api.service */
      "./src/app/services/api/api.service.ts");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _common_common_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../common/common.service */
      "./src/app/common/common.service.ts");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

      var DeleteconfirmPage = /*#__PURE__*/function () {
        function DeleteconfirmPage(navParams, api, router, common, modalController) {
          _classCallCheck(this, DeleteconfirmPage);

          this.navParams = navParams;
          this.api = api;
          this.router = router;
          this.common = common;
          this.modalController = modalController;
          this.paymentid = navParams.get('paymentid');
        }

        _createClass(DeleteconfirmPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "cancelok",
          value: function cancelok() {
            this.modalController.dismiss('deletedsuccessfully');
          }
        }, {
          key: "cancel",
          value: function cancel() {
            this.modalController.dismiss();
          }
        }, {
          key: "delete",
          value: function _delete() {
            var _this3 = this;

            var dict = {
              id: this.paymentid
            };
            this.common.presentLoading();
            this.api.post('DeletePayment', dict, '').subscribe(function (result) {
              _this3.common.stopLoading();

              var res;
              res = result;

              if (res.status == 1) {
                _this3.common.presentToast('Payment method deleted successfully !.', 'success');

                _this3.cancelok();
              } else {
                _this3.common.presentToast(res.message, 'danger');
              }
            }, function (err) {});
          }
        }]);

        return DeleteconfirmPage;
      }();

      DeleteconfirmPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavParams"]
        }, {
          type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
        }, {
          type: _common_common_service__WEBPACK_IMPORTED_MODULE_4__["CommonService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"]
        }];
      };

      DeleteconfirmPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-deleteconfirm',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./deleteconfirm.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/deleteconfirm/deleteconfirm.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./deleteconfirm.page.scss */
        "./src/app/deleteconfirm/deleteconfirm.page.scss"))["default"]]
      })], DeleteconfirmPage);
      /***/
    },

    /***/
    "./src/app/jointeamconfirm/jointeamconfirm.page.scss":
    /*!***********************************************************!*\
      !*** ./src/app/jointeamconfirm/jointeamconfirm.page.scss ***!
      \***********************************************************/

    /*! exports provided: default */

    /***/
    function srcAppJointeamconfirmJointeamconfirmPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".jointeamconfirm {\n  width: 100%;\n  height: 100%;\n  max-width: 325px;\n  margin: 0 auto;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  background-color: #fff;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvam9pbnRlYW1jb25maXJtL2pvaW50ZWFtY29uZmlybS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0Esc0JBQUE7QUFDSiIsImZpbGUiOiJzcmMvYXBwL2pvaW50ZWFtY29uZmlybS9qb2ludGVhbWNvbmZpcm0ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmpvaW50ZWFtY29uZmlybSB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIG1heC13aWR0aDogMzI1cHg7XHJcbiAgICBtYXJnaW46IDAgYXV0bztcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xyXG59Il19 */";
      /***/
    },

    /***/
    "./src/app/jointeamconfirm/jointeamconfirm.page.ts":
    /*!*********************************************************!*\
      !*** ./src/app/jointeamconfirm/jointeamconfirm.page.ts ***!
      \*********************************************************/

    /*! exports provided: JointeamconfirmPage */

    /***/
    function srcAppJointeamconfirmJointeamconfirmPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "JointeamconfirmPage", function () {
        return JointeamconfirmPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../services/api/api.service */
      "./src/app/services/api/api.service.ts");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _common_common_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../common/common.service */
      "./src/app/common/common.service.ts");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

      var JointeamconfirmPage = /*#__PURE__*/function () {
        function JointeamconfirmPage(navParams, api, router, common, modalController) {
          _classCallCheck(this, JointeamconfirmPage);

          this.navParams = navParams;
          this.api = api;
          this.router = router;
          this.common = common;
          this.modalController = modalController;
          this.userid = navParams.get('userid');
          this.teamid = navParams.get('teamid');
        }

        _createClass(JointeamconfirmPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "cancelok",
          value: function cancelok() {
            this.modalController.dismiss('joinedsuucessfully');
          }
        }, {
          key: "cancel",
          value: function cancel() {
            this.modalController.dismiss();
          }
        }, {
          key: "join",
          value: function join() {
            var _this4 = this;

            var dict = {
              userid: this.userid,
              teamid: this.teamid
            };
            this.common.presentLoading();
            this.api.post('JoinTeam', dict, '').subscribe(function (result) {
              _this4.common.stopLoading();

              var res;
              res = result;

              if (res.status == 1) {
                _this4.common.presentToast('Team joined successfully !.', 'success');

                _this4.cancelok();
              } else {
                _this4.common.presentToast(res.message, 'danger');
              }
            }, function (err) {});
          }
        }]);

        return JointeamconfirmPage;
      }();

      JointeamconfirmPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavParams"]
        }, {
          type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
        }, {
          type: _common_common_service__WEBPACK_IMPORTED_MODULE_4__["CommonService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"]
        }];
      };

      JointeamconfirmPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-jointeamconfirm',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./jointeamconfirm.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/jointeamconfirm/jointeamconfirm.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./jointeamconfirm.page.scss */
        "./src/app/jointeamconfirm/jointeamconfirm.page.scss"))["default"]]
      })], JointeamconfirmPage);
      /***/
    },

    /***/
    "./src/app/leaveteamconfirm/leaveteamconfirm.page.scss":
    /*!*************************************************************!*\
      !*** ./src/app/leaveteamconfirm/leaveteamconfirm.page.scss ***!
      \*************************************************************/

    /*! exports provided: default */

    /***/
    function srcAppLeaveteamconfirmLeaveteamconfirmPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2xlYXZldGVhbWNvbmZpcm0vbGVhdmV0ZWFtY29uZmlybS5wYWdlLnNjc3MifQ== */";
      /***/
    },

    /***/
    "./src/app/leaveteamconfirm/leaveteamconfirm.page.ts":
    /*!***********************************************************!*\
      !*** ./src/app/leaveteamconfirm/leaveteamconfirm.page.ts ***!
      \***********************************************************/

    /*! exports provided: LeaveteamconfirmPage */

    /***/
    function srcAppLeaveteamconfirmLeaveteamconfirmPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "LeaveteamconfirmPage", function () {
        return LeaveteamconfirmPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../services/api/api.service */
      "./src/app/services/api/api.service.ts");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _common_common_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../common/common.service */
      "./src/app/common/common.service.ts");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

      var LeaveteamconfirmPage = /*#__PURE__*/function () {
        function LeaveteamconfirmPage(navParams, api, router, common, modalController) {
          _classCallCheck(this, LeaveteamconfirmPage);

          this.navParams = navParams;
          this.api = api;
          this.router = router;
          this.common = common;
          this.modalController = modalController;
          this.userid = navParams.get('userid');
          this.teamid = navParams.get('teamid');
          this.getteamdetails();
        }

        _createClass(LeaveteamconfirmPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "getteamdetails",
          value: function getteamdetails() {
            var _this5 = this;

            var dict = {
              id: this.teamid
            };
            this.common.presentLoading();
            this.api.post('teamdetail', dict, '').subscribe(function (result) {
              _this5.common.stopLoading();

              var res;
              res = result;

              if (res.status == 1) {
                _this5.team_name = res.data.name;
              } else {}
            }, function (err) {});
          }
        }, {
          key: "cancelok",
          value: function cancelok() {
            this.modalController.dismiss('joinedsuucessfully');
          }
        }, {
          key: "cancel",
          value: function cancel() {
            this.modalController.dismiss();
          }
        }, {
          key: "join",
          value: function join() {
            var _this6 = this;

            var dict = {
              userid: this.userid,
              teamid: this.teamid
            };
            this.common.presentLoading();
            this.api.post('JoinTeam', dict, '').subscribe(function (result) {
              _this6.common.stopLoading();

              var res;
              res = result;

              if (res.status == 1) {
                _this6.common.presentToast('Team leaved successfully !.', 'success');

                _this6.cancelok();
              } else {
                _this6.common.presentToast(res.message, 'danger');
              }
            }, function (err) {});
          }
        }]);

        return LeaveteamconfirmPage;
      }();

      LeaveteamconfirmPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["NavParams"]
        }, {
          type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
        }, {
          type: _common_common_service__WEBPACK_IMPORTED_MODULE_4__["CommonService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"]
        }];
      };

      LeaveteamconfirmPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-leaveteamconfirm',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./leaveteamconfirm.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/leaveteamconfirm/leaveteamconfirm.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./leaveteamconfirm.page.scss */
        "./src/app/leaveteamconfirm/leaveteamconfirm.page.scss"))["default"]]
      })], LeaveteamconfirmPage);
      /***/
    },

    /***/
    "./src/app/paymentlistmodal/paymentlistmodal.page.scss":
    /*!*************************************************************!*\
      !*** ./src/app/paymentlistmodal/paymentlistmodal.page.scss ***!
      \*************************************************************/

    /*! exports provided: default */

    /***/
    function srcAppPaymentlistmodalPaymentlistmodalPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-header ion-toolbar {\n  --ion-color-base: var(--ion-color-bggradient)!important;\n  --border-width: 0;\n}\nion-header ion-toolbar ion-title {\n  color: var(--ion-color-white);\n  text-align: center;\n  font-style: normal;\n  font-family: \"Poppins\", sans-serif !important;\n}\nion-header ion-toolbar ion-buttons {\n  font-size: 25px;\n  margin-right: 10px;\n}\nion-header::after {\n  display: none;\n}\nion-content [amountimg] img {\n  height: 120px;\n  width: 120px;\n  -o-object-fit: cover;\n     object-fit: cover;\n  border-radius: 50%;\n  border: 5px solid var(--ion-color-softgreen);\n}\nion-content [amountimg] p {\n  font-size: 14px;\n  line-height: 22px;\n  font-weight: 300;\n  color: #adadad;\n  margin-top: 10px;\n}\nion-content [formfield] {\n  position: relative;\n  border: 1px solid #e8e8e8;\n  height: 52px;\n  border-radius: 50px;\n  background: var(--ion-color-white);\n  padding: 0 16px;\n  margin-top: 25px;\n}\nion-content [formfield] label {\n  position: absolute;\n  top: -10px;\n  z-index: 111;\n  background: var(--ion-color-white);\n  left: 29px;\n  padding: 0 3px;\n  font-size: 12px;\n  font-weight: 700;\n  color: #3a3a3a;\n}\nion-content [formfield] ion-input, ion-content [formfield] ion-datetime {\n  padding: 0px;\n  --padding-start: 0px;\n  --padding-end: 0px;\n  font-size: 14px;\n  --placeholder-color: #9a9a9a;\n  --placeholder-opacity: 1;\n  font-family: \"Poppins\", sans-serif !important;\n  color: #222;\n}\nion-content .btn-losns {\n  --background:var( --ion-color-primary);\n  margin-top: 20px;\n  --box-shadow: none;\n  min-height: 48px;\n  margin-bottom: 15px;\n  text-transform: uppercase;\n  letter-spacing: 1px;\n}\n[error] {\n  color: red;\n  font-size: 12px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcGF5bWVudGxpc3Rtb2RhbC9wYXltZW50bGlzdG1vZGFsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHRztFQUNDLHVEQUFBO0VBQ0QsaUJBQUE7QUFGSDtBQUlJO0VBQ0EsNkJBQUE7RUFDQSxrQkFBQTtFQUNRLGtCQUFBO0VBQ0EsNkNBQUE7QUFGWjtBQUlFO0VBRUEsZUFBQTtFQUNFLGtCQUFBO0FBSEo7QUFNQztFQUVBLGFBQUE7QUFMRDtBQVdFO0VBRUksYUFBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtLQUFBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSw0Q0FBQTtBQVROO0FBV0U7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQVRKO0FBYUE7RUFDRyxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0Esa0NBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUFYSDtBQVlHO0VBQ0Msa0JBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLGtDQUFBO0VBQ0EsVUFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FBVko7QUFZRztFQUNDLFlBQUE7RUFDQSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLDRCQUFBO0VBQ0Esd0JBQUE7RUFDQSw2Q0FBQTtFQUNBLFdBQUE7QUFWSjtBQWFFO0VBQ0Msc0NBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ1MsZ0JBQUE7RUFDVCxtQkFBQTtFQUNBLHlCQUFBO0VBQ0EsbUJBQUE7QUFYSDtBQWNBO0VBRUEsVUFBQTtFQUNBLGVBQUE7QUFaQSIsImZpbGUiOiJzcmMvYXBwL3BheW1lbnRsaXN0bW9kYWwvcGF5bWVudGxpc3Rtb2RhbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyXHJcbntcclxuXHRcclxuXHQgIGlvbi10b29sYmFyXHJcblx0ICB7LS1pb24tY29sb3ItYmFzZTogdmFyKC0taW9uLWNvbG9yLWJnZ3JhZGllbnQpIWltcG9ydGFudDtcclxuXHQgIC0tYm9yZGVyLXdpZHRoOiAwO1xyXG5cdFxyXG5cdFx0ICBpb24tdGl0bGV7XHJcblx0XHQgIGNvbG9yOnZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcblx0XHQgIHRleHQtYWxpZ246Y2VudGVyO1xyXG4gICAgICAgICAgICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcclxuICAgICAgICB9XHJcblx0XHRpb24tYnV0dG9uc1xyXG5cdFx0e1xyXG5cdFx0Zm9udC1zaXplOiAyNXB4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG5cdFx0fVxyXG5cdH1cclxuXHQmOjphZnRlclxyXG5cdHtcclxuXHRkaXNwbGF5Om5vbmU7XHJcblx0fVxyXG59XHJcbmlvbi1jb250ZW50XHJcbntbYW1vdW50aW1nXVxyXG57XHJcbiAgaW1nXHJcbiAge1xyXG4gICAgICBoZWlnaHQ6IDEyMHB4O1xyXG4gICAgICB3aWR0aDogMTIwcHg7XHJcbiAgICAgIG9iamVjdC1maXQ6IGNvdmVyO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgIGJvcmRlcjogNXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1zb2Z0Z3JlZW4pO1xyXG4gIH1cclxuICBwXHJcbiAge1x0Zm9udC1zaXplOiAxNHB4O1xyXG5cdFx0XHRcdGxpbmUtaGVpZ2h0OiAyMnB4O1xyXG5cdFx0XHRcdGZvbnQtd2VpZ2h0OiAzMDA7XHJcblx0XHRcdFx0Y29sb3I6ICNhZGFkYWQ7XHJcblx0XHRcdFx0bWFyZ2luLXRvcDogMTBweDtcclxuICBcclxuICB9XHJcbn1cclxuW2Zvcm1maWVsZF0ge1xyXG5cdFx0XHRwb3NpdGlvbjogcmVsYXRpdmU7XHJcblx0XHRcdGJvcmRlcjogMXB4IHNvbGlkICNlOGU4ZTg7XHJcblx0XHRcdGhlaWdodDogNTJweDtcclxuXHRcdFx0Ym9yZGVyLXJhZGl1czogNTBweDtcclxuXHRcdFx0YmFja2dyb3VuZDp2YXIoIC0taW9uLWNvbG9yLXdoaXRlKTtcclxuXHRcdFx0cGFkZGluZzogMCAxNnB4O1xyXG5cdFx0XHRtYXJnaW4tdG9wOjI1cHg7XHJcblx0XHRcdGxhYmVsIHtcclxuXHRcdFx0XHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0XHRcdFx0dG9wOiAtMTBweDtcclxuXHRcdFx0XHR6LWluZGV4OiAxMTE7XHJcblx0XHRcdFx0YmFja2dyb3VuZDogdmFyKCAtLWlvbi1jb2xvci13aGl0ZSk7XHJcblx0XHRcdFx0bGVmdDogMjlweDtcclxuXHRcdFx0XHRwYWRkaW5nOiAwIDNweDtcclxuXHRcdFx0XHRmb250LXNpemU6IDEycHg7XHJcblx0XHRcdFx0Zm9udC13ZWlnaHQ6IDcwMDtcclxuXHRcdFx0XHRjb2xvcjogIzNhM2EzYTtcclxuXHRcdFx0fVxyXG5cdFx0XHRpb24taW5wdXQgLCBpb24tZGF0ZXRpbWUgIHtcclxuXHRcdFx0XHRwYWRkaW5nOiAwcHg7XHJcblx0XHRcdFx0LS1wYWRkaW5nLXN0YXJ0OiAwcHg7XHJcblx0XHRcdFx0LS1wYWRkaW5nLWVuZDogMHB4O1xyXG5cdFx0XHRcdGZvbnQtc2l6ZTogMTRweDtcclxuXHRcdFx0XHQtLXBsYWNlaG9sZGVyLWNvbG9yOiAjOWE5YTlhO1xyXG5cdFx0XHRcdC0tcGxhY2Vob2xkZXItb3BhY2l0eTogMTtcclxuXHRcdFx0XHRmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XHJcblx0XHRcdFx0Y29sb3I6ICMyMjI7XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHRcdC5idG4tbG9zbnN7XHJcblx0XHRcdC0tYmFja2dyb3VuZDp2YXIoIC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG5cdFx0XHRtYXJnaW4tdG9wOiAyMHB4O1xyXG5cdFx0XHQtLWJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICAgICAgICAgIG1pbi1oZWlnaHQ6IDQ4cHg7XHJcblx0XHRcdG1hcmdpbi1ib3R0b206IDE1cHg7XHJcblx0XHRcdHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcblx0XHRcdGxldHRlci1zcGFjaW5nOiAxcHg7XHJcblx0XHR9XHJcbn1cclxuW2Vycm9yXVxyXG57XHJcbmNvbG9yOnJlZDtcclxuZm9udC1zaXplOjEycHg7XHJcbn0iXX0= */";
      /***/
    },

    /***/
    "./src/app/paymentlistmodal/paymentlistmodal.page.ts":
    /*!***********************************************************!*\
      !*** ./src/app/paymentlistmodal/paymentlistmodal.page.ts ***!
      \***********************************************************/

    /*! exports provided: PaymentlistmodalPage */

    /***/
    function srcAppPaymentlistmodalPaymentlistmodalPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "PaymentlistmodalPage", function () {
        return PaymentlistmodalPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../services/api/api.service */
      "./src/app/services/api/api.service.ts");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _common_common_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../common/common.service */
      "./src/app/common/common.service.ts");
      /* harmony import */


      var jquery__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! jquery */
      "./node_modules/jquery/dist/jquery.js");
      /* harmony import */


      var jquery__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_5__);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _services_globalFooService_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../services/globalFooService.service */
      "./src/app/services/globalFooService.service.ts");

      var PaymentlistmodalPage = /*#__PURE__*/function () {
        function PaymentlistmodalPage(globalFooService, navParams, api, router, common, modalController) {
          _classCallCheck(this, PaymentlistmodalPage);

          this.globalFooService = globalFooService;
          this.navParams = navParams;
          this.api = api;
          this.router = router;
          this.common = common;
          this.modalController = modalController;
          this.errors = ['', null, undefined];
          this.paymentlist = [];
          this.is_submit_payment = false;
          this.charityid = navParams.get('charityid');
          this.teamid = navParams.get('teamid');
          this.actid = navParams.get('actid');
          this.amount = navParams.get('amount');
          this.userid = navParams.get('userid');
          this.listpayment();
        }

        _createClass(PaymentlistmodalPage, [{
          key: "search_keyword",
          value: function search_keyword(event) {
            this.cardid = '';
            jquery__WEBPACK_IMPORTED_MODULE_5__('.radiobox').val('');
          }
        }, {
          key: "pay",
          value: function pay() {
            var _this7 = this;

            this.name = jquery__WEBPACK_IMPORTED_MODULE_5__('.namee').val();
            this.card_number = jquery__WEBPACK_IMPORTED_MODULE_5__('.card_numberr').val();
            this.exp_date = jquery__WEBPACK_IMPORTED_MODULE_5__('.exp_datee').val();
            this.cvc = jquery__WEBPACK_IMPORTED_MODULE_5__('.cvcc').val();

            if (this.errors.indexOf(this.cardid) >= 0 && this.errors.indexOf(this.name) >= 0 && this.errors.indexOf(this.card_number) >= 0 && this.errors.indexOf(this.exp_date) >= 0 && this.errors.indexOf(this.cvc) >= 0) {
              this.common.presentToast('Please select card or add new card', 'danger');
              return false;
            } else {
              if (this.errors.indexOf(this.cardid) == -1) {
                var dict = {
                  cardid: this.cardid,
                  userid: this.userid,
                  amount: this.amount,
                  charityid: this.charityid,
                  actid: this.actid,
                  teamid: this.teamid
                };
                this.common.presentLoading();
                this.api.post('AddPaymentwithsubscriptionCard', dict, '').subscribe(function (result) {
                  _this7.common.stopLoading();

                  _this7.is_submit_payment = false;
                  var res;
                  res = result;

                  if (res.status == 1) {
                    _this7.name = '';
                    _this7.card_number = '';
                    _this7.exp_date = '';
                    _this7.cvc = '';

                    _this7.common.presentToast('Donated Successfully !.', 'success');

                    _this7.dismiss();
                    /* this.globalFooService.publishSomeData({
                    set: {'paydata': res.status}
                      }); */


                    if (_this7.errors.indexOf(_this7.actid) == -1) {
                      _this7.router.navigate(['/tabs/tribes']);
                    } else if (_this7.errors.indexOf(_this7.teamid) == -1) {
                      _this7.router.navigate(['/searchteam']);
                    } else {
                      _this7.router.navigate(['/tabs/home']);
                    }
                  } else {
                    _this7.common.presentToast(res.msg, 'danger');
                  }
                }, function (err) {
                  _this7.common.stopLoading();

                  _this7.common.presentToast('Some error occured', 'danger');
                });
              } else {
                this.is_submit_payment = true;

                if (this.errors.indexOf(this.name) >= 0 && this.errors.indexOf(this.card_number) >= 0 && this.errors.indexOf(this.exp_date) >= 0 && this.errors.indexOf(this.cvc) >= 0) {
                  this.common.presentToast('Please select card or add new card', 'danger');
                  return false;
                } else {
                  var _dict = {
                    name: this.name,
                    card_number: this.card_number,
                    exp_date: this.exp_date,
                    cvc: this.cvc,
                    userid: this.userid,
                    amount: this.amount,
                    charityid: this.charityid,
                    actid: this.actid,
                    teamid: this.teamid
                  };
                  this.common.presentLoading();
                  this.api.post('AddPaymentwithsubscription', _dict, '').subscribe(function (result) {
                    _this7.common.stopLoading();

                    _this7.is_submit_payment = false;
                    var res;
                    res = result;

                    if (res.status == 1) {
                      _this7.name = '';
                      _this7.card_number = '';
                      _this7.exp_date = '';
                      _this7.cvc = '';

                      _this7.common.presentToast('Donated Successfully !.', 'success');

                      _this7.dismiss();

                      if (_this7.errors.indexOf(_this7.actid) == -1) {
                        /* this.globalFooService.publishSomeData({
                        set: {'paydata': res.status}
                        }); */
                        _this7.router.navigate(['/tabs/tribes']);
                      } else if (_this7.errors.indexOf(_this7.teamid) == -1) {
                        /* this.globalFooService.publishSomeData({
                        set: {'paydata1': res.status}
                        }); */
                        _this7.router.navigate(['/searchteam']);
                      } else {
                        _this7.router.navigate(['/tabs/home']);
                      }
                    } else {
                      _this7.common.presentToast(res.msg, 'danger');
                    }
                  }, function (err) {
                    _this7.common.stopLoading();

                    _this7.common.presentToast('Some error occured', 'danger');
                  });
                }
              }
            }
          }
        }, {
          key: "cardno",
          value: function cardno(id) {
            this.cardid = id;
          }
        }, {
          key: "dismiss",
          value: function dismiss() {
            this.modalController.dismiss({
              'dismissed': true
            });
          }
        }, {
          key: "confirm",
          value: function confirm() {
            jquery__WEBPACK_IMPORTED_MODULE_5__('.add_new_card_btn').hide();
            jquery__WEBPACK_IMPORTED_MODULE_5__('.add_payment').show();
          }
        }, {
          key: "listpayment",
          value: function listpayment() {
            var _this8 = this;

            if (this.errors.indexOf(this.userid) >= 0) {
              this.common.presentToast('Please login first!.', 'danger');
              return false;
            }

            var dict = {
              userid: this.userid
            };
            this.common.presentLoading();
            this.api.post('ListPayment', dict, '').subscribe(function (result) {
              _this8.common.stopLoading();

              var res;
              res = result;

              if (res.status == 1) {
                _this8.paymentlist = res.data;
              } else {
                _this8.common.presentToast(res.message, 'danger');
              }
            }, function (err) {});
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return PaymentlistmodalPage;
      }();

      PaymentlistmodalPage.ctorParameters = function () {
        return [{
          type: _services_globalFooService_service__WEBPACK_IMPORTED_MODULE_7__["GlobalFooService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavParams"]
        }, {
          type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
        }, {
          type: _common_common_service__WEBPACK_IMPORTED_MODULE_4__["CommonService"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ModalController"]
        }];
      };

      PaymentlistmodalPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-paymentlistmodal',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./paymentlistmodal.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/paymentlistmodal/paymentlistmodal.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./paymentlistmodal.page.scss */
        "./src/app/paymentlistmodal/paymentlistmodal.page.scss"))["default"]]
      })], PaymentlistmodalPage);
      /***/
    },

    /***/
    "./src/app/services/api/api.service.ts":
    /*!*********************************************!*\
      !*** ./src/app/services/api/api.service.ts ***!
      \*********************************************/

    /*! exports provided: ApiService */

    /***/
    function srcAppServicesApiApiServiceTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ApiService", function () {
        return ApiService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! rxjs/add/operator/map */
      "./node_modules/rxjs/add/operator/map.js");
      /* harmony import */


      var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_2__);
      /* harmony import */


      var rxjs_add_operator_catch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! rxjs/add/operator/catch */
      "./node_modules/rxjs/add/operator/catch.js");
      /* harmony import */


      var rxjs_add_operator_catch__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(rxjs_add_operator_catch__WEBPACK_IMPORTED_MODULE_3__);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../../config */
      "./src/app/config.ts");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/common/http */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
      /* harmony import */


      var crypto_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! crypto-js */
      "./node_modules/crypto-js/index.js");
      /* harmony import */


      var crypto_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_7__);

      var ApiService = /*#__PURE__*/function () {
        function ApiService(HttpClient, actionSheetController, navCtrl) {
          _classCallCheck(this, ApiService);

          this.HttpClient = HttpClient;
          this.actionSheetController = actionSheetController;
          this.navCtrl = navCtrl;
          this.url = _config__WEBPACK_IMPORTED_MODULE_5__["config"].API_URL;
        }

        _createClass(ApiService, [{
          key: "post",
          value: function post(endpoint, data, headers) {
            return this.HttpClient.post(this.url + endpoint, data).map(function (responseData) {
              return responseData; // console.log('yes');
            }, function (error) {
              console.log(error);
            });
          }
        }, {
          key: "encryptData",
          value: function encryptData(data, salt) {
            try {
              var enc = crypto_js__WEBPACK_IMPORTED_MODULE_7__["AES"].encrypt(JSON.stringify(data), salt).toString();
              enc = enc.split('+').join('xMl3Jk').split('/').join('Por21Ld').split('=').join('Ml32');
              return enc;
            } catch (e) {
              return 0;
            }
          }
        }]);

        return ApiService;
      }();

      ApiService.ctorParameters = function () {
        return [{
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_6__["HttpClient"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ActionSheetController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"]
        }];
      };

      ApiService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], ApiService);
      /***/
    },

    /***/
    "./src/app/services/globalFooService.service.ts":
    /*!******************************************************!*\
      !*** ./src/app/services/globalFooService.service.ts ***!
      \******************************************************/

    /*! exports provided: GlobalFooService */

    /***/
    function srcAppServicesGlobalFooServiceServiceTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "GlobalFooService", function () {
        return GlobalFooService;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! rxjs */
      "./node_modules/rxjs/_esm2015/index.js");

      var GlobalFooService = /*#__PURE__*/function () {
        function GlobalFooService() {
          _classCallCheck(this, GlobalFooService);

          this.fooSubject = new rxjs__WEBPACK_IMPORTED_MODULE_2__["Subject"]();
        }

        _createClass(GlobalFooService, [{
          key: "publishSomeData",
          value: function publishSomeData(data) {
            this.fooSubject.next(data);
          }
        }, {
          key: "getObservable",
          value: function getObservable() {
            return this.fooSubject;
          }
        }]);

        return GlobalFooService;
      }();

      GlobalFooService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
      })], GlobalFooService);
      /***/
    },

    /***/
    "./src/environments/environment.ts":
    /*!*****************************************!*\
      !*** ./src/environments/environment.ts ***!
      \*****************************************/

    /*! exports provided: environment */

    /***/
    function srcEnvironmentsEnvironmentTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "environment", function () {
        return environment;
      }); // This file can be replaced during build by using the `fileReplacements` array.
      // `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
      // The list of file replacements can be found in `angular.json`.


      var environment = {
        production: false
      };
      /*
       * For easier debugging in development mode, you can import the following file
       * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
       *
       * This import should be commented out in production mode because it will have a negative impact
       * on performance if an error is thrown.
       */
      // import 'zone.js/dist/zone-error';  // Included with Angular CLI.

      /***/
    },

    /***/
    "./src/main.ts":
    /*!*********************!*\
      !*** ./src/main.ts ***!
      \*********************/

    /*! no exports provided */

    /***/
    function srcMainTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/platform-browser-dynamic */
      "./node_modules/@angular/platform-browser-dynamic/__ivy_ngcc__/fesm2015/platform-browser-dynamic.js");
      /* harmony import */


      var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./app/app.module */
      "./src/app/app.module.ts");
      /* harmony import */


      var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./environments/environment */
      "./src/environments/environment.ts");

      if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
      }

      Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])["catch"](function (err) {
        return console.log(err);
      });
      /***/
    },

    /***/
    0:
    /*!***************************!*\
      !*** multi ./src/main.ts ***!
      \***************************/

    /*! no static exports found */

    /***/
    function _(module, exports, __webpack_require__) {
      module.exports = __webpack_require__(
      /*! E:\foodforlife27apr\src\main.ts */
      "./src/main.ts");
      /***/
    }
  }, [[0, "runtime", "vendor"]]]);
})();
//# sourceMappingURL=main-es5.js.map