(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["about-about-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/about/about.page.html":
    /*!*****************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/about/about.page.html ***!
      \*****************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppAboutAboutPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n\t<ion-back-button defaultHref=\"/tabs/settings\" slot=\"start\">\r\n\t</ion-back-button>\r\n\t<ion-title class=\"ion-text-center\">About Us</ion-title>\r\n  </ion-toolbar>\r\n  </ion-header>\r\n<ion-content>\r\n<div class=\"cont-box-main\">\r\n\t\t<div class=\"top-img\">\r\n\t\t\t<img src=\"assets/images/paul-feeding.jpg\">\r\n\t\t</div>\r\n\t\t<div class=\"content-bxa about_us\" [innerHTML]='about?.description'>\r\n\t\t</div>\r\n\t\t<div class=\"content-bxa\">\r\n\t\t\r\n\t\t\t<!--h4> <span class=\"left-rf-boc\"> A Brief History of Food for Life Global </span> </h4>\r\n\t\t\t<p> Food for Life Global (FFLG) was founded in 1995 and currently has a headquarters based in Delaware, USA (FFLG – Americas), and a European office based in Ljubljana, Slovenia to serve as the coordinating, training and support team for all Food for Life projects worldwide. With 213 affiliates in 60 countries serving up to 2 million plant-based meals daily, FFLG is the world’s largest food relief organization. With a mission to address the root cause of all social issues through teaching spiritual equality in practice and precept, our projects also include health education, eco-farming, schooling, animal rescue, and animal care.</p>\r\n\t\t\t<h4 class=\"mt-15\"> <span class=\"left-rf-boc \"> Background on the Food for Life Project </span> </h4>\r\n\t\t\t<p>The distribution of sanctified plant-based meals has been and will continue to be an essential part of India’s Vedic culture of hospitality from which Food for Life was born. Since its inception in the early ’70s, Food for Life has tried to liberally distribute pure plant-based meals (prasadam) throughout the world with the aim of creating peace and prosperity. The Food for Life Global office facilitates the expansion, coordination, and promotion of prasadam distribution throughout the world. The project started in 1974 after yoga students of Swami Prabhupada, the founder of ISKCON became inspired by his plea that “No one within a ten-mile radius of a temple should go hungry!” Today Food for Life is active in over 60 countries. </p-->\r\n\t\t</div>\r\n\t\t<span class=\"about-bg-txt \"> About Us </span>\r\n\t</div>\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "./src/app/about/about-routing.module.ts":
    /*!***********************************************!*\
      !*** ./src/app/about/about-routing.module.ts ***!
      \***********************************************/

    /*! exports provided: AboutPageRoutingModule */

    /***/
    function srcAppAboutAboutRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AboutPageRoutingModule", function () {
        return AboutPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _about_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./about.page */
      "./src/app/about/about.page.ts");

      var routes = [{
        path: '',
        component: _about_page__WEBPACK_IMPORTED_MODULE_3__["AboutPage"]
      }];

      var AboutPageRoutingModule = function AboutPageRoutingModule() {
        _classCallCheck(this, AboutPageRoutingModule);
      };

      AboutPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], AboutPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/about/about.module.ts":
    /*!***************************************!*\
      !*** ./src/app/about/about.module.ts ***!
      \***************************************/

    /*! exports provided: AboutPageModule */

    /***/
    function srcAppAboutAboutModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AboutPageModule", function () {
        return AboutPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _about_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./about-routing.module */
      "./src/app/about/about-routing.module.ts");
      /* harmony import */


      var _about_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./about.page */
      "./src/app/about/about.page.ts");

      var AboutPageModule = function AboutPageModule() {
        _classCallCheck(this, AboutPageModule);
      };

      AboutPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _about_routing_module__WEBPACK_IMPORTED_MODULE_5__["AboutPageRoutingModule"]],
        declarations: [_about_page__WEBPACK_IMPORTED_MODULE_6__["AboutPage"]]
      })], AboutPageModule);
      /***/
    },

    /***/
    "./src/app/about/about.page.scss":
    /*!***************************************!*\
      !*** ./src/app/about/about.page.scss ***!
      \***************************************/

    /*! exports provided: default */

    /***/
    function srcAppAboutAboutPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-header ion-toolbar {\n  --ion-color-base: var(--ion-color-bggradient)!important;\n  --border-width: 0;\n}\nion-header ion-toolbar ion-title {\n  color: var(--ion-color-white);\n  text-align: center;\n  font-style: normal;\n  font-family: \"Poppins\", sans-serif !important;\n}\nion-header::after {\n  display: none;\n}\nion-content .cont-box-main {\n  min-height: 100%;\n  position: relative;\n  z-index: 0;\n}\nion-content .cont-box-main .top-img img {\n  width: 100%;\n  height: 230px;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\nion-content .cont-box-main .content-bxa {\n  padding: 15px;\n  text-align: center;\n  position: relative;\n  z-index: 0;\n}\nion-content .cont-box-main .content-bxa h4 {\n  margin: 0px;\n  font-size: 16px;\n  margin-top: -14px;\n}\nion-content .cont-box-main .content-bxa h4.mt-15 {\n  margin-top: 15px;\n}\nion-content .cont-box-main .content-bxa h4 span.left-rf-boc {\n  position: relative;\n  z-index: 0;\n}\nion-content .cont-box-main .content-bxa h4 span.left-rf-boc:before {\n  content: \"\";\n  position: absolute;\n  width: 20px;\n  height: 2px;\n  background: #888888;\n  left: -28px;\n  top: 13px;\n}\nion-content .cont-box-main .content-bxa h4 span.left-rf-boc:after {\n  content: \"\";\n  position: absolute;\n  width: 20px;\n  height: 2px;\n  background: #888888;\n  right: -28px;\n  top: 13px;\n}\nion-content .cont-box-main .content-bxa p {\n  font-size: 14px !important;\n  line-height: 22px !important;\n  font-weight: 300 !important;\n  color: #adadad !important;\n  margin-top: 10px !important;\n}\nion-content .cont-box-main .content-bxa:after {\n  content: \"\";\n  background: url('about2.png');\n  position: absolute;\n  top: -40px;\n  left: 0;\n  right: 0;\n  width: 100%;\n  height: 60px;\n  z-index: -1;\n  background-size: cover;\n  background-position: center;\n}\nion-content .about-bg-txt {\n  position: absolute;\n  left: 0;\n  right: 0;\n  text-align: center;\n  bottom: 0px;\n  font-size: 60px;\n  white-space: nowrap;\n  text-transform: uppercase;\n  font-weight: 800;\n  z-index: 0;\n  opacity: 0.03;\n  letter-spacing: 4px;\n}\n.about_us p {\n  font-size: 14px !important;\n  line-height: 22px !important;\n  font-weight: 300 !important;\n  color: #adadad !important;\n  margin-top: 10px !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWJvdXQvYWJvdXQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdHO0VBQ0MsdURBQUE7RUFDRCxpQkFBQTtBQUZIO0FBSUk7RUFDQSw2QkFBQTtFQUNBLGtCQUFBO0VBQ1Esa0JBQUE7RUFDQSw2Q0FBQTtBQUZaO0FBS0M7RUFFQSxhQUFBO0FBSkQ7QUFRQztFQUNDLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0FBTEY7QUFNRTtFQUNDLFdBQUE7RUFDQSxhQUFBO0VBQ0Esb0JBQUE7S0FBQSxpQkFBQTtBQUpIO0FBTUU7RUFDQyxhQUFBO0VBRUEsa0JBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7QUFMSDtBQU1HO0VBQ0MsV0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQUpKO0FBS0k7RUFFQSxnQkFBQTtBQUpKO0FBTUk7RUFDQyxrQkFBQTtFQUNBLFVBQUE7QUFKTDtBQUtLO0VBQ0MsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0FBSE47QUFLSztFQUNDLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsU0FBQTtBQUhOO0FBT0c7RUFDRSwwQkFBQTtFQUNBLDRCQUFBO0VBQ0EsMkJBQUE7RUFDQSx5QkFBQTtFQUNBLDJCQUFBO0FBTEw7QUFPRztFQUNDLFdBQUE7RUFDQSw2QkFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSwyQkFBQTtBQUxKO0FBU0M7RUFDRyxrQkFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0EseUJBQUE7RUFDQSxnQkFBQTtFQUNBLFVBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUFQSjtBQVdBO0VBRUEsMEJBQUE7RUFDSSw0QkFBQTtFQUNBLDJCQUFBO0VBQ0EseUJBQUE7RUFDQSwyQkFBQTtBQVRKIiwiZmlsZSI6InNyYy9hcHAvYWJvdXQvYWJvdXQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlclxyXG57XHJcblx0XHJcblx0ICBpb24tdG9vbGJhclxyXG5cdCAgey0taW9uLWNvbG9yLWJhc2U6IHZhcigtLWlvbi1jb2xvci1iZ2dyYWRpZW50KSFpbXBvcnRhbnQ7XHJcblx0ICAtLWJvcmRlci13aWR0aDogMDtcclxuXHRcclxuXHRcdCAgaW9uLXRpdGxle1xyXG5cdFx0ICBjb2xvcjp2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdFx0ICB0ZXh0LWFsaWduOmNlbnRlcjtcclxuICAgICAgICAgICAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gICAgICAgICAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgfVxyXG5cdH1cclxuXHQmOjphZnRlclxyXG5cdHtcclxuXHRkaXNwbGF5Om5vbmU7XHJcblx0fVxyXG59XHJcbmlvbi1jb250ZW50IHtcclxuXHQuY29udC1ib3gtbWFpbiB7XHJcblx0XHRtaW4taGVpZ2h0OjEwMCU7XHJcblx0XHRwb3NpdGlvbjpyZWxhdGl2ZTtcclxuXHRcdHotaW5kZXg6MDtcclxuXHRcdC50b3AtaW1nIGltZyB7XHJcblx0XHRcdHdpZHRoOiAxMDAlO1xyXG5cdFx0XHRoZWlnaHQ6IDIzMHB4O1xyXG5cdFx0XHRvYmplY3QtZml0OiBjb3ZlcjtcclxuXHRcdH1cclxuXHRcdC5jb250ZW50LWJ4YSB7XHJcblx0XHRcdHBhZGRpbmc6IDE1cHg7XHJcblx0XHRcclxuXHRcdFx0dGV4dC1hbGlnbjpjZW50ZXI7XHJcblx0XHRcdHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHRcdFx0ei1pbmRleDogMDtcclxuXHRcdFx0aDQgIHtcclxuXHRcdFx0XHRtYXJnaW46IDBweDtcclxuXHRcdFx0XHRmb250LXNpemU6IDE2cHg7XHJcblx0XHRcdFx0bWFyZ2luLXRvcDogLTE0cHg7XHJcblx0XHRcdFx0Ji5tdC0xNVxyXG5cdFx0XHRcdHtcclxuXHRcdFx0XHRtYXJnaW4tdG9wOjE1cHg7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHRcdHNwYW4ubGVmdC1yZi1ib2Mge1xyXG5cdFx0XHRcdFx0cG9zaXRpb246IHJlbGF0aXZlO1xyXG5cdFx0XHRcdFx0ei1pbmRleDogMDtcdFxyXG5cdFx0XHRcdFx0JjpiZWZvcmUge1xyXG5cdFx0XHRcdFx0XHRjb250ZW50OiBcIlwiO1xyXG5cdFx0XHRcdFx0XHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0XHRcdFx0XHRcdHdpZHRoOiAyMHB4O1xyXG5cdFx0XHRcdFx0XHRoZWlnaHQ6IDJweDtcclxuXHRcdFx0XHRcdFx0YmFja2dyb3VuZDogIzg4ODg4ODtcclxuXHRcdFx0XHRcdFx0bGVmdDogLTI4cHg7XHJcblx0XHRcdFx0XHRcdHRvcDogMTNweDtcclxuXHRcdFx0XHRcdH1cclxuXHRcdFx0XHRcdCY6YWZ0ZXIge1xyXG5cdFx0XHRcdFx0XHRjb250ZW50OiBcIlwiO1xyXG5cdFx0XHRcdFx0XHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0XHRcdFx0XHRcdHdpZHRoOiAyMHB4O1xyXG5cdFx0XHRcdFx0XHRoZWlnaHQ6IDJweDtcclxuXHRcdFx0XHRcdFx0YmFja2dyb3VuZDogIzg4ODg4ODtcclxuXHRcdFx0XHRcdFx0cmlnaHQ6IC0yOHB4O1xyXG5cdFx0XHRcdFx0XHR0b3A6IDEzcHg7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblx0XHRcdHAge1xyXG5cdFx0XHRcdFx0Zm9udC1zaXplOiAxNHB4ICFpbXBvcnRhbnQ7XHJcblx0XHRcdFx0XHRsaW5lLWhlaWdodDogMjJweCAhaW1wb3J0YW50O1xyXG5cdFx0XHRcdFx0Zm9udC13ZWlnaHQ6IDMwMCAhaW1wb3J0YW50O1xyXG5cdFx0XHRcdFx0Y29sb3I6ICNhZGFkYWQgIWltcG9ydGFudDtcclxuXHRcdFx0XHRcdG1hcmdpbi10b3A6IDEwcHggIWltcG9ydGFudDtcclxuXHRcdFx0fVxyXG5cdFx0XHQmOmFmdGVyIHtcclxuXHRcdFx0XHRjb250ZW50OlwiXCI7XHJcblx0XHRcdFx0YmFja2dyb3VuZDogdXJsKFwiLi4vLi4vYXNzZXRzL2ltYWdlcy9hYm91dDIucG5nXCIpO1xyXG5cdFx0XHRcdHBvc2l0aW9uOmFic29sdXRlO1xyXG5cdFx0XHRcdHRvcDogLTQwcHg7XHJcblx0XHRcdFx0bGVmdDogMDtcclxuXHRcdFx0XHRyaWdodDogMDtcclxuXHRcdFx0XHR3aWR0aDogMTAwJTtcclxuXHRcdFx0XHRoZWlnaHQ6IDYwcHg7XHJcblx0XHRcdFx0ei1pbmRleDogLTE7XHJcblx0XHRcdFx0YmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxuXHRcdFx0XHRiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXI7XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHR9XHJcblx0LmFib3V0LWJnLXR4dCB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBib3R0b206IDBweDtcclxuICAgIGZvbnQtc2l6ZTogNjBweDtcclxuICAgIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG4gICAgZm9udC13ZWlnaHQ6IDgwMDtcclxuICAgIHotaW5kZXg6IDA7XHJcbiAgICBvcGFjaXR5OiAwLjAzO1xyXG4gICAgbGV0dGVyLXNwYWNpbmc6IDRweDtcclxuXHJcbn1cclxufVxyXG4uYWJvdXRfdXMgcHtcclxuXHJcbmZvbnQtc2l6ZTogMTRweCAhaW1wb3J0YW50O1xyXG4gICAgbGluZS1oZWlnaHQ6IDIycHggIWltcG9ydGFudDtcclxuICAgIGZvbnQtd2VpZ2h0OiAzMDAgIWltcG9ydGFudDtcclxuICAgIGNvbG9yOiAjYWRhZGFkICFpbXBvcnRhbnQ7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4ICFpbXBvcnRhbnQ7XHJcblx0fSJdfQ== */";
      /***/
    },

    /***/
    "./src/app/about/about.page.ts":
    /*!*************************************!*\
      !*** ./src/app/about/about.page.ts ***!
      \*************************************/

    /*! exports provided: AboutPage */

    /***/
    function srcAppAboutAboutPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AboutPage", function () {
        return AboutPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../services/api/api.service */
      "./src/app/services/api/api.service.ts");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _common_common_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../common/common.service */
      "./src/app/common/common.service.ts");

      var AboutPage = /*#__PURE__*/function () {
        function AboutPage(api, router, common) {
          _classCallCheck(this, AboutPage);

          this.api = api;
          this.router = router;
          this.common = common;
        }

        _createClass(AboutPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "ionViewDidEnter",
          value: function ionViewDidEnter() {
            this.getfaqdetails();
          }
        }, {
          key: "getfaqdetails",
          value: function getfaqdetails() {
            var _this = this;

            this.common.presentLoading();
            this.api.post('Getaboutuscontent', '', '').subscribe(function (result) {
              _this.common.stopLoading();

              var res;
              res = result;

              if (res.status == 1) {
                _this.about = res.data; //this.common.presentToast('FAQ fetched successfully !.','success');
              } else {
                //this.common.presentToast(res.message,'danger');
                _this.about = '';
              }
            }, function (err) {});
          }
        }]);

        return AboutPage;
      }();

      AboutPage.ctorParameters = function () {
        return [{
          type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
        }, {
          type: _common_common_service__WEBPACK_IMPORTED_MODULE_4__["CommonService"]
        }];
      };

      AboutPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-about',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./about.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/about/about.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./about.page.scss */
        "./src/app/about/about.page.scss"))["default"]]
      })], AboutPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=about-about-module-es5.js.map