(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["thetabledetail-thetabledetail-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/thetabledetail/thetabledetail.page.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/thetabledetail/thetabledetail.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n      <ion-toolbar color=\"primary\">\r\n        <ion-back-button defaultHref=\"/tabs/thetable\" slot=\"start\">\r\n        </ion-back-button>\r\n        <ion-title class=\"ion-text-center\">Subscription Plans</ion-title>\r\n      </ion-toolbar>\r\n</ion-header><!--ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n\t      <ion-buttons slot=\"start\">\r\n          <ion-back-button  defaulHref=\"/thetable\"></ion-back-button>\r\n        </ion-buttons>\r\n\t<ion-title class=\"ion-text-center\">Subscription Plans</ion-title>\r\n  </ion-toolbar>\r\n  </ion-header-->\r\n\r\n<ion-content>\r\n\r\n<div packimg>\r\n  <img src=\"assets/images/sliderimg1.jpg\" style=\"width:100%;\"/> \r\n</div>\r\n<!--div packdetail class=\"ion-padding\"  *ngIf=\"sublist?.length>0\">\r\n<h3>Transactions</h3>\r\n<table>\r\n<th>Transaction ID</th>\r\n<th>Amount</th>\r\n<th>Date</th>\r\n<th>Date</th>\r\n</table>\r\n</div-->\r\n<div packdetail class=\"ion-padding\" >\r\n<h3>Choose An Amount</h3>\r\n \r\n <ion-slides pager=\"false\" [options]=\"slideOpts\">\r\n        <ion-slide  *ngFor=\"let li of list\"  (click)=\"selectwekk($event,li?.id)\" class=\"day day{{li?.id}}\" >\r\n          <div plans>\r\n\t\t\t  <img src=\"{{IMAGES_URL}}/{{li?.image}}\"/>\r\n\t\t\t  <h4>${{li?.amount}}</h4>\r\n\t\t\t  <p>monthly</p>\r\n\t\t  </div>\r\n        </ion-slide>\r\n\t\t<ion-slide class=\"amount_day day\">\r\n          <div plans>\r\n\t\t  <ion-icon (click)=\"addamount()\" name=\"create-outline\"></ion-icon>\r\n\t\t\t  <img src=\"assets/images/prj15.jpg\"/>\r\n\t\t\t  <h4 id=\"amount\">Your Choice</h4>\r\n\t\t\t  <input type=\"hidden\" value=\"\" id=\"amountval\">\r\n\t\t\t  <p>monthly</p>\r\n\t\t  </div>\r\n        </ion-slide>\r\n      </ion-slides>\r\n<div packcontent>\r\n<p>Help vulnerable families in India , Africa , South America and Ukraine  purchase healty food</p>\r\n<ion-radio-group value=\"{{cardid}}\" class=\"radiobox\">\r\n    <ion-item lines=\"none\" *ngFor=\"let pay of paymentlist\">\r\n      <ion-label>{{pay?.card_number}}</ion-label>\r\n      <ion-radio value=\"{{pay?.id}}\"  (click)=\"cardno(pay?.id)\" class=\"radiobox\"></ion-radio>\r\n    </ion-item>\r\n</ion-radio-group>\t\r\n\r\n\r\n\r\n<div addpayment><a routerLink=\"/addpayment\" href=\"javascript:void(0)\"><ion-icon name=\"add-sharp\"></ion-icon> Add Payment Method</a></div>\r\n  <ion-button shape=\"round\" expand=\"full\" (click)=\"subs();\" *ngIf=\"errors.indexOf(sublist)>=0\">Confirm Subscription</ion-button>\r\n   <ion-button shape=\"round\" expand=\"full\" (click)=\"updatesubs();\" *ngIf=\"errors.indexOf(sublist)==-1\">Update Subscription</ion-button>\r\n<span>Your subscription will be renew automatically after every month. You can cancel it any time.</span>\r\n</div>\r\n</div>\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/thetabledetail/thetabledetail-routing.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/thetabledetail/thetabledetail-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: ThetabledetailPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ThetabledetailPageRoutingModule", function() { return ThetabledetailPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _thetabledetail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./thetabledetail.page */ "./src/app/thetabledetail/thetabledetail.page.ts");




const routes = [
    {
        path: '',
        component: _thetabledetail_page__WEBPACK_IMPORTED_MODULE_3__["ThetabledetailPage"]
    }
];
let ThetabledetailPageRoutingModule = class ThetabledetailPageRoutingModule {
};
ThetabledetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ThetabledetailPageRoutingModule);



/***/ }),

/***/ "./src/app/thetabledetail/thetabledetail.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/thetabledetail/thetabledetail.module.ts ***!
  \*********************************************************/
/*! exports provided: ThetabledetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ThetabledetailPageModule", function() { return ThetabledetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _thetabledetail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./thetabledetail-routing.module */ "./src/app/thetabledetail/thetabledetail-routing.module.ts");
/* harmony import */ var _thetabledetail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./thetabledetail.page */ "./src/app/thetabledetail/thetabledetail.page.ts");







let ThetabledetailPageModule = class ThetabledetailPageModule {
};
ThetabledetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _thetabledetail_routing_module__WEBPACK_IMPORTED_MODULE_5__["ThetabledetailPageRoutingModule"]
        ],
        declarations: [_thetabledetail_page__WEBPACK_IMPORTED_MODULE_6__["ThetabledetailPage"]]
    })
], ThetabledetailPageModule);



/***/ }),

/***/ "./src/app/thetabledetail/thetabledetail.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/thetabledetail/thetabledetail.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-toolbar {\n  --ion-color-base: var(--ion-color-bggradient)!important;\n  --border-width: 0;\n}\nion-header ion-toolbar ion-buttons {\n  font-size: 22px;\n}\nion-header ion-toolbar ion-buttons[mr-10] {\n  margin-right: 10px;\n}\nion-header ion-toolbar ion-title {\n  color: var(--ion-color-white);\n  text-align: center;\n  font-style: normal;\n  font-family: \"Poppins\", sans-serif !important;\n}\nion-header::after {\n  display: none;\n}\nion-content .active_plan [plans] {\n  border: 2px solid var(--ion-color-primary);\n}\nion-content [packimg] {\n  min-height: 290px;\n  max-height: 290px;\n  position: relative;\n  z-index: 1;\n}\nion-content [packimg] img {\n  border-radius: 0px 0px 25px 25px;\n  min-height: 290px;\n  max-height: 290px;\n  width: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\nion-content [packimg]:after {\n  border-radius: 0px 0px 25px 25px;\n  content: \"\";\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background: #000;\n  opacity: 0.5;\n  display: inline-block;\n  position: absolute;\n}\nion-content [packdetail] {\n  margin-top: -130px;\n  position: relative;\n  z-index: 1;\n  text-align: center;\n}\nion-content [packdetail] h3 {\n  margin-top: 0px;\n  color: var(--ion-color-white);\n}\nion-content [packdetail] ion-button {\n  min-height: 42px;\n  --box-shadow:none;\n}\nion-content [packdetail] [packcontent] span {\n  font-weight: 300;\n  color: #adadad;\n  font-size: 11px;\n  line-height: 17px;\n  display: block;\n  margin-top: 10px;\n}\nion-content [packdetail] [packcontent] p {\n  font-weight: 300;\n  color: #adadad;\n  font-size: 14px;\n}\nion-content [packdetail] [packcontent] [addpayment] {\n  text-align: left;\n  font-size: 14px;\n  margin-bottom: 10px;\n}\nion-content [packdetail] [packcontent] [addpayment] a {\n  text-decoration: none;\n}\nion-content [packdetail] [plans] {\n  position: relative;\n  background: var(--ion-color-white);\n  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.13);\n  margin-top: 10px;\n  width: 100%;\n  padding: 15px 10px;\n  border-radius: 6px;\n}\nion-content [packdetail] [plans] ion-icon {\n  position: absolute;\n  right: 5px;\n  top: 4px;\n  color: var(--ion-color-primary);\n}\nion-content [packdetail] [plans] img {\n  height: 40px;\n}\nion-content [packdetail] [plans] h4 {\n  font-size: 13px;\n  margin: 10px 0px 0px;\n}\nion-content [packdetail] [plans] p {\n  font-weight: 300;\n  color: #adadad;\n  font-size: 11px;\n  margin: 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGhldGFibGVkZXRhaWwvdGhldGFibGVkZXRhaWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdHO0VBQ0MsdURBQUE7RUFDRCxpQkFBQTtBQUZIO0FBR0U7RUFFQSxlQUFBO0FBRkY7QUFHRTtFQUVDLGtCQUFBO0FBRkg7QUFLSTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7RUFDUSxrQkFBQTtFQUNBLDZDQUFBO0FBSFo7QUFNQztFQUVBLGFBQUE7QUFMRDtBQVlBO0VBRUksMENBQUE7QUFWSjtBQWFBO0VBQ08saUJBQUE7RUFDSCxpQkFBQTtFQUNKLGtCQUFBO0VBQ0EsVUFBQTtBQVhBO0FBWUE7RUFDSyxnQ0FBQTtFQUNFLGlCQUFBO0VBQ0gsaUJBQUE7RUFDQSxXQUFBO0VBQ0Esb0JBQUE7S0FBQSxpQkFBQTtBQVZKO0FBWUE7RUFBYSxnQ0FBQTtFQUNULFdBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtBQVRKO0FBWUE7RUFDSyxrQkFBQTtFQUNELGtCQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0FBVko7QUFXRTtFQUVFLGVBQUE7RUFDSCw2QkFBQTtBQVZEO0FBWUE7RUFFQSxnQkFBQTtFQUNBLGlCQUFBO0FBWEE7QUFlQTtFQUVBLGdCQUFBO0VBQ0ksY0FBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQWRKO0FBZ0JBO0VBQUUsZ0JBQUE7RUFDRSxjQUFBO0VBQ0EsZUFBQTtBQWJKO0FBY0M7RUFDRyxnQkFBQTtFQUNBLGVBQUE7RUFDQSxtQkFBQTtBQVpKO0FBYUM7RUFDQyxxQkFBQTtBQVhGO0FBZUE7RUFBUyxrQkFBQTtFQUNMLGtDQUFBO0VBQ0EsNENBQUE7RUFDQSxnQkFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FBWko7QUFhQztFQUVJLGtCQUFBO0VBQ0gsVUFBQTtFQUNBLFFBQUE7RUFDQSwrQkFBQTtBQVpGO0FBY0M7RUFFSSxZQUFBO0FBYkw7QUFlQztFQUNHLGVBQUE7RUFDQSxvQkFBQTtBQWJKO0FBY0M7RUFBRSxnQkFBQTtFQUNDLGNBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtBQVhKIiwiZmlsZSI6InNyYy9hcHAvdGhldGFibGVkZXRhaWwvdGhldGFibGVkZXRhaWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlclxyXG57XHJcblxyXG5cdCAgaW9uLXRvb2xiYXJcclxuXHQgIHstLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1pb24tY29sb3ItYmdncmFkaWVudCkhaW1wb3J0YW50O1xyXG5cdCAgLS1ib3JkZXItd2lkdGg6IDA7XHJcblx0IGlvbi1idXR0b25zXHJcblx0IHtcclxuXHQgZm9udC1zaXplOiAyMnB4O1xyXG5cdCAmWyBtci0xMF1cclxuXHQge1xyXG5cdCAgbWFyZ2luLXJpZ2h0OjEwcHg7XHJcblx0IH1cclxuXHQgfVxyXG5cdFx0ICBpb24tdGl0bGV7XHJcblx0XHQgIGNvbG9yOnZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcblx0XHQgIHRleHQtYWxpZ246Y2VudGVyO1xyXG4gICAgICAgICAgICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcclxuICAgICAgICB9XHJcblx0fVxyXG5cdCY6OmFmdGVyXHJcblx0e1xyXG5cdGRpc3BsYXk6bm9uZTtcclxuXHR9XHJcbn1cclxuaW9uLWNvbnRlbnRcclxue1xyXG4uYWN0aXZlX3BsYW5cclxue1xyXG5bcGxhbnNdXHJcbntcclxuICAgIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxufVx0XHJcbn1cclxuW3BhY2tpbWddXHJcbnsgICAgICBtaW4taGVpZ2h0OiAyOTBweDtcclxuICAgIG1heC1oZWlnaHQ6IDI5MHB4O1xyXG5wb3NpdGlvbjpyZWxhdGl2ZTtcclxuei1pbmRleDoxO1xyXG5pbWdcclxueyAgICBib3JkZXItcmFkaXVzOiAwcHggMHB4IDI1cHggMjVweDtcclxuICAgICAgIG1pbi1oZWlnaHQ6IDI5MHB4O1xyXG4gICAgbWF4LWhlaWdodDogMjkwcHg7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIG9iamVjdC1maXQ6IGNvdmVyO1xyXG59XHJcbiY6YWZ0ZXIgeyAgICBib3JkZXItcmFkaXVzOiAwcHggMHB4IDI1cHggMjVweDtcclxuICAgIGNvbnRlbnQ6IFwiXCI7XHJcbiAgICB0b3A6IDA7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICBib3R0b206IDA7XHJcbiAgICBiYWNrZ3JvdW5kOiAjMDAwO1xyXG4gICAgb3BhY2l0eTogLjU7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbn1cclxufVxyXG5bcGFja2RldGFpbF1cclxueyAgICBtYXJnaW4tdG9wOiAtMTMwcHg7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICB6LWluZGV4OiAxO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG5cdFx0aDMge1xyXG4gIFxyXG4gICAgbWFyZ2luLXRvcDogMHB4O1xyXG5cdGNvbG9yOiB2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG59XHJcbmlvbi1idXR0b25cclxue1xyXG5taW4taGVpZ2h0OjQycHg7XHJcbi0tYm94LXNoYWRvdzpub25lO1xyXG59XHJcbltwYWNrY29udGVudF1cclxue1xyXG5zcGFuXHJcbntcclxuZm9udC13ZWlnaHQ6IDMwMDtcclxuICAgIGNvbG9yOiAjYWRhZGFkO1xyXG4gICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDE3cHg7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIG1hcmdpbi10b3A6IDEwcHg7XHJcbn1cclxucHtmb250LXdlaWdodDogMzAwO1xyXG5cdFx0XHRcdGNvbG9yOiAjYWRhZGFkO1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG59W2FkZHBheW1lbnRdIHtcclxuICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOjEwcHg7XHJcblx0YVxyXG5cdHt0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcblx0fVxyXG59XHJcbn1cclxuW3BsYW5zXSB7cG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgIGJveC1zaGFkb3c6IDBweCAwcHggMTBweCByZ2JhKDAsMCwwLDEzJSk7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBwYWRkaW5nOiAxNXB4IDEwcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiA2cHg7XHJcblx0aW9uLWljb25cclxuXHR7XHJcblx0ICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRcdHJpZ2h0OiA1cHg7XHJcblx0XHR0b3A6IDRweDtcclxuXHRcdGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcblx0fVxyXG5cdGltZ1xyXG5cdHtcclxuXHQgICAgaGVpZ2h0OiA0MHB4O1xyXG5cdH1cclxuXHRoNCB7XHJcbiAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICBtYXJnaW46IDEwcHggMHB4IDBweDtcclxufXB7Zm9udC13ZWlnaHQ6IDMwMDtcclxuXHRcdFx0XHRjb2xvcjogI2FkYWRhZDtcclxuICAgIGZvbnQtc2l6ZTogMTFweDtcclxuICAgIG1hcmdpbjogMHB4O1xyXG59XHJcbn1cclxufVxyXG59Il19 */");

/***/ }),

/***/ "./src/app/thetabledetail/thetabledetail.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/thetabledetail/thetabledetail.page.ts ***!
  \*******************************************************/
/*! exports provided: ThetabledetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ThetabledetailPage", function() { return ThetabledetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _customamount_customamount_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../customamount/customamount.page */ "./src/app/customamount/customamount.page.ts");
/* harmony import */ var _services_api_api_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/api/api.service */ "./src/app/services/api/api.service.ts");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../config */ "./src/app/config.ts");
/* harmony import */ var _common_common_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../common/common.service */ "./src/app/common/common.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_8__);









let ThetabledetailPage = class ThetabledetailPage {
    constructor(router, modalController, api, common) {
        this.router = router;
        this.modalController = modalController;
        this.api = api;
        this.common = common;
        this.list = [];
        this.paymentlist = [];
        this.sublist = [];
        this.errors = ['', null, undefined];
        this.IMAGES_URL = _config__WEBPACK_IMPORTED_MODULE_5__["config"].IMAGES_URL;
        this.slideOpts = {
            slidesPerView: 3,
            centeredSlides: true,
            spaceBetween: 10,
            initialSlide: 1,
            speed: 400
        };
        this.show = false;
        this.buttonName = 'Show';
    }
    addamount() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _customamount_customamount_page__WEBPACK_IMPORTED_MODULE_3__["CustomamountPage"],
                cssClass: 'leaveteam',
                componentProps: {}
            });
            modal.onDidDismiss().then((detail) => {
                if (this.errors.indexOf(detail.data) == -1) {
                    jquery__WEBPACK_IMPORTED_MODULE_8__('#amountval').val(detail.data.data);
                    jquery__WEBPACK_IMPORTED_MODULE_8__('#amount').text(detail.data.data);
                    jquery__WEBPACK_IMPORTED_MODULE_8__('.amount_day').addClass('active_plan');
                }
            });
            return yield modal.present();
        });
    }
    cardno(id) {
        this.cardid = id;
    }
    updatesubs() {
        if (this.errors.indexOf(this.cardid) >= 0) {
            this.common.presentToast('Please select card', 'danger');
            return false;
        }
        if (this.errors.indexOf(this.days) >= 0 && this.errors.indexOf(jquery__WEBPACK_IMPORTED_MODULE_8__('#amountval').val()) >= 0) {
            this.common.presentToast('Please select plan or add amount', 'danger');
            return false;
        }
        if (this.errors.indexOf(this.days) == -1) {
            let dict = {
                cardid: this.cardid,
                plan_id: this.days,
                userid: this.userid,
            };
            this.common.presentLoading();
            this.api.post('update_monthly_Subscription', dict, '').subscribe((result) => {
                this.common.stopLoading();
                var res;
                res = result;
                if (res.status == 1) {
                    this.common.presentToast('Subscription updated Successfully !.', 'success');
                    this.router.navigate(['/tabs/home']);
                }
                else {
                    this.common.presentToast(res.message, 'danger');
                }
            }, err => {
                this.common.stopLoading();
                this.common.presentToast('Some error occured', 'danger');
            });
        }
        if (this.errors.indexOf(jquery__WEBPACK_IMPORTED_MODULE_8__('#amountval').val()) == -1) {
            let dict = {
                cardid: this.cardid,
                userid: this.userid,
                amount: jquery__WEBPACK_IMPORTED_MODULE_8__('#amountval').val(),
            };
            this.common.presentLoading();
            this.api.post('update_monthly_Subscription', dict, '').subscribe((result) => {
                this.common.stopLoading();
                var res;
                res = result;
                if (res.status == 1) {
                    this.cardid = '';
                    jquery__WEBPACK_IMPORTED_MODULE_8__('#amountval').val("");
                    this.common.presentToast('Subscribed Successfully !.', 'success');
                    this.router.navigate(['/tabs/home']);
                }
                else {
                    this.common.presentToast(res.message, 'danger');
                }
            }, err => {
                this.common.stopLoading();
                this.common.presentToast('Some error occured', 'danger');
            });
        }
    }
    subs() {
        if (this.errors.indexOf(this.cardid) >= 0) {
            this.common.presentToast('Please select card', 'danger');
            return false;
        }
        if (this.errors.indexOf(this.days) >= 0 && this.errors.indexOf(jquery__WEBPACK_IMPORTED_MODULE_8__('#amountval').val()) >= 0) {
            this.common.presentToast('Please select plan or add amount', 'danger');
            return false;
        }
        if (this.errors.indexOf(this.days) == -1) {
            let dict = {
                cardid: this.cardid,
                plan_id: this.days,
                userid: this.userid,
            };
            this.common.presentLoading();
            this.api.post('add_monthly_Subscription', dict, '').subscribe((result) => {
                this.common.stopLoading();
                var res;
                res = result;
                if (res.status == 1) {
                    this.common.presentToast('Subscribed Successfully !.', 'success');
                    this.router.navigate(['/tabs/home']);
                }
                else {
                    this.common.presentToast(res.message, 'danger');
                }
            }, err => {
                this.common.stopLoading();
                this.common.presentToast('Some error occured', 'danger');
            });
        }
        if (this.errors.indexOf(jquery__WEBPACK_IMPORTED_MODULE_8__('#amountval').val()) == -1) {
            let dict = {
                cardid: this.cardid,
                userid: this.userid,
                amount: jquery__WEBPACK_IMPORTED_MODULE_8__('#amountval').val(),
            };
            this.common.presentLoading();
            this.api.post('add_monthly_Subscription', dict, '').subscribe((result) => {
                this.common.stopLoading();
                var res;
                res = result;
                if (res.status == 1) {
                    this.cardid = '';
                    jquery__WEBPACK_IMPORTED_MODULE_8__('#amountval').val("");
                    this.common.presentToast('Subscribed Successfully !.', 'success');
                    this.router.navigate(['/tabs/home']);
                }
                else {
                    this.common.presentToast(res.message, 'danger');
                }
            }, err => {
                this.common.stopLoading();
                this.common.presentToast('Some error occured', 'danger');
            });
        }
    }
    selectwekk(event, day) {
        if (jquery__WEBPACK_IMPORTED_MODULE_8__["inArray"](day, this.days) >= 0) {
            var carIndex = this.days.indexOf(day);
            this.days = '';
            jquery__WEBPACK_IMPORTED_MODULE_8__('.day').removeClass('active_plan');
        }
        else {
            jquery__WEBPACK_IMPORTED_MODULE_8__('.day').removeClass('active_plan');
            jquery__WEBPACK_IMPORTED_MODULE_8__('#amountval').val('');
            jquery__WEBPACK_IMPORTED_MODULE_8__('#amount').text('0');
            jquery__WEBPACK_IMPORTED_MODULE_8__('.amount_day').removeClass('active_plan');
            this.days = '';
            this.days = day;
            jquery__WEBPACK_IMPORTED_MODULE_8__('.day' + day).addClass('active_plan');
        }
    }
    ngOnInit() {
    }
    select(id) {
        this.show = !this.show;
        // CHANGE THE NAME OF THE BUTTON.
        if (this.show) {
            this.buttonName = "Hide";
            jquery__WEBPACK_IMPORTED_MODULE_8__('.plans_list' + id).addClass("active_plan");
        }
        else {
            this.buttonName = "Show";
            jquery__WEBPACK_IMPORTED_MODULE_8__('.plans_list' + id).removeClass("active_plan");
        }
        this.planid = id;
    }
    ionViewDidEnter() {
        this.userid = localStorage.getItem('userid');
        this.getsubscription();
        this.listpayment();
        this.subscriptionlistUser();
    }
    subscriptionlistUser() {
        let dict = {
            userid: this.userid,
        };
        this.api.post('Sublistuser', dict, '').subscribe((result) => {
            var res;
            res = result;
            if (res.status == 1) {
                this.sublist = res.data;
                console.log(this.sublist);
                if (this.errors.indexOf(this.sublist) == -1) {
                    var res1;
                    res1 = this.sublist;
                    this.cardid = res1.cardid;
                    if (this.errors.indexOf(res1.plan_id) >= 0) {
                        jquery__WEBPACK_IMPORTED_MODULE_8__('#amountval').val(res1.payment_amount);
                        jquery__WEBPACK_IMPORTED_MODULE_8__('#amount').text(res1.payment_amount);
                        jquery__WEBPACK_IMPORTED_MODULE_8__('.amount_day').addClass('active_plan');
                    }
                    else {
                        this.days = res1.plan_id;
                        jquery__WEBPACK_IMPORTED_MODULE_8__('.day' + this.days).addClass('active_plan');
                    }
                }
            }
            else {
                this.common.presentToast(res.message, 'danger');
            }
        }, err => {
        });
    }
    listpayment() {
        let dict = {
            userid: this.userid,
        };
        this.api.post('ListPayment', dict, '').subscribe((result) => {
            var res;
            res = result;
            if (res.status == 1) {
                this.paymentlist = res.data;
            }
            else {
                this.common.presentToast(res.message, 'danger');
            }
        }, err => {
        });
    }
    getsubscription() {
        this.common.presentLoading();
        this.api.post('subscriptionlist', '', '').subscribe((result) => {
            this.common.stopLoading();
            var res;
            res = result;
            if (res.status == 1) {
                this.list = res.data;
            }
            else {
            }
        }, err => {
        });
    }
};
ThetabledetailPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
    { type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_4__["ApiService"] },
    { type: _common_common_service__WEBPACK_IMPORTED_MODULE_6__["CommonService"] }
];
ThetabledetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-thetabledetail',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./thetabledetail.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/thetabledetail/thetabledetail.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./thetabledetail.page.scss */ "./src/app/thetabledetail/thetabledetail.page.scss")).default]
    })
], ThetabledetailPage);



/***/ })

}]);
//# sourceMappingURL=thetabledetail-thetabledetail-module-es2015.js.map