(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["editprofile-editprofile-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/editprofile/editprofile.page.html":
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/editprofile/editprofile.page.html ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("   <ion-header>\r\n      <ion-toolbar color=\"primary\">\r\n        <ion-back-button defaultHref=\"/tabs/profile\" slot=\"start\">\r\n        </ion-back-button>\r\n        <ion-title class=\"ion-text-center\">Edit Profile</ion-title>\r\n      </ion-toolbar>\r\n\t  </ion-header>\r\n\r\n<ion-content>\r\n<div profileinfo>\r\n<div profileimg>\r\n  <img src=\"assets/images/paul-feeding.jpg\"/>\r\n  <div userinner>\r\n  <label for=\"editphoto\" btnedit >\r\n    <ion-icon name=\"camera-outline\"></ion-icon>\r\n  </label>\r\n  <img   src=\"assets/images/user1.jpg\" *ngIf=\"is_license_uploaded == false && errors.indexOf(userdetails?.image) >= 0\"  class=\"user_image1\">\r\n   <img   src=\"{{IMAGES_URL}}/{{userdetails?.image}}\" *ngIf=\"errors.indexOf(userdetails?.image) == -1\"  class=\"user_image1\">\r\n  <img *ngIf=\"is_license_uploaded == true\"  [src]=\"sanitizer.bypassSecurityTrustUrl(license_image_url)\"\r\n\t\t\t\t\t\t\t\tclass=\"user_image1\">\r\n <input type=\"file\" id=\"editphoto\" (change)=\"uploadImage($event)\"  name=\"editphoto\" style=\"display:none;\" />\r\n<!--img *ngIf=\"errors.indexOf(userdetails?.image) == -1 && getimage(userdetails?.image) == false && is_live_image_updated_profile == false\" src=\"{{IMAGES_URL + userdetails?.image}}\">\r\n <img *ngIf=\"errors.indexOf(userdetails?.image) == -1 && getimage(userdetails?.image) == true  && is_live_image_updated_profile == false\" src=\"{{IMAGES_URL}}/{{userdetails?.image}}\">\r\n <img *ngIf=\"image_type == 'profile'  && is_live_image_updated_profile == true\" [src]=\"win.Ionic.WebView.convertFileSrc(live_image_url)\">\r\n <img *ngIf=\"errors.indexOf(userdetails?.image) >= 0 && is_live_image_updated_profile == false\" src=\"assets/images/user1.jpg\"-->\r\n</div>\r\n\r\n</div>\r\n<div editprofile>\r\n<div userinfo>\r\n <h2 class=\"name\">{{userdetails?.first_name}} {{userdetails?.last_name}}</h2>\r\n <p class=\"email_address\">{{userdetails?.email}}</p>\r\n</div>\r\n<div formfield>\r\n\t\t\t\t<label>First Name</label>\r\n\t\t\t\t<ion-item lines=\"none\" class=\"fls\"> \r\n\t\t\t\t\t<ion-input placeholder=\"Enter First Name\" value=\"{{userdetails?.first_name}}\"\r\n\t\t\t\t\t[(ngModel)]=\"first_name\" name=\"first_name\" \r\n\t\t\t\t\t></ion-input>\r\n\t\t\t\t</ion-item>\r\n\t\t\t\t<span error *ngIf=\"errors.indexOf(first_name) >= 0 && is_submit_update== true\">Please enter your first name</span>\r\n\t\t\t\t\r\n</div>\r\n<div formfield>\r\n\t\t\t\t<label>Last Name</label>\r\n\t\t\t\t<ion-item lines=\"none\" class=\"fls\"> \r\n\t\t\t\t\t<ion-input placeholder=\"Enter Last Name\" value=\"{{userdetails?.last_name}}\"[(ngModel)]=\"last_name\" name=\"last_name\" \r\n\t\t\t\t\t></ion-input>\r\n\t\t\t\t</ion-item>\r\n\t\t\t\t<span error *ngIf=\"errors.indexOf(last_name) >= 0 && is_submit_update== true\">Please enter your last name</span>\r\n\t\t\t\t\r\n</div>\r\n<div formfield>\r\n\t\t\t\t<label>Email Address</label>\r\n\t\t\t\t<ion-item lines=\"none\" class=\"fls\"> \r\n\t\t\t\t\t<ion-input placeholder=\"Enter Email Address\" value=\"{{userdetails?.email}}\"[(ngModel)]=\"email\" name=\"email\" \r\n\t\t\t\t\tdisabled></ion-input>\r\n\t\t\t\t</ion-item>\r\n\t\t\t\t<span error *ngIf=\"errors.indexOf(email) >= 0 && is_submit_update== true\">Please enter your email address</span>\r\n</div>\r\n<div formfield>\r\n\t\t\t\t<label>Address</label>\r\n\t\t\t\t<ion-item lines=\"none\" class=\"fls\"> \r\n\t\t\t\t\t<ion-input placeholder=\"Enter Address\" value=\"{{userdetails?.address}}\" [(ngModel)]=\"address\" name=\"address\" ></ion-input>\r\n\t\t\t\t</ion-item>\r\n\t\t\t\t<span error *ngIf=\"errors.indexOf(address) >= 0 && is_submit_update== true\">Please enter your address</span>\r\n</div>\r\n\r\n<div formfield>\r\n\t\t\t\t<label>Facebook Url</label>\r\n\t\t\t\t<ion-item lines=\"none\" class=\"fls\"> \r\n\t\t\t\t\t<ion-input placeholder=\"Facebook Url\" value=\"{{userdetails?.facebook}}\" [(ngModel)]=\"facebook\" name=\"facebook\" ></ion-input>\r\n\t\t\t\t</ion-item>\r\n\t\t\t\t<span error *ngIf=\"errors.indexOf(facebook) >= 0 && is_submit_update== true\">Please enter your facebook url</span>\r\n</div>\r\n<div formfield>\r\n\t\t\t\t<label>Twitter Url</label>\r\n\t\t\t\t<ion-item lines=\"none\" class=\"fls\"> \r\n\t\t\t\t\t<ion-input placeholder=\"Twitter Url\" value=\"{{userdetails?.twitter}}\" [(ngModel)]=\"twitter\" name=\"twitter\" ></ion-input>\r\n\t\t\t\t</ion-item>\r\n\t\t\t\t<span error *ngIf=\"errors.indexOf(twitter) >= 0 && is_submit_update== true\">Please enter your twitter url</span>\r\n</div>\r\n<div formfield>\r\n\t\t\t\t<label>LinkedIn Url</label>\r\n\t\t\t\t<ion-item lines=\"none\" class=\"fls\"> \r\n\t\t\t\t\t<ion-input placeholder=\"LinkedIn Url\" value=\"{{userdetails?.linkedin}}\" [(ngModel)]=\"linkedin\" name=\"linkedin\" ></ion-input>\r\n\t\t\t\t</ion-item>\r\n\t\t\t\t<span error *ngIf=\"errors.indexOf(linkedin) >= 0 && is_submit_update== true\">Please enter your linkedin url</span>\r\n</div>\r\n\r\n\r\n<ion-button  expand=\"full\" shape=\"round\" class=\"btn-losns\"(click)=\"update()\">Submit</ion-button>\r\n</div>\r\n</div>\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/editprofile/editprofile-routing.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/editprofile/editprofile-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: EditprofilePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditprofilePageRoutingModule", function() { return EditprofilePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _editprofile_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./editprofile.page */ "./src/app/editprofile/editprofile.page.ts");




const routes = [
    {
        path: '',
        component: _editprofile_page__WEBPACK_IMPORTED_MODULE_3__["EditprofilePage"]
    }
];
let EditprofilePageRoutingModule = class EditprofilePageRoutingModule {
};
EditprofilePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], EditprofilePageRoutingModule);



/***/ }),

/***/ "./src/app/editprofile/editprofile.module.ts":
/*!***************************************************!*\
  !*** ./src/app/editprofile/editprofile.module.ts ***!
  \***************************************************/
/*! exports provided: EditprofilePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditprofilePageModule", function() { return EditprofilePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _editprofile_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./editprofile-routing.module */ "./src/app/editprofile/editprofile-routing.module.ts");
/* harmony import */ var _editprofile_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./editprofile.page */ "./src/app/editprofile/editprofile.page.ts");







let EditprofilePageModule = class EditprofilePageModule {
};
EditprofilePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _editprofile_routing_module__WEBPACK_IMPORTED_MODULE_5__["EditprofilePageRoutingModule"]
        ],
        declarations: [_editprofile_page__WEBPACK_IMPORTED_MODULE_6__["EditprofilePage"]]
    })
], EditprofilePageModule);



/***/ }),

/***/ "./src/app/editprofile/editprofile.page.scss":
/*!***************************************************!*\
  !*** ./src/app/editprofile/editprofile.page.scss ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-toolbar {\n  --ion-color-base: var(--ion-color-bggradient)!important;\n  --border-width: 0;\n}\nion-header ion-toolbar ion-title {\n  color: var(--ion-color-white);\n  text-align: center;\n  font-style: normal;\n  font-family: \"Poppins\", sans-serif !important;\n}\nion-header::after {\n  display: none;\n}\nion-content [profileinfo] [editprofile] {\n  padding: 60px 15px 0;\n  margin-top: -20px;\n  background: var(--ion-color-white);\n  position: relative;\n  border-radius: 15px 15px 0 0;\n}\nion-content [profileinfo] [editprofile] [userinfo] {\n  margin-bottom: 24px;\n  text-align: center;\n}\nion-content [profileinfo] [editprofile] [userinfo] h2 {\n  margin: 0;\n  font-size: 14px;\n}\nion-content [profileinfo] [editprofile] [userinfo] p {\n  margin: 0;\n  font-size: 12px;\n}\nion-content [profileinfo] [editprofile] [formfield] {\n  position: relative;\n  border: 1px solid #e8e8e8;\n  height: 52px;\n  border-radius: 50px;\n  background: var(--ion-color-white);\n  padding: 0 16px;\n  margin-top: 25px;\n}\nion-content [profileinfo] [editprofile] [formfield] label {\n  position: absolute;\n  top: -10px;\n  z-index: 111;\n  background: var(--ion-color-white);\n  left: 29px;\n  padding: 0 3px;\n  font-size: 12px;\n  font-weight: 700;\n  color: #3a3a3a;\n}\nion-content [profileinfo] [editprofile] [formfield] ion-input {\n  padding: 0px;\n  --padding-start: 0px;\n  --padding-end: 0px;\n  font-size: 14px;\n  --placeholder-color: #9a9a9a;\n  --placeholder-opacity: 1;\n  font-family: \"Poppins\", sans-serif !important;\n  color: #222;\n}\nion-content [profileinfo] [editprofile] .btn-losns {\n  --background:var( --ion-color-primary);\n  margin-top: 20px;\n  --box-shadow: none;\n  min-height: 48px;\n  margin-bottom: 15px;\n  text-transform: uppercase;\n  letter-spacing: 1px;\n}\nion-content [profileinfo] [profileimg] {\n  position: relative;\n  height: 160px;\n}\nion-content [profileinfo] [profileimg] img {\n  max-width: 100%;\n  max-height: 100%;\n  width: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n  -o-object-position: bottom;\n     object-position: bottom;\n}\nion-content [profileinfo] [profileimg] [userinner] {\n  position: relative;\n  text-align: center;\n  margin-top: -62px;\n  z-index: 1;\n}\nion-content [profileinfo] [profileimg] [userinner] [btnedit] {\n  margin-left: 45px;\n  width: 30px;\n  height: 30px;\n  background: var(--ion-color-primary);\n  border-radius: 50%;\n  display: inline-block;\n  line-height: 30px;\n  border: 2px solid var(--ion-color-white);\n  position: absolute;\n  bottom: 1px;\n}\nion-content [profileinfo] [profileimg] [userinner] [btnedit] ion-icon {\n  color: var(--ion-color-white);\n}\nion-content [profileinfo] [profileimg] [userinner] img {\n  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.25);\n  width: 80px;\n  height: 80px;\n  border-radius: 50%;\n  border: 2px solid var(--ion-color-white);\n  margin: 0 auto;\n  text-align: center;\n}\n[error] {\n  color: red;\n  font-size: 12px;\n}\nion-content {\n  margin-top: 25px !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZWRpdHByb2ZpbGUvZWRpdHByb2ZpbGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdHO0VBQ0MsdURBQUE7RUFDRCxpQkFBQTtBQUZIO0FBSUk7RUFDQSw2QkFBQTtFQUNBLGtCQUFBO0VBQ1Esa0JBQUE7RUFDQSw2Q0FBQTtBQUZaO0FBS0M7RUFFQSxhQUFBO0FBSkQ7QUFXQztFQUNNLG9CQUFBO0VBQ0gsaUJBQUE7RUFDQSxrQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsNEJBQUE7QUFSSjtBQVNDO0VBQ0ksbUJBQUE7RUFDRCxrQkFBQTtBQVBKO0FBUUM7RUFDRyxTQUFBO0VBQ0EsZUFBQTtBQU5KO0FBT0M7RUFDRyxTQUFBO0VBQ0EsZUFBQTtBQUxKO0FBUUM7RUFDRSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0Esa0NBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUFOSDtBQU9HO0VBQ0Msa0JBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLGtDQUFBO0VBQ0EsVUFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0FBTEo7QUFPRztFQUNDLFlBQUE7RUFDQSxvQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLDRCQUFBO0VBQ0Esd0JBQUE7RUFDQSw2Q0FBQTtFQUNBLFdBQUE7QUFMSjtBQVFFO0VBQ0Msc0NBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ1MsZ0JBQUE7RUFDVCxtQkFBQTtFQUNBLHlCQUFBO0VBQ0EsbUJBQUE7QUFOSDtBQVNDO0VBQ0ssa0JBQUE7RUFFSCxhQUFBO0FBUkg7QUFTRztFQUVFLGVBQUE7RUFDRCxnQkFBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtLQUFBLGlCQUFBO0VBQ0EsMEJBQUE7S0FBQSx1QkFBQTtBQVJKO0FBVUc7RUFFQyxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxVQUFBO0FBVEo7QUFXQztFQUNHLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxvQ0FBQTtFQUNBLGtCQUFBO0VBQ0EscUJBQUE7RUFDQSxpQkFBQTtFQUNBLHdDQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0FBVEo7QUFVQztFQUNDLDZCQUFBO0FBUkY7QUFXRTtFQUNHLDRDQUFBO0VBQ0QsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLHdDQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0FBVEo7QUFnQkM7RUFFQSxVQUFBO0VBQ0EsZUFBQTtBQWREO0FBZ0JDO0VBQ0EsMkJBQUE7QUFiRCIsImZpbGUiOiJzcmMvYXBwL2VkaXRwcm9maWxlL2VkaXRwcm9maWxlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXJcclxuXHR7XHJcblx0XHJcblx0ICBpb24tdG9vbGJhclxyXG5cdCAgey0taW9uLWNvbG9yLWJhc2U6IHZhcigtLWlvbi1jb2xvci1iZ2dyYWRpZW50KSFpbXBvcnRhbnQ7XHJcblx0ICAtLWJvcmRlci13aWR0aDogMDtcclxuXHRcclxuXHRcdCAgaW9uLXRpdGxle1xyXG5cdFx0ICBjb2xvcjp2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdFx0ICB0ZXh0LWFsaWduOmNlbnRlcjtcclxuICAgICAgICAgICAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gICAgICAgICAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgfVxyXG5cdH1cclxuXHQmOjphZnRlclxyXG5cdHtcclxuXHRkaXNwbGF5Om5vbmU7XHJcblx0fVxyXG5cdH1cclxuXHRpb24tY29udGVudFxyXG5cdHtcclxuXHRbcHJvZmlsZWluZm9dXHJcbiB7XHJcbiBbZWRpdHByb2ZpbGVdXHJcbiB7ICAgICBwYWRkaW5nOiA2MHB4IDE1cHggMDtcclxuICAgIG1hcmdpbi10b3A6IC0yMHB4O1xyXG4gICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDE1cHggMTVweCAwIDA7IFxyXG5cdFt1c2VyaW5mb10ge1xyXG5cdCAgICBtYXJnaW4tYm90dG9tOiAyNHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG5cdGgyIHtcclxuICAgIG1hcmdpbjogMDtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxufXAge1xyXG4gICAgbWFyZ2luOiAwO1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG59XHJcbn1cclxuXHRbZm9ybWZpZWxkXSB7XHJcblx0XHRcdHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHRcdFx0Ym9yZGVyOiAxcHggc29saWQgI2U4ZThlODtcclxuXHRcdFx0aGVpZ2h0OiA1MnB4O1xyXG5cdFx0XHRib3JkZXItcmFkaXVzOiA1MHB4O1xyXG5cdFx0XHRiYWNrZ3JvdW5kOnZhciggLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdFx0XHRwYWRkaW5nOiAwIDE2cHg7XHJcblx0XHRcdG1hcmdpbi10b3A6MjVweDtcclxuXHRcdFx0bGFiZWwge1xyXG5cdFx0XHRcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRcdFx0XHR0b3A6IC0xMHB4O1xyXG5cdFx0XHRcdHotaW5kZXg6IDExMTtcclxuXHRcdFx0XHRiYWNrZ3JvdW5kOiB2YXIoIC0taW9uLWNvbG9yLXdoaXRlKTtcclxuXHRcdFx0XHRsZWZ0OiAyOXB4O1xyXG5cdFx0XHRcdHBhZGRpbmc6IDAgM3B4O1xyXG5cdFx0XHRcdGZvbnQtc2l6ZTogMTJweDtcclxuXHRcdFx0XHRmb250LXdlaWdodDogNzAwO1xyXG5cdFx0XHRcdGNvbG9yOiAjM2EzYTNhO1xyXG5cdFx0XHR9XHJcblx0XHRcdGlvbi1pbnB1dCAge1xyXG5cdFx0XHRcdHBhZGRpbmc6IDBweDtcclxuXHRcdFx0XHQtLXBhZGRpbmctc3RhcnQ6IDBweDtcclxuXHRcdFx0XHQtLXBhZGRpbmctZW5kOiAwcHg7XHJcblx0XHRcdFx0Zm9udC1zaXplOiAxNHB4O1xyXG5cdFx0XHRcdC0tcGxhY2Vob2xkZXItY29sb3I6ICM5YTlhOWE7XHJcblx0XHRcdFx0LS1wbGFjZWhvbGRlci1vcGFjaXR5OiAxO1xyXG5cdFx0XHRcdGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcclxuXHRcdFx0XHRjb2xvcjogIzIyMjtcclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cdFx0LmJ0bi1sb3Nuc3tcclxuXHRcdFx0LS1iYWNrZ3JvdW5kOnZhciggLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcblx0XHRcdG1hcmdpbi10b3A6IDIwcHg7XHJcblx0XHRcdC0tYm94LXNoYWRvdzogbm9uZTtcclxuICAgICAgICAgICAgbWluLWhlaWdodDogNDhweDtcclxuXHRcdFx0bWFyZ2luLWJvdHRvbTogMTVweDtcclxuXHRcdFx0dGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuXHRcdFx0bGV0dGVyLXNwYWNpbmc6IDFweDtcclxuXHRcdH1cclxuIH1cclxuIFtwcm9maWxlaW1nXVxyXG4geyAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcblxyXG4gICBoZWlnaHQ6MTYwcHg7XHJcbiAgIGltZ1xyXG4gICB7XHJcbiAgICAgbWF4LXdpZHRoOiAxMDAlO1xyXG4gICAgbWF4LWhlaWdodDogMTAwJTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgb2JqZWN0LWZpdDogY292ZXI7XHJcbiAgICBvYmplY3QtcG9zaXRpb246Ym90dG9tO1xyXG4gICB9XHJcbiAgIFt1c2VyaW5uZXJdXHJcbiB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBtYXJnaW4tdG9wOiAtNjJweDtcclxuICAgIHotaW5kZXg6IDE7XHJcbiAgXHJcblx0W2J0bmVkaXRdIHtcclxuICAgIG1hcmdpbi1sZWZ0OiA0NXB4O1xyXG4gICAgd2lkdGg6IDMwcHg7XHJcbiAgICBoZWlnaHQ6IDMwcHg7XHJcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbiAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICBsaW5lLWhlaWdodDogMzBweDtcclxuICAgIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBib3R0b206IDFweDtcclxuXHRpb24taWNvblxyXG5cdHtjb2xvcjp2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdH1cclxufVxyXG4gIGltZ1xyXG5cdCAgIHtib3gtc2hhZG93OiAwcHggMHB4IDEwcHggcmdiYSgwLCAwLCAwLCAwLjI1KTtcclxuXHQgICB3aWR0aDogODBweDtcclxuICAgIGhlaWdodDogODBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcbiAgICBtYXJnaW46IDAgYXV0bztcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHQgICB9XHJcbn1cclxuIH1cclxuIH1cclxuICBcclxuXHR9XHJcblx0W2Vycm9yXVxyXG5cdHtcclxuXHRjb2xvcjpyZWQ7XHJcblx0Zm9udC1zaXplOjEycHg7XHJcblx0fVxyXG5cdGlvbi1jb250ZW50e1xyXG5cdG1hcmdpbi10b3A6IDI1cHggIWltcG9ydGFudDtcclxuXHR9Il19 */");

/***/ }),

/***/ "./src/app/editprofile/editprofile.page.ts":
/*!*************************************************!*\
  !*** ./src/app/editprofile/editprofile.page.ts ***!
  \*************************************************/
/*! exports provided: EditprofilePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditprofilePage", function() { return EditprofilePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/api/api.service */ "./src/app/services/api/api.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../config */ "./src/app/config.ts");
/* harmony import */ var _common_common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../common/common.service */ "./src/app/common/common.service.ts");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/camera/ngx */ "./node_modules/@ionic-native/camera/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/file/ngx */ "./node_modules/@ionic-native/file/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/file-path/ngx */ "./node_modules/@ionic-native/file-path/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/file-transfer/ngx */ "./node_modules/@ionic-native/file-transfer/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var ng2_file_upload__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ng2-file-upload */ "./node_modules/ng2-file-upload/__ivy_ngcc__/fesm2015/ng2-file-upload.js");












let EditprofilePage = class EditprofilePage {
    constructor(api, router, common, camera, file, filePath, transfer) {
        this.api = api;
        this.router = router;
        this.common = common;
        this.camera = camera;
        this.file = file;
        this.filePath = filePath;
        this.transfer = transfer;
        this.win = window;
        this.is_submit_update = false;
        this.is_live_image_updated_cover = false;
        this.is_live_image_updated_profile = false;
        this.errors = ['', null, undefined];
        this.donationlist = [];
        this.IMAGES_URL = _config__WEBPACK_IMPORTED_MODULE_4__["config"].IMAGES_URL;
        this.allowedMimes = ['image/png', 'image/jpg', 'image/jpeg'];
        this.license_error = false;
        this.is_license_uploaded = false;
        this.uploader = new ng2_file_upload__WEBPACK_IMPORTED_MODULE_11__["FileUploader"]({ url: '' });
    }
    ngOnInit() {
    }
    getimage(img) {
        if (this.errors.indexOf(img) == -1) {
            if (img.includes('https') == true) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            return false;
        }
    }
    selectImage(type) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.image_type = type;
            const actionSheet = yield this.api.actionSheetController.create({
                header: "Select Image",
                buttons: [{
                        text: 'From Gallery',
                        handler: () => {
                            this.takePicture(this.camera.PictureSourceType.PHOTOLIBRARY, type);
                        }
                    },
                    {
                        text: 'Use Camera',
                        handler: () => {
                            this.takePicture(this.camera.PictureSourceType.CAMERA, type);
                        }
                    },
                    {
                        text: 'Cancel',
                        role: 'cancel'
                    }
                ]
            });
            yield actionSheet.present();
        });
    }
    uploadImage(event) {
        this.license_error = false;
        var self = this;
        if (event.target.files && event.target.files[0]) {
            var reader = new FileReader();
            var image_file = event.target.files[0];
            if (self.allowedMimes.indexOf(image_file.type) == -1) {
                this.license_error = true;
                this.common.presentToast('This format is not allowed !.', 'danger');
            }
            else {
                self.license_file = image_file;
                self.license_image_url = window.URL.createObjectURL(image_file);
                jquery__WEBPACK_IMPORTED_MODULE_6__('.user_image1').attr('src', self.license_image_url);
            }
        }
    }
    takePicture(sourceType, type) {
        var options = {
            quality: 25,
            sourceType: sourceType,
            saveToPhotoAlbum: false,
            correctOrientation: true,
            allowEdit: true
        };
        this.camera.getPicture(options).then(imagePath => {
            if (sourceType === this.camera.PictureSourceType.PHOTOLIBRARY) {
                if (type == 'profile') {
                    this.live_image_url = imagePath;
                    this.is_live_image_updated_profile = true;
                }
                if (type == 'cover') {
                    this.bgImage = this.win.Ionic.WebView.convertFileSrc(imagePath);
                    this.is_live_image_updated_cover = true;
                }
                this.filePath.resolveNativePath(imagePath)
                    .then(filePath => {
                    this.startUpload(imagePath, type);
                });
            }
            else {
                if (type == 'profile') {
                    this.live_image_url = imagePath;
                    this.is_live_image_updated_profile = true;
                }
                if (type == 'cover') {
                    this.bgImage = this.win.Ionic.WebView.convertFileSrc(imagePath);
                    this.is_live_image_updated_cover = true;
                }
                this.startUpload(imagePath, type);
            }
        }, (err) => {
            console.log('err');
            console.log(err);
        });
    }
    ;
    ionViewDidEnter() {
        this.userid = localStorage.getItem('userid');
        this.getuserdetails();
    }
    startUpload(imageData, type) {
        this.file.resolveLocalFilesystemUrl(imageData).then(entry => {
            entry.file(file => {
                this.readFile(file, type);
            });
        })
            .catch(err => {
            this.common.presentToast('Error while reading file.', 'danger');
        });
    }
    readFile(file, type) {
        var self = this;
        const reader = new FileReader();
        reader.onloadend = () => {
            if (type == 'profile') {
                const imgBlobProfile = new Blob([reader.result], {
                    type: file.type
                });
                self.imgBlobProfile = imgBlobProfile;
                self.live_file_name_profile = file.name;
                self.profileImageSubmit(type);
            }
            else {
                const imgBlobCover = new Blob([reader.result], {
                    type: file.type
                });
                self.imgBlobCover = imgBlobCover;
                self.live_file_name_cover = file.name;
            }
            // const imgBlob = new Blob([reader.result], {
            //     type: file.type
            // });
            // self.imgBlob = imgBlob;
            // self.live_file_name = file.name;
            //self.profileImageSubmit(type);
        };
        reader.readAsArrayBuffer(file);
    }
    profileImageSubmit(type) {
        // this.apiService.presentLoading();
        const frmData = new FormData();
        frmData.append('file', this.imgBlobProfile, this.live_file_name_profile);
        frmData.append("live_image", this.live_file_name_profile.replace(/ /g, "_"));
        frmData.append("userId", localStorage.getItem('userid'));
        frmData.append("type", type);
        this.api.post('update_user_image', frmData, '').subscribe((result) => {
            var res;
            res = result;
            if (res.status == 1) {
                this.userdetails.image = res.data;
                this.is_live_image_updated_profile = false;
            }
            else {
                this.common.presentToast('Error while sending request,Please try after some time', 'success');
            }
        }, err => {
            this.common.presentToast('Technical error,Please try after some time', 'success');
        });
    }
    getuserdetails() {
        let dict = {
            id: this.userid
        };
        if (this.errors.indexOf(this.userid) >= 0) {
            this.common.presentToast('Please login first!.', 'danger');
            return false;
        }
        this.common.presentLoading();
        this.api.post('Userdetails', dict, '').subscribe((result) => {
            this.common.stopLoading();
            var res;
            res = result;
            if (res.status == 1) {
                this.userdetails = res.data;
                this.donationlist = res.donations;
                this.common.presentToast(res.message, 'success');
            }
            else {
                this.common.presentToast(res.message, 'danger');
            }
        }, err => {
        });
    }
    update() {
        this.is_submit_update = true;
        if (this.errors.indexOf(this.first_name) >= 0 || this.errors.indexOf(this.last_name) >= 0 || this.errors.indexOf(this.email) >= 0 || this.errors.indexOf(this.address) >= 0) {
            return false;
        }
        if (this.errors.indexOf(this.userid) >= 0) {
            this.common.presentToast('Please login first!.', 'danger');
            return false;
        }
        const frmData = new FormData();
        if (this.errors.indexOf(this.license_file) == -1) {
            frmData.append("image", this.license_file);
        }
        frmData.append("first_name", this.first_name);
        frmData.append("last_name", this.last_name);
        frmData.append("email", this.email);
        frmData.append("address", this.address);
        frmData.append("facebook", this.facebook);
        frmData.append("twitter", this.twitter);
        frmData.append("linkedin", this.linkedin);
        frmData.append("id", this.userid);
        this.common.presentLoading();
        this.api.post('updateUserDetails', frmData, '').subscribe((result) => {
            this.is_submit_update = false;
            this.common.stopLoading();
            var res;
            res = result;
            if (res.status == 1) {
                jquery__WEBPACK_IMPORTED_MODULE_6__('.name').text(this.first_name + ' ' + this.last_name);
                this.common.presentToast('Updated successfully !.', 'success');
            }
            else {
                this.common.presentToast(res.message, 'danger');
            }
        }, err => {
        });
    }
};
EditprofilePage.ctorParameters = () => [
    { type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _common_common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"] },
    { type: _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_7__["Camera"] },
    { type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_8__["File"] },
    { type: _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_9__["FilePath"] },
    { type: _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_10__["FileTransfer"] }
];
EditprofilePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-editprofile',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./editprofile.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/editprofile/editprofile.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./editprofile.page.scss */ "./src/app/editprofile/editprofile.page.scss")).default]
    })
], EditprofilePage);



/***/ })

}]);
//# sourceMappingURL=editprofile-editprofile-module-es2015.js.map