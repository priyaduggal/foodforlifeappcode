(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["searchteam-searchteam-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/searchteam/searchteam.page.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/searchteam/searchteam.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n\t<ion-back-button defaultHref=\"/tabs/tribes\" slot=\"start\">\r\n\t</ion-back-button>\r\n\t<ion-title class=\"ion-text-center\">Search or Create Team</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n<ion-content class=\"ion-padding\">\r\n  <div class=\"search\">\r\n  <ion-searchbar placeholder=\"Search Team...\" (keyup)=\"search_keyword($event);\"   ></ion-searchbar>\r\n  </div>\r\n  <ion-item lines=\"none\" *ngIf=\"teams?.length==0\">\r\n\t <ion-label>\r\n\t\t <h2>Teams not found</h2>\r\n\t\t  </ion-label>\r\n\t\t</ion-item>\r\n  \r\n  <ion-item lines=\"none\" *ngFor=\"let team of teams\" routerLink=\"/teamdetail/{{team?.id}}\">\r\n\t\t <ion-thumbnail>\r\n\t\t <img src=\"{{IMAGES_URL}}/{{team?.image}}\"/>\r\n\t\t </ion-thumbnail>\r\n\t\t <ion-label>\r\n\t\t <h2>{{team?.name}}</h2>\r\n\t\t <p><span><ion-icon name=\"heart\"></ion-icon>{{team?.meals}}</span> <span><ion-icon name=\"people\"></ion-icon>{{team?.joins}}</span></p>\r\n\t\t </ion-label>\r\n\t\t <ion-icon name=\"chevron-forward-outline\" slot=\"end\" ></ion-icon>\r\n\t\t</ion-item>\r\n\t\t\t\t\r\n\t\t<ion-fab routerLink=\"/createteam\" vertical=\"bottom\" horizontal=\"end\" edge size=\"small\" slot=\"fixed\">\r\n    <ion-fab-button>\r\n      <ion-icon name=\"add-outline\"></ion-icon>\r\n    </ion-fab-button>\r\n  </ion-fab>\r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/searchteam/searchteam-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/searchteam/searchteam-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: SearchteamPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchteamPageRoutingModule", function() { return SearchteamPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _searchteam_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./searchteam.page */ "./src/app/searchteam/searchteam.page.ts");




const routes = [
    {
        path: '',
        component: _searchteam_page__WEBPACK_IMPORTED_MODULE_3__["SearchteamPage"]
    }
];
let SearchteamPageRoutingModule = class SearchteamPageRoutingModule {
};
SearchteamPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SearchteamPageRoutingModule);



/***/ }),

/***/ "./src/app/searchteam/searchteam.module.ts":
/*!*************************************************!*\
  !*** ./src/app/searchteam/searchteam.module.ts ***!
  \*************************************************/
/*! exports provided: SearchteamPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchteamPageModule", function() { return SearchteamPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _searchteam_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./searchteam-routing.module */ "./src/app/searchteam/searchteam-routing.module.ts");
/* harmony import */ var _searchteam_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./searchteam.page */ "./src/app/searchteam/searchteam.page.ts");







let SearchteamPageModule = class SearchteamPageModule {
};
SearchteamPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _searchteam_routing_module__WEBPACK_IMPORTED_MODULE_5__["SearchteamPageRoutingModule"]
        ],
        declarations: [_searchteam_page__WEBPACK_IMPORTED_MODULE_6__["SearchteamPage"]]
    })
], SearchteamPageModule);



/***/ }),

/***/ "./src/app/searchteam/searchteam.page.scss":
/*!*************************************************!*\
  !*** ./src/app/searchteam/searchteam.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-toolbar {\n  --ion-color-base: var(--ion-color-bggradient)!important;\n  --border-width: 0;\n}\nion-header ion-toolbar ion-title {\n  color: var(--ion-color-white);\n  text-align: center;\n  font-style: normal;\n  font-family: \"Poppins\", sans-serif !important;\n}\nion-header::after {\n  display: none;\n}\nion-content {\n  --background: #f7f7f7;\n}\nion-content ion-fab {\n  bottom: 3px;\n  right: 4px;\n}\nion-content ion-item {\n  --padding-start: 10px;\n  margin-top: 15px;\n  border-radius: 15px 0 15px;\n  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);\n  border-left: 2px solid var(--ion-color-primary);\n  --inner-padding-end: 5px;\n}\nion-content ion-item ion-thumbnail {\n  width: 70px;\n  height: 70px;\n}\nion-content ion-item ion-thumbnail img {\n  width: 70px;\n  height: 70px;\n  border-radius: 8px;\n}\nion-content ion-item ion-label {\n  margin-left: 15px;\n}\nion-content ion-item ion-label h2 {\n  margin-bottom: 5px;\n}\nion-content ion-item ion-label p span {\n  margin-right: 10px;\n  font-size: 14px;\n}\nion-content ion-item ion-label p span ion-icon {\n  margin-right: 3px;\n  color: var(--ion-color-primary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2VhcmNodGVhbS9zZWFyY2h0ZWFtLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHRztFQUNDLHVEQUFBO0VBQ0QsaUJBQUE7QUFGSDtBQUlJO0VBQ0EsNkJBQUE7RUFDQSxrQkFBQTtFQUNRLGtCQUFBO0VBQ0EsNkNBQUE7QUFGWjtBQUtDO0VBRUEsYUFBQTtBQUpEO0FBT0E7RUFDSyxxQkFBQTtBQUpMO0FBS0E7RUFDSSxXQUFBO0VBQ0EsVUFBQTtBQUhKO0FBS0E7RUFDRSxxQkFBQTtFQUNLLGdCQUFBO0VBQ0gsMEJBQUE7RUFDQSwyQ0FBQTtFQUNBLCtDQUFBO0VBQ0Esd0JBQUE7QUFISjtBQUlHO0VBRUksV0FBQTtFQUNILFlBQUE7QUFISjtBQUlDO0VBRUksV0FBQTtFQUNELFlBQUE7RUFDSCxrQkFBQTtBQUhEO0FBTUc7RUFFQyxpQkFBQTtBQUxKO0FBTUk7RUFFQSxrQkFBQTtBQUxKO0FBU0k7RUFDQyxrQkFBQTtFQUNELGVBQUE7QUFQSjtBQVFJO0VBQ0MsaUJBQUE7RUFDRCwrQkFBQTtBQU5KIiwiZmlsZSI6InNyYy9hcHAvc2VhcmNodGVhbS9zZWFyY2h0ZWFtLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXJcclxue1xyXG5cdFxyXG5cdCAgaW9uLXRvb2xiYXJcclxuXHQgIHstLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1pb24tY29sb3ItYmdncmFkaWVudCkhaW1wb3J0YW50O1xyXG5cdCAgLS1ib3JkZXItd2lkdGg6IDA7XHJcblx0XHJcblx0XHQgIGlvbi10aXRsZXtcclxuXHRcdCAgY29sb3I6dmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuXHRcdCAgdGV4dC1hbGlnbjpjZW50ZXI7XHJcbiAgICAgICAgICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xyXG4gICAgICAgIH1cclxuXHR9XHJcblx0Jjo6YWZ0ZXJcclxuXHR7XHJcblx0ZGlzcGxheTpub25lO1xyXG5cdH1cclxufVxyXG5pb24tY29udGVudFxyXG57ICAgIC0tYmFja2dyb3VuZDogI2Y3ZjdmNztcclxuaW9uLWZhYiB7XHJcbiAgICBib3R0b206IDNweDtcclxuICAgIHJpZ2h0OiA0cHg7IFxyXG59XHJcbmlvbi1pdGVtXHJcblx0ey0tcGFkZGluZy1zdGFydDogMTBweDtcclxuICAgICAgIG1hcmdpbi10b3A6IDE1cHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxNXB4IDAgMTVweDtcclxuICAgIGJveC1zaGFkb3c6IDBweCAwcHggMTBweCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbiAgICBib3JkZXItbGVmdDogMnB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuICAgIC0taW5uZXItcGFkZGluZy1lbmQ6IDVweDtcclxuXHQgIGlvbi10aHVtYm5haWxcclxuXHQgIHtcclxuXHQgICAgICB3aWR0aDogNzBweDtcclxuICAgIGhlaWdodDogNzBweDtcclxuXHRpbWdcclxuXHR7XHJcblx0ICAgIHdpZHRoOiA3MHB4O1xyXG4gICAgaGVpZ2h0OiA3MHB4O1xyXG5cdGJvcmRlci1yYWRpdXM6OHB4O1xyXG5cdH1cclxuXHQgIH1cclxuXHQgIGlvbi1sYWJlbFxyXG5cdCAge1xyXG5cdCAgIG1hcmdpbi1sZWZ0OiAxNXB4O1xyXG5cdCAgIGgyXHJcblx0ICAge1xyXG5cdCAgIG1hcmdpbi1ib3R0b206IDVweDtcclxuXHQgICB9XHJcblx0ICAgcFxyXG5cdCAgIHtcclxuXHQgICBzcGFuXHJcblx0ICAge21hcmdpbi1yaWdodDoxMHB4O1xyXG5cdCAgIGZvbnQtc2l6ZToxNHB4O1xyXG5cdCAgIGlvbi1pY29uXHJcblx0ICAge21hcmdpbi1yaWdodDozcHg7XHJcblx0ICAgY29sb3I6dmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG5cdCAgIH1cclxuXHQgICB9XHJcblx0ICAgfVxyXG5cdCAgfVxyXG5cdH1cclxufSJdfQ== */");

/***/ }),

/***/ "./src/app/searchteam/searchteam.page.ts":
/*!***********************************************!*\
  !*** ./src/app/searchteam/searchteam.page.ts ***!
  \***********************************************/
/*! exports provided: SearchteamPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchteamPage", function() { return SearchteamPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/api/api.service */ "./src/app/services/api/api.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../config */ "./src/app/config.ts");
/* harmony import */ var _common_common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../common/common.service */ "./src/app/common/common.service.ts");






let SearchteamPage = class SearchteamPage {
    constructor(api, router, common) {
        this.api = api;
        this.router = router;
        this.common = common;
        this.IMAGES_URL = _config__WEBPACK_IMPORTED_MODULE_4__["config"].IMAGES_URL;
        this.errors = ['', null, undefined];
        this.teams = [];
        this.timeout = null;
    }
    ngOnInit() {
    }
    search_keyword(event) {
        clearTimeout(this.timeout);
        var self = this;
        this.timeout = setTimeout(function () {
            if (self.errors.indexOf(event.target.value) == -1) {
                self.search_text = event.target.value;
                self.save1();
            }
            else {
                self.search_text = event.target.value;
                self.save1();
            }
        }, 500);
    }
    save1() {
        let dict = {
            text: this.search_text
        };
        //this.common.presentLoading();
        this.api.post('SearchTeams', dict, '').subscribe((result) => {
            //this.common.stopLoading();
            var res;
            res = result;
            if (res.status == 1) {
                this.teams = res.data;
                //this.common.presentToast('Teams fetched successfully !.','success');
            }
            else {
                //this.common.presentToast(res.message,'danger');
                this.teams = [];
            }
        }, err => {
        });
    }
    ionViewDidEnter() {
        this.userid = localStorage.getItem('userid');
        this.getallteams();
    }
    getallteams() {
        this.common.presentLoading();
        this.api.post('GetAllTeams', '', '').subscribe((result) => {
            this.common.stopLoading();
            var res;
            res = result;
            if (res.status == 1) {
                this.teams = res.data;
                this.common.presentToast('Teams fetched successfully !.', 'success');
            }
            else {
                this.common.presentToast(res.message, 'danger');
                this.teams = [];
            }
        }, err => {
        });
    }
};
SearchteamPage.ctorParameters = () => [
    { type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _common_common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"] }
];
SearchteamPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-searchteam',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./searchteam.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/searchteam/searchteam.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./searchteam.page.scss */ "./src/app/searchteam/searchteam.page.scss")).default]
    })
], SearchteamPage);



/***/ })

}]);
//# sourceMappingURL=searchteam-searchteam-module-es2015.js.map