(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["activitydetail-activitydetail-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/activitydetail/activitydetail.page.html":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/activitydetail/activitydetail.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n\t<ion-back-button defaultHref=\"/tabs/tribes\" slot=\"start\">\r\n\t</ion-back-button>\r\n\t<ion-title class=\"ion-text-center\">Activity Detail</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n<ion-content>\r\n<div detailbanner>\r\n<img src=\"{{IMAGES_URL}}/{{activity?.image}}\"/>\r\n</div>\r\n\r\n<div detailcontent class=\"ion-padding\">\r\n<h2>{{activity?.title}}</h2>\r\n<h5>{{activity?.meals}} meals</h5>\r\n <ion-note><ion-icon name=\"calendar-outline\"></ion-icon> {{activity?.created_at | date : 'd MMM'}}</ion-note>\r\n<p>{{activity?.description}}</p>\r\n\r\n  <ion-button shape=\"round\" expand=\"full\" (click)=\"give(activity?.id)\">Give Now</ion-button>\r\n</div>\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/activitydetail/activitydetail-routing.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/activitydetail/activitydetail-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: ActivitydetailPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ActivitydetailPageRoutingModule", function() { return ActivitydetailPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _activitydetail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./activitydetail.page */ "./src/app/activitydetail/activitydetail.page.ts");




const routes = [
    {
        path: '',
        component: _activitydetail_page__WEBPACK_IMPORTED_MODULE_3__["ActivitydetailPage"]
    }
];
let ActivitydetailPageRoutingModule = class ActivitydetailPageRoutingModule {
};
ActivitydetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ActivitydetailPageRoutingModule);



/***/ }),

/***/ "./src/app/activitydetail/activitydetail.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/activitydetail/activitydetail.module.ts ***!
  \*********************************************************/
/*! exports provided: ActivitydetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ActivitydetailPageModule", function() { return ActivitydetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _activitydetail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./activitydetail-routing.module */ "./src/app/activitydetail/activitydetail-routing.module.ts");
/* harmony import */ var _activitydetail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./activitydetail.page */ "./src/app/activitydetail/activitydetail.page.ts");







let ActivitydetailPageModule = class ActivitydetailPageModule {
};
ActivitydetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _activitydetail_routing_module__WEBPACK_IMPORTED_MODULE_5__["ActivitydetailPageRoutingModule"]
        ],
        declarations: [_activitydetail_page__WEBPACK_IMPORTED_MODULE_6__["ActivitydetailPage"]]
    })
], ActivitydetailPageModule);



/***/ }),

/***/ "./src/app/activitydetail/activitydetail.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/activitydetail/activitydetail.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-toolbar {\n  --ion-color-base: var(--ion-color-bggradient)!important;\n  --border-width: 0;\n}\nion-header ion-toolbar ion-title {\n  color: var(--ion-color-white);\n  text-align: center;\n  font-style: normal;\n  font-family: \"Poppins\", sans-serif !important;\n}\nion-header::after {\n  display: none;\n}\nion-content [detailbanner] {\n  position: relative;\n  z-index: 1;\n  height: 225px;\n}\nion-content [detailbanner] img {\n  height: 225px;\n  width: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n  border-radius: 0px 0px 25px 25px;\n}\nion-content [detailbanner]:after {\n  content: \"\";\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  padding: 0;\n  background: var(--ion-color-black);\n  opacity: 0.5;\n  display: inline-block;\n  position: absolute;\n  z-index: 1;\n  border-radius: 0px 0px 25px 25px;\n}\nion-content [detailcontent] ion-note {\n  color: #bbb;\n  font-size: 14px;\n}\nion-content [detailcontent] h2 {\n  margin-bottom: 0;\n  font-size: 20px;\n  margin-top: 0;\n  font-weight: 600;\n}\nion-content [detailcontent] p {\n  font-size: 14px;\n  color: #666;\n  font-weight: 300;\n}\nion-content [detailcontent] h3 {\n  font-size: 14px;\n}\nion-content [detailcontent] ion-button {\n  margin-top: 30px;\n  --box-shadow: none;\n  min-height: 42px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWN0aXZpdHlkZXRhaWwvYWN0aXZpdHlkZXRhaWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdHO0VBQ0MsdURBQUE7RUFDRCxpQkFBQTtBQUZIO0FBSUk7RUFDQSw2QkFBQTtFQUNBLGtCQUFBO0VBQ1Esa0JBQUE7RUFDQSw2Q0FBQTtBQUZaO0FBS0M7RUFFQSxhQUFBO0FBSkQ7QUFTQTtFQUVJLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLGFBQUE7QUFQSjtBQVFDO0VBQ0csYUFBQTtFQUNBLFdBQUE7RUFDQSxvQkFBQTtLQUFBLGlCQUFBO0VBQ0EsZ0NBQUE7QUFOSjtBQVFFO0VBQ0YsV0FBQTtFQUNJLE9BQUE7RUFDQSxRQUFBO0VBQ0EsTUFBQTtFQUNBLFNBQUE7RUFDQSxVQUFBO0VBQ0Esa0NBQUE7RUFDQSxZQUFBO0VBQ0EscUJBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxnQ0FBQTtBQU5KO0FBV0U7RUFDTSxXQUFBO0VBQ04sZUFBQTtBQVRGO0FBV0E7RUFDSyxnQkFBQTtFQUNELGVBQUE7RUFDQSxhQUFBO0VBQ0EsZ0JBQUE7QUFUSjtBQVdDO0VBQ0UsZUFBQTtFQUNDLFdBQUE7RUFDQSxnQkFBQTtBQVRKO0FBV0E7RUFFQSxlQUFBO0FBVkE7QUFZQTtFQUNFLGdCQUFBO0VBQ0csa0JBQUE7RUFDRCxnQkFBQTtBQVZKIiwiZmlsZSI6InNyYy9hcHAvYWN0aXZpdHlkZXRhaWwvYWN0aXZpdHlkZXRhaWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlclxyXG57XHJcblx0XHJcblx0ICBpb24tdG9vbGJhclxyXG5cdCAgey0taW9uLWNvbG9yLWJhc2U6IHZhcigtLWlvbi1jb2xvci1iZ2dyYWRpZW50KSFpbXBvcnRhbnQ7XHJcblx0ICAtLWJvcmRlci13aWR0aDogMDtcclxuXHRcclxuXHRcdCAgaW9uLXRpdGxle1xyXG5cdFx0ICBjb2xvcjp2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdFx0ICB0ZXh0LWFsaWduOmNlbnRlcjtcclxuICAgICAgICAgICAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gICAgICAgICAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgfVxyXG5cdH1cclxuXHQmOjphZnRlclxyXG5cdHtcclxuXHRkaXNwbGF5Om5vbmU7XHJcblx0fVxyXG59XHJcbmlvbi1jb250ZW50XHJcbntcclxuW2RldGFpbGJhbm5lcl1cclxue1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgei1pbmRleDogMTtcclxuICAgIGhlaWdodDogMjI1cHg7XHJcbiBpbWcge1xyXG4gICAgaGVpZ2h0OiAyMjVweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgb2JqZWN0LWZpdDogY292ZXI7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwcHggMHB4IDI1cHggMjVweDtcclxufVxyXG4gICY6YWZ0ZXJ7XHJcbmNvbnRlbnQ6IFwiXCI7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICB0b3A6IDA7XHJcbiAgICBib3R0b206IDA7XHJcbiAgICBwYWRkaW5nOiAwO1xyXG4gICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWJsYWNrKTtcclxuICAgIG9wYWNpdHk6IDAuNTtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHotaW5kZXg6IDE7XHJcbiAgICBib3JkZXItcmFkaXVzOiAwcHggMHB4IDI1cHggMjVweDtcclxuICAgICAgICAgICAgICAgIH1cclxuXHJcbn1cclxuW2RldGFpbGNvbnRlbnRdXHJcbnsgaW9uLW5vdGVcclxuXHQgIHsgICAgY29sb3I6ICNiYmI7XHJcblx0IGZvbnQtc2l6ZTogMTRweDsgXHJcblx0ICB9XHJcbmgyXHJcbnsgICAgbWFyZ2luLWJvdHRvbTogMDtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIG1hcmdpbi10b3A6IDA7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG59XHJcblx0cCB7XHJcbiAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGNvbG9yOiAjNjY2O1xyXG4gICAgZm9udC13ZWlnaHQ6IDMwMDtcclxufVxyXG5oM1xyXG57XHJcbmZvbnQtc2l6ZToxNHB4O1xyXG59XHJcbmlvbi1idXR0b25cclxuXHR7bWFyZ2luLXRvcDogMzBweDtcclxuXHQgICAgLS1ib3gtc2hhZG93OiBub25lO1xyXG4gICAgbWluLWhlaWdodDogNDJweDtcclxuXHR9XHJcblxyXG59XHJcbn0iXX0= */");

/***/ }),

/***/ "./src/app/activitydetail/activitydetail.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/activitydetail/activitydetail.page.ts ***!
  \*******************************************************/
/*! exports provided: ActivitydetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ActivitydetailPage", function() { return ActivitydetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/api/api.service */ "./src/app/services/api/api.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../config */ "./src/app/config.ts");
/* harmony import */ var _common_common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../common/common.service */ "./src/app/common/common.service.ts");
/* harmony import */ var _addamount_addamount_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../addamount/addamount.page */ "./src/app/addamount/addamount.page.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _services_globalFooService_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../services/globalFooService.service */ "./src/app/services/globalFooService.service.ts");









let ActivitydetailPage = class ActivitydetailPage {
    constructor(globalFooService, modalController, activatedRoute, api, router, common) {
        this.globalFooService = globalFooService;
        this.modalController = modalController;
        this.activatedRoute = activatedRoute;
        this.api = api;
        this.router = router;
        this.common = common;
        this.IMAGES_URL = _config__WEBPACK_IMPORTED_MODULE_4__["config"].IMAGES_URL;
        this.errors = ['', null, undefined];
        this.activityid = activatedRoute.snapshot.paramMap.get('id');
        this.globalFooService.getObservable().subscribe((data) => {
            if (this.errors.indexOf(data.paydata) == -1) {
                this.getactivitydetails();
            }
        });
    }
    give(id) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _addamount_addamount_page__WEBPACK_IMPORTED_MODULE_6__["AddamountPage"],
                cssClass: 'leaveteam',
                componentProps: {
                    actid: id,
                }
            });
            modal.onDidDismiss().then((detail) => {
                if (this.errors.indexOf(detail.data) == -1) {
                    //this.team.joins=this.team.joins - 1;
                    //this.getuserteams();
                }
            });
            return yield modal.present();
        });
    }
    ngOnInit() {
    }
    ionViewDidEnter() {
        this.getactivitydetails();
    }
    getactivitydetails() {
        let dict = {
            id: this.activityid,
        };
        this.common.presentLoading();
        this.api.post('activitydetail', dict, '').subscribe((result) => {
            this.common.stopLoading();
            var res;
            res = result;
            if (res.status == 1) {
                this.activity = res.data;
            }
            else {
            }
        }, err => {
        });
    }
};
ActivitydetailPage.ctorParameters = () => [
    { type: _services_globalFooService_service__WEBPACK_IMPORTED_MODULE_8__["GlobalFooService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _common_common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"] }
];
ActivitydetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-activitydetail',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./activitydetail.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/activitydetail/activitydetail.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./activitydetail.page.scss */ "./src/app/activitydetail/activitydetail.page.scss")).default]
    })
], ActivitydetailPage);



/***/ })

}]);
//# sourceMappingURL=activitydetail-activitydetail-module-es2015.js.map