(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home2-home2-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/home2/home2.page.html":
    /*!*****************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home2/home2.page.html ***!
      \*****************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppHome2Home2PageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<!--ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>home</ion-title>\r\n  </ion-toolbar>\r\n</ion-header-->\r\n\r\n<ion-content home-page>\r\n     <ion-header>\r\n      <ion-toolbar>\r\n        <ion-buttons slot=\"start\">\r\n          <ion-menu-button></ion-menu-button>\r\n        </ion-buttons>\r\n        <ion-title>Goals</ion-title>\r\n\t\t<!--ion-buttons mr-10 (click)=\"presentModal()\" slot=\"end\">\r\n\t\t  <img height=\"22px\" src=\"assets/images/jar.png\"/>\r\n\t\t</ion-buttons-->\r\n      </ion-toolbar>\r\n\t  </ion-header>\r\n      <ion-slides #slideWithNav [options]=\"slideOptsOne\"  (ionSlideWillChange)=\"onSlideChangeStart($event)\" (ionSlideDidChange)=\"onSlideChanged($event)\" pager=\"true\" class=\"home-slider\">\r\n    \r\n    <ion-slide  hm-slider>\r\n      <img src=\"assets/images/sliderimg1.jpg\" style=\"width:100%;\"/>\r\n      <div class=\"sld_cnt\">\r\n        <div>\r\n        <h3 routerLink=\"/charitydetail\">Feed Children Around World</h3>\r\n        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry....</p>\r\n\t\t<ion-row>\r\n\t\t<!--><ion-col size=\"6\">\r\n        <ion-button shape=\"round\">Give Now</ion-button>\r\n\t\t</ion-col></-->\r\n\t\t<ion-col size=\"12\" class=\"ion-no-padding\">\r\n\t\t<p class=\"ion-text-left\"><b>5000 Meals</b></p>\r\n\t\t</ion-col>\r\n\t\t</ion-row>\r\n      </div>\r\n      </div>\r\n    </ion-slide>\r\n    <ion-slide  hm-slider>\r\n      <img src=\"assets/images/sliderimg2.png\" style=\"width:100%;\"/>\r\n      <div class=\"sld_cnt\">\r\n        <div>\r\n        <h3 routerLink=\"/charitydetail\">Feed Children Around World</h3>\r\n        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry....</p>\r\n        \t<ion-row>\r\n\t\t<!--><ion-col size=\"6\">\r\n        <ion-button shape=\"round\">Give Now</ion-button>\r\n\t\t</ion-col></-->\r\n\t\t<ion-col size=\"12\" class=\"ion-no-padding\">\r\n\t\t<p class=\"ion-text-left\"><b>5000 Meals</b></p>\r\n\t\t</ion-col>\r\n\t\t</ion-row>\r\n\t\t\r\n      </div>\r\n      </div>\r\n    </ion-slide>\r\n    <ion-slide  hm-slider>\r\n      <img src=\"assets/images/sliderimg3.jpg\" style=\"width:100%;\"/>\r\n      <div class=\"sld_cnt\">\r\n        <div>\r\n        <h3 routerLink=\"/charitydetail\">Feed Children Around World</h3>\r\n        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry....</p>\r\n     \t<ion-row>\r\n\t\t<!--><ion-col size=\"6\">\r\n        <ion-button shape=\"round\">Give Now</ion-button>\r\n\t\t</ion-col></-->\r\n\t\t<ion-col size=\"12\" class=\"ion-no-padding\">\r\n\t\t<p class=\"ion-text-left\"><b>5000 Meals</b></p>\r\n\t\t</ion-col>\r\n\t\t</ion-row>\r\n      </div>\r\n      </div>\r\n\t   \r\n    </ion-slide>\r\n    \r\n  </ion-slides>\r\n<ion-row>\r\n\r\n\r\n  <ion-col size=\"12\" class=\"ion-padding-start ion-padding-end\"> \r\n    <div class=\"donationjar\">\r\n      <h3><span>Donation</span> Jar</h3>\r\n  \r\n\t  <div donationimg>\r\n\t   <img src=\"assets/images/donationjar1.png\"/>\r\n\t  </div>\r\n     <p>Please press button below to donate 25 cents</p>\r\n<ion-button  expand=\"full\" shape=\"round\" class=\"btn-losns\">Give Now</ion-button>\r\n<span>To Donate More <a href=\"javasctipt:void(0)\">Click Here</a> </span>     \r\n    </div>\r\n  </ion-col>\r\n</ion-row>\r\n\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "./src/app/home2/home2-routing.module.ts":
    /*!***********************************************!*\
      !*** ./src/app/home2/home2-routing.module.ts ***!
      \***********************************************/

    /*! exports provided: Home2PageRoutingModule */

    /***/
    function srcAppHome2Home2RoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Home2PageRoutingModule", function () {
        return Home2PageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _home2_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./home2.page */
      "./src/app/home2/home2.page.ts");

      var routes = [{
        path: '',
        component: _home2_page__WEBPACK_IMPORTED_MODULE_3__["Home2Page"]
      }];

      var Home2PageRoutingModule = function Home2PageRoutingModule() {
        _classCallCheck(this, Home2PageRoutingModule);
      };

      Home2PageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], Home2PageRoutingModule);
      /***/
    },

    /***/
    "./src/app/home2/home2.module.ts":
    /*!***************************************!*\
      !*** ./src/app/home2/home2.module.ts ***!
      \***************************************/

    /*! exports provided: Home2PageModule */

    /***/
    function srcAppHome2Home2ModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Home2PageModule", function () {
        return Home2PageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _home2_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./home2-routing.module */
      "./src/app/home2/home2-routing.module.ts");
      /* harmony import */


      var _home2_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./home2.page */
      "./src/app/home2/home2.page.ts");

      var Home2PageModule = function Home2PageModule() {
        _classCallCheck(this, Home2PageModule);
      };

      Home2PageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _home2_routing_module__WEBPACK_IMPORTED_MODULE_5__["Home2PageRoutingModule"]],
        declarations: [_home2_page__WEBPACK_IMPORTED_MODULE_6__["Home2Page"]]
      })], Home2PageModule);
      /***/
    },

    /***/
    "./src/app/home2/home2.page.scss":
    /*!***************************************!*\
      !*** ./src/app/home2/home2.page.scss ***!
      \***************************************/

    /*! exports provided: default */

    /***/
    function srcAppHome2Home2PageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "[home-page] {\n  margin: 0 10px !important;\n  --background: #f3f3f3;\n}\n[home-page] ion-header {\n  position: absolute;\n}\n[home-page] ion-header ion-toolbar {\n  --background: transparent;\n  --border-width: 0;\n}\n[home-page] ion-header ion-toolbar ion-buttons {\n  color: var(--ion-color-white);\n}\n[home-page] ion-header ion-toolbar ion-buttons[mr-10] {\n  margin-right: 10px;\n}\n[home-page] ion-header ion-toolbar ion-title {\n  color: var(--ion-color-white);\n  text-align: center;\n  font-style: normal;\n  font-family: \"Poppins\", sans-serif !important;\n}\n[home-page] ion-header::after {\n  display: none;\n}\n[home-page] .home-slider [hm-slider] {\n  --bullet-background:#dcdcdc;\n  --bullet-background-active:var(--ion-color-primary);\n  display: block;\n  text-align: left;\n  border-radius: 0px 0px 20px 20px;\n  overflow: hidden;\n}\n[home-page] .home-slider [hm-slider] img {\n  border-radius: 0px 0px 20px 20px;\n  height: 65vh;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n[home-page] .home-slider [hm-slider] .sld_cnt {\n  position: absolute;\n  left: 0;\n  right: 0;\n  bottom: 7px;\n  top: 0;\n  background: rgba(0, 0, 0, 0.6);\n  color: var(--ion-color-white);\n  padding: 25px 25px 40px 25px;\n  display: flex;\n  align-items: flex-end;\n  border-radius: 0 0 20px 20px;\n}\n[home-page] .home-slider [hm-slider] .sld_cnt h3 {\n  font-size: 16px;\n}\n[home-page] .home-slider [hm-slider] .sld_cnt p {\n  font-size: 12px;\n  color: var(--ion-color-white);\n  margin: 5px 0px 0px;\n}\n[home-page] .home-slider [hm-slider] .sld_cnt ion-button {\n  font-size: 12px;\n  --padding-start: 30px;\n  --padding-end: 25px;\n  letter-spacing: 0.7px;\n  --background:var(--ion-color-primary);\n  margin: 0;\n}\n[home-page] .home-slider .swiper-pagination {\n  --scroll-bar-background: red;\n}\n[home-page] .donationjar {\n  padding: 15px 10px 5px;\n  border-radius: 10px;\n  background-color: var(--ion-color-white);\n  position: relative;\n  color: var(--ion-color-black);\n  text-align: center;\n  margin-bottom: 10px;\n}\n[home-page] .donationjar [donationimg] {\n  margin: 5px 0px;\n}\n[home-page] .donationjar [donationimg] img {\n  max-width: 120px;\n}\n[home-page] .donationjar h3 {\n  margin: 0;\n  font-weight: 600;\n  display: inline-block;\n  font-size: 18px;\n}\n[home-page] .donationjar h3 span {\n  position: relative;\n  z-index: 1;\n}\n[home-page] .donationjar h3 span:after {\n  content: \"\";\n  height: 4px;\n  width: 100%;\n  background: var(--ion-color-softgreen);\n  /*opacity:.5;*/\n  display: inline-block;\n  position: absolute;\n  bottom: 5px;\n  left: 0;\n  z-index: -1;\n}\n[home-page] .donationjar p {\n  color: rgba(0, 0, 0, 0.5);\n  font-size: 13px;\n}\n[home-page] .donationjar span {\n  font-size: 14px;\n  line-height: 22px;\n  font-weight: 300;\n  color: #adadad;\n  margin-top: 10px;\n  display: block;\n  text-align: center;\n}\n[home-page] .donationjar .btn-losns {\n  --background:var( --ion-color-primary);\n  margin-top: 20px;\n  --box-shadow: none;\n  min-height: 48px;\n  margin-bottom: 15px;\n  text-transform: uppercase;\n  letter-spacing: 1px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZTIvaG9tZTIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kseUJBQUE7RUFDQSxxQkFBQTtBQUNKO0FBQUE7RUFFRyxrQkFBQTtBQUNIO0FBQUc7RUFDQyx5QkFBQTtFQUEwQixpQkFBQTtBQUc5QjtBQUZHO0VBRUMsNkJBQUE7QUFHSjtBQUZJO0VBRUEsa0JBQUE7QUFHSjtBQUFJO0VBQ0EsNkJBQUE7RUFDQSxrQkFBQTtFQUNRLGtCQUFBO0VBQ0EsNkNBQUE7QUFFWjtBQUNDO0VBRUEsYUFBQTtBQUFEO0FBTUk7RUFDSSwyQkFBQTtFQUNBLG1EQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsZ0NBQUE7RUFDQSxnQkFBQTtBQUpSO0FBTVE7RUFDSCxnQ0FBQTtFQUNGLFlBQUE7RUFDQSxvQkFBQTtLQUFBLGlCQUFBO0FBSkg7QUFNUTtFQUNJLGtCQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxXQUFBO0VBQ0EsTUFBQTtFQUNBLDhCQUFBO0VBQ0EsNkJBQUE7RUFDQSw0QkFBQTtFQUNBLGFBQUE7RUFDQSxxQkFBQTtFQUNBLDRCQUFBO0FBSlo7QUFLWTtFQUNJLGVBQUE7QUFIaEI7QUFLWTtFQUNJLGVBQUE7RUFDQSw2QkFBQTtFQUNBLG1CQUFBO0FBSGhCO0FBS1k7RUFDSSxlQUFBO0VBQ0EscUJBQUE7RUFDQSxtQkFBQTtFQUNBLHFCQUFBO0VBQ0EscUNBQUE7RUFDQSxTQUFBO0FBSGhCO0FBVUE7RUFDSSw0QkFBQTtBQVJKO0FBU0M7RUFDUSxzQkFBQTtFQUNELG1CQUFBO0VBQ0Esd0NBQUE7RUFDQSxrQkFBQTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7RUFDTixtQkFBQTtBQVBGO0FBUUU7RUFDSyxlQUFBO0FBTlA7QUFPRTtFQUVDLGdCQUFBO0FBTkg7QUFTUTtFQUNJLFNBQUE7RUFDQSxnQkFBQTtFQUNBLHFCQUFBO0VBQ0EsZUFBQTtBQVBaO0FBUVk7RUFDSSxrQkFBQTtFQUNaLFVBQUE7QUFOSjtBQU9nQjtFQUNJLFdBQUE7RUFDQSxXQUFBO0VBQ0EsV0FBQTtFQUNBLHNDQUFBO0VBQ2YsY0FBQTtFQUNlLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsT0FBQTtFQUNBLFdBQUE7QUFMcEI7QUFTUTtFQUNJLHlCQUFBO0VBQ0EsZUFBQTtBQVBaO0FBU0M7RUFDRSxlQUFBO0VBQ0MsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtBQVBKO0FBVUU7RUFDQyxzQ0FBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDUyxnQkFBQTtFQUNULG1CQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtBQVJIIiwiZmlsZSI6InNyYy9hcHAvaG9tZTIvaG9tZTIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiW2hvbWUtcGFnZV17XHJcbiAgICBtYXJnaW46IDAgMTBweCAhaW1wb3J0YW50O1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjZjNmM2YzO1xyXG5pb24taGVhZGVyXHJcblx0e1xyXG5cdCAgcG9zaXRpb246YWJzb2x1dGU7XHJcblx0ICBpb24tdG9vbGJhclxyXG5cdCAgey0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7LS1ib3JkZXItd2lkdGg6IDA7XHJcblx0ICBpb24tYnV0dG9uc1xyXG5cdCAge1xyXG5cdCAgIGNvbG9yOnZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcblx0ICAgJlttci0xMF1cclxuXHQgICB7XHJcblx0ICAgbWFyZ2luLXJpZ2h0OjEwcHg7XHJcblx0ICAgfVxyXG5cdCAgfVxyXG5cdFx0ICBpb24tdGl0bGV7XHJcblx0XHQgIGNvbG9yOnZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcblx0XHQgIHRleHQtYWxpZ246Y2VudGVyO1xyXG4gICAgICAgICAgICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcclxuICAgICAgICB9XHJcblx0fVxyXG5cdCY6OmFmdGVyXHJcblx0e1xyXG5cdGRpc3BsYXk6bm9uZTtcclxuXHR9XHJcblx0fVxyXG5cclxuICAgIC5ob21lLXNsaWRlcntcclxuICAgICAgICBcclxuICAgIFtobS1zbGlkZXJde1xyXG4gICAgICAgIC0tYnVsbGV0LWJhY2tncm91bmQ6I2RjZGNkYztcclxuICAgICAgICAtLWJ1bGxldC1iYWNrZ3JvdW5kLWFjdGl2ZTp2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbiAgICAgICAgZGlzcGxheTpibG9jaztcclxuICAgICAgICB0ZXh0LWFsaWduOmxlZnQ7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogMHB4IDBweCAyMHB4IDIwcHg7XHJcbiAgICAgICAgb3ZlcmZsb3c6aGlkZGVuO1xyXG4gICAgICAgIFxyXG4gICAgICAgIGltZ3tcclxuXHRcdCAgIGJvcmRlci1yYWRpdXM6IDBweCAwcHggMjBweCAyMHB4O1xyXG5cdFx0XHRoZWlnaHQ6IDY1dmg7XHJcblx0XHRcdG9iamVjdC1maXQ6IGNvdmVyO1xyXG4gICAgICAgIH1cclxuICAgICAgICAuc2xkX2NudHtcclxuICAgICAgICAgICAgcG9zaXRpb246YWJzb2x1dGU7XHJcbiAgICAgICAgICAgIGxlZnQ6MDtcclxuICAgICAgICAgICAgcmlnaHQ6MDtcclxuICAgICAgICAgICAgYm90dG9tOjdweDtcclxuICAgICAgICAgICAgdG9wOjA7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6cmdiYSgwLDAsMCwwLjYwKTtcclxuICAgICAgICAgICAgY29sb3I6dmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgICAgICAgICAgcGFkZGluZzoyNXB4IDI1cHggNDBweCAyNXB4IDtcclxuICAgICAgICAgICAgZGlzcGxheTpmbGV4O1xyXG4gICAgICAgICAgICBhbGlnbi1pdGVtczpmbGV4LWVuZDtcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czowIDAgMjBweCAyMHB4O1xyXG4gICAgICAgICAgICBoM3tcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZToxNnB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHB7XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6MTJweDtcclxuICAgICAgICAgICAgICAgIGNvbG9yOnZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW46IDVweCAwcHggMHB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlvbi1idXR0b257XHJcbiAgICAgICAgICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgICAgICAgICAgICAtLXBhZGRpbmctc3RhcnQ6IDMwcHg7XHJcbiAgICAgICAgICAgICAgICAtLXBhZGRpbmctZW5kOiAyNXB4O1xyXG4gICAgICAgICAgICAgICAgbGV0dGVyLXNwYWNpbmc6IDAuN3B4O1xyXG4gICAgICAgICAgICAgICAgLS1iYWNrZ3JvdW5kOnZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuICAgICAgICAgICAgICAgIG1hcmdpbjogMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgIH1cclxuICAgXHJcbn1cclxuLmhvbWUtc2xpZGVyIC5zd2lwZXItcGFnaW5hdGlvbiB7XHJcbiAgICAtLXNjcm9sbC1iYXItYmFja2dyb3VuZDogcmVkO1xyXG59LmRvbmF0aW9uamFye1xyXG4gICAgICAgICBwYWRkaW5nOjE1cHggMTBweCAgNXB4O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6MTBweDtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOnZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcbiAgICAgICAgcG9zaXRpb246cmVsYXRpdmU7XHJcbiAgICAgICAgY29sb3I6dmFyKC0taW9uLWNvbG9yLWJsYWNrKTtcclxuICAgICAgICB0ZXh0LWFsaWduOmNlbnRlcjtcclxuXHRcdG1hcmdpbi1ib3R0b206MTBweDtcclxuXHRcdFtkb25hdGlvbmltZ11cclxuXHRcdHsgICAgbWFyZ2luOiA1cHggMHB4O1xyXG5cdFx0aW1nXHJcblx0XHR7XHJcblx0XHQgbWF4LXdpZHRoOiAxMjBweDtcclxuXHRcdH1cclxuXHRcdH1cclxuICAgICAgICBoM3tcclxuICAgICAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZToxOHB4O1xyXG4gICAgICAgICAgICBzcGFue1xyXG4gICAgICAgICAgICAgICAgcG9zaXRpb246cmVsYXRpdmU7XHJcblx0XHRcdFx0ei1pbmRleDoxO1xyXG4gICAgICAgICAgICAgICAgJjphZnRlcntcclxuICAgICAgICAgICAgICAgICAgICBjb250ZW50OiBcIlwiO1xyXG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogNHB4O1xyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1zb2Z0Z3JlZW4pO1xyXG5cdFx0XHRcdFx0LypvcGFjaXR5Oi41OyovXHJcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICAgICAgICAgICAgICBib3R0b206IDVweDtcclxuICAgICAgICAgICAgICAgICAgICBsZWZ0OiAwO1xyXG4gICAgICAgICAgICAgICAgICAgIHotaW5kZXg6IC0xO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHB7XHJcbiAgICAgICAgICAgIGNvbG9yOiByZ2JhKDAsIDAsIDAgLCAwLjUwKTtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAgIH1cclxuIHNwYW5cclxuICB7Zm9udC1zaXplOiAxNHB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDIycHg7XHJcbiAgICBmb250LXdlaWdodDogMzAwO1xyXG4gICAgY29sb3I6ICNhZGFkYWQ7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgXHJcbiAgfVxyXG5cdFx0LmJ0bi1sb3Nuc3tcclxuXHRcdFx0LS1iYWNrZ3JvdW5kOnZhciggLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcblx0XHRcdG1hcmdpbi10b3A6IDIwcHg7XHJcblx0XHRcdC0tYm94LXNoYWRvdzogbm9uZTtcclxuICAgICAgICAgICAgbWluLWhlaWdodDogNDhweDtcclxuXHRcdFx0bWFyZ2luLWJvdHRvbTogMTVweDtcclxuXHRcdFx0dGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcclxuXHRcdFx0bGV0dGVyLXNwYWNpbmc6IDFweDtcclxuXHRcdH1cdFx0XHJcbiAgICB9XHJcbn0iXX0= */";
      /***/
    },

    /***/
    "./src/app/home2/home2.page.ts":
    /*!*************************************!*\
      !*** ./src/app/home2/home2.page.ts ***!
      \*************************************/

    /*! exports provided: Home2Page */

    /***/
    function srcAppHome2Home2PageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "Home2Page", function () {
        return Home2Page;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _donationjar_donationjar_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../donationjar/donationjar.page */
      "./src/app/donationjar/donationjar.page.ts");

      var Home2Page = /*#__PURE__*/function () {
        function Home2Page(modalController) {
          _classCallCheck(this, Home2Page);

          this.modalController = modalController;
          this.slideOptsOne = {
            initialSlide: 0,
            slidesPerView: 1,
            autoplay: true
          };
        }

        _createClass(Home2Page, [{
          key: "presentModal",
          value: function presentModal() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var modal;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.modalController.create({
                        component: _donationjar_donationjar_page__WEBPACK_IMPORTED_MODULE_3__["DonationjarPage"],
                        cssClass: 'my-custom-class'
                      });

                    case 2:
                      modal = _context.sent;
                      _context.next = 5;
                      return modal.present();

                    case 5:
                      return _context.abrupt("return", _context.sent);

                    case 6:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return Home2Page;
      }();

      Home2Page.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
        }];
      };

      Home2Page = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-home2',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./home2.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/home2/home2.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./home2.page.scss */
        "./src/app/home2/home2.page.scss"))["default"]]
      })], Home2Page);
      /***/
    }
  }]);
})();
//# sourceMappingURL=home2-home2-module-es5.js.map