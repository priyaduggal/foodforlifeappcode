(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["edit-payment-edit-payment-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/edit-payment/edit-payment.page.html":
    /*!*******************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/edit-payment/edit-payment.page.html ***!
      \*******************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppEditPaymentEditPaymentPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\r\n      <ion-toolbar color=\"primary\">\r\n        <ion-back-button defaultHref=\"/tabs/settings\" slot=\"start\">\r\n        </ion-back-button>\r\n        <ion-title class=\"ion-text-center\">Edit Payment Method</ion-title>\r\n      </ion-toolbar>\r\n</ion-header>\r\n<ion-content class=\"ion-padding\">\r\n<div paymentimg class=\"ion-text-center\">\r\n<img src=\"assets/images/addpayment.jpg\"/>\r\n</div>\r\n<div formfield>\r\n\t\t\t\t<label>Card Holder Name</label>\r\n\t\t\t\t<ion-item lines=\"none\" class=\"fls\"> \r\n\t\t\t\t\t<ion-input placeholder=\"Enter Name\" [(ngModel)]=\"name\" name=\"name\" ></ion-input>\r\n\t\t\t\t</ion-item>\r\n\t\t\t\t<span error *ngIf=\"errors.indexOf(name) >= 0 && is_submit_payment == true\">Please enter card holder name</span>\r\n</div>\r\n<div formfield>\r\n\t\t\t\t<label>Card Number</label>\r\n\t\t\t\t<ion-item lines=\"none\" class=\"fls\"> \r\n\t\t\t\t\t<ion-input placeholder=\"Enter Card Number\" [(ngModel)]=\"card_number\" name=\"card_number\"></ion-input>\r\n\t\t\t\t</ion-item>\r\n\t\t\t\t<span error *ngIf=\"errors.indexOf(card_number) >= 0 && is_submit_payment == true\">Please enter card number</span>\r\n</div>\r\n<div formfield>\r\n\t\t\t\t<label>Expiration Date</label>\r\n\t\t\t\t<ion-item lines=\"none\" class=\"fls\"> \r\n\t\t\t\t<ion-datetime displayFormat=\"MM/YYYY\" placeholder=\"Select Date\" display-timezone=\"utc\"\r\n\t\t\t\t [(ngModel)]=\"exp_date\" name=\"exp_date\" min=\"2021\" max=\"2030\"></ion-datetime>\r\n\t\t\t\t</ion-item>\r\n\t\t\t\t <span error *ngIf=\"errors.indexOf(exp_date) >= 0 && is_submit_payment == true\">Please enter expiration date</span>\r\n\t\t\t\t\r\n</div>\r\n<div formfield>\r\n\t\t\t\t<label>CVC</label>\r\n\t\t\t\t<ion-item lines=\"none\" class=\"fls\"> \r\n\t\t\t\t\t<ion-input placeholder=\"Enter CVC\" [(ngModel)]=\"cvc\" name=\"cvc\"></ion-input>\r\n\t\t\t\t</ion-item>\r\n\t\t\t\t <span error *ngIf=\"errors.indexOf(cvc) >= 0 && is_submit_payment == true\">Please enter cvc</span>\r\n\t\t\t\r\n</div>\r\n<ion-button  expand=\"full\" shape=\"round\" class=\"btn-losns\" (click)=\"addcard()\">Update Payment Method</ion-button>\r\n\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "./src/app/edit-payment/edit-payment-routing.module.ts":
    /*!*************************************************************!*\
      !*** ./src/app/edit-payment/edit-payment-routing.module.ts ***!
      \*************************************************************/

    /*! exports provided: EditPaymentPageRoutingModule */

    /***/
    function srcAppEditPaymentEditPaymentRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "EditPaymentPageRoutingModule", function () {
        return EditPaymentPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _edit_payment_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./edit-payment.page */
      "./src/app/edit-payment/edit-payment.page.ts");

      var routes = [{
        path: '',
        component: _edit_payment_page__WEBPACK_IMPORTED_MODULE_3__["EditPaymentPage"]
      }];

      var EditPaymentPageRoutingModule = function EditPaymentPageRoutingModule() {
        _classCallCheck(this, EditPaymentPageRoutingModule);
      };

      EditPaymentPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], EditPaymentPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/edit-payment/edit-payment.module.ts":
    /*!*****************************************************!*\
      !*** ./src/app/edit-payment/edit-payment.module.ts ***!
      \*****************************************************/

    /*! exports provided: EditPaymentPageModule */

    /***/
    function srcAppEditPaymentEditPaymentModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "EditPaymentPageModule", function () {
        return EditPaymentPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _edit_payment_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./edit-payment-routing.module */
      "./src/app/edit-payment/edit-payment-routing.module.ts");
      /* harmony import */


      var _edit_payment_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./edit-payment.page */
      "./src/app/edit-payment/edit-payment.page.ts");

      var EditPaymentPageModule = function EditPaymentPageModule() {
        _classCallCheck(this, EditPaymentPageModule);
      };

      EditPaymentPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _edit_payment_routing_module__WEBPACK_IMPORTED_MODULE_5__["EditPaymentPageRoutingModule"]],
        declarations: [_edit_payment_page__WEBPACK_IMPORTED_MODULE_6__["EditPaymentPage"]]
      })], EditPaymentPageModule);
      /***/
    },

    /***/
    "./src/app/edit-payment/edit-payment.page.scss":
    /*!*****************************************************!*\
      !*** ./src/app/edit-payment/edit-payment.page.scss ***!
      \*****************************************************/

    /*! exports provided: default */

    /***/
    function srcAppEditPaymentEditPaymentPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-header ion-toolbar {\n  --ion-color-base: var(--ion-color-bggradient)!important;\n  --border-width: 0;\n}\nion-header ion-toolbar ion-title {\n  color: var(--ion-color-white);\n  text-align: center;\n  font-style: normal;\n  font-family: \"Poppins\", sans-serif !important;\n}\nion-header::after {\n  display: none;\n}\nion-content [paymentimg] img {\n  max-width: 250px;\n}\nion-content [formfield] {\n  position: relative;\n  border: 1px solid #e8e8e8;\n  height: 52px;\n  border-radius: 50px;\n  background: var(--ion-color-white);\n  padding: 0 16px;\n  margin-top: 20px;\n}\nion-content [formfield] label {\n  position: absolute;\n  top: -10px;\n  z-index: 111;\n  background: var(--ion-color-white);\n  left: 29px;\n  padding: 0 3px;\n  font-size: 12px;\n  font-weight: 700;\n  color: #3a3a3a;\n}\nion-content [formfield] ion-input, ion-content [formfield] ion-datetime {\n  padding: 0px;\n  --padding-start: 0px;\n  --padding-end: 0px;\n  font-size: 14px;\n  --placeholder-color: #9a9a9a;\n  --placeholder-opacity: 1;\n  font-family: \"Poppins\", sans-serif !important;\n  color: #222;\n}\nion-content .btn-losns {\n  --background:var( --ion-color-primary);\n  margin-top: 20px;\n  --box-shadow: none;\n  min-height: 48px;\n  margin-bottom: 15px;\n  text-transform: uppercase;\n  letter-spacing: 1px;\n}\n[span] {\n  margin-bottom: 15px !important;\n  color: red;\n  padding: 11px;\n  font-size: 12px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZWRpdC1wYXltZW50L2VkaXQtcGF5bWVudC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUc7RUFDQyx1REFBQTtFQUNELGlCQUFBO0FBREg7QUFHSTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7RUFDUSxrQkFBQTtFQUNBLDZDQUFBO0FBRFo7QUFJQztFQUVBLGFBQUE7QUFIRDtBQVVFO0VBRUUsZ0JBQUE7QUFSSjtBQVdBO0VBQ0csa0JBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGtDQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBVEg7QUFVRztFQUNDLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxrQ0FBQTtFQUNBLFVBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQVJKO0FBVUc7RUFDQyxZQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSw0QkFBQTtFQUNBLHdCQUFBO0VBQ0EsNkNBQUE7RUFDQSxXQUFBO0FBUko7QUFXRTtFQUNDLHNDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNTLGdCQUFBO0VBQ1QsbUJBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0FBVEg7QUFZQTtFQUVJLDhCQUFBO0VBQ0EsVUFBQTtFQUNBLGFBQUE7RUFDQSxlQUFBO0FBVkoiLCJmaWxlIjoic3JjL2FwcC9lZGl0LXBheW1lbnQvZWRpdC1wYXltZW50LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXJcclxuXHR7XHJcblx0ICBpb24tdG9vbGJhclxyXG5cdCAgey0taW9uLWNvbG9yLWJhc2U6IHZhcigtLWlvbi1jb2xvci1iZ2dyYWRpZW50KSFpbXBvcnRhbnQ7XHJcblx0ICAtLWJvcmRlci13aWR0aDogMDtcclxuXHRcclxuXHRcdCAgaW9uLXRpdGxle1xyXG5cdFx0ICBjb2xvcjp2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdFx0ICB0ZXh0LWFsaWduOmNlbnRlcjtcclxuICAgICAgICAgICAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gICAgICAgICAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgfVxyXG5cdH1cclxuXHQmOjphZnRlclxyXG5cdHtcclxuXHRkaXNwbGF5Om5vbmU7XHJcblx0fVxyXG5cdH1cclxuaW9uLWNvbnRlbnRcclxue1xyXG5bcGF5bWVudGltZ11cclxue1xyXG4gIGltZ1xyXG4gIHtcclxuICAgIG1heC13aWR0aDoyNTBweDtcclxuICB9XHJcbn1cclxuW2Zvcm1maWVsZF0ge1xyXG5cdFx0XHRwb3NpdGlvbjogcmVsYXRpdmU7XHJcblx0XHRcdGJvcmRlcjogMXB4IHNvbGlkICNlOGU4ZTg7XHJcblx0XHRcdGhlaWdodDogNTJweDtcclxuXHRcdFx0Ym9yZGVyLXJhZGl1czogNTBweDtcclxuXHRcdFx0YmFja2dyb3VuZDp2YXIoIC0taW9uLWNvbG9yLXdoaXRlKTtcclxuXHRcdFx0cGFkZGluZzogMCAxNnB4O1xyXG5cdFx0XHRtYXJnaW4tdG9wOjIwcHg7XHJcblx0XHRcdGxhYmVsIHtcclxuXHRcdFx0XHRwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0XHRcdFx0dG9wOiAtMTBweDtcclxuXHRcdFx0XHR6LWluZGV4OiAxMTE7XHJcblx0XHRcdFx0YmFja2dyb3VuZDogdmFyKCAtLWlvbi1jb2xvci13aGl0ZSk7XHJcblx0XHRcdFx0bGVmdDogMjlweDtcclxuXHRcdFx0XHRwYWRkaW5nOiAwIDNweDtcclxuXHRcdFx0XHRmb250LXNpemU6IDEycHg7XHJcblx0XHRcdFx0Zm9udC13ZWlnaHQ6IDcwMDtcclxuXHRcdFx0XHRjb2xvcjogIzNhM2EzYTtcclxuXHRcdFx0fVxyXG5cdFx0XHRpb24taW5wdXQgLCBpb24tZGF0ZXRpbWUgIHtcclxuXHRcdFx0XHRwYWRkaW5nOiAwcHg7XHJcblx0XHRcdFx0LS1wYWRkaW5nLXN0YXJ0OiAwcHg7XHJcblx0XHRcdFx0LS1wYWRkaW5nLWVuZDogMHB4O1xyXG5cdFx0XHRcdGZvbnQtc2l6ZTogMTRweDtcclxuXHRcdFx0XHQtLXBsYWNlaG9sZGVyLWNvbG9yOiAjOWE5YTlhO1xyXG5cdFx0XHRcdC0tcGxhY2Vob2xkZXItb3BhY2l0eTogMTtcclxuXHRcdFx0XHRmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XHJcblx0XHRcdFx0Y29sb3I6ICMyMjI7XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHRcdC5idG4tbG9zbnN7XHJcblx0XHRcdC0tYmFja2dyb3VuZDp2YXIoIC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG5cdFx0XHRtYXJnaW4tdG9wOiAyMHB4O1xyXG5cdFx0XHQtLWJveC1zaGFkb3c6IG5vbmU7XHJcbiAgICAgICAgICAgIG1pbi1oZWlnaHQ6IDQ4cHg7XHJcblx0XHRcdG1hcmdpbi1ib3R0b206IDE1cHg7XHJcblx0XHRcdHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcblx0XHRcdGxldHRlci1zcGFjaW5nOiAxcHg7XHJcblx0XHR9XHJcbn1cclxuW3NwYW5dXHJcbntcclxuICAgIG1hcmdpbi1ib3R0b206IDE1cHggIWltcG9ydGFudDtcclxuICAgIGNvbG9yOiByZWQ7XHJcbiAgICBwYWRkaW5nOiAxMXB4O1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG59Il19 */";
      /***/
    },

    /***/
    "./src/app/edit-payment/edit-payment.page.ts":
    /*!***************************************************!*\
      !*** ./src/app/edit-payment/edit-payment.page.ts ***!
      \***************************************************/

    /*! exports provided: EditPaymentPage */

    /***/
    function srcAppEditPaymentEditPaymentPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "EditPaymentPage", function () {
        return EditPaymentPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../services/api/api.service */
      "./src/app/services/api/api.service.ts");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _common_common_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../common/common.service */
      "./src/app/common/common.service.ts");
      /* harmony import */


      var _services_globalFooService_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../services/globalFooService.service */
      "./src/app/services/globalFooService.service.ts");

      var EditPaymentPage = /*#__PURE__*/function () {
        function EditPaymentPage(globalFooService, activatedRoute, api, router, common) {
          _classCallCheck(this, EditPaymentPage);

          this.globalFooService = globalFooService;
          this.activatedRoute = activatedRoute;
          this.api = api;
          this.router = router;
          this.common = common;
          this.is_submit_payment = false;
          this.errors = ['', null, undefined];
          this.paymentid = activatedRoute.snapshot.paramMap.get('id');
        }

        _createClass(EditPaymentPage, [{
          key: "addcard",
          value: function addcard() {
            var _this = this;

            this.is_submit_payment = true;

            if (this.errors.indexOf(this.name) >= 0 || this.errors.indexOf(this.card_number) >= 0 || this.errors.indexOf(this.cvc) >= 0 || this.errors.indexOf(this.exp_date) >= 0) {
              return false;
            }

            if (this.errors.indexOf(this.userid) >= 0) {
              this.common.presentToast('Please login first!.', 'danger');
              return false;
            }

            var dict = {
              id: this.paymentid,
              name: this.name,
              card_number: this.card_number,
              exp_date: this.exp_date,
              cvc: this.cvc,
              userid: this.userid
            };
            this.common.presentLoading();
            this.api.post('UpdatePayment', dict, '').subscribe(function (result) {
              _this.common.stopLoading();

              var res;
              res = result;

              if (res.status == 1) {
                _this.common.presentToast('Updated Successfully !.', 'success');

                _this.globalFooService.publishSomeData({
                  set: {
                    'data': res.status
                  }
                });

                _this.api.navCtrl.navigateRoot('/tabs/settings');
              } else {
                _this.common.presentToast(res.message, 'danger');
              }
            }, function (err) {});
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "ionViewDidEnter",
          value: function ionViewDidEnter() {
            this.userid = localStorage.getItem('userid');
            this.getpaymentdetails();
          }
        }, {
          key: "getpaymentdetails",
          value: function getpaymentdetails() {
            var _this2 = this;

            var dict = {
              id: this.paymentid
            };
            this.common.presentLoading();
            this.api.post('paymentdetail', dict, '').subscribe(function (result) {
              _this2.common.stopLoading();

              var res;
              res = result;

              if (res.status == 1) {
                _this2.payment = res.data;
                _this2.card_number = res.data.card_number;
                _this2.name = res.data.card_holder_name;
                _this2.exp_date = res.data.expiry_date;
                _this2.cvc = res.data.cvv;
              } else {}
            }, function (err) {});
          }
        }]);

        return EditPaymentPage;
      }();

      EditPaymentPage.ctorParameters = function () {
        return [{
          type: _services_globalFooService_service__WEBPACK_IMPORTED_MODULE_5__["GlobalFooService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
        }, {
          type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
        }, {
          type: _common_common_service__WEBPACK_IMPORTED_MODULE_4__["CommonService"]
        }];
      };

      EditPaymentPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-edit-payment',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./edit-payment.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/edit-payment/edit-payment.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./edit-payment.page.scss */
        "./src/app/edit-payment/edit-payment.page.scss"))["default"]]
      })], EditPaymentPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=edit-payment-edit-payment-module-es5.js.map