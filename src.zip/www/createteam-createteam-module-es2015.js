(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["createteam-createteam-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/createteam/createteam.page.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/createteam/createteam.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n\t<ion-back-button defaultHref=\"/searchteam\" slot=\"start\">\r\n\t</ion-back-button>\r\n\t<ion-title class=\"ion-text-center\">Create Team</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\t<ion-content class=\"ion-padding\">\r\n\t<div teamdetail>\r\n\t<!--img src=\"assets/images/createteam.png\" class=\"user_image\" /--->\r\n\t<img   src=\"assets/images/createteam.png\" *ngIf=\"is_license_uploaded == false\"  class=\"user_image1\">\r\n\t\t\t\t\t\t\t\t<img *ngIf=\"is_license_uploaded == true\"  [src]=\"sanitizer.bypassSecurityTrustUrl(license_image_url)\"\r\n\t\t\t\t\t\t\t\tclass=\"user_image1\">\r\n\t\t\t\t\t\t\t\t<!--label for=\"editprofile1\"><i class=\"fa fa-pencil\"></i></label--->\r\n\t\t\t\t\t\t\t\t<label for=\"editprofile1\" btnedit >\r\n\t\t\t\t\t\t\t\t<ion-icon name=\"camera-outline\"></ion-icon>\r\n\t\t\t\t\t\t\t\t</label>\r\n\t\t\t\t\t\t\t\t<input type=\"file\" (change)=\"uploadImage($event)\" name=\"editprofile1\" id=\"editprofile1\" style=\"display:none\">\r\n\t\t\t\t\t\t\t\t<span error *ngIf=\"errors.indexOf(this.license_file) >= 0 && is_submit_team == true\">Please select Image</span>\r\n\t\r\n\t\r\n\t<div formfield>\r\n\t<label>Name</label>\r\n\t<ion-item lines=\"none\" class=\"fls\"> \r\n\t<ion-input placeholder=\"Enter Team Name\" [(ngModel)]=\"name\" name=\"name\" ></ion-input>\r\n\t</ion-item>\r\n\t<span error *ngIf=\"errors.indexOf(name) >= 0 && is_submit_team == true\">Please enter team name</span>\r\n\t\t\t\t\r\n\t</div>\r\n\t<div formfield>\r\n\t<label>Description</label>\r\n\t<ion-item lines=\"none\" class=\"fls\"> \r\n\t<ion-input placeholder=\"Enter Description\" [(ngModel)]=\"description\" name=\"description\" ></ion-input>\r\n\t</ion-item>\r\n\t<span error *ngIf=\"errors.indexOf(description) >= 0 && is_submit_team == true\">Please enter team description</span>\t\t\r\n\t</div>\r\n\t<p *ngIf=\"teamlist?.length==0\">No records found..!</p>\r\n\t<ion-item  teamcont lines=\"none\" *ngFor=\"let team of teamlist\" >\r\n\t\t <ion-thumbnail>\r\n\t\t <img src=\"assets/images/createteam.png\"  *ngIf=\"errors.indexOf(team?.image)>=0\">\r\n         <img src=\"{{IMAGES_URL}}/{{team?.image}}\"  *ngIf=\"errors.indexOf(team?.image)==-1\">\r\n\t\t </ion-thumbnail>\r\n\t\t <ion-label>\r\n\t\t <h2>{{team?.name}}</h2>\r\n\t\t <p><span><ion-icon name=\"heart\"></ion-icon>{{team?.meals}}</span> <span><ion-icon name=\"people\"></ion-icon>{{team?.joins}}</span></p>\r\n\t\t </ion-label>\r\n\t\t <ion-icon name=\"chevron-forward-outline\" slot=\"end\" routerLink=\"/teamdetail/{{team?.id}}\"></ion-icon>\r\n\t\t</ion-item>\r\n</div>\r\n\t<ion-fab  vertical=\"bottom\" horizontal=\"end\" edge size=\"small\" slot=\"fixed\" (click)=\"submit();\">\r\n    <ion-fab-button>\r\n     <ion-icon name=\"checkmark-outline\" ></ion-icon>\r\n    </ion-fab-button>\r\n  </ion-fab>\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/createteam/createteam-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/createteam/createteam-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: CreateteamPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateteamPageRoutingModule", function() { return CreateteamPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _createteam_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./createteam.page */ "./src/app/createteam/createteam.page.ts");




const routes = [
    {
        path: '',
        component: _createteam_page__WEBPACK_IMPORTED_MODULE_3__["CreateteamPage"]
    }
];
let CreateteamPageRoutingModule = class CreateteamPageRoutingModule {
};
CreateteamPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CreateteamPageRoutingModule);



/***/ }),

/***/ "./src/app/createteam/createteam.module.ts":
/*!*************************************************!*\
  !*** ./src/app/createteam/createteam.module.ts ***!
  \*************************************************/
/*! exports provided: CreateteamPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateteamPageModule", function() { return CreateteamPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _createteam_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./createteam-routing.module */ "./src/app/createteam/createteam-routing.module.ts");
/* harmony import */ var _createteam_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./createteam.page */ "./src/app/createteam/createteam.page.ts");







let CreateteamPageModule = class CreateteamPageModule {
};
CreateteamPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _createteam_routing_module__WEBPACK_IMPORTED_MODULE_5__["CreateteamPageRoutingModule"]
        ],
        declarations: [_createteam_page__WEBPACK_IMPORTED_MODULE_6__["CreateteamPage"]]
    })
], CreateteamPageModule);



/***/ }),

/***/ "./src/app/createteam/createteam.page.scss":
/*!*************************************************!*\
  !*** ./src/app/createteam/createteam.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-toolbar {\n  --ion-color-base: var(--ion-color-bggradient)!important;\n  --border-width: 0;\n}\nion-header ion-toolbar ion-title {\n  color: var(--ion-color-white);\n  text-align: center;\n  font-style: normal;\n  font-family: \"Poppins\", sans-serif !important;\n}\nion-header::after {\n  display: none;\n}\nion-content [teamdetail] {\n  text-align: Center;\n}\nion-content [teamdetail] [formfield] {\n  position: relative;\n  border: 1px solid #e8e8e8;\n  height: 52px;\n  border-radius: 50px;\n  background: var(--ion-color-white);\n  padding: 0 16px;\n  margin-top: 20px;\n  margin-bottom: 35px;\n}\nion-content [teamdetail] [formfield] label {\n  position: absolute;\n  top: -10px;\n  z-index: 111;\n  background: var(--ion-color-white);\n  left: 29px;\n  padding: 0 3px;\n  font-size: 12px;\n  font-weight: 700;\n  color: #3a3a3a;\n}\nion-content [teamdetail] [formfield] ion-input, ion-content [teamdetail] [formfield] ion-datetime {\n  padding: 0px;\n  --padding-start: 0px;\n  --padding-end: 0px;\n  font-size: 14px;\n  --placeholder-color: #9a9a9a;\n  --placeholder-opacity: 1;\n  font-family: \"Poppins\", sans-serif !important;\n  color: #222;\n}\nion-content [teamdetail] img {\n  max-width: 120px;\n  margin: 0 auto;\n}\nion-content [teamdetail] [teamcont] {\n  --padding-start: 10px;\n  margin-top: 15px;\n  border-radius: 15px 0 15px;\n  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);\n  border-left: 2px solid var(--ion-color-primary);\n  --inner-padding-end: 5px;\n}\nion-content [teamdetail] [teamcont] ion-thumbnail {\n  width: 70px;\n  height: 70px;\n}\nion-content [teamdetail] [teamcont] ion-thumbnail img {\n  width: 70px;\n  height: 70px;\n  border-radius: 8px;\n}\nion-content [teamdetail] [teamcont] ion-label {\n  margin-left: 15px;\n}\nion-content [teamdetail] [teamcont] ion-label h2 {\n  margin-bottom: 5px;\n}\nion-content [teamdetail] [teamcont] ion-label p span {\n  margin-right: 10px;\n  font-size: 14px;\n}\nion-content [teamdetail] [teamcont] ion-label p span ion-icon {\n  margin-right: 3px;\n  color: var(--ion-color-primary);\n}\nion-content ion-fab {\n  bottom: 3px;\n  right: 4px;\n}\n[error] {\n  font-size: 12px;\n  color: red;\n  display: block;\n}\n[btnedit] {\n  background: var(--ion-color-primary);\n  border-radius: 50%;\n  display: inline-block;\n  line-height: 30px;\n  border: 2px solid var(--ion-color-white);\n  width: 30px;\n  height: 30px;\n  position: absolute;\n  top: 26px;\n  margin-left: -28px;\n}\n[btnedit] ion-icon {\n  color: var(--ion-color-white);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY3JlYXRldGVhbS9jcmVhdGV0ZWFtLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHRztFQUNDLHVEQUFBO0VBQ0QsaUJBQUE7QUFGSDtBQUlJO0VBQ0EsNkJBQUE7RUFDQSxrQkFBQTtFQUNRLGtCQUFBO0VBQ0EsNkNBQUE7QUFGWjtBQUtDO0VBRUEsYUFBQTtBQUpEO0FBV0E7RUFnQ0Esa0JBQUE7QUF2Q0E7QUFRQztFQUNFLGtCQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQ0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FBTkg7QUFPRztFQUNDLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxrQ0FBQTtFQUNBLFVBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQUxKO0FBT0c7RUFDQyxZQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSw0QkFBQTtFQUNBLHdCQUFBO0VBQ0EsNkNBQUE7RUFDQSxXQUFBO0FBTEo7QUFTQTtFQUVJLGdCQUFBO0VBQ0EsY0FBQTtBQVJKO0FBVUE7RUFDRSxxQkFBQTtFQUNLLGdCQUFBO0VBQ0gsMEJBQUE7RUFDQSwyQ0FBQTtFQUNBLCtDQUFBO0VBQ0Esd0JBQUE7QUFSSjtBQVNHO0VBRUksV0FBQTtFQUNILFlBQUE7QUFSSjtBQVNDO0VBRUksV0FBQTtFQUNELFlBQUE7RUFDSCxrQkFBQTtBQVJEO0FBV0c7RUFFQyxpQkFBQTtBQVZKO0FBV0k7RUFFQSxrQkFBQTtBQVZKO0FBY0k7RUFDQyxrQkFBQTtFQUNELGVBQUE7QUFaSjtBQWFJO0VBQ0MsaUJBQUE7RUFDRCwrQkFBQTtBQVhKO0FBa0JBO0VBQ0ksV0FBQTtFQUNBLFVBQUE7QUFoQko7QUFtQkE7RUFFQSxlQUFBO0VBQ0EsVUFBQTtFQUNBLGNBQUE7QUFqQkE7QUFtQkE7RUFDSSxvQ0FBQTtFQUNBLGtCQUFBO0VBQ0EscUJBQUE7RUFDQSxpQkFBQTtFQUNBLHdDQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxrQkFBQTtBQWhCSjtBQWtCQztFQUNDLDZCQUFBO0FBaEJGIiwiZmlsZSI6InNyYy9hcHAvY3JlYXRldGVhbS9jcmVhdGV0ZWFtLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXJcclxue1xyXG5cdFxyXG5cdCAgaW9uLXRvb2xiYXJcclxuXHQgIHstLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1pb24tY29sb3ItYmdncmFkaWVudCkhaW1wb3J0YW50O1xyXG5cdCAgLS1ib3JkZXItd2lkdGg6IDA7XHJcblx0XHJcblx0XHQgIGlvbi10aXRsZXtcclxuXHRcdCAgY29sb3I6dmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuXHRcdCAgdGV4dC1hbGlnbjpjZW50ZXI7XHJcbiAgICAgICAgICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xyXG4gICAgICAgIH1cclxuXHR9XHJcblx0Jjo6YWZ0ZXJcclxuXHR7XHJcblx0ZGlzcGxheTpub25lO1xyXG5cdH1cclxufVxyXG5cclxuaW9uLWNvbnRlbnRcclxue1xyXG5cclxuW3RlYW1kZXRhaWxdXHJcbntbZm9ybWZpZWxkXSB7XHJcblx0XHRcdHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHRcdFx0Ym9yZGVyOiAxcHggc29saWQgI2U4ZThlODtcclxuXHRcdFx0aGVpZ2h0OiA1MnB4O1xyXG5cdFx0XHRib3JkZXItcmFkaXVzOiA1MHB4O1xyXG5cdFx0XHRiYWNrZ3JvdW5kOnZhciggLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdFx0XHRwYWRkaW5nOiAwIDE2cHg7XHJcblx0XHRcdG1hcmdpbi10b3A6MjBweDtcclxuXHRcdFx0bWFyZ2luLWJvdHRvbTozNXB4O1xyXG5cdFx0XHRsYWJlbCB7XHJcblx0XHRcdFx0cG9zaXRpb246IGFic29sdXRlO1xyXG5cdFx0XHRcdHRvcDogLTEwcHg7XHJcblx0XHRcdFx0ei1pbmRleDogMTExO1xyXG5cdFx0XHRcdGJhY2tncm91bmQ6IHZhciggLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdFx0XHRcdGxlZnQ6IDI5cHg7XHJcblx0XHRcdFx0cGFkZGluZzogMCAzcHg7XHJcblx0XHRcdFx0Zm9udC1zaXplOiAxMnB4O1xyXG5cdFx0XHRcdGZvbnQtd2VpZ2h0OiA3MDA7XHJcblx0XHRcdFx0Y29sb3I6ICMzYTNhM2E7XHJcblx0XHRcdH1cclxuXHRcdFx0aW9uLWlucHV0ICwgaW9uLWRhdGV0aW1lICB7XHJcblx0XHRcdFx0cGFkZGluZzogMHB4O1xyXG5cdFx0XHRcdC0tcGFkZGluZy1zdGFydDogMHB4O1xyXG5cdFx0XHRcdC0tcGFkZGluZy1lbmQ6IDBweDtcclxuXHRcdFx0XHRmb250LXNpemU6IDE0cHg7XHJcblx0XHRcdFx0LS1wbGFjZWhvbGRlci1jb2xvcjogIzlhOWE5YTtcclxuXHRcdFx0XHQtLXBsYWNlaG9sZGVyLW9wYWNpdHk6IDE7XHJcblx0XHRcdFx0Zm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xyXG5cdFx0XHRcdGNvbG9yOiAjMjIyO1xyXG5cdFx0XHR9XHJcblx0XHR9XHJcbnRleHQtYWxpZ246Q2VudGVyO1xyXG5pbWdcclxue1xyXG4gICAgbWF4LXdpZHRoOiAxMjBweDtcclxuICAgIG1hcmdpbjogMCBhdXRvO1xyXG59XHJcblt0ZWFtY29udF1cclxuXHR7LS1wYWRkaW5nLXN0YXJ0OiAxMHB4O1xyXG4gICAgICAgbWFyZ2luLXRvcDogMTVweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDE1cHggMCAxNXB4O1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDBweCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuICAgIGJvcmRlci1sZWZ0OiAycHggc29saWQgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgLS1pbm5lci1wYWRkaW5nLWVuZDogNXB4O1xyXG5cdCAgaW9uLXRodW1ibmFpbFxyXG5cdCAge1xyXG5cdCAgICAgIHdpZHRoOiA3MHB4O1xyXG4gICAgaGVpZ2h0OiA3MHB4O1xyXG5cdGltZ1xyXG5cdHtcclxuXHQgICAgd2lkdGg6IDcwcHg7XHJcbiAgICBoZWlnaHQ6IDcwcHg7XHJcblx0Ym9yZGVyLXJhZGl1czo4cHg7XHJcblx0fVxyXG5cdCAgfVxyXG5cdCAgaW9uLWxhYmVsXHJcblx0ICB7XHJcblx0ICAgbWFyZ2luLWxlZnQ6IDE1cHg7XHJcblx0ICAgaDJcclxuXHQgICB7XHJcblx0ICAgbWFyZ2luLWJvdHRvbTogNXB4O1xyXG5cdCAgIH1cclxuXHQgICBwXHJcblx0ICAge1xyXG5cdCAgIHNwYW5cclxuXHQgICB7bWFyZ2luLXJpZ2h0OjEwcHg7XHJcblx0ICAgZm9udC1zaXplOjE0cHg7XHJcblx0ICAgaW9uLWljb25cclxuXHQgICB7bWFyZ2luLXJpZ2h0OjNweDtcclxuXHQgICBjb2xvcjp2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcblx0ICAgfVxyXG5cdCAgIH1cclxuXHQgICB9XHJcblx0ICB9XHJcblx0fVxyXG5cdH1cclxuaW9uLWZhYiB7XHJcbiAgICBib3R0b206IDNweDtcclxuICAgIHJpZ2h0OiA0cHg7IFxyXG59XHJcbn1cclxuW2Vycm9yXVxyXG57XHJcbmZvbnQtc2l6ZToxMnB4O1xyXG5jb2xvcjpyZWQ7XHJcbmRpc3BsYXk6YmxvY2s7XHJcbn1cclxuW2J0bmVkaXRdIHtcclxuICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIGxpbmUtaGVpZ2h0OiAzMHB4O1xyXG4gICAgYm9yZGVyOiAycHggc29saWQgdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgIHdpZHRoOiAzMHB4O1xyXG4gICAgaGVpZ2h0OiAzMHB4O1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAyNnB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IC0yOHB4O1xyXG5cclxuXHRpb24taWNvblxyXG5cdHtjb2xvcjp2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdH1cclxufSJdfQ== */");

/***/ }),

/***/ "./src/app/createteam/createteam.page.ts":
/*!***********************************************!*\
  !*** ./src/app/createteam/createteam.page.ts ***!
  \***********************************************/
/*! exports provided: CreateteamPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateteamPage", function() { return CreateteamPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/api/api.service */ "./src/app/services/api/api.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../config */ "./src/app/config.ts");
/* harmony import */ var _common_common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../common/common.service */ "./src/app/common/common.service.ts");
/* harmony import */ var ng2_file_upload__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ng2-file-upload */ "./node_modules/ng2-file-upload/__ivy_ngcc__/fesm2015/ng2-file-upload.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_8__);









let CreateteamPage = class CreateteamPage {
    constructor(activatedRoute, api, router, common, sanitizer) {
        this.activatedRoute = activatedRoute;
        this.api = api;
        this.router = router;
        this.common = common;
        this.sanitizer = sanitizer;
        this.IMAGES_URL = _config__WEBPACK_IMPORTED_MODULE_4__["config"].IMAGES_URL;
        this.is_submit_team = false;
        this.errors = ['', null, undefined];
        this.teamlist = [];
        this.allowedMimes = ['image/png', 'image/jpg', 'image/jpeg'];
        this.license_error = false;
        this.is_license_uploaded = false;
        this.uploader = new ng2_file_upload__WEBPACK_IMPORTED_MODULE_6__["FileUploader"]({ url: '' });
        this.userid = localStorage.getItem('userid');
    }
    ngOnInit() {
    }
    uploadImage(event) {
        this.license_error = false;
        var self = this;
        if (event.target.files && event.target.files[0]) {
            var reader = new FileReader();
            var image_file = event.target.files[0];
            if (self.allowedMimes.indexOf(image_file.type) == -1) {
                this.license_error = true;
                this.common.presentToast('This format is not allowed !.', 'danger');
            }
            else {
                self.license_file = image_file;
                self.license_image_url = window.URL.createObjectURL(image_file);
                jquery__WEBPACK_IMPORTED_MODULE_8__('.user_image1').attr('src', self.license_image_url);
            }
        }
    }
    ionViewDidEnter() {
        this.userid = localStorage.getItem('userid');
        this.getmyteam();
    }
    getmyteam() {
        let dict = {
            userid: this.userid,
        };
        this.common.presentLoading();
        this.api.post('Getmyteams', dict, '').subscribe((result) => {
            this.common.stopLoading();
            var res;
            res = result;
            if (res.status == 1) {
                this.teamlist = res.data;
            }
            else {
            }
        }, err => {
        });
    }
    submit() {
        this.is_submit_team = true;
        if (this.errors.indexOf(this.license_file) >= 0 || this.errors.indexOf(this.name) >= 0 || this.errors.indexOf(this.description) >= 0) {
            return false;
        }
        if (this.errors.indexOf(this.userid) >= 0) {
            this.common.presentToast('Please login first!.', 'danger');
            return false;
        }
        this.common.presentLoading();
        const frmData = new FormData();
        frmData.append("image", this.license_file);
        frmData.append("name", this.name);
        frmData.append("description", this.description);
        frmData.append("userid", this.userid);
        this.api.post('addTeam', frmData, '').subscribe((result) => {
            this.common.stopLoading();
            var res;
            res = result;
            if (res.status == 1) {
                this.is_submit_team = false;
                this.getmyteam();
                this.license_file = '';
                this.name = '';
                this.description = '';
                this.license_file = '';
                this.is_license_uploaded = false;
                jquery__WEBPACK_IMPORTED_MODULE_8__('.user_image1').attr('src', 'assets/images/createteam.png');
                this.common.presentToast('Team added successfully!.', 'success');
            }
            else {
                this.common.presentToast('Error in adding team!.', 'danger');
            }
        }, err => {
        });
    }
};
CreateteamPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _common_common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"] },
    { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_7__["DomSanitizer"] }
];
CreateteamPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-createteam',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./createteam.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/createteam/createteam.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./createteam.page.scss */ "./src/app/createteam/createteam.page.scss")).default]
    })
], CreateteamPage);



/***/ })

}]);
//# sourceMappingURL=createteam-createteam-module-es2015.js.map