(function () {
  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["styles"], {
    /***/
    "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/sass-loader/dist/cjs.js?!./src/global.scss":
    /*!*********************************************************************************************************************************************************************************************************************!*\
      !*** ./node_modules/css-loader/dist/cjs.js??ref--14-1!./node_modules/postcss-loader/src??embedded!./node_modules/resolve-url-loader??ref--14-3!./node_modules/sass-loader/dist/cjs.js??ref--14-4!./src/global.scss ***!
      \*********************************************************************************************************************************************************************************************************************/

    /*! no static exports found */

    /***/
    function node_modulesCssLoaderDistCjsJsNode_modulesPostcssLoaderSrcIndexJsNode_modulesResolveUrlLoaderIndexJsNode_modulesSassLoaderDistCjsJsSrcGlobalScss(module, exports, __webpack_require__) {
      // Imports
      var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(
      /*! ../node_modules/css-loader/dist/runtime/api.js */
      "./node_modules/css-loader/dist/runtime/api.js");

      exports = ___CSS_LOADER_API_IMPORT___(true); // Module

      exports.push([module.i, "/*\n * App Global CSS\n * ----------------------------------------------------------------------------\n * Put style rules here that you want to apply globally. These styles are for\n * the entire app and not just one component. Additionally, this file can be\n * used as an entry point to import other CSS/Sass files to be included in the\n * output CSS.\n * For more information on global stylesheets, visit the documentation:\n * https://ionicframework.com/docs/layout/global-stylesheets\n */\n/* Core CSS required for Ionic components to work properly */\nhtml.ios {\r\n  --ion-default-font: -apple-system, BlinkMacSystemFont, \"Helvetica Neue\", \"Roboto\", sans-serif;\r\n}\nhtml.md {\r\n  --ion-default-font: \"Roboto\", \"Helvetica Neue\", sans-serif;\r\n}\nhtml {\r\n  --ion-font-family: var(--ion-default-font);\r\n}\nbody {\r\n  background: var(--ion-background-color);\r\n}\nbody.backdrop-no-scroll {\r\n  overflow: hidden;\r\n}\nhtml.ios ion-modal.modal-card .ion-page > ion-header > ion-toolbar:first-of-type {\r\n  padding-top: 0px;\r\n}\nhtml.ios ion-modal .ion-page {\r\n  border-radius: inherit;\r\n}\n.ion-color-primary {\r\n  --ion-color-base: var(--ion-color-primary, #3880ff) !important;\r\n  --ion-color-base-rgb: var(--ion-color-primary-rgb, 56, 128, 255) !important;\r\n  --ion-color-contrast: var(--ion-color-primary-contrast, #fff) !important;\r\n  --ion-color-contrast-rgb: var(--ion-color-primary-contrast-rgb, 255, 255, 255) !important;\r\n  --ion-color-shade: var(--ion-color-primary-shade, #3171e0) !important;\r\n  --ion-color-tint: var(--ion-color-primary-tint, #4c8dff) !important;\r\n}\n.ion-color-secondary {\r\n  --ion-color-base: var(--ion-color-secondary, #3dc2ff) !important;\r\n  --ion-color-base-rgb: var(--ion-color-secondary-rgb, 61, 194, 255) !important;\r\n  --ion-color-contrast: var(--ion-color-secondary-contrast, #fff) !important;\r\n  --ion-color-contrast-rgb: var(--ion-color-secondary-contrast-rgb, 255, 255, 255) !important;\r\n  --ion-color-shade: var(--ion-color-secondary-shade, #36abe0) !important;\r\n  --ion-color-tint: var(--ion-color-secondary-tint, #50c8ff) !important;\r\n}\n.ion-color-tertiary {\r\n  --ion-color-base: var(--ion-color-tertiary, #5260ff) !important;\r\n  --ion-color-base-rgb: var(--ion-color-tertiary-rgb, 82, 96, 255) !important;\r\n  --ion-color-contrast: var(--ion-color-tertiary-contrast, #fff) !important;\r\n  --ion-color-contrast-rgb: var(--ion-color-tertiary-contrast-rgb, 255, 255, 255) !important;\r\n  --ion-color-shade: var(--ion-color-tertiary-shade, #4854e0) !important;\r\n  --ion-color-tint: var(--ion-color-tertiary-tint, #6370ff) !important;\r\n}\n.ion-color-success {\r\n  --ion-color-base: var(--ion-color-success, #2dd36f) !important;\r\n  --ion-color-base-rgb: var(--ion-color-success-rgb, 45, 211, 111) !important;\r\n  --ion-color-contrast: var(--ion-color-success-contrast, #fff) !important;\r\n  --ion-color-contrast-rgb: var(--ion-color-success-contrast-rgb, 255, 255, 255) !important;\r\n  --ion-color-shade: var(--ion-color-success-shade, #28ba62) !important;\r\n  --ion-color-tint: var(--ion-color-success-tint, #42d77d) !important;\r\n}\n.ion-color-warning {\r\n  --ion-color-base: var(--ion-color-warning, #ffc409) !important;\r\n  --ion-color-base-rgb: var(--ion-color-warning-rgb, 255, 196, 9) !important;\r\n  --ion-color-contrast: var(--ion-color-warning-contrast, #000) !important;\r\n  --ion-color-contrast-rgb: var(--ion-color-warning-contrast-rgb, 0, 0, 0) !important;\r\n  --ion-color-shade: var(--ion-color-warning-shade, #e0ac08) !important;\r\n  --ion-color-tint: var(--ion-color-warning-tint, #ffca22) !important;\r\n}\n.ion-color-danger {\r\n  --ion-color-base: var(--ion-color-danger, #eb445a) !important;\r\n  --ion-color-base-rgb: var(--ion-color-danger-rgb, 235, 68, 90) !important;\r\n  --ion-color-contrast: var(--ion-color-danger-contrast, #fff) !important;\r\n  --ion-color-contrast-rgb: var(--ion-color-danger-contrast-rgb, 255, 255, 255) !important;\r\n  --ion-color-shade: var(--ion-color-danger-shade, #cf3c4f) !important;\r\n  --ion-color-tint: var(--ion-color-danger-tint, #ed576b) !important;\r\n}\n.ion-color-light {\r\n  --ion-color-base: var(--ion-color-light, #f4f5f8) !important;\r\n  --ion-color-base-rgb: var(--ion-color-light-rgb, 244, 245, 248) !important;\r\n  --ion-color-contrast: var(--ion-color-light-contrast, #000) !important;\r\n  --ion-color-contrast-rgb: var(--ion-color-light-contrast-rgb, 0, 0, 0) !important;\r\n  --ion-color-shade: var(--ion-color-light-shade, #d7d8da) !important;\r\n  --ion-color-tint: var(--ion-color-light-tint, #f5f6f9) !important;\r\n}\n.ion-color-medium {\r\n  --ion-color-base: var(--ion-color-medium, #92949c) !important;\r\n  --ion-color-base-rgb: var(--ion-color-medium-rgb, 146, 148, 156) !important;\r\n  --ion-color-contrast: var(--ion-color-medium-contrast, #fff) !important;\r\n  --ion-color-contrast-rgb: var(--ion-color-medium-contrast-rgb, 255, 255, 255) !important;\r\n  --ion-color-shade: var(--ion-color-medium-shade, #808289) !important;\r\n  --ion-color-tint: var(--ion-color-medium-tint, #9d9fa6) !important;\r\n}\n.ion-color-dark {\r\n  --ion-color-base: var(--ion-color-dark, #222428) !important;\r\n  --ion-color-base-rgb: var(--ion-color-dark-rgb, 34, 36, 40) !important;\r\n  --ion-color-contrast: var(--ion-color-dark-contrast, #fff) !important;\r\n  --ion-color-contrast-rgb: var(--ion-color-dark-contrast-rgb, 255, 255, 255) !important;\r\n  --ion-color-shade: var(--ion-color-dark-shade, #1e2023) !important;\r\n  --ion-color-tint: var(--ion-color-dark-tint, #383a3e) !important;\r\n}\n.ion-page {\r\n  left: 0;\r\n  right: 0;\r\n  top: 0;\r\n  bottom: 0;\r\n  display: flex;\r\n  position: absolute;\r\n  flex-direction: column;\r\n  justify-content: space-between;\r\n  contain: layout size style;\r\n  overflow: hidden;\r\n  z-index: 0;\r\n}\n.split-pane-visible > .ion-page.split-pane-main {\r\n  position: relative;\r\n}\nion-route,\r\nion-route-redirect,\r\nion-router,\r\nion-select-option,\r\nion-nav-controller,\r\nion-menu-controller,\r\nion-action-sheet-controller,\r\nion-alert-controller,\r\nion-loading-controller,\r\nion-modal-controller,\r\nion-picker-controller,\r\nion-popover-controller,\r\nion-toast-controller,\r\n.ion-page-hidden,\r\n[hidden] {\r\n  /* stylelint-disable-next-line declaration-no-important */\r\n  display: none !important;\r\n}\n.ion-page-invisible {\r\n  opacity: 0;\r\n}\n.can-go-back > ion-header ion-back-button {\r\n  display: block;\r\n}\nhtml.plt-ios.plt-hybrid, html.plt-ios.plt-pwa {\r\n  --ion-statusbar-padding: 20px;\r\n}\n@supports (padding-top: 20px) {\r\n  html {\r\n    --ion-safe-area-top: var(--ion-statusbar-padding);\r\n  }\r\n}\n@supports (padding-top: constant(safe-area-inset-top)) {\r\n  html {\r\n    --ion-safe-area-top: constant(safe-area-inset-top);\r\n    --ion-safe-area-bottom: constant(safe-area-inset-bottom);\r\n    --ion-safe-area-left: constant(safe-area-inset-left);\r\n    --ion-safe-area-right: constant(safe-area-inset-right);\r\n  }\r\n}\n@supports (padding-top: env(safe-area-inset-top)) {\r\n  html {\r\n    --ion-safe-area-top: env(safe-area-inset-top);\r\n    --ion-safe-area-bottom: env(safe-area-inset-bottom);\r\n    --ion-safe-area-left: env(safe-area-inset-left);\r\n    --ion-safe-area-right: env(safe-area-inset-right);\r\n  }\r\n}\nion-card.ion-color .ion-inherit-color,\r\nion-card-header.ion-color .ion-inherit-color {\r\n  color: inherit;\r\n}\n.menu-content {\r\n  transform: translate3d(0,  0,  0);\r\n}\n.menu-content-open {\r\n  cursor: pointer;\r\n  touch-action: manipulation;\r\n  pointer-events: none;\r\n}\n.ios .menu-content-reveal {\r\n  box-shadow: -8px 0 42px rgba(0, 0, 0, 0.08);\r\n}\n[dir=rtl].ios .menu-content-reveal {\r\n  box-shadow: 8px 0 42px rgba(0, 0, 0, 0.08);\r\n}\n.md .menu-content-reveal {\r\n  box-shadow: 4px 0px 16px rgba(0, 0, 0, 0.18);\r\n}\n.md .menu-content-push {\r\n  box-shadow: 4px 0px 16px rgba(0, 0, 0, 0.18);\r\n}\n/* Basic CSS for apps built with Ionic */\naudio,\r\ncanvas,\r\nprogress,\r\nvideo {\r\n  vertical-align: baseline;\r\n}\naudio:not([controls]) {\r\n  display: none;\r\n  height: 0;\r\n}\nb,\r\nstrong {\r\n  font-weight: bold;\r\n}\nimg {\r\n  max-width: 100%;\r\n  border: 0;\r\n}\nsvg:not(:root) {\r\n  overflow: hidden;\r\n}\nfigure {\r\n  margin: 1em 40px;\r\n}\nhr {\r\n  height: 1px;\r\n  border-width: 0;\r\n  box-sizing: content-box;\r\n}\npre {\r\n  overflow: auto;\r\n}\ncode,\r\nkbd,\r\npre,\r\nsamp {\r\n  font-family: monospace, monospace;\r\n  font-size: 1em;\r\n}\nlabel,\r\ninput,\r\nselect,\r\ntextarea {\r\n  font-family: inherit;\r\n  line-height: normal;\r\n}\ntextarea {\r\n  overflow: auto;\r\n  height: auto;\r\n  font: inherit;\r\n  color: inherit;\r\n}\ntextarea::-moz-placeholder {\r\n  padding-left: 2px;\r\n}\ntextarea::placeholder {\r\n  padding-left: 2px;\r\n}\nform,\r\ninput,\r\noptgroup,\r\nselect {\r\n  margin: 0;\r\n  font: inherit;\r\n  color: inherit;\r\n}\nhtml input[type=button],\r\ninput[type=reset],\r\ninput[type=submit] {\r\n  cursor: pointer;\r\n  -webkit-appearance: button;\r\n}\na,\r\na div,\r\na span,\r\na ion-icon,\r\na ion-label,\r\nbutton,\r\nbutton div,\r\nbutton span,\r\nbutton ion-icon,\r\nbutton ion-label,\r\n.ion-tappable,\r\n[tappable],\r\n[tappable] div,\r\n[tappable] span,\r\n[tappable] ion-icon,\r\n[tappable] ion-label,\r\ninput,\r\ntextarea {\r\n  touch-action: manipulation;\r\n}\na ion-label,\r\nbutton ion-label {\r\n  pointer-events: none;\r\n}\nbutton {\r\n  border: 0;\r\n  border-radius: 0;\r\n  font-family: inherit;\r\n  font-style: inherit;\r\n  font-variant: inherit;\r\n  line-height: 1;\r\n  text-transform: none;\r\n  cursor: pointer;\r\n  -webkit-appearance: button;\r\n}\n[tappable] {\r\n  cursor: pointer;\r\n}\na[disabled],\r\nbutton[disabled],\r\nhtml input[disabled] {\r\n  cursor: default;\r\n}\nbutton::-moz-focus-inner,\r\ninput::-moz-focus-inner {\r\n  padding: 0;\r\n  border: 0;\r\n}\ninput[type=checkbox],\r\ninput[type=radio] {\r\n  padding: 0;\r\n  box-sizing: border-box;\r\n}\ninput[type=number]::-webkit-inner-spin-button,\r\ninput[type=number]::-webkit-outer-spin-button {\r\n  height: auto;\r\n}\ninput[type=search]::-webkit-search-cancel-button,\r\ninput[type=search]::-webkit-search-decoration {\r\n  -webkit-appearance: none;\r\n}\ntable {\r\n  border-collapse: collapse;\r\n  border-spacing: 0;\r\n}\ntd,\r\nth {\r\n  padding: 0;\r\n}\n* {\r\n  box-sizing: border-box;\r\n  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\r\n  -webkit-tap-highlight-color: transparent;\r\n  -webkit-touch-callout: none;\r\n}\nhtml {\r\n  width: 100%;\r\n  height: 100%;\r\n  -webkit-text-size-adjust: 100%;\r\n     -moz-text-size-adjust: 100%;\r\n          text-size-adjust: 100%;\r\n}\nhtml:not(.hydrated) body {\r\n  display: none;\r\n}\nhtml.plt-pwa {\r\n  height: 100vh;\r\n}\nbody {\r\n  -moz-osx-font-smoothing: grayscale;\r\n  -webkit-font-smoothing: antialiased;\r\n  margin-left: 0;\r\n  margin-right: 0;\r\n  margin-top: 0;\r\n  margin-bottom: 0;\r\n  padding-left: 0;\r\n  padding-right: 0;\r\n  padding-top: 0;\r\n  padding-bottom: 0;\r\n  position: fixed;\r\n  width: 100%;\r\n  max-width: 100%;\r\n  height: 100%;\r\n  max-height: 100%;\r\n  text-rendering: optimizeLegibility;\r\n  overflow: hidden;\r\n  touch-action: manipulation;\r\n  -webkit-user-drag: none;\r\n  -ms-content-zooming: none;\r\n  word-wrap: break-word;\r\n  overscroll-behavior-y: none;\r\n  -webkit-text-size-adjust: none;\r\n     -moz-text-size-adjust: none;\r\n          text-size-adjust: none;\r\n}\nhtml {\r\n  font-family: var(--ion-font-family);\r\n}\na {\r\n  background-color: transparent;\r\n  color: var(--ion-color-primary, #3880ff);\r\n}\nh1,\r\nh2,\r\nh3,\r\nh4,\r\nh5,\r\nh6 {\r\n  margin-top: 16px;\r\n  margin-bottom: 10px;\r\n  font-weight: 500;\r\n  line-height: 1.2;\r\n}\nh1 {\r\n  margin-top: 20px;\r\n  font-size: 26px;\r\n}\nh2 {\r\n  margin-top: 18px;\r\n  font-size: 24px;\r\n}\nh3 {\r\n  font-size: 22px;\r\n}\nh4 {\r\n  font-size: 20px;\r\n}\nh5 {\r\n  font-size: 18px;\r\n}\nh6 {\r\n  font-size: 16px;\r\n}\nsmall {\r\n  font-size: 75%;\r\n}\nsub,\r\nsup {\r\n  position: relative;\r\n  font-size: 75%;\r\n  line-height: 0;\r\n  vertical-align: baseline;\r\n}\nsup {\r\n  top: -0.5em;\r\n}\nsub {\r\n  bottom: -0.25em;\r\n}\n.ion-hide {\r\n  display: none !important;\r\n}\n.ion-hide-up {\r\n  display: none !important;\r\n}\n.ion-hide-down {\r\n  display: none !important;\r\n}\n@media (min-width: 576px) {\r\n  .ion-hide-sm-up {\r\n    display: none !important;\r\n  }\r\n}\n@media (max-width: 575.98px) {\r\n  .ion-hide-sm-down {\r\n    display: none !important;\r\n  }\r\n}\n@media (min-width: 768px) {\r\n  .ion-hide-md-up {\r\n    display: none !important;\r\n  }\r\n}\n@media (max-width: 767.98px) {\r\n  .ion-hide-md-down {\r\n    display: none !important;\r\n  }\r\n}\n@media (min-width: 992px) {\r\n  .ion-hide-lg-up {\r\n    display: none !important;\r\n  }\r\n}\n@media (max-width: 991.98px) {\r\n  .ion-hide-lg-down {\r\n    display: none !important;\r\n  }\r\n}\n@media (min-width: 1200px) {\r\n  .ion-hide-xl-up {\r\n    display: none !important;\r\n  }\r\n}\n@media (max-width: 1199.98px) {\r\n  .ion-hide-xl-down {\r\n    display: none !important;\r\n  }\r\n}\n/* Optional CSS utils that can be commented out */\n.ion-no-padding {\r\n  --padding-start: 0;\r\n  --padding-end: 0;\r\n  --padding-top: 0;\r\n  --padding-bottom: 0;\r\n  padding-left: 0;\r\n  padding-right: 0;\r\n  padding-top: 0;\r\n  padding-bottom: 0;\r\n}\n.ion-padding {\r\n  --padding-start: var(--ion-padding, 16px);\r\n  --padding-end: var(--ion-padding, 16px);\r\n  --padding-top: var(--ion-padding, 16px);\r\n  --padding-bottom: var(--ion-padding, 16px);\r\n  padding-left: var(--ion-padding, 16px);\r\n  padding-right: var(--ion-padding, 16px);\r\n  padding-top: var(--ion-padding, 16px);\r\n  padding-bottom: var(--ion-padding, 16px);\r\n}\n@supports ((-webkit-margin-start: 0) or (margin-inline-start: 0)) or (-webkit-margin-start: 0) {\r\n  .ion-padding {\r\n    padding-left: unset;\r\n    padding-right: unset;\r\n    -webkit-padding-start: var(--ion-padding, 16px);\r\n    padding-inline-start: var(--ion-padding, 16px);\r\n    -webkit-padding-end: var(--ion-padding, 16px);\r\n    padding-inline-end: var(--ion-padding, 16px);\r\n  }\r\n}\n.ion-padding-top {\r\n  --padding-top: var(--ion-padding, 16px);\r\n  padding-top: var(--ion-padding, 16px);\r\n}\n.ion-padding-start {\r\n  --padding-start: var(--ion-padding, 16px);\r\n  padding-left: var(--ion-padding, 16px);\r\n}\n@supports ((-webkit-margin-start: 0) or (margin-inline-start: 0)) or (-webkit-margin-start: 0) {\r\n  .ion-padding-start {\r\n    padding-left: unset;\r\n    -webkit-padding-start: var(--ion-padding, 16px);\r\n    padding-inline-start: var(--ion-padding, 16px);\r\n  }\r\n}\n.ion-padding-end {\r\n  --padding-end: var(--ion-padding, 16px);\r\n  padding-right: var(--ion-padding, 16px);\r\n}\n@supports ((-webkit-margin-start: 0) or (margin-inline-start: 0)) or (-webkit-margin-start: 0) {\r\n  .ion-padding-end {\r\n    padding-right: unset;\r\n    -webkit-padding-end: var(--ion-padding, 16px);\r\n    padding-inline-end: var(--ion-padding, 16px);\r\n  }\r\n}\n.ion-padding-bottom {\r\n  --padding-bottom: var(--ion-padding, 16px);\r\n  padding-bottom: var(--ion-padding, 16px);\r\n}\n.ion-padding-vertical {\r\n  --padding-top: var(--ion-padding, 16px);\r\n  --padding-bottom: var(--ion-padding, 16px);\r\n  padding-top: var(--ion-padding, 16px);\r\n  padding-bottom: var(--ion-padding, 16px);\r\n}\n.ion-padding-horizontal {\r\n  --padding-start: var(--ion-padding, 16px);\r\n  --padding-end: var(--ion-padding, 16px);\r\n  padding-left: var(--ion-padding, 16px);\r\n  padding-right: var(--ion-padding, 16px);\r\n}\n@supports ((-webkit-margin-start: 0) or (margin-inline-start: 0)) or (-webkit-margin-start: 0) {\r\n  .ion-padding-horizontal {\r\n    padding-left: unset;\r\n    padding-right: unset;\r\n    -webkit-padding-start: var(--ion-padding, 16px);\r\n    padding-inline-start: var(--ion-padding, 16px);\r\n    -webkit-padding-end: var(--ion-padding, 16px);\r\n    padding-inline-end: var(--ion-padding, 16px);\r\n  }\r\n}\n.ion-no-margin {\r\n  --margin-start: 0;\r\n  --margin-end: 0;\r\n  --margin-top: 0;\r\n  --margin-bottom: 0;\r\n  margin-left: 0;\r\n  margin-right: 0;\r\n  margin-top: 0;\r\n  margin-bottom: 0;\r\n}\n.ion-margin {\r\n  --margin-start: var(--ion-margin, 16px);\r\n  --margin-end: var(--ion-margin, 16px);\r\n  --margin-top: var(--ion-margin, 16px);\r\n  --margin-bottom: var(--ion-margin, 16px);\r\n  margin-left: var(--ion-margin, 16px);\r\n  margin-right: var(--ion-margin, 16px);\r\n  margin-top: var(--ion-margin, 16px);\r\n  margin-bottom: var(--ion-margin, 16px);\r\n}\n@supports ((-webkit-margin-start: 0) or (margin-inline-start: 0)) or (-webkit-margin-start: 0) {\r\n  .ion-margin {\r\n    margin-left: unset;\r\n    margin-right: unset;\r\n    -webkit-margin-start: var(--ion-margin, 16px);\r\n    margin-inline-start: var(--ion-margin, 16px);\r\n    -webkit-margin-end: var(--ion-margin, 16px);\r\n    margin-inline-end: var(--ion-margin, 16px);\r\n  }\r\n}\n.ion-margin-top {\r\n  --margin-top: var(--ion-margin, 16px);\r\n  margin-top: var(--ion-margin, 16px);\r\n}\n.ion-margin-start {\r\n  --margin-start: var(--ion-margin, 16px);\r\n  margin-left: var(--ion-margin, 16px);\r\n}\n@supports ((-webkit-margin-start: 0) or (margin-inline-start: 0)) or (-webkit-margin-start: 0) {\r\n  .ion-margin-start {\r\n    margin-left: unset;\r\n    -webkit-margin-start: var(--ion-margin, 16px);\r\n    margin-inline-start: var(--ion-margin, 16px);\r\n  }\r\n}\n.ion-margin-end {\r\n  --margin-end: var(--ion-margin, 16px);\r\n  margin-right: var(--ion-margin, 16px);\r\n}\n@supports ((-webkit-margin-start: 0) or (margin-inline-start: 0)) or (-webkit-margin-start: 0) {\r\n  .ion-margin-end {\r\n    margin-right: unset;\r\n    -webkit-margin-end: var(--ion-margin, 16px);\r\n    margin-inline-end: var(--ion-margin, 16px);\r\n  }\r\n}\n.ion-margin-bottom {\r\n  --margin-bottom: var(--ion-margin, 16px);\r\n  margin-bottom: var(--ion-margin, 16px);\r\n}\n.ion-margin-vertical {\r\n  --margin-top: var(--ion-margin, 16px);\r\n  --margin-bottom: var(--ion-margin, 16px);\r\n  margin-top: var(--ion-margin, 16px);\r\n  margin-bottom: var(--ion-margin, 16px);\r\n}\n.ion-margin-horizontal {\r\n  --margin-start: var(--ion-margin, 16px);\r\n  --margin-end: var(--ion-margin, 16px);\r\n  margin-left: var(--ion-margin, 16px);\r\n  margin-right: var(--ion-margin, 16px);\r\n}\n@supports ((-webkit-margin-start: 0) or (margin-inline-start: 0)) or (-webkit-margin-start: 0) {\r\n  .ion-margin-horizontal {\r\n    margin-left: unset;\r\n    margin-right: unset;\r\n    -webkit-margin-start: var(--ion-margin, 16px);\r\n    margin-inline-start: var(--ion-margin, 16px);\r\n    -webkit-margin-end: var(--ion-margin, 16px);\r\n    margin-inline-end: var(--ion-margin, 16px);\r\n  }\r\n}\n.ion-float-left {\r\n  float: left !important;\r\n}\n.ion-float-right {\r\n  float: right !important;\r\n}\n.ion-float-start {\r\n  float: left !important;\r\n}\n[dir=rtl] .ion-float-start, :host-context([dir=rtl]) .ion-float-start {\r\n  float: right !important;\r\n}\n.ion-float-end {\r\n  float: right !important;\r\n}\n[dir=rtl] .ion-float-end, :host-context([dir=rtl]) .ion-float-end {\r\n  float: left !important;\r\n}\n@media (min-width: 576px) {\r\n  .ion-float-sm-left {\r\n    float: left !important;\r\n  }\r\n\r\n  .ion-float-sm-right {\r\n    float: right !important;\r\n  }\r\n\r\n  .ion-float-sm-start {\r\n    float: left !important;\r\n  }\r\n  [dir=rtl] .ion-float-sm-start, :host-context([dir=rtl]) .ion-float-sm-start {\r\n    float: right !important;\r\n  }\r\n\r\n  .ion-float-sm-end {\r\n    float: right !important;\r\n  }\r\n  [dir=rtl] .ion-float-sm-end, :host-context([dir=rtl]) .ion-float-sm-end {\r\n    float: left !important;\r\n  }\r\n}\n@media (min-width: 768px) {\r\n  .ion-float-md-left {\r\n    float: left !important;\r\n  }\r\n\r\n  .ion-float-md-right {\r\n    float: right !important;\r\n  }\r\n\r\n  .ion-float-md-start {\r\n    float: left !important;\r\n  }\r\n  [dir=rtl] .ion-float-md-start, :host-context([dir=rtl]) .ion-float-md-start {\r\n    float: right !important;\r\n  }\r\n\r\n  .ion-float-md-end {\r\n    float: right !important;\r\n  }\r\n  [dir=rtl] .ion-float-md-end, :host-context([dir=rtl]) .ion-float-md-end {\r\n    float: left !important;\r\n  }\r\n}\n@media (min-width: 992px) {\r\n  .ion-float-lg-left {\r\n    float: left !important;\r\n  }\r\n\r\n  .ion-float-lg-right {\r\n    float: right !important;\r\n  }\r\n\r\n  .ion-float-lg-start {\r\n    float: left !important;\r\n  }\r\n  [dir=rtl] .ion-float-lg-start, :host-context([dir=rtl]) .ion-float-lg-start {\r\n    float: right !important;\r\n  }\r\n\r\n  .ion-float-lg-end {\r\n    float: right !important;\r\n  }\r\n  [dir=rtl] .ion-float-lg-end, :host-context([dir=rtl]) .ion-float-lg-end {\r\n    float: left !important;\r\n  }\r\n}\n@media (min-width: 1200px) {\r\n  .ion-float-xl-left {\r\n    float: left !important;\r\n  }\r\n\r\n  .ion-float-xl-right {\r\n    float: right !important;\r\n  }\r\n\r\n  .ion-float-xl-start {\r\n    float: left !important;\r\n  }\r\n  [dir=rtl] .ion-float-xl-start, :host-context([dir=rtl]) .ion-float-xl-start {\r\n    float: right !important;\r\n  }\r\n\r\n  .ion-float-xl-end {\r\n    float: right !important;\r\n  }\r\n  [dir=rtl] .ion-float-xl-end, :host-context([dir=rtl]) .ion-float-xl-end {\r\n    float: left !important;\r\n  }\r\n}\n.ion-text-center {\r\n  text-align: center !important;\r\n}\n.ion-text-justify {\r\n  text-align: justify !important;\r\n}\n.ion-text-start {\r\n  text-align: start !important;\r\n}\n.ion-text-end {\r\n  text-align: end !important;\r\n}\n.ion-text-left {\r\n  text-align: left !important;\r\n}\n.ion-text-right {\r\n  text-align: right !important;\r\n}\n.ion-text-nowrap {\r\n  white-space: nowrap !important;\r\n}\n.ion-text-wrap {\r\n  white-space: normal !important;\r\n}\n@media (min-width: 576px) {\r\n  .ion-text-sm-center {\r\n    text-align: center !important;\r\n  }\r\n\r\n  .ion-text-sm-justify {\r\n    text-align: justify !important;\r\n  }\r\n\r\n  .ion-text-sm-start {\r\n    text-align: start !important;\r\n  }\r\n\r\n  .ion-text-sm-end {\r\n    text-align: end !important;\r\n  }\r\n\r\n  .ion-text-sm-left {\r\n    text-align: left !important;\r\n  }\r\n\r\n  .ion-text-sm-right {\r\n    text-align: right !important;\r\n  }\r\n\r\n  .ion-text-sm-nowrap {\r\n    white-space: nowrap !important;\r\n  }\r\n\r\n  .ion-text-sm-wrap {\r\n    white-space: normal !important;\r\n  }\r\n}\n@media (min-width: 768px) {\r\n  .ion-text-md-center {\r\n    text-align: center !important;\r\n  }\r\n\r\n  .ion-text-md-justify {\r\n    text-align: justify !important;\r\n  }\r\n\r\n  .ion-text-md-start {\r\n    text-align: start !important;\r\n  }\r\n\r\n  .ion-text-md-end {\r\n    text-align: end !important;\r\n  }\r\n\r\n  .ion-text-md-left {\r\n    text-align: left !important;\r\n  }\r\n\r\n  .ion-text-md-right {\r\n    text-align: right !important;\r\n  }\r\n\r\n  .ion-text-md-nowrap {\r\n    white-space: nowrap !important;\r\n  }\r\n\r\n  .ion-text-md-wrap {\r\n    white-space: normal !important;\r\n  }\r\n}\n@media (min-width: 992px) {\r\n  .ion-text-lg-center {\r\n    text-align: center !important;\r\n  }\r\n\r\n  .ion-text-lg-justify {\r\n    text-align: justify !important;\r\n  }\r\n\r\n  .ion-text-lg-start {\r\n    text-align: start !important;\r\n  }\r\n\r\n  .ion-text-lg-end {\r\n    text-align: end !important;\r\n  }\r\n\r\n  .ion-text-lg-left {\r\n    text-align: left !important;\r\n  }\r\n\r\n  .ion-text-lg-right {\r\n    text-align: right !important;\r\n  }\r\n\r\n  .ion-text-lg-nowrap {\r\n    white-space: nowrap !important;\r\n  }\r\n\r\n  .ion-text-lg-wrap {\r\n    white-space: normal !important;\r\n  }\r\n}\n@media (min-width: 1200px) {\r\n  .ion-text-xl-center {\r\n    text-align: center !important;\r\n  }\r\n\r\n  .ion-text-xl-justify {\r\n    text-align: justify !important;\r\n  }\r\n\r\n  .ion-text-xl-start {\r\n    text-align: start !important;\r\n  }\r\n\r\n  .ion-text-xl-end {\r\n    text-align: end !important;\r\n  }\r\n\r\n  .ion-text-xl-left {\r\n    text-align: left !important;\r\n  }\r\n\r\n  .ion-text-xl-right {\r\n    text-align: right !important;\r\n  }\r\n\r\n  .ion-text-xl-nowrap {\r\n    white-space: nowrap !important;\r\n  }\r\n\r\n  .ion-text-xl-wrap {\r\n    white-space: normal !important;\r\n  }\r\n}\n.ion-text-uppercase {\r\n  /* stylelint-disable-next-line declaration-no-important */\r\n  text-transform: uppercase !important;\r\n}\n.ion-text-lowercase {\r\n  /* stylelint-disable-next-line declaration-no-important */\r\n  text-transform: lowercase !important;\r\n}\n.ion-text-capitalize {\r\n  /* stylelint-disable-next-line declaration-no-important */\r\n  text-transform: capitalize !important;\r\n}\n@media (min-width: 576px) {\r\n  .ion-text-sm-uppercase {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: uppercase !important;\r\n  }\r\n\r\n  .ion-text-sm-lowercase {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: lowercase !important;\r\n  }\r\n\r\n  .ion-text-sm-capitalize {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: capitalize !important;\r\n  }\r\n}\n@media (min-width: 768px) {\r\n  .ion-text-md-uppercase {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: uppercase !important;\r\n  }\r\n\r\n  .ion-text-md-lowercase {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: lowercase !important;\r\n  }\r\n\r\n  .ion-text-md-capitalize {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: capitalize !important;\r\n  }\r\n}\n@media (min-width: 992px) {\r\n  .ion-text-lg-uppercase {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: uppercase !important;\r\n  }\r\n\r\n  .ion-text-lg-lowercase {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: lowercase !important;\r\n  }\r\n\r\n  .ion-text-lg-capitalize {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: capitalize !important;\r\n  }\r\n}\n@media (min-width: 1200px) {\r\n  .ion-text-xl-uppercase {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: uppercase !important;\r\n  }\r\n\r\n  .ion-text-xl-lowercase {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: lowercase !important;\r\n  }\r\n\r\n  .ion-text-xl-capitalize {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: capitalize !important;\r\n  }\r\n}\n.ion-align-self-start {\r\n  align-self: flex-start !important;\r\n}\n.ion-align-self-end {\r\n  align-self: flex-end !important;\r\n}\n.ion-align-self-center {\r\n  align-self: center !important;\r\n}\n.ion-align-self-stretch {\r\n  align-self: stretch !important;\r\n}\n.ion-align-self-baseline {\r\n  align-self: baseline !important;\r\n}\n.ion-align-self-auto {\r\n  align-self: auto !important;\r\n}\n.ion-wrap {\r\n  flex-wrap: wrap !important;\r\n}\n.ion-nowrap {\r\n  flex-wrap: nowrap !important;\r\n}\n.ion-wrap-reverse {\r\n  flex-wrap: wrap-reverse !important;\r\n}\n.ion-justify-content-start {\r\n  justify-content: flex-start !important;\r\n}\n.ion-justify-content-center {\r\n  justify-content: center !important;\r\n}\n.ion-justify-content-end {\r\n  justify-content: flex-end !important;\r\n}\n.ion-justify-content-around {\r\n  justify-content: space-around !important;\r\n}\n.ion-justify-content-between {\r\n  justify-content: space-between !important;\r\n}\n.ion-justify-content-evenly {\r\n  justify-content: space-evenly !important;\r\n}\n.ion-align-items-start {\r\n  align-items: flex-start !important;\r\n}\n.ion-align-items-center {\r\n  align-items: center !important;\r\n}\n.ion-align-items-end {\r\n  align-items: flex-end !important;\r\n}\n.ion-align-items-stretch {\r\n  align-items: stretch !important;\r\n}\n.ion-align-items-baseline {\r\n  align-items: baseline !important;\r\n}\n[content-padding] {\n  padding: 20px;\n}\n/*.swiper-slide-active [plans] {\n    border: 2px solid var(--ion-color-primary);\n}*/\n.circleloader {\n  position: absolute;\n  right: 20px;\n  bottom: 22px;\n  font-size: 75px;\n  width: 0.82em;\n  height: 0.82em;\n  border-radius: 50%;\n  float: left;\n  border: 3px solid var(--ion-color-white);\n}\n.circleloader span {\n  position: absolute;\n  width: 100%;\n  z-index: 1;\n  left: 0;\n  top: 0;\n  width: 4.5em;\n  line-height: 4.5em;\n  font-size: 12px;\n  color: var(--ion-color-white);\n  display: block;\n  text-align: center;\n  white-space: nowrap;\n  transition-property: all;\n  transition-duration: 0.2s;\n  transition-timing-function: ease-out;\n}\n.circleloader .slice {\n  transform: rotate(180deg);\n  position: absolute;\n  left: -3px;\n  top: -3px;\n  width: 0.82em;\n  height: 0.82em;\n}\n.circleloader .bar, .circleloader .fill {\n  position: absolute;\n  border: 3px solid var(--ion-color-green);\n  width: 0.82em;\n  height: 0.82em;\n  clip: rect(0em, 0.6em, 1em, 0em);\n  border-radius: 50%;\n}\n[slidetable] .swiper-pagination.swiper-pagination-bullets {\n  bottom: -6px;\n}\n.search ion-searchbar {\n  padding: 0px;\n  --box-shadow: 0px 0px 10px rgba(0,0,0,0.1);\n}\n.search ion-searchbar .searchbar-search-icon {\n  right: 16px;\n  top: 16px;\n  left: initial;\n  color: #d1cfcf;\n}\n.search ion-searchbar input.searchbar-input {\n  font-size: 16px;\n  line-height: 34px !important;\n  background: var(--ion-color-white);\n  color: #d1cfcf;\n  border-radius: 30px;\n  --placeholder-opacity: 1;\n  -webkit-padding-start: 20px !important;\n          padding-inline-start: 20px !important;\n  -webkit-padding-end: 15px !important;\n          padding-inline-end: 15px !important;\n}\n.search ion-searchbar .searchbar-clear-button {\n  right: 40px;\n}", "", {
        "version": 3,
        "sources": ["global.scss", "../node_modules/@ionic/angular/src/css/core.scss", "../node_modules/@ionic/angular/css/core.css", "../node_modules/@ionic/angular/src/themes/ionic.mixins.scss", "../node_modules/@ionic/angular/src/themes/ionic.globals.scss", "../node_modules/@ionic/angular/src/components/menu/menu.ios.vars.scss", "../node_modules/@ionic/angular/src/components/menu/menu.md.vars.scss", "../node_modules/@ionic/angular/src/css/normalize.scss", "../node_modules/@ionic/angular/css/normalize.css", "../node_modules/@ionic/angular/src/css/structure.scss", "../node_modules/@ionic/angular/css/structure.css", "../node_modules/@ionic/angular/src/css/typography.scss", "../node_modules/@ionic/angular/css/typography.css", "../node_modules/@ionic/angular/src/css/display.scss", "../node_modules/@ionic/angular/css/display.css", "../node_modules/@ionic/angular/src/css/padding.scss", "../node_modules/@ionic/angular/css/padding.css", "../node_modules/@ionic/angular/src/css/float-elements.scss", "../node_modules/@ionic/angular/css/float-elements.css", "../node_modules/@ionic/angular/src/css/text-alignment.scss", "../node_modules/@ionic/angular/css/text-alignment.css", "../node_modules/@ionic/angular/src/css/text-transformation.scss", "../node_modules/@ionic/angular/css/text-transformation.css", "../node_modules/@ionic/angular/src/css/flex-utils.scss", "../node_modules/@ionic/angular/css/flex-utils.css"],
        "names": [],
        "mappings": "AAAA;;;;;;;;;EAAA;AAWA,4DAAA;ACHA;EACE,6FAAA;ACPF;ADSA;EACE,0DAAA;ACNF;ADSA;EACE,0CAAA;ACNF;ADSA;EACE,uCAAA;ACNF;ADSA;EACE,gBAAA;ACNF;ADmBA;EACE,gBAAA;AChBF;ADsBA;EACE,sBAAA;ACnBF;AD4CE;EATA,8DAAA;EACA,2EAAA;EACA,wEAAA;EACA,yFAAA;EACA,qEAAA;EACA,mEAAA;AC/BF;ADmCE;EATA,gEAAA;EACA,6EAAA;EACA,0EAAA;EACA,2FAAA;EACA,uEAAA;EACA,qEAAA;ACtBF;AD0BE;EATA,+DAAA;EACA,2EAAA;EACA,yEAAA;EACA,0FAAA;EACA,sEAAA;EACA,oEAAA;ACbF;ADiBE;EATA,8DAAA;EACA,2EAAA;EACA,wEAAA;EACA,yFAAA;EACA,qEAAA;EACA,mEAAA;ACJF;ADQE;EATA,8DAAA;EACA,0EAAA;EACA,wEAAA;EACA,mFAAA;EACA,qEAAA;EACA,mEAAA;ACKF;ADDE;EATA,6DAAA;EACA,yEAAA;EACA,uEAAA;EACA,wFAAA;EACA,oEAAA;EACA,kEAAA;ACcF;ADVE;EATA,4DAAA;EACA,0EAAA;EACA,sEAAA;EACA,iFAAA;EACA,mEAAA;EACA,iEAAA;ACuBF;ADnBE;EATA,6DAAA;EACA,2EAAA;EACA,uEAAA;EACA,wFAAA;EACA,oEAAA;EACA,kEAAA;ACgCF;AD5BE;EATA,2DAAA;EACA,sEAAA;EACA,qEAAA;EACA,sFAAA;EACA,kEAAA;EACA,gEAAA;ACyCF;AD5BA;EE8NM,OF7NuB;EE8NvB,QF9NiB;EEuPrB,MFvPkB;EEwPlB,SFxPwB;EAExB,aAAA;EACA,kBAAA;EAEA,sBAAA;EACA,8BAAA;EAEA,0BAAA;EACA,gBAAA;EACA,UGxC+B;AFuEjC;AD5BA;EACE,kBAAA;AC+BF;AD5BA;;;;;;;;;;;;;;;EAeE,yDAAA;EACA,wBAAA;AC+BF;AD5BA;EACE,UAAA;AC+BF;AD5BA;EACE,cAAA;AC+BF;ADxBA;EACE,6BAAA;AC2BF;ADxBA;EACE;IACE,iDAAA;EC2BF;AACF;ADvBA;EACE;IACE,kDAAA;IACA,wDAAA;IACA,oDAAA;IACA,sDAAA;ECyBF;AACF;ADtBA;EACE;IACE,6CAAA;IACA,mDAAA;IACA,+CAAA;IACA,iDAAA;ECwBF;AACF;ADjBA;;EAEE,cAAA;ACmBF;ADXA;EEyUM,iCAAA;AD1TN;ADXA;EACE,eAAA;EACA,0BAAA;EAIA,oBAAA;ACWF;ADRA;EACE,2CI7K+B;AHwLjC;ADRA;EACE,0CI9K+B;AHyLjC;ADJA;EACE,4CK5L8B;AJmMhC;ADJA;EACE,4CKhM8B;AJuMhC;AFlMA,wCAAA;AOPA;;;;EAIE,wBAAA;ACNF;ADWA;EACE,aAAA;EAEA,SAAA;ACTF;ADiBA;;EAEE,iBAAA;ACdF;ADsBA;EACE,eAAA;EAEA,SAAA;ACpBF;ADwBA;EACE,gBAAA;ACrBF;AD6BA;EACE,gBAAA;AC1BF;AD6BA;EACE,WAAA;EAEA,eAAA;EAEA,uBAAA;AC5BF;ADgCA;EACE,cAAA;AC7BF;ADiCA;;;;EAIE,iCAAA;EACA,cAAA;AC9BF;AD8CA;;;;EAIE,oBAAA;EACA,mBAAA;AC3CF;AD8CA;EACE,cAAA;EAEA,YAAA;EAEA,aAAA;EACA,cAAA;AC7CF;ADgDA;EACE,iBAAA;AC7CF;AD4CA;EACE,iBAAA;AC7CF;ADgDA;;;;EAIE,SAAA;EAEA,aAAA;EACA,cAAA;AC9CF;ADsDA;;;EAGE,eAAA;EAEA,0BAAA;ACpDF;ADwDA;;;;;;;;;;;;;;;;;;EAkBE,0BAAA;ACrDF;ADwDA;;EAEE,oBAAA;ACrDF;ADwDA;EACE,SAAA;EACA,gBAAA;EACA,oBAAA;EACA,mBAAA;EACA,qBAAA;EACA,cAAA;EACA,oBAAA;EACA,eAAA;EAEA,0BAAA;ACtDF;ADyDA;EACE,eAAA;ACtDF;AD0DA;;;EAGE,eAAA;ACvDF;AD2DA;;EAEE,UAAA;EAEA,SAAA;ACzDF;AD+DA;;EAEE,UAAA;EAEA,sBAAA;AC7DF;ADmEA;;EAEE,YAAA;AChEF;ADsEA;;EAEE,wBAAA;ACnEF;AD2EA;EACE,yBAAA;EACA,iBAAA;ACxEF;AD2EA;;EAEE,UAAA;ACxEF;ACxJA;EACE,sBAAA;EAEA,6CAAA;EACA,wCAAA;EACA,2BAAA;ACTF;ADYA;EACE,WAAA;EACA,YAAA;EAEA,8BAAA;KAAA,2BAAA;UAAA,sBAAA;ACVF;ADaA;EACE,aAAA;ACVF;ADaA;EACE,aAAA;ACVF;ADaA;ENoBE,kCAAA;EACA,mCAAA;EAoKE,cMvLc;ENwLd,eMxLc;EN4NhB,aM5NgB;EN6NhB,gBM7NgB;ENuLd,eMtLe;ENuLf,gBMvLe;EN2NjB,cM3NiB;EN4NjB,iBM5NiB;EAEjB,eAAA;EAEA,WAAA;EACA,eAAA;EACA,YAAA;EACA,gBAAA;EAEA,kCAAA;EAEA,gBAAA;EAEA,0BAAA;EAEA,uBAAA;EAEA,yBAAA;EAEA,qBAAA;EAEA,2BAAA;EAEA,8BAAA;KAAA,2BAAA;UAAA,sBAAA;ACbF;ACdA;EACE,mCAAA;AC9BF;ADiCA;EACE,6BAAA;EACA,wCAAA;AC9BF;ADiCA;;;;;;ERsNE,gBQhNgB;ERiNhB,mBQjN4B;EAE5B,gBAxC6B;EA0C7B,gBAvC6B;ACQ/B;ADkCA;ERyME,gBQxMgB;EAEhB,eA1C6B;ACS/B;ADoCA;ERmME,gBQlMgB;EAEhB,eA7C6B;ACU/B;ADsCA;EACE,eA9C6B;ACU/B;ADuCA;EACE,eA/C6B;ACW/B;ADuCA;EACE,eAhD6B;ACY/B;ADuCA;EACE,eAjD6B;ACa/B;ADuCA;EACE,cAAA;ACpCF;ADuCA;;EAEE,kBAAA;EAEA,cAAA;EAEA,cAAA;EAEA,wBAAA;ACvCF;AD0CA;EACE,WAAA;ACvCF;AD0CA;EACE,eAAA;ACvCF;ACtDA;EACE,wBAAA;ACPF;ADiBI;EACE,wBAAA;ACdN;ADqBI;EACE,wBAAA;AClBN;AX6FI;EUpFA;IACE,wBAAA;ECLJ;AACF;AXgII;EUrHA;IACE,wBAAA;ECRJ;AACF;AXkFI;EUpFA;IACE,wBAAA;ECKJ;AACF;AXsHI;EUrHA;IACE,wBAAA;ECEJ;AACF;AXwEI;EUpFA;IACE,wBAAA;ECeJ;AACF;AX4GI;EUrHA;IACE,wBAAA;ECYJ;AACF;AX8DI;EUpFA;IACE,wBAAA;ECyBJ;AACF;AXkGI;EUrHA;IACE,wBAAA;ECsBJ;AACF;Ad/BA,iDAAA;AeJA;EACE,kBAAA;EACA,gBAAA;EACA,gBAAA;EACA,mBAAA;EZqME,eYnMe;EZoMf,gBYpMe;EZwOjB,cYxOiB;EZyOjB,iBYzOiB;ACbnB;ADgBA;EACE,yCAAA;EACA,uCAAA;EACA,uCAAA;EACA,0CAAA;EZgME,sCYnNM;EZoNN,uCYpNM;EZoPR,qCYpPQ;EZqPR,wCYrPQ;ACUV;Ab6MM;EACE;IAEI,mBAAA;IAGA,oBAAA;IAGF,+CYhOA;IZiOA,8CYjOA;IZkOA,6CYlOA;IZmOA,4CYnOA;ECmBR;AACF;ADIA;EACE,uCAAA;EZ2NA,qCYpPQ;ACyBV;ADKA;EACE,yCAAA;EZoLE,sCYnNM;AC6BV;Ab0LM;EACE;IAEI,mBAAA;IAMF,+CYhOA;IZiOA,8CYjOA;ECmCR;AACF;ADAA;EACE,uCAAA;EZ+KE,uCYpNM;ACyCV;Ab8KM;EACE;IAKI,oBAAA;IAKF,6CYlOA;IZmOA,4CYnOA;EC+CR;AACF;ADNA;EACE,0CAAA;EZ0MA,wCYrPQ;ACqDV;ADLA;EACE,uCAAA;EACA,0CAAA;EZkMA,qCYpPQ;EZqPR,wCYrPQ;AC2DV;ADJA;EACE,yCAAA;EACA,uCAAA;EZ0JE,sCYnNM;EZoNN,uCYpNM;ACiEV;AbsJM;EACE;IAEI,mBAAA;IAGA,oBAAA;IAGF,+CYhOA;IZiOA,8CYjOA;IZkOA,6CYlOA;IZmOA,4CYnOA;EC0ER;AACF;ADTA;EACE,iBAAA;EACA,eAAA;EACA,eAAA;EACA,kBAAA;EZyIE,cYvIc;EZwId,eYxIc;EZ4KhB,aY5KgB;EZ6KhB,gBY7KgB;ACclB;ADXA;EACE,uCAAA;EACA,qCAAA;EACA,qCAAA;EACA,wCAAA;EZoIE,oCYlNK;EZmNL,qCYnNK;EZmPP,mCYnPO;EZoPP,sCYpPO;ACgGT;AbsHM;EACE;IAEI,kBAAA;IAGA,mBAAA;IAGF,6CY/ND;IZgOC,4CYhOD;IZiOC,2CYjOD;IZkOC,0CYlOD;ECyGP;AACF;ADvBA;EACE,qCAAA;EZ+JA,mCYnPO;AC+GT;ADtBA;EACE,uCAAA;EZwHE,oCYlNK;ACmHT;AbmGM;EACE;IAEI,kBAAA;IAMF,6CY/ND;IZgOC,4CYhOD;ECyHP;AACF;AD3BA;EACE,qCAAA;EZmHE,qCYnNK;AC+HT;AbuFM;EACE;IAKI,mBAAA;IAKF,2CYjOD;IZkOC,0CYlOD;ECqIP;AACF;ADjCA;EACE,wCAAA;EZ8IA,sCYpPO;AC2IT;ADhCA;EACE,qCAAA;EACA,wCAAA;EZsIA,mCYnPO;EZoPP,sCYpPO;ACiJT;AD/BA;EACE,uCAAA;EACA,qCAAA;EZ8FE,oCYlNK;EZmNL,qCYnNK;ACuJT;Ab+DM;EACE;IAEI,kBAAA;IAGA,mBAAA;IAGF,6CY/ND;IZgOC,4CYhOD;IZiOC,2CYjOD;IZkOC,0CYlOD;ECgKP;AACF;AC9JI;Ed0YE,sBAAA;AetZN;ADgBI;EdsYE,uBAAA;AelZN;ADgBI;EdoXE,sBAAA;AehYN;AfmKW;EAgOL,uBAAA;AehYN;ADaI;EduXE,uBAAA;AehYN;Af4JW;EAuOL,sBAAA;AehYN;AfmFI;EczFA;Id0YE,sBAAA;Ee/XJ;;EDPE;IdsYE,uBAAA;Ee3XJ;;EDPE;IdoXE,sBAAA;EezWJ;Ef4IS;IAgOL,uBAAA;EezWJ;;EDVE;IduXE,uBAAA;EezWJ;EfqIS;IAuOL,sBAAA;EezWJ;AACF;Af2DI;EczFA;Id0YE,sBAAA;EexWJ;;ED9BE;IdsYE,uBAAA;EepWJ;;ED9BE;IdoXE,sBAAA;EelVJ;EfqHS;IAgOL,uBAAA;EelVJ;;EDjCE;IduXE,uBAAA;EelVJ;Ef8GS;IAuOL,sBAAA;EelVJ;AACF;AfoCI;EczFA;Id0YE,sBAAA;EejVJ;;EDrDE;IdsYE,uBAAA;Ee7UJ;;EDrDE;IdoXE,sBAAA;Ee3TJ;Ef8FS;IAgOL,uBAAA;Ee3TJ;;EDxDE;IduXE,uBAAA;Ee3TJ;EfuFS;IAuOL,sBAAA;Ee3TJ;AACF;AfaI;EczFA;Id0YE,sBAAA;Ee1TJ;;ED5EE;IdsYE,uBAAA;EetTJ;;ED5EE;IdoXE,sBAAA;EepSJ;EfuES;IAgOL,uBAAA;EepSJ;;ED/EE;IduXE,uBAAA;EepSJ;EfgES;IAuOL,sBAAA;EepSJ;AACF;ACnGI;EACE,6BAAA;ACbN;ADgBI;EACE,8BAAA;ACbN;ADgBI;EACE,4BAAA;ACbN;ADgBI;EACE,0BAAA;ACbN;ADgBI;EACE,2BAAA;ACbN;ADgBI;EACE,4BAAA;ACbN;ADgBI;EACE,8BAAA;ACbN;ADgBI;EACE,8BAAA;ACbN;AjByEI;EgBzFA;IACE,6BAAA;ECoBJ;;EDjBE;IACE,8BAAA;ECoBJ;;EDjBE;IACE,4BAAA;ECoBJ;;EDjBE;IACE,0BAAA;ECoBJ;;EDjBE;IACE,2BAAA;ECoBJ;;EDjBE;IACE,4BAAA;ECoBJ;;EDjBE;IACE,8BAAA;ECoBJ;;EDjBE;IACE,8BAAA;ECoBJ;AACF;AjBuCI;EgBzFA;IACE,6BAAA;ECqDJ;;EDlDE;IACE,8BAAA;ECqDJ;;EDlDE;IACE,4BAAA;ECqDJ;;EDlDE;IACE,0BAAA;ECqDJ;;EDlDE;IACE,2BAAA;ECqDJ;;EDlDE;IACE,4BAAA;ECqDJ;;EDlDE;IACE,8BAAA;ECqDJ;;EDlDE;IACE,8BAAA;ECqDJ;AACF;AjBMI;EgBzFA;IACE,6BAAA;ECsFJ;;EDnFE;IACE,8BAAA;ECsFJ;;EDnFE;IACE,4BAAA;ECsFJ;;EDnFE;IACE,0BAAA;ECsFJ;;EDnFE;IACE,2BAAA;ECsFJ;;EDnFE;IACE,4BAAA;ECsFJ;;EDnFE;IACE,8BAAA;ECsFJ;;EDnFE;IACE,8BAAA;ECsFJ;AACF;AjB3BI;EgBzFA;IACE,6BAAA;ECuHJ;;EDpHE;IACE,8BAAA;ECuHJ;;EDpHE;IACE,4BAAA;ECuHJ;;EDpHE;IACE,0BAAA;ECuHJ;;EDpHE;IACE,2BAAA;ECuHJ;;EDpHE;IACE,4BAAA;ECuHJ;;EDpHE;IACE,8BAAA;ECuHJ;;EDpHE;IACE,8BAAA;ECuHJ;AACF;ACrJI;EACE,yDAAA;EACA,oCAAA;ACbN;ADgBI;EACE,yDAAA;EACA,oCAAA;ACbN;ADgBI;EACE,yDAAA;EACA,qCAAA;ACbN;AnB0FI;EkBzFA;IACE,yDAAA;IACA,oCAAA;ECGJ;;EDAE;IACE,yDAAA;IACA,oCAAA;ECGJ;;EDAE;IACE,yDAAA;IACA,qCAAA;ECGJ;AACF;AnByEI;EkBzFA;IACE,yDAAA;IACA,oCAAA;ECmBJ;;EDhBE;IACE,yDAAA;IACA,oCAAA;ECmBJ;;EDhBE;IACE,yDAAA;IACA,qCAAA;ECmBJ;AACF;AnByDI;EkBzFA;IACE,yDAAA;IACA,oCAAA;ECmCJ;;EDhCE;IACE,yDAAA;IACA,oCAAA;ECmCJ;;EDhCE;IACE,yDAAA;IACA,qCAAA;ECmCJ;AACF;AnByCI;EkBzFA;IACE,yDAAA;IACA,oCAAA;ECmDJ;;EDhDE;IACE,yDAAA;IACA,oCAAA;ECmDJ;;EDhDE;IACE,yDAAA;IACA,qCAAA;ECmDJ;AACF;ACtEA;EACE,iCAAA;ACPF;ADUA;EACE,+BAAA;ACPF;ADUA;EACE,6BAAA;ACPF;ADUA;EACE,8BAAA;ACPF;ADUA;EACE,+BAAA;ACPF;ADUA;EACE,2BAAA;ACPF;ADcA;EACE,0BAAA;ACXF;ADcA;EACE,4BAAA;ACXF;ADcA;EACE,kCAAA;ACXF;ADkBA;EACE,sCAAA;ACfF;ADkBA;EACE,kCAAA;ACfF;ADkBA;EACE,oCAAA;ACfF;ADkBA;EACE,wCAAA;ACfF;ADkBA;EACE,yCAAA;ACfF;ADkBA;EACE,wCAAA;ACfF;ADsBA;EACE,kCAAA;ACnBF;ADsBA;EACE,8BAAA;ACnBF;ADsBA;EACE,gCAAA;ACnBF;ADsBA;EACE,+BAAA;ACnBF;ADsBA;EACE,gCAAA;ACnBF;AxBpDA;EAEI,aAAA;AAHJ;AAIC;;EAAA;AAGD;EACA,kBAAA;EACI,WAAA;EACA,YAAA;EACA,eAAA;EACG,aAAA;EACH,cAAA;EACA,kBAAA;EACA,WAAA;EACA,wCAAA;AADJ;AAEE;EACE,kBAAA;EACA,WAAA;EACA,UAAA;EACA,OAAA;EACA,MAAA;EACE,YAAA;EACF,kBAAA;EACA,eAAA;EACA,6BAAA;EACA,cAAA;EACA,kBAAA;EACA,mBAAA;EACA,wBAAA;EACA,yBAAA;EACA,oCAAA;AAAJ;AAEA;EAAQ,yBAAA;EACF,kBAAA;EACF,UAAA;EACA,SAAA;EACH,aAAA;EACG,cAAA;AACJ;AACA;EAEA,kBAAA;EACI,wCAAA;EACA,aAAA;EACA,cAAA;EACA,gCAAA;EACA,kBAAA;AAAJ;AAKA;EAEA,YAAA;AAHA;AASA;EAEI,YAAA;EACA,0CAAA;AAPJ;AAQC;EACG,WAAA;EAAgB,SAAA;EAChB,aAAA;EACA,cAAA;AALJ;AAOC;EACS,eAAA;EAAgB,4BAAA;EACzB,kCAAA;EACA,cAAA;EACG,mBAAA;EAAwB,wBAAA;EACxB,sCAAA;UAAA,qCAAA;EACA,oCAAA;UAAA,mCAAA;AAHJ;AAKC;EAEG,WAAA;AAJJ",
        "file": "global.scss",
        "sourcesContent": ["/*\r\n * App Global CSS\r\n * ----------------------------------------------------------------------------\r\n * Put style rules here that you want to apply globally. These styles are for\r\n * the entire app and not just one component. Additionally, this file can be\r\n * used as an entry point to import other CSS/Sass files to be included in the\r\n * output CSS.\r\n * For more information on global stylesheets, visit the documentation:\r\n * https://ionicframework.com/docs/layout/global-stylesheets\r\n */\r\n\r\n/* Core CSS required for Ionic components to work properly */\r\n@import \"~@ionic/angular/css/core.css\";\r\n\r\n/* Basic CSS for apps built with Ionic */\r\n@import \"~@ionic/angular/css/normalize.css\";\r\n@import \"~@ionic/angular/css/structure.css\";\r\n@import \"~@ionic/angular/css/typography.css\";\r\n@import '~@ionic/angular/css/display.css';\r\n\r\n/* Optional CSS utils that can be commented out */\r\n@import \"~@ionic/angular/css/padding.css\";\r\n@import \"~@ionic/angular/css/float-elements.css\";\r\n@import \"~@ionic/angular/css/text-alignment.css\";\r\n@import \"~@ionic/angular/css/text-transformation.css\";\r\n@import \"~@ionic/angular/css/flex-utils.css\";\r\n[content-padding]\r\n{\r\n    padding:20px;\r\n}/*.swiper-slide-active [plans] {\r\n    border: 2px solid var(--ion-color-primary);\r\n}*/\r\n.circleloader {\r\nposition: absolute;\r\n    right: 20px;\r\n    bottom: 22px;\r\n    font-size: 75px;\r\n       width: 0.82em;\r\n    height: 0.82em;\r\n    border-radius: 50%;\r\n    float: left;\r\n    border: 3px solid var(--ion-color-white);\r\n\t span {\r\n    position: absolute;\r\n    width: 100%;\r\n    z-index: 1;\r\n    left: 0;\r\n    top: 0;\r\n      width: 4.5em;\r\n    line-height: 4.5em;\r\n    font-size: 12px;\r\n    color: var(--ion-color-white);\r\n    display: block;\r\n    text-align: center;\r\n    white-space: nowrap;\r\n    transition-property: all;\r\n    transition-duration: 0.2s;\r\n    transition-timing-function: ease-out;\r\n}\r\n.slice {transform: rotate(180deg);\r\n      position: absolute;\r\n    left: -3px;\r\n    top: -3px;    \r\n\twidth: 0.82em;\r\n    height: 0.82em;\r\n}\r\n.bar  , .fill\r\n{\r\nposition: absolute;\r\n    border: 3px  solid var(--ion-color-green);\r\n    width: 0.82em;\r\n    height: 0.82em;\r\n    clip: rect(0em, 0.6em, 1em, 0em);\r\n    border-radius: 50%;\r\n}\r\n}\r\n[slidetable]\r\n{\r\n.swiper-pagination.swiper-pagination-bullets\r\n{\r\nbottom: -6px;\r\n}\r\n}\r\n.search\r\n{\r\n\r\nion-searchbar {\r\n   \r\n\t   padding:0px;\r\n    --box-shadow: 0px 0px 10px rgba(0,0,0,0.1);\r\n\t.searchbar-search-icon{\r\n    right: 16px;    top: 16px;\r\n    left: initial;\r\n    color: #d1cfcf;\r\n}\r\n\tinput.searchbar-input\r\n\t{        font-size: 16px;line-height: 34px!important;\r\n\tbackground: var(--ion-color-white);\r\n\tcolor:#d1cfcf;\r\n    border-radius: 30px;    --placeholder-opacity: 1;\r\n    padding-inline-start: 20px!important;\r\n    padding-inline-end: 15px!important;\r\n\t}\r\n\t.searchbar-clear-button\r\n\t{\r\n\t   right: 40px;\r\n\t}\r\n}\r\n}", null, "html.ios {\r\n  --ion-default-font: -apple-system, BlinkMacSystemFont, \"Helvetica Neue\", \"Roboto\", sans-serif;\r\n}\r\n\r\nhtml.md {\r\n  --ion-default-font: \"Roboto\", \"Helvetica Neue\", sans-serif;\r\n}\r\n\r\nhtml {\r\n  --ion-font-family: var(--ion-default-font);\r\n}\r\n\r\nbody {\r\n  background: var(--ion-background-color);\r\n}\r\n\r\nbody.backdrop-no-scroll {\r\n  overflow: hidden;\r\n}\r\n\r\nhtml.ios ion-modal.modal-card .ion-page > ion-header > ion-toolbar:first-of-type {\r\n  padding-top: 0px;\r\n}\r\n\r\nhtml.ios ion-modal .ion-page {\r\n  border-radius: inherit;\r\n}\r\n\r\n.ion-color-primary {\r\n  --ion-color-base: var(--ion-color-primary, #3880ff) !important;\r\n  --ion-color-base-rgb: var(--ion-color-primary-rgb, 56, 128, 255) !important;\r\n  --ion-color-contrast: var(--ion-color-primary-contrast, #fff) !important;\r\n  --ion-color-contrast-rgb: var(--ion-color-primary-contrast-rgb, 255, 255, 255) !important;\r\n  --ion-color-shade: var(--ion-color-primary-shade, #3171e0) !important;\r\n  --ion-color-tint: var(--ion-color-primary-tint, #4c8dff) !important;\r\n}\r\n\r\n.ion-color-secondary {\r\n  --ion-color-base: var(--ion-color-secondary, #3dc2ff) !important;\r\n  --ion-color-base-rgb: var(--ion-color-secondary-rgb, 61, 194, 255) !important;\r\n  --ion-color-contrast: var(--ion-color-secondary-contrast, #fff) !important;\r\n  --ion-color-contrast-rgb: var(--ion-color-secondary-contrast-rgb, 255, 255, 255) !important;\r\n  --ion-color-shade: var(--ion-color-secondary-shade, #36abe0) !important;\r\n  --ion-color-tint: var(--ion-color-secondary-tint, #50c8ff) !important;\r\n}\r\n\r\n.ion-color-tertiary {\r\n  --ion-color-base: var(--ion-color-tertiary, #5260ff) !important;\r\n  --ion-color-base-rgb: var(--ion-color-tertiary-rgb, 82, 96, 255) !important;\r\n  --ion-color-contrast: var(--ion-color-tertiary-contrast, #fff) !important;\r\n  --ion-color-contrast-rgb: var(--ion-color-tertiary-contrast-rgb, 255, 255, 255) !important;\r\n  --ion-color-shade: var(--ion-color-tertiary-shade, #4854e0) !important;\r\n  --ion-color-tint: var(--ion-color-tertiary-tint, #6370ff) !important;\r\n}\r\n\r\n.ion-color-success {\r\n  --ion-color-base: var(--ion-color-success, #2dd36f) !important;\r\n  --ion-color-base-rgb: var(--ion-color-success-rgb, 45, 211, 111) !important;\r\n  --ion-color-contrast: var(--ion-color-success-contrast, #fff) !important;\r\n  --ion-color-contrast-rgb: var(--ion-color-success-contrast-rgb, 255, 255, 255) !important;\r\n  --ion-color-shade: var(--ion-color-success-shade, #28ba62) !important;\r\n  --ion-color-tint: var(--ion-color-success-tint, #42d77d) !important;\r\n}\r\n\r\n.ion-color-warning {\r\n  --ion-color-base: var(--ion-color-warning, #ffc409) !important;\r\n  --ion-color-base-rgb: var(--ion-color-warning-rgb, 255, 196, 9) !important;\r\n  --ion-color-contrast: var(--ion-color-warning-contrast, #000) !important;\r\n  --ion-color-contrast-rgb: var(--ion-color-warning-contrast-rgb, 0, 0, 0) !important;\r\n  --ion-color-shade: var(--ion-color-warning-shade, #e0ac08) !important;\r\n  --ion-color-tint: var(--ion-color-warning-tint, #ffca22) !important;\r\n}\r\n\r\n.ion-color-danger {\r\n  --ion-color-base: var(--ion-color-danger, #eb445a) !important;\r\n  --ion-color-base-rgb: var(--ion-color-danger-rgb, 235, 68, 90) !important;\r\n  --ion-color-contrast: var(--ion-color-danger-contrast, #fff) !important;\r\n  --ion-color-contrast-rgb: var(--ion-color-danger-contrast-rgb, 255, 255, 255) !important;\r\n  --ion-color-shade: var(--ion-color-danger-shade, #cf3c4f) !important;\r\n  --ion-color-tint: var(--ion-color-danger-tint, #ed576b) !important;\r\n}\r\n\r\n.ion-color-light {\r\n  --ion-color-base: var(--ion-color-light, #f4f5f8) !important;\r\n  --ion-color-base-rgb: var(--ion-color-light-rgb, 244, 245, 248) !important;\r\n  --ion-color-contrast: var(--ion-color-light-contrast, #000) !important;\r\n  --ion-color-contrast-rgb: var(--ion-color-light-contrast-rgb, 0, 0, 0) !important;\r\n  --ion-color-shade: var(--ion-color-light-shade, #d7d8da) !important;\r\n  --ion-color-tint: var(--ion-color-light-tint, #f5f6f9) !important;\r\n}\r\n\r\n.ion-color-medium {\r\n  --ion-color-base: var(--ion-color-medium, #92949c) !important;\r\n  --ion-color-base-rgb: var(--ion-color-medium-rgb, 146, 148, 156) !important;\r\n  --ion-color-contrast: var(--ion-color-medium-contrast, #fff) !important;\r\n  --ion-color-contrast-rgb: var(--ion-color-medium-contrast-rgb, 255, 255, 255) !important;\r\n  --ion-color-shade: var(--ion-color-medium-shade, #808289) !important;\r\n  --ion-color-tint: var(--ion-color-medium-tint, #9d9fa6) !important;\r\n}\r\n\r\n.ion-color-dark {\r\n  --ion-color-base: var(--ion-color-dark, #222428) !important;\r\n  --ion-color-base-rgb: var(--ion-color-dark-rgb, 34, 36, 40) !important;\r\n  --ion-color-contrast: var(--ion-color-dark-contrast, #fff) !important;\r\n  --ion-color-contrast-rgb: var(--ion-color-dark-contrast-rgb, 255, 255, 255) !important;\r\n  --ion-color-shade: var(--ion-color-dark-shade, #1e2023) !important;\r\n  --ion-color-tint: var(--ion-color-dark-tint, #383a3e) !important;\r\n}\r\n\r\n.ion-page {\r\n  left: 0;\r\n  right: 0;\r\n  top: 0;\r\n  bottom: 0;\r\n  display: flex;\r\n  position: absolute;\r\n  flex-direction: column;\r\n  justify-content: space-between;\r\n  contain: layout size style;\r\n  overflow: hidden;\r\n  z-index: 0;\r\n}\r\n\r\n.split-pane-visible > .ion-page.split-pane-main {\r\n  position: relative;\r\n}\r\n\r\nion-route,\r\nion-route-redirect,\r\nion-router,\r\nion-select-option,\r\nion-nav-controller,\r\nion-menu-controller,\r\nion-action-sheet-controller,\r\nion-alert-controller,\r\nion-loading-controller,\r\nion-modal-controller,\r\nion-picker-controller,\r\nion-popover-controller,\r\nion-toast-controller,\r\n.ion-page-hidden,\r\n[hidden] {\r\n  /* stylelint-disable-next-line declaration-no-important */\r\n  display: none !important;\r\n}\r\n\r\n.ion-page-invisible {\r\n  opacity: 0;\r\n}\r\n\r\n.can-go-back > ion-header ion-back-button {\r\n  display: block;\r\n}\r\n\r\nhtml.plt-ios.plt-hybrid, html.plt-ios.plt-pwa {\r\n  --ion-statusbar-padding: 20px;\r\n}\r\n\r\n@supports (padding-top: 20px) {\r\n  html {\r\n    --ion-safe-area-top: var(--ion-statusbar-padding);\r\n  }\r\n}\r\n@supports (padding-top: constant(safe-area-inset-top)) {\r\n  html {\r\n    --ion-safe-area-top: constant(safe-area-inset-top);\r\n    --ion-safe-area-bottom: constant(safe-area-inset-bottom);\r\n    --ion-safe-area-left: constant(safe-area-inset-left);\r\n    --ion-safe-area-right: constant(safe-area-inset-right);\r\n  }\r\n}\r\n@supports (padding-top: env(safe-area-inset-top)) {\r\n  html {\r\n    --ion-safe-area-top: env(safe-area-inset-top);\r\n    --ion-safe-area-bottom: env(safe-area-inset-bottom);\r\n    --ion-safe-area-left: env(safe-area-inset-left);\r\n    --ion-safe-area-right: env(safe-area-inset-right);\r\n  }\r\n}\r\nion-card.ion-color .ion-inherit-color,\r\nion-card-header.ion-color .ion-inherit-color {\r\n  color: inherit;\r\n}\r\n\r\n.menu-content {\r\n  transform: translate3d(0,  0,  0);\r\n}\r\n\r\n.menu-content-open {\r\n  cursor: pointer;\r\n  touch-action: manipulation;\r\n  pointer-events: none;\r\n}\r\n\r\n.ios .menu-content-reveal {\r\n  box-shadow: -8px 0 42px rgba(0, 0, 0, 0.08);\r\n}\r\n\r\n[dir=rtl].ios .menu-content-reveal {\r\n  box-shadow: 8px 0 42px rgba(0, 0, 0, 0.08);\r\n}\r\n\r\n.md .menu-content-reveal {\r\n  box-shadow: 4px 0px 16px rgba(0, 0, 0, 0.18);\r\n}\r\n\r\n.md .menu-content-push {\r\n  box-shadow: 4px 0px 16px rgba(0, 0, 0, 0.18);\r\n}\r\n\r\n/*# sourceMappingURL=core.css.map */\r\n", null, null, null, null, null, "audio,\r\ncanvas,\r\nprogress,\r\nvideo {\r\n  vertical-align: baseline;\r\n}\r\n\r\naudio:not([controls]) {\r\n  display: none;\r\n  height: 0;\r\n}\r\n\r\nb,\r\nstrong {\r\n  font-weight: bold;\r\n}\r\n\r\nimg {\r\n  max-width: 100%;\r\n  border: 0;\r\n}\r\n\r\nsvg:not(:root) {\r\n  overflow: hidden;\r\n}\r\n\r\nfigure {\r\n  margin: 1em 40px;\r\n}\r\n\r\nhr {\r\n  height: 1px;\r\n  border-width: 0;\r\n  box-sizing: content-box;\r\n}\r\n\r\npre {\r\n  overflow: auto;\r\n}\r\n\r\ncode,\r\nkbd,\r\npre,\r\nsamp {\r\n  font-family: monospace, monospace;\r\n  font-size: 1em;\r\n}\r\n\r\nlabel,\r\ninput,\r\nselect,\r\ntextarea {\r\n  font-family: inherit;\r\n  line-height: normal;\r\n}\r\n\r\ntextarea {\r\n  overflow: auto;\r\n  height: auto;\r\n  font: inherit;\r\n  color: inherit;\r\n}\r\n\r\ntextarea::placeholder {\r\n  padding-left: 2px;\r\n}\r\n\r\nform,\r\ninput,\r\noptgroup,\r\nselect {\r\n  margin: 0;\r\n  font: inherit;\r\n  color: inherit;\r\n}\r\n\r\nhtml input[type=button],\r\ninput[type=reset],\r\ninput[type=submit] {\r\n  cursor: pointer;\r\n  -webkit-appearance: button;\r\n}\r\n\r\na,\r\na div,\r\na span,\r\na ion-icon,\r\na ion-label,\r\nbutton,\r\nbutton div,\r\nbutton span,\r\nbutton ion-icon,\r\nbutton ion-label,\r\n.ion-tappable,\r\n[tappable],\r\n[tappable] div,\r\n[tappable] span,\r\n[tappable] ion-icon,\r\n[tappable] ion-label,\r\ninput,\r\ntextarea {\r\n  touch-action: manipulation;\r\n}\r\n\r\na ion-label,\r\nbutton ion-label {\r\n  pointer-events: none;\r\n}\r\n\r\nbutton {\r\n  border: 0;\r\n  border-radius: 0;\r\n  font-family: inherit;\r\n  font-style: inherit;\r\n  font-variant: inherit;\r\n  line-height: 1;\r\n  text-transform: none;\r\n  cursor: pointer;\r\n  -webkit-appearance: button;\r\n}\r\n\r\n[tappable] {\r\n  cursor: pointer;\r\n}\r\n\r\na[disabled],\r\nbutton[disabled],\r\nhtml input[disabled] {\r\n  cursor: default;\r\n}\r\n\r\nbutton::-moz-focus-inner,\r\ninput::-moz-focus-inner {\r\n  padding: 0;\r\n  border: 0;\r\n}\r\n\r\ninput[type=checkbox],\r\ninput[type=radio] {\r\n  padding: 0;\r\n  box-sizing: border-box;\r\n}\r\n\r\ninput[type=number]::-webkit-inner-spin-button,\r\ninput[type=number]::-webkit-outer-spin-button {\r\n  height: auto;\r\n}\r\n\r\ninput[type=search]::-webkit-search-cancel-button,\r\ninput[type=search]::-webkit-search-decoration {\r\n  -webkit-appearance: none;\r\n}\r\n\r\ntable {\r\n  border-collapse: collapse;\r\n  border-spacing: 0;\r\n}\r\n\r\ntd,\r\nth {\r\n  padding: 0;\r\n}\r\n\r\n/*# sourceMappingURL=normalize.css.map */\r\n", null, "* {\r\n  box-sizing: border-box;\r\n  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\r\n  -webkit-tap-highlight-color: transparent;\r\n  -webkit-touch-callout: none;\r\n}\r\n\r\nhtml {\r\n  width: 100%;\r\n  height: 100%;\r\n  text-size-adjust: 100%;\r\n}\r\n\r\nhtml:not(.hydrated) body {\r\n  display: none;\r\n}\r\n\r\nhtml.plt-pwa {\r\n  height: 100vh;\r\n}\r\n\r\nbody {\r\n  -moz-osx-font-smoothing: grayscale;\r\n  -webkit-font-smoothing: antialiased;\r\n  margin-left: 0;\r\n  margin-right: 0;\r\n  margin-top: 0;\r\n  margin-bottom: 0;\r\n  padding-left: 0;\r\n  padding-right: 0;\r\n  padding-top: 0;\r\n  padding-bottom: 0;\r\n  position: fixed;\r\n  width: 100%;\r\n  max-width: 100%;\r\n  height: 100%;\r\n  max-height: 100%;\r\n  text-rendering: optimizeLegibility;\r\n  overflow: hidden;\r\n  touch-action: manipulation;\r\n  -webkit-user-drag: none;\r\n  -ms-content-zooming: none;\r\n  word-wrap: break-word;\r\n  overscroll-behavior-y: none;\r\n  text-size-adjust: none;\r\n}\r\n\r\n/*# sourceMappingURL=structure.css.map */\r\n", null, "html {\r\n  font-family: var(--ion-font-family);\r\n}\r\n\r\na {\r\n  background-color: transparent;\r\n  color: var(--ion-color-primary, #3880ff);\r\n}\r\n\r\nh1,\r\nh2,\r\nh3,\r\nh4,\r\nh5,\r\nh6 {\r\n  margin-top: 16px;\r\n  margin-bottom: 10px;\r\n  font-weight: 500;\r\n  line-height: 1.2;\r\n}\r\nh1 {\r\n  margin-top: 20px;\r\n  font-size: 26px;\r\n}\r\nh2 {\r\n  margin-top: 18px;\r\n  font-size: 24px;\r\n}\r\nh3 {\r\n  font-size: 22px;\r\n}\r\n\r\nh4 {\r\n  font-size: 20px;\r\n}\r\n\r\nh5 {\r\n  font-size: 18px;\r\n}\r\n\r\nh6 {\r\n  font-size: 16px;\r\n}\r\n\r\nsmall {\r\n  font-size: 75%;\r\n}\r\n\r\nsub,\r\nsup {\r\n  position: relative;\r\n  font-size: 75%;\r\n  line-height: 0;\r\n  vertical-align: baseline;\r\n}\r\n\r\nsup {\r\n  top: -0.5em;\r\n}\r\n\r\nsub {\r\n  bottom: -0.25em;\r\n}\r\n\r\n/*# sourceMappingURL=typography.css.map */\r\n", null, ".ion-hide {\r\n  display: none !important;\r\n}\r\n\r\n.ion-hide-up {\r\n  display: none !important;\r\n}\r\n\r\n.ion-hide-down {\r\n  display: none !important;\r\n}\r\n\r\n@media (min-width: 576px) {\r\n  .ion-hide-sm-up {\r\n    display: none !important;\r\n  }\r\n}\r\n@media (max-width: 575.98px) {\r\n  .ion-hide-sm-down {\r\n    display: none !important;\r\n  }\r\n}\r\n@media (min-width: 768px) {\r\n  .ion-hide-md-up {\r\n    display: none !important;\r\n  }\r\n}\r\n@media (max-width: 767.98px) {\r\n  .ion-hide-md-down {\r\n    display: none !important;\r\n  }\r\n}\r\n@media (min-width: 992px) {\r\n  .ion-hide-lg-up {\r\n    display: none !important;\r\n  }\r\n}\r\n@media (max-width: 991.98px) {\r\n  .ion-hide-lg-down {\r\n    display: none !important;\r\n  }\r\n}\r\n@media (min-width: 1200px) {\r\n  .ion-hide-xl-up {\r\n    display: none !important;\r\n  }\r\n}\r\n@media (max-width: 1199.98px) {\r\n  .ion-hide-xl-down {\r\n    display: none !important;\r\n  }\r\n}\r\n\r\n/*# sourceMappingURL=display.css.map */\r\n", null, ".ion-no-padding {\r\n  --padding-start: 0;\r\n  --padding-end: 0;\r\n  --padding-top: 0;\r\n  --padding-bottom: 0;\r\n  padding-left: 0;\r\n  padding-right: 0;\r\n  padding-top: 0;\r\n  padding-bottom: 0;\r\n}\r\n\r\n.ion-padding {\r\n  --padding-start: var(--ion-padding, 16px);\r\n  --padding-end: var(--ion-padding, 16px);\r\n  --padding-top: var(--ion-padding, 16px);\r\n  --padding-bottom: var(--ion-padding, 16px);\r\n  padding-left: var(--ion-padding, 16px);\r\n  padding-right: var(--ion-padding, 16px);\r\n  padding-top: var(--ion-padding, 16px);\r\n  padding-bottom: var(--ion-padding, 16px);\r\n}\r\n@supports (margin-inline-start: 0) or (-webkit-margin-start: 0) {\r\n  .ion-padding {\r\n    padding-left: unset;\r\n    padding-right: unset;\r\n    -webkit-padding-start: var(--ion-padding, 16px);\r\n    padding-inline-start: var(--ion-padding, 16px);\r\n    -webkit-padding-end: var(--ion-padding, 16px);\r\n    padding-inline-end: var(--ion-padding, 16px);\r\n  }\r\n}\r\n\r\n.ion-padding-top {\r\n  --padding-top: var(--ion-padding, 16px);\r\n  padding-top: var(--ion-padding, 16px);\r\n}\r\n.ion-padding-start {\r\n  --padding-start: var(--ion-padding, 16px);\r\n  padding-left: var(--ion-padding, 16px);\r\n}\r\n@supports (margin-inline-start: 0) or (-webkit-margin-start: 0) {\r\n  .ion-padding-start {\r\n    padding-left: unset;\r\n    -webkit-padding-start: var(--ion-padding, 16px);\r\n    padding-inline-start: var(--ion-padding, 16px);\r\n  }\r\n}\r\n\r\n.ion-padding-end {\r\n  --padding-end: var(--ion-padding, 16px);\r\n  padding-right: var(--ion-padding, 16px);\r\n}\r\n@supports (margin-inline-start: 0) or (-webkit-margin-start: 0) {\r\n  .ion-padding-end {\r\n    padding-right: unset;\r\n    -webkit-padding-end: var(--ion-padding, 16px);\r\n    padding-inline-end: var(--ion-padding, 16px);\r\n  }\r\n}\r\n\r\n.ion-padding-bottom {\r\n  --padding-bottom: var(--ion-padding, 16px);\r\n  padding-bottom: var(--ion-padding, 16px);\r\n}\r\n.ion-padding-vertical {\r\n  --padding-top: var(--ion-padding, 16px);\r\n  --padding-bottom: var(--ion-padding, 16px);\r\n  padding-top: var(--ion-padding, 16px);\r\n  padding-bottom: var(--ion-padding, 16px);\r\n}\r\n.ion-padding-horizontal {\r\n  --padding-start: var(--ion-padding, 16px);\r\n  --padding-end: var(--ion-padding, 16px);\r\n  padding-left: var(--ion-padding, 16px);\r\n  padding-right: var(--ion-padding, 16px);\r\n}\r\n@supports (margin-inline-start: 0) or (-webkit-margin-start: 0) {\r\n  .ion-padding-horizontal {\r\n    padding-left: unset;\r\n    padding-right: unset;\r\n    -webkit-padding-start: var(--ion-padding, 16px);\r\n    padding-inline-start: var(--ion-padding, 16px);\r\n    -webkit-padding-end: var(--ion-padding, 16px);\r\n    padding-inline-end: var(--ion-padding, 16px);\r\n  }\r\n}\r\n\r\n.ion-no-margin {\r\n  --margin-start: 0;\r\n  --margin-end: 0;\r\n  --margin-top: 0;\r\n  --margin-bottom: 0;\r\n  margin-left: 0;\r\n  margin-right: 0;\r\n  margin-top: 0;\r\n  margin-bottom: 0;\r\n}\r\n\r\n.ion-margin {\r\n  --margin-start: var(--ion-margin, 16px);\r\n  --margin-end: var(--ion-margin, 16px);\r\n  --margin-top: var(--ion-margin, 16px);\r\n  --margin-bottom: var(--ion-margin, 16px);\r\n  margin-left: var(--ion-margin, 16px);\r\n  margin-right: var(--ion-margin, 16px);\r\n  margin-top: var(--ion-margin, 16px);\r\n  margin-bottom: var(--ion-margin, 16px);\r\n}\r\n@supports (margin-inline-start: 0) or (-webkit-margin-start: 0) {\r\n  .ion-margin {\r\n    margin-left: unset;\r\n    margin-right: unset;\r\n    -webkit-margin-start: var(--ion-margin, 16px);\r\n    margin-inline-start: var(--ion-margin, 16px);\r\n    -webkit-margin-end: var(--ion-margin, 16px);\r\n    margin-inline-end: var(--ion-margin, 16px);\r\n  }\r\n}\r\n\r\n.ion-margin-top {\r\n  --margin-top: var(--ion-margin, 16px);\r\n  margin-top: var(--ion-margin, 16px);\r\n}\r\n.ion-margin-start {\r\n  --margin-start: var(--ion-margin, 16px);\r\n  margin-left: var(--ion-margin, 16px);\r\n}\r\n@supports (margin-inline-start: 0) or (-webkit-margin-start: 0) {\r\n  .ion-margin-start {\r\n    margin-left: unset;\r\n    -webkit-margin-start: var(--ion-margin, 16px);\r\n    margin-inline-start: var(--ion-margin, 16px);\r\n  }\r\n}\r\n\r\n.ion-margin-end {\r\n  --margin-end: var(--ion-margin, 16px);\r\n  margin-right: var(--ion-margin, 16px);\r\n}\r\n@supports (margin-inline-start: 0) or (-webkit-margin-start: 0) {\r\n  .ion-margin-end {\r\n    margin-right: unset;\r\n    -webkit-margin-end: var(--ion-margin, 16px);\r\n    margin-inline-end: var(--ion-margin, 16px);\r\n  }\r\n}\r\n\r\n.ion-margin-bottom {\r\n  --margin-bottom: var(--ion-margin, 16px);\r\n  margin-bottom: var(--ion-margin, 16px);\r\n}\r\n.ion-margin-vertical {\r\n  --margin-top: var(--ion-margin, 16px);\r\n  --margin-bottom: var(--ion-margin, 16px);\r\n  margin-top: var(--ion-margin, 16px);\r\n  margin-bottom: var(--ion-margin, 16px);\r\n}\r\n.ion-margin-horizontal {\r\n  --margin-start: var(--ion-margin, 16px);\r\n  --margin-end: var(--ion-margin, 16px);\r\n  margin-left: var(--ion-margin, 16px);\r\n  margin-right: var(--ion-margin, 16px);\r\n}\r\n@supports (margin-inline-start: 0) or (-webkit-margin-start: 0) {\r\n  .ion-margin-horizontal {\r\n    margin-left: unset;\r\n    margin-right: unset;\r\n    -webkit-margin-start: var(--ion-margin, 16px);\r\n    margin-inline-start: var(--ion-margin, 16px);\r\n    -webkit-margin-end: var(--ion-margin, 16px);\r\n    margin-inline-end: var(--ion-margin, 16px);\r\n  }\r\n}\r\n\r\n/*# sourceMappingURL=padding.css.map */\r\n", null, ".ion-float-left {\r\n  float: left !important;\r\n}\r\n\r\n.ion-float-right {\r\n  float: right !important;\r\n}\r\n\r\n.ion-float-start {\r\n  float: left !important;\r\n}\r\n[dir=rtl] .ion-float-start, :host-context([dir=rtl]) .ion-float-start {\r\n  float: right !important;\r\n}\r\n\r\n.ion-float-end {\r\n  float: right !important;\r\n}\r\n[dir=rtl] .ion-float-end, :host-context([dir=rtl]) .ion-float-end {\r\n  float: left !important;\r\n}\r\n\r\n@media (min-width: 576px) {\r\n  .ion-float-sm-left {\r\n    float: left !important;\r\n  }\r\n\r\n  .ion-float-sm-right {\r\n    float: right !important;\r\n  }\r\n\r\n  .ion-float-sm-start {\r\n    float: left !important;\r\n  }\r\n  [dir=rtl] .ion-float-sm-start, :host-context([dir=rtl]) .ion-float-sm-start {\r\n    float: right !important;\r\n  }\r\n\r\n  .ion-float-sm-end {\r\n    float: right !important;\r\n  }\r\n  [dir=rtl] .ion-float-sm-end, :host-context([dir=rtl]) .ion-float-sm-end {\r\n    float: left !important;\r\n  }\r\n}\r\n@media (min-width: 768px) {\r\n  .ion-float-md-left {\r\n    float: left !important;\r\n  }\r\n\r\n  .ion-float-md-right {\r\n    float: right !important;\r\n  }\r\n\r\n  .ion-float-md-start {\r\n    float: left !important;\r\n  }\r\n  [dir=rtl] .ion-float-md-start, :host-context([dir=rtl]) .ion-float-md-start {\r\n    float: right !important;\r\n  }\r\n\r\n  .ion-float-md-end {\r\n    float: right !important;\r\n  }\r\n  [dir=rtl] .ion-float-md-end, :host-context([dir=rtl]) .ion-float-md-end {\r\n    float: left !important;\r\n  }\r\n}\r\n@media (min-width: 992px) {\r\n  .ion-float-lg-left {\r\n    float: left !important;\r\n  }\r\n\r\n  .ion-float-lg-right {\r\n    float: right !important;\r\n  }\r\n\r\n  .ion-float-lg-start {\r\n    float: left !important;\r\n  }\r\n  [dir=rtl] .ion-float-lg-start, :host-context([dir=rtl]) .ion-float-lg-start {\r\n    float: right !important;\r\n  }\r\n\r\n  .ion-float-lg-end {\r\n    float: right !important;\r\n  }\r\n  [dir=rtl] .ion-float-lg-end, :host-context([dir=rtl]) .ion-float-lg-end {\r\n    float: left !important;\r\n  }\r\n}\r\n@media (min-width: 1200px) {\r\n  .ion-float-xl-left {\r\n    float: left !important;\r\n  }\r\n\r\n  .ion-float-xl-right {\r\n    float: right !important;\r\n  }\r\n\r\n  .ion-float-xl-start {\r\n    float: left !important;\r\n  }\r\n  [dir=rtl] .ion-float-xl-start, :host-context([dir=rtl]) .ion-float-xl-start {\r\n    float: right !important;\r\n  }\r\n\r\n  .ion-float-xl-end {\r\n    float: right !important;\r\n  }\r\n  [dir=rtl] .ion-float-xl-end, :host-context([dir=rtl]) .ion-float-xl-end {\r\n    float: left !important;\r\n  }\r\n}\r\n\r\n/*# sourceMappingURL=float-elements.css.map */\r\n", null, ".ion-text-center {\r\n  text-align: center !important;\r\n}\r\n\r\n.ion-text-justify {\r\n  text-align: justify !important;\r\n}\r\n\r\n.ion-text-start {\r\n  text-align: start !important;\r\n}\r\n\r\n.ion-text-end {\r\n  text-align: end !important;\r\n}\r\n\r\n.ion-text-left {\r\n  text-align: left !important;\r\n}\r\n\r\n.ion-text-right {\r\n  text-align: right !important;\r\n}\r\n\r\n.ion-text-nowrap {\r\n  white-space: nowrap !important;\r\n}\r\n\r\n.ion-text-wrap {\r\n  white-space: normal !important;\r\n}\r\n\r\n@media (min-width: 576px) {\r\n  .ion-text-sm-center {\r\n    text-align: center !important;\r\n  }\r\n\r\n  .ion-text-sm-justify {\r\n    text-align: justify !important;\r\n  }\r\n\r\n  .ion-text-sm-start {\r\n    text-align: start !important;\r\n  }\r\n\r\n  .ion-text-sm-end {\r\n    text-align: end !important;\r\n  }\r\n\r\n  .ion-text-sm-left {\r\n    text-align: left !important;\r\n  }\r\n\r\n  .ion-text-sm-right {\r\n    text-align: right !important;\r\n  }\r\n\r\n  .ion-text-sm-nowrap {\r\n    white-space: nowrap !important;\r\n  }\r\n\r\n  .ion-text-sm-wrap {\r\n    white-space: normal !important;\r\n  }\r\n}\r\n@media (min-width: 768px) {\r\n  .ion-text-md-center {\r\n    text-align: center !important;\r\n  }\r\n\r\n  .ion-text-md-justify {\r\n    text-align: justify !important;\r\n  }\r\n\r\n  .ion-text-md-start {\r\n    text-align: start !important;\r\n  }\r\n\r\n  .ion-text-md-end {\r\n    text-align: end !important;\r\n  }\r\n\r\n  .ion-text-md-left {\r\n    text-align: left !important;\r\n  }\r\n\r\n  .ion-text-md-right {\r\n    text-align: right !important;\r\n  }\r\n\r\n  .ion-text-md-nowrap {\r\n    white-space: nowrap !important;\r\n  }\r\n\r\n  .ion-text-md-wrap {\r\n    white-space: normal !important;\r\n  }\r\n}\r\n@media (min-width: 992px) {\r\n  .ion-text-lg-center {\r\n    text-align: center !important;\r\n  }\r\n\r\n  .ion-text-lg-justify {\r\n    text-align: justify !important;\r\n  }\r\n\r\n  .ion-text-lg-start {\r\n    text-align: start !important;\r\n  }\r\n\r\n  .ion-text-lg-end {\r\n    text-align: end !important;\r\n  }\r\n\r\n  .ion-text-lg-left {\r\n    text-align: left !important;\r\n  }\r\n\r\n  .ion-text-lg-right {\r\n    text-align: right !important;\r\n  }\r\n\r\n  .ion-text-lg-nowrap {\r\n    white-space: nowrap !important;\r\n  }\r\n\r\n  .ion-text-lg-wrap {\r\n    white-space: normal !important;\r\n  }\r\n}\r\n@media (min-width: 1200px) {\r\n  .ion-text-xl-center {\r\n    text-align: center !important;\r\n  }\r\n\r\n  .ion-text-xl-justify {\r\n    text-align: justify !important;\r\n  }\r\n\r\n  .ion-text-xl-start {\r\n    text-align: start !important;\r\n  }\r\n\r\n  .ion-text-xl-end {\r\n    text-align: end !important;\r\n  }\r\n\r\n  .ion-text-xl-left {\r\n    text-align: left !important;\r\n  }\r\n\r\n  .ion-text-xl-right {\r\n    text-align: right !important;\r\n  }\r\n\r\n  .ion-text-xl-nowrap {\r\n    white-space: nowrap !important;\r\n  }\r\n\r\n  .ion-text-xl-wrap {\r\n    white-space: normal !important;\r\n  }\r\n}\r\n\r\n/*# sourceMappingURL=text-alignment.css.map */\r\n", null, ".ion-text-uppercase {\r\n  /* stylelint-disable-next-line declaration-no-important */\r\n  text-transform: uppercase !important;\r\n}\r\n\r\n.ion-text-lowercase {\r\n  /* stylelint-disable-next-line declaration-no-important */\r\n  text-transform: lowercase !important;\r\n}\r\n\r\n.ion-text-capitalize {\r\n  /* stylelint-disable-next-line declaration-no-important */\r\n  text-transform: capitalize !important;\r\n}\r\n\r\n@media (min-width: 576px) {\r\n  .ion-text-sm-uppercase {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: uppercase !important;\r\n  }\r\n\r\n  .ion-text-sm-lowercase {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: lowercase !important;\r\n  }\r\n\r\n  .ion-text-sm-capitalize {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: capitalize !important;\r\n  }\r\n}\r\n@media (min-width: 768px) {\r\n  .ion-text-md-uppercase {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: uppercase !important;\r\n  }\r\n\r\n  .ion-text-md-lowercase {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: lowercase !important;\r\n  }\r\n\r\n  .ion-text-md-capitalize {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: capitalize !important;\r\n  }\r\n}\r\n@media (min-width: 992px) {\r\n  .ion-text-lg-uppercase {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: uppercase !important;\r\n  }\r\n\r\n  .ion-text-lg-lowercase {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: lowercase !important;\r\n  }\r\n\r\n  .ion-text-lg-capitalize {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: capitalize !important;\r\n  }\r\n}\r\n@media (min-width: 1200px) {\r\n  .ion-text-xl-uppercase {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: uppercase !important;\r\n  }\r\n\r\n  .ion-text-xl-lowercase {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: lowercase !important;\r\n  }\r\n\r\n  .ion-text-xl-capitalize {\r\n    /* stylelint-disable-next-line declaration-no-important */\r\n    text-transform: capitalize !important;\r\n  }\r\n}\r\n\r\n/*# sourceMappingURL=text-transformation.css.map */\r\n", null, ".ion-align-self-start {\r\n  align-self: flex-start !important;\r\n}\r\n\r\n.ion-align-self-end {\r\n  align-self: flex-end !important;\r\n}\r\n\r\n.ion-align-self-center {\r\n  align-self: center !important;\r\n}\r\n\r\n.ion-align-self-stretch {\r\n  align-self: stretch !important;\r\n}\r\n\r\n.ion-align-self-baseline {\r\n  align-self: baseline !important;\r\n}\r\n\r\n.ion-align-self-auto {\r\n  align-self: auto !important;\r\n}\r\n\r\n.ion-wrap {\r\n  flex-wrap: wrap !important;\r\n}\r\n\r\n.ion-nowrap {\r\n  flex-wrap: nowrap !important;\r\n}\r\n\r\n.ion-wrap-reverse {\r\n  flex-wrap: wrap-reverse !important;\r\n}\r\n\r\n.ion-justify-content-start {\r\n  justify-content: flex-start !important;\r\n}\r\n\r\n.ion-justify-content-center {\r\n  justify-content: center !important;\r\n}\r\n\r\n.ion-justify-content-end {\r\n  justify-content: flex-end !important;\r\n}\r\n\r\n.ion-justify-content-around {\r\n  justify-content: space-around !important;\r\n}\r\n\r\n.ion-justify-content-between {\r\n  justify-content: space-between !important;\r\n}\r\n\r\n.ion-justify-content-evenly {\r\n  justify-content: space-evenly !important;\r\n}\r\n\r\n.ion-align-items-start {\r\n  align-items: flex-start !important;\r\n}\r\n\r\n.ion-align-items-center {\r\n  align-items: center !important;\r\n}\r\n\r\n.ion-align-items-end {\r\n  align-items: flex-end !important;\r\n}\r\n\r\n.ion-align-items-stretch {\r\n  align-items: stretch !important;\r\n}\r\n\r\n.ion-align-items-baseline {\r\n  align-items: baseline !important;\r\n}\r\n\r\n/*# sourceMappingURL=flex-utils.css.map */\r\n"]
      }]); // Exports

      module.exports = exports;
      /***/
    },

    /***/
    "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/sass-loader/dist/cjs.js?!./src/theme/variables.scss":
    /*!******************************************************************************************************************************************************************************************************************************!*\
      !*** ./node_modules/css-loader/dist/cjs.js??ref--14-1!./node_modules/postcss-loader/src??embedded!./node_modules/resolve-url-loader??ref--14-3!./node_modules/sass-loader/dist/cjs.js??ref--14-4!./src/theme/variables.scss ***!
      \******************************************************************************************************************************************************************************************************************************/

    /*! no static exports found */

    /***/
    function node_modulesCssLoaderDistCjsJsNode_modulesPostcssLoaderSrcIndexJsNode_modulesResolveUrlLoaderIndexJsNode_modulesSassLoaderDistCjsJsSrcThemeVariablesScss(module, exports, __webpack_require__) {
      // Imports
      var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(
      /*! ../../node_modules/css-loader/dist/runtime/api.js */
      "./node_modules/css-loader/dist/runtime/api.js");

      exports = ___CSS_LOADER_API_IMPORT___(true); // Module

      exports.push([module.i, "/** Ionic CSS Variables **/\n:root {\n  /** primary **/\n  --ion-color-primary: #ea9b02;\n  --ion-color-primary-rgb: 234, 155, 2;\n  --ion-color-primary-contrast: #ffffff;\n  --ion-color-primary-contrast-rgb: 255, 255, 255;\n  --ion-color-primary-shade: #111;\n  --ion-color-primary-tint: #333;\n  /** secondary **/\n  --ion-color-secondary: #3dc2ff;\n  --ion-color-secondary-rgb: 61, 194, 255;\n  --ion-color-secondary-contrast: #ffffff;\n  --ion-color-secondary-contrast-rgb: 255, 255, 255;\n  --ion-color-secondary-shade: #36abe0;\n  --ion-color-secondary-tint: #50c8ff;\n  /** tertiary **/\n  --ion-color-tertiary: #5260ff;\n  --ion-color-tertiary-rgb: 82, 96, 255;\n  --ion-color-tertiary-contrast: #ffffff;\n  --ion-color-tertiary-contrast-rgb: 255, 255, 255;\n  --ion-color-tertiary-shade: #4854e0;\n  --ion-color-tertiary-tint: #6370ff;\n  /** success **/\n  --ion-color-success: #2dd36f;\n  --ion-color-success-rgb: 45, 211, 111;\n  --ion-color-success-contrast: #ffffff;\n  --ion-color-success-contrast-rgb: 255, 255, 255;\n  --ion-color-success-shade: #28ba62;\n  --ion-color-success-tint: #42d77d;\n  /** warning **/\n  --ion-color-warning: #ffc409;\n  --ion-color-warning-rgb: 255, 196, 9;\n  --ion-color-warning-contrast: #000000;\n  --ion-color-warning-contrast-rgb: 0, 0, 0;\n  --ion-color-warning-shade: #e0ac08;\n  --ion-color-warning-tint: #ffca22;\n  /** danger **/\n  --ion-color-danger: #eb445a;\n  --ion-color-danger-rgb: 235, 68, 90;\n  --ion-color-danger-contrast: #ffffff;\n  --ion-color-danger-contrast-rgb: 255, 255, 255;\n  --ion-color-danger-shade: #cf3c4f;\n  --ion-color-danger-tint: #ed576b;\n  /** dark **/\n  --ion-color-dark: #222428;\n  --ion-color-dark-rgb: 34, 36, 40;\n  --ion-color-dark-contrast: #ffffff;\n  --ion-color-dark-contrast-rgb: 255, 255, 255;\n  --ion-color-dark-shade: #1e2023;\n  --ion-color-dark-tint: #383a3e;\n  /** medium **/\n  --ion-color-medium: #92949c;\n  --ion-color-medium-rgb: 146, 148, 156;\n  --ion-color-medium-contrast: #ffffff;\n  --ion-color-medium-contrast-rgb: 255, 255, 255;\n  --ion-color-medium-shade: #808289;\n  --ion-color-medium-tint: #9d9fa6;\n  /** light **/\n  --ion-color-light: #f4f5f8;\n  --ion-color-light-rgb: 244, 245, 248;\n  --ion-color-light-contrast: #000000;\n  --ion-color-light-contrast-rgb: 0, 0, 0;\n  --ion-color-light-shade: #d7d8da;\n  --ion-color-light-tint: #f5f6f9;\n  --ion-color-white:#fff;\n  --ion-color-black:#000;\n  --ion-color-green:#089930;\n  --ion-color-softgreen:#d7ffe4;\n  --ion-color-bggradient:linear-gradient(0deg, #eb9c03 0%, #fcae16 100%);\n}\n@media (prefers-color-scheme: dark) {\n  /*\n   * Dark Colors\n   * -------------------------------------------\n   */\n  body {\n    --ion-color-primary: #428cff;\n    --ion-color-primary-rgb: 66,140,255;\n    --ion-color-primary-contrast: #ffffff;\n    --ion-color-primary-contrast-rgb: 255,255,255;\n    --ion-color-primary-shade: #3a7be0;\n    --ion-color-primary-tint: #5598ff;\n    --ion-color-secondary: #50c8ff;\n    --ion-color-secondary-rgb: 80,200,255;\n    --ion-color-secondary-contrast: #ffffff;\n    --ion-color-secondary-contrast-rgb: 255,255,255;\n    --ion-color-secondary-shade: #46b0e0;\n    --ion-color-secondary-tint: #62ceff;\n    --ion-color-tertiary: #6a64ff;\n    --ion-color-tertiary-rgb: 106,100,255;\n    --ion-color-tertiary-contrast: #ffffff;\n    --ion-color-tertiary-contrast-rgb: 255,255,255;\n    --ion-color-tertiary-shade: #5d58e0;\n    --ion-color-tertiary-tint: #7974ff;\n    --ion-color-success: #2fdf75;\n    --ion-color-success-rgb: 47,223,117;\n    --ion-color-success-contrast: #000000;\n    --ion-color-success-contrast-rgb: 0,0,0;\n    --ion-color-success-shade: #29c467;\n    --ion-color-success-tint: #44e283;\n    --ion-color-warning: #ffd534;\n    --ion-color-warning-rgb: 255,213,52;\n    --ion-color-warning-contrast: #000000;\n    --ion-color-warning-contrast-rgb: 0,0,0;\n    --ion-color-warning-shade: #e0bb2e;\n    --ion-color-warning-tint: #ffd948;\n    --ion-color-danger: #ff4961;\n    --ion-color-danger-rgb: 255,73,97;\n    --ion-color-danger-contrast: #ffffff;\n    --ion-color-danger-contrast-rgb: 255,255,255;\n    --ion-color-danger-shade: #e04055;\n    --ion-color-danger-tint: #ff5b71;\n    --ion-color-dark: #f4f5f8;\n    --ion-color-dark-rgb: 244,245,248;\n    --ion-color-dark-contrast: #000000;\n    --ion-color-dark-contrast-rgb: 0,0,0;\n    --ion-color-dark-shade: #d7d8da;\n    --ion-color-dark-tint: #f5f6f9;\n    --ion-color-medium: #989aa2;\n    --ion-color-medium-rgb: 152,154,162;\n    --ion-color-medium-contrast: #000000;\n    --ion-color-medium-contrast-rgb: 0,0,0;\n    --ion-color-medium-shade: #86888f;\n    --ion-color-medium-tint: #a2a4ab;\n    --ion-color-light: #222428;\n    --ion-color-light-rgb: 34,36,40;\n    --ion-color-light-contrast: #ffffff;\n    --ion-color-light-contrast-rgb: 255,255,255;\n    --ion-color-light-shade: #1e2023;\n    --ion-color-light-tint: #383a3e;\n  }\n\n  /*\n   * iOS Dark Theme\n   * -------------------------------------------\n   */\n  .ios body {\n    --ion-background-color: #000000;\n    --ion-background-color-rgb: 0,0,0;\n    --ion-text-color: #ffffff;\n    --ion-text-color-rgb: 255,255,255;\n    --ion-color-step-50: #0d0d0d;\n    --ion-color-step-100: #1a1a1a;\n    --ion-color-step-150: #262626;\n    --ion-color-step-200: #333333;\n    --ion-color-step-250: #404040;\n    --ion-color-step-300: #4d4d4d;\n    --ion-color-step-350: #595959;\n    --ion-color-step-400: #666666;\n    --ion-color-step-450: #737373;\n    --ion-color-step-500: #808080;\n    --ion-color-step-550: #8c8c8c;\n    --ion-color-step-600: #999999;\n    --ion-color-step-650: #a6a6a6;\n    --ion-color-step-700: #b3b3b3;\n    --ion-color-step-750: #bfbfbf;\n    --ion-color-step-800: #cccccc;\n    --ion-color-step-850: #d9d9d9;\n    --ion-color-step-900: #e6e6e6;\n    --ion-color-step-950: #f2f2f2;\n    --ion-toolbar-background: #0d0d0d;\n    --ion-item-background: #000000;\n    --ion-card-background: #1c1c1d;\n  }\n\n  /*\n   * Material Design Dark Theme\n   * -------------------------------------------\n   */\n  .md body {\n    --ion-background-color: #121212;\n    --ion-background-color-rgb: 18,18,18;\n    --ion-text-color: #ffffff;\n    --ion-text-color-rgb: 255,255,255;\n    --ion-border-color: #222222;\n    --ion-color-step-50: #1e1e1e;\n    --ion-color-step-100: #2a2a2a;\n    --ion-color-step-150: #363636;\n    --ion-color-step-200: #414141;\n    --ion-color-step-250: #4d4d4d;\n    --ion-color-step-300: #595959;\n    --ion-color-step-350: #656565;\n    --ion-color-step-400: #717171;\n    --ion-color-step-450: #7d7d7d;\n    --ion-color-step-500: #898989;\n    --ion-color-step-550: #949494;\n    --ion-color-step-600: #a0a0a0;\n    --ion-color-step-650: #acacac;\n    --ion-color-step-700: #b8b8b8;\n    --ion-color-step-750: #c4c4c4;\n    --ion-color-step-800: #d0d0d0;\n    --ion-color-step-850: #dbdbdb;\n    --ion-color-step-900: #e7e7e7;\n    --ion-color-step-950: #f3f3f3;\n    --ion-item-background: #1e1e1e;\n    --ion-toolbar-background: #1f1f1f;\n    --ion-tab-bar-background: #1f1f1f;\n    --ion-card-background: #1e1e1e;\n  }\n}", "", {
        "version": 3,
        "sources": ["variables.scss"],
        "names": [],
        "mappings": "AAGA,0BAAA;AACA;EACE,cAAA;EACA,4BAAA;EACA,oCAAA;EACA,qCAAA;EACA,+CAAA;EACA,+BAAA;EACA,8BAAA;EAEA,gBAAA;EACA,8BAAA;EACA,uCAAA;EACA,uCAAA;EACA,iDAAA;EACA,oCAAA;EACA,mCAAA;EAEA,eAAA;EACA,6BAAA;EACA,qCAAA;EACA,sCAAA;EACA,gDAAA;EACA,mCAAA;EACA,kCAAA;EAEA,cAAA;EACA,4BAAA;EACA,qCAAA;EACA,qCAAA;EACA,+CAAA;EACA,kCAAA;EACA,iCAAA;EAEA,cAAA;EACA,4BAAA;EACA,oCAAA;EACA,qCAAA;EACA,yCAAA;EACA,kCAAA;EACA,iCAAA;EAEA,aAAA;EACA,2BAAA;EACA,mCAAA;EACA,oCAAA;EACA,8CAAA;EACA,iCAAA;EACA,gCAAA;EAEA,WAAA;EACA,yBAAA;EACA,gCAAA;EACA,kCAAA;EACA,4CAAA;EACA,+BAAA;EACA,8BAAA;EAEA,aAAA;EACA,2BAAA;EACA,qCAAA;EACA,oCAAA;EACA,8CAAA;EACA,iCAAA;EACA,gCAAA;EAEA,YAAA;EACA,0BAAA;EACA,oCAAA;EACA,mCAAA;EACA,uCAAA;EACA,gCAAA;EACA,+BAAA;EAEA,sBAAA;EACA,sBAAA;EACA,yBAAA;EACA,6BAAA;EACG,sEAAA;AAXL;AAcA;EACE;;;IAAA;EAKA;IACE,4BAAA;IACA,mCAAA;IACA,qCAAA;IACA,6CAAA;IACA,kCAAA;IACA,iCAAA;IAEA,8BAAA;IACA,qCAAA;IACA,uCAAA;IACA,+CAAA;IACA,oCAAA;IACA,mCAAA;IAEA,6BAAA;IACA,qCAAA;IACA,sCAAA;IACA,8CAAA;IACA,mCAAA;IACA,kCAAA;IAEA,4BAAA;IACA,mCAAA;IACA,qCAAA;IACA,uCAAA;IACA,kCAAA;IACA,iCAAA;IAEA,4BAAA;IACA,mCAAA;IACA,qCAAA;IACA,uCAAA;IACA,kCAAA;IACA,iCAAA;IAEA,2BAAA;IACA,iCAAA;IACA,oCAAA;IACA,4CAAA;IACA,iCAAA;IACA,gCAAA;IAEA,yBAAA;IACA,iCAAA;IACA,kCAAA;IACA,oCAAA;IACA,+BAAA;IACA,8BAAA;IAEA,2BAAA;IACA,mCAAA;IACA,oCAAA;IACA,sCAAA;IACA,iCAAA;IACA,gCAAA;IAEA,0BAAA;IACA,+BAAA;IACA,mCAAA;IACA,2CAAA;IACA,gCAAA;IACA,+BAAA;EApBF;;EAuBA;;;IAAA;EAKA;IACE,+BAAA;IACA,iCAAA;IAEA,yBAAA;IACA,iCAAA;IAEA,4BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IAEA,iCAAA;IAEA,8BAAA;IAEA,8BAAA;EA1BF;;EA8BA;;;IAAA;EAKA;IACE,+BAAA;IACA,oCAAA;IAEA,yBAAA;IACA,iCAAA;IAEA,2BAAA;IAEA,4BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IACA,6BAAA;IAEA,8BAAA;IAEA,iCAAA;IAEA,iCAAA;IAEA,8BAAA;EAnCF;AACF",
        "file": "variables.scss",
        "sourcesContent": ["// Ionic Variables and Theming. For more info, please see:\r\n// http://ionicframework.com/docs/theming/\r\n\r\n/** Ionic CSS Variables **/\r\n:root {\r\n  /** primary **/\r\n  --ion-color-primary: #ea9b02;\r\n  --ion-color-primary-rgb: 234, 155, 2;\r\n  --ion-color-primary-contrast: #ffffff;\r\n  --ion-color-primary-contrast-rgb: 255, 255, 255;\r\n  --ion-color-primary-shade: #111;\r\n  --ion-color-primary-tint: #333;\r\n\r\n  /** secondary **/\r\n  --ion-color-secondary: #3dc2ff;\r\n  --ion-color-secondary-rgb: 61, 194, 255;\r\n  --ion-color-secondary-contrast: #ffffff;\r\n  --ion-color-secondary-contrast-rgb: 255, 255, 255;\r\n  --ion-color-secondary-shade: #36abe0;\r\n  --ion-color-secondary-tint: #50c8ff;\r\n\r\n  /** tertiary **/\r\n  --ion-color-tertiary: #5260ff;\r\n  --ion-color-tertiary-rgb: 82, 96, 255;\r\n  --ion-color-tertiary-contrast: #ffffff;\r\n  --ion-color-tertiary-contrast-rgb: 255, 255, 255;\r\n  --ion-color-tertiary-shade: #4854e0;\r\n  --ion-color-tertiary-tint: #6370ff;\r\n\r\n  /** success **/\r\n  --ion-color-success: #2dd36f;\r\n  --ion-color-success-rgb: 45, 211, 111;\r\n  --ion-color-success-contrast: #ffffff;\r\n  --ion-color-success-contrast-rgb: 255, 255, 255;\r\n  --ion-color-success-shade: #28ba62;\r\n  --ion-color-success-tint: #42d77d;\r\n\r\n  /** warning **/\r\n  --ion-color-warning: #ffc409;\r\n  --ion-color-warning-rgb: 255, 196, 9;\r\n  --ion-color-warning-contrast: #000000;\r\n  --ion-color-warning-contrast-rgb: 0, 0, 0;\r\n  --ion-color-warning-shade: #e0ac08;\r\n  --ion-color-warning-tint: #ffca22;\r\n\r\n  /** danger **/\r\n  --ion-color-danger: #eb445a;\r\n  --ion-color-danger-rgb: 235, 68, 90;\r\n  --ion-color-danger-contrast: #ffffff;\r\n  --ion-color-danger-contrast-rgb: 255, 255, 255;\r\n  --ion-color-danger-shade: #cf3c4f;\r\n  --ion-color-danger-tint: #ed576b;\r\n\r\n  /** dark **/\r\n  --ion-color-dark: #222428;\r\n  --ion-color-dark-rgb: 34, 36, 40;\r\n  --ion-color-dark-contrast: #ffffff;\r\n  --ion-color-dark-contrast-rgb: 255, 255, 255;\r\n  --ion-color-dark-shade: #1e2023;\r\n  --ion-color-dark-tint: #383a3e;\r\n\r\n  /** medium **/\r\n  --ion-color-medium: #92949c;\r\n  --ion-color-medium-rgb: 146, 148, 156;\r\n  --ion-color-medium-contrast: #ffffff;\r\n  --ion-color-medium-contrast-rgb: 255, 255, 255;\r\n  --ion-color-medium-shade: #808289;\r\n  --ion-color-medium-tint: #9d9fa6;\r\n\r\n  /** light **/\r\n  --ion-color-light: #f4f5f8;\r\n  --ion-color-light-rgb: 244, 245, 248;\r\n  --ion-color-light-contrast: #000000;\r\n  --ion-color-light-contrast-rgb: 0, 0, 0;\r\n  --ion-color-light-shade: #d7d8da;\r\n  --ion-color-light-tint: #f5f6f9;\r\n  \r\n  --ion-color-white:#fff;\r\n  --ion-color-black:#000;\r\n  --ion-color-green:#089930;\r\n  --ion-color-softgreen:#d7ffe4;\r\n     --ion-color-bggradient:linear-gradient(0deg, #eb9c03 0%, #fcae16 100%);\r\n}\r\n\r\n@media (prefers-color-scheme: dark) {\r\n  /*\r\n   * Dark Colors\r\n   * -------------------------------------------\r\n   */\r\n\r\n  body {\r\n    --ion-color-primary: #428cff;\r\n    --ion-color-primary-rgb: 66,140,255;\r\n    --ion-color-primary-contrast: #ffffff;\r\n    --ion-color-primary-contrast-rgb: 255,255,255;\r\n    --ion-color-primary-shade: #3a7be0;\r\n    --ion-color-primary-tint: #5598ff;\r\n\r\n    --ion-color-secondary: #50c8ff;\r\n    --ion-color-secondary-rgb: 80,200,255;\r\n    --ion-color-secondary-contrast: #ffffff;\r\n    --ion-color-secondary-contrast-rgb: 255,255,255;\r\n    --ion-color-secondary-shade: #46b0e0;\r\n    --ion-color-secondary-tint: #62ceff;\r\n\r\n    --ion-color-tertiary: #6a64ff;\r\n    --ion-color-tertiary-rgb: 106,100,255;\r\n    --ion-color-tertiary-contrast: #ffffff;\r\n    --ion-color-tertiary-contrast-rgb: 255,255,255;\r\n    --ion-color-tertiary-shade: #5d58e0;\r\n    --ion-color-tertiary-tint: #7974ff;\r\n\r\n    --ion-color-success: #2fdf75;\r\n    --ion-color-success-rgb: 47,223,117;\r\n    --ion-color-success-contrast: #000000;\r\n    --ion-color-success-contrast-rgb: 0,0,0;\r\n    --ion-color-success-shade: #29c467;\r\n    --ion-color-success-tint: #44e283;\r\n\r\n    --ion-color-warning: #ffd534;\r\n    --ion-color-warning-rgb: 255,213,52;\r\n    --ion-color-warning-contrast: #000000;\r\n    --ion-color-warning-contrast-rgb: 0,0,0;\r\n    --ion-color-warning-shade: #e0bb2e;\r\n    --ion-color-warning-tint: #ffd948;\r\n\r\n    --ion-color-danger: #ff4961;\r\n    --ion-color-danger-rgb: 255,73,97;\r\n    --ion-color-danger-contrast: #ffffff;\r\n    --ion-color-danger-contrast-rgb: 255,255,255;\r\n    --ion-color-danger-shade: #e04055;\r\n    --ion-color-danger-tint: #ff5b71;\r\n\r\n    --ion-color-dark: #f4f5f8;\r\n    --ion-color-dark-rgb: 244,245,248;\r\n    --ion-color-dark-contrast: #000000;\r\n    --ion-color-dark-contrast-rgb: 0,0,0;\r\n    --ion-color-dark-shade: #d7d8da;\r\n    --ion-color-dark-tint: #f5f6f9;\r\n\r\n    --ion-color-medium: #989aa2;\r\n    --ion-color-medium-rgb: 152,154,162;\r\n    --ion-color-medium-contrast: #000000;\r\n    --ion-color-medium-contrast-rgb: 0,0,0;\r\n    --ion-color-medium-shade: #86888f;\r\n    --ion-color-medium-tint: #a2a4ab;\r\n\r\n    --ion-color-light: #222428;\r\n    --ion-color-light-rgb: 34,36,40;\r\n    --ion-color-light-contrast: #ffffff;\r\n    --ion-color-light-contrast-rgb: 255,255,255;\r\n    --ion-color-light-shade: #1e2023;\r\n    --ion-color-light-tint: #383a3e;\r\n  }\r\n\r\n  /*\r\n   * iOS Dark Theme\r\n   * -------------------------------------------\r\n   */\r\n\r\n  .ios body {\r\n    --ion-background-color: #000000;\r\n    --ion-background-color-rgb: 0,0,0;\r\n\r\n    --ion-text-color: #ffffff;\r\n    --ion-text-color-rgb: 255,255,255;\r\n\r\n    --ion-color-step-50: #0d0d0d;\r\n    --ion-color-step-100: #1a1a1a;\r\n    --ion-color-step-150: #262626;\r\n    --ion-color-step-200: #333333;\r\n    --ion-color-step-250: #404040;\r\n    --ion-color-step-300: #4d4d4d;\r\n    --ion-color-step-350: #595959;\r\n    --ion-color-step-400: #666666;\r\n    --ion-color-step-450: #737373;\r\n    --ion-color-step-500: #808080;\r\n    --ion-color-step-550: #8c8c8c;\r\n    --ion-color-step-600: #999999;\r\n    --ion-color-step-650: #a6a6a6;\r\n    --ion-color-step-700: #b3b3b3;\r\n    --ion-color-step-750: #bfbfbf;\r\n    --ion-color-step-800: #cccccc;\r\n    --ion-color-step-850: #d9d9d9;\r\n    --ion-color-step-900: #e6e6e6;\r\n    --ion-color-step-950: #f2f2f2;\r\n\r\n    --ion-toolbar-background: #0d0d0d;\r\n\r\n    --ion-item-background: #000000;\r\n\r\n    --ion-card-background: #1c1c1d;\r\n  }\r\n\r\n\r\n  /*\r\n   * Material Design Dark Theme\r\n   * -------------------------------------------\r\n   */\r\n\r\n  .md body {\r\n    --ion-background-color: #121212;\r\n    --ion-background-color-rgb: 18,18,18;\r\n\r\n    --ion-text-color: #ffffff;\r\n    --ion-text-color-rgb: 255,255,255;\r\n\r\n    --ion-border-color: #222222;\r\n\r\n    --ion-color-step-50: #1e1e1e;\r\n    --ion-color-step-100: #2a2a2a;\r\n    --ion-color-step-150: #363636;\r\n    --ion-color-step-200: #414141;\r\n    --ion-color-step-250: #4d4d4d;\r\n    --ion-color-step-300: #595959;\r\n    --ion-color-step-350: #656565;\r\n    --ion-color-step-400: #717171;\r\n    --ion-color-step-450: #7d7d7d;\r\n    --ion-color-step-500: #898989;\r\n    --ion-color-step-550: #949494;\r\n    --ion-color-step-600: #a0a0a0;\r\n    --ion-color-step-650: #acacac;\r\n    --ion-color-step-700: #b8b8b8;\r\n    --ion-color-step-750: #c4c4c4;\r\n    --ion-color-step-800: #d0d0d0;\r\n    --ion-color-step-850: #dbdbdb;\r\n    --ion-color-step-900: #e7e7e7;\r\n    --ion-color-step-950: #f3f3f3;\r\n\r\n    --ion-item-background: #1e1e1e;\r\n\r\n    --ion-toolbar-background: #1f1f1f;\r\n\r\n    --ion-tab-bar-background: #1f1f1f;\r\n\r\n    --ion-card-background: #1e1e1e;\r\n  }\r\n}"]
      }]); // Exports

      module.exports = exports;
      /***/
    },

    /***/
    "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/assets/css/style.css":
    /*!*******************************************************************************************************************************!*\
      !*** ./node_modules/css-loader/dist/cjs.js??ref--13-1!./node_modules/postcss-loader/src??embedded!./src/assets/css/style.css ***!
      \*******************************************************************************************************************************/

    /*! no static exports found */

    /***/
    function node_modulesCssLoaderDistCjsJsNode_modulesPostcssLoaderSrcIndexJsSrcAssetsCssStyleCss(module, exports, __webpack_require__) {
      // Imports
      var ___CSS_LOADER_API_IMPORT___ = __webpack_require__(
      /*! ../../../node_modules/css-loader/dist/runtime/api.js */
      "./node_modules/css-loader/dist/runtime/api.js");

      exports = ___CSS_LOADER_API_IMPORT___(true);
      exports.push([module.i, "@import url(https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap);"]); // Module

      exports.push([module.i, "ion-content, ion-header, ion-button , ion-label, h1, h2, h3, h4, h5, h6, p, span {\r\n\tfont-family: 'Poppins', sans-serif !important;\r\n}\r\n.profile_listing\r\n{\r\n\tfont-weight:500;\r\n\tcolor: #000000b8;\r\n\tborder-bottom: 1px solid #0000001c;\r\n}\r\n.leaveteam  {\r\n\t height: 100%;\r\n    display: flex;\r\n    align-items: center;\r\n    justify-content: center;\r\n}\r\n.resend{\r\n\tfont-weight: 500;\r\n\tcolor:var(--ion-color-primary, #3880ff);\r\n}\r\n.jointeamconfirm {\r\n    \r\n    height: 100%;\r\n    display: flex;\r\n    align-items: center;\r\n    justify-content: center;\r\n    \r\n}\r\n.list_pay{\r\n\tpadding: 4px;\r\n    text-align: left;\r\n}\r\n.popupconfirm\r\n{\r\n\t    width: 100%;\r\n    padding: 15px;\r\n    max-width: 325px;\r\n    margin: 0 auto;\r\n    background-color: #fff;\r\n    height: 100%;\r\n    display: flex;\r\n    flex-direction: column;\r\n    align-items: center;\r\n    justify-content: center;\r\n}\r\n.modal-wrapper{\r\n    background: transparent !important;\r\n}\r\n.about_us p{\r\n\r\nfont-size: 14px !important;\r\n    line-height: 22px !important;\r\n    font-weight: 300 !important;\r\n    color: #adadad !important;\r\n    margin-top: 10px !important;\r\n\t}\r\n.about_us span.left-rf-boc{\r\n   font-weight: 500;\r\n    line-height: 1.2;\r\n\tfont-size: 17px;\r\n}\r\n.privacy_description p{\r\n\t\r\n\tmargin-top: 0px;\r\n    margin-bottom: 7px;\r\n    font-size: 14px;\r\n    line-height: 24px;\r\n    color: #999;\r\n    font-weight: 400;\r\n}\r\n.privacy_description h4 after {\r\n    content: \"\";\r\n    position: absolute;\r\n    left: 0;\r\n    width: 30px;\r\n    height: 30px;\r\n    background: var(--ion-color-softgreen);\r\n    border-radius: 50%;\r\n    z-index: -1;\r\n    top: -6px;\r\n}\r\n.privacy_description ul li {\r\n    display: block;\r\n    margin-bottom: 7px;\r\n    font-size: 14px;\r\n    line-height: 24px;\r\n    color: #999;\r\n    font-weight: 400;\r\n}\r\n.privacy_description h4{\r\n\tmargin: 15px 0px 10px 0px;\r\n    font-size: 18px;\r\n    position: relative;\r\n    z-index: 1;\r\n    padding-left: 7px;\r\n}\r\n.home_page .swiper-pagination\r\n{\r\n\tdisplay:none;\r\n}", "", {
        "version": 3,
        "sources": ["style.css"],
        "names": [],
        "mappings": "AACA;CACC,6CAA6C;AAC9C;AACA;;CAEC,eAAe;CACf,gBAAgB;CAChB,kCAAkC;AACnC;AACA;EACE,YAAY;IACV,aAAa;IACb,mBAAmB;IACnB,uBAAuB;AAC3B;AACA;CACC,gBAAgB;CAChB,uCAAuC;AACxC;AACA;;IAEI,YAAY;IACZ,aAAa;IACb,mBAAmB;IACnB,uBAAuB;;AAE3B;AACA;CACC,YAAY;IACT,gBAAgB;AACpB;AACA;;KAEK,WAAW;IACZ,aAAa;IACb,gBAAgB;IAChB,cAAc;IACd,sBAAsB;IACtB,YAAY;IACZ,aAAa;IACb,sBAAsB;IACtB,mBAAmB;IACnB,uBAAuB;AAC3B;AAEA;IACI,kCAAkC;AACtC;AACA;;AAEA,0BAA0B;IACtB,4BAA4B;IAC5B,2BAA2B;IAC3B,yBAAyB;IACzB,2BAA2B;CAC9B;AACD;GACG,gBAAgB;IACf,gBAAgB;CACnB,eAAe;AAChB;AACA;;CAEC,eAAe;IACZ,kBAAkB;IAClB,eAAe;IACf,iBAAiB;IACjB,WAAW;IACX,gBAAgB;AACpB;AACA;IACI,WAAW;IACX,kBAAkB;IAClB,OAAO;IACP,WAAW;IACX,YAAY;IACZ,sCAAsC;IACtC,kBAAkB;IAClB,WAAW;IACX,SAAS;AACb;AACA;IACI,cAAc;IACd,kBAAkB;IAClB,eAAe;IACf,iBAAiB;IACjB,WAAW;IACX,gBAAgB;AACpB;AACA;CACC,yBAAyB;IACtB,eAAe;IACf,kBAAkB;IAClB,UAAU;IACV,iBAAiB;AACrB;AACA;;CAEC,YAAY;AACb",
        "file": "style.css",
        "sourcesContent": ["@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap');\r\nion-content, ion-header, ion-button , ion-label, h1, h2, h3, h4, h5, h6, p, span {\r\n\tfont-family: 'Poppins', sans-serif !important;\r\n}\r\n.profile_listing\r\n{\r\n\tfont-weight:500;\r\n\tcolor: #000000b8;\r\n\tborder-bottom: 1px solid #0000001c;\r\n}\r\n.leaveteam  {\r\n\t height: 100%;\r\n    display: flex;\r\n    align-items: center;\r\n    justify-content: center;\r\n}\r\n.resend{\r\n\tfont-weight: 500;\r\n\tcolor:var(--ion-color-primary, #3880ff);\r\n}\r\n.jointeamconfirm {\r\n    \r\n    height: 100%;\r\n    display: flex;\r\n    align-items: center;\r\n    justify-content: center;\r\n    \r\n}\r\n.list_pay{\r\n\tpadding: 4px;\r\n    text-align: left;\r\n}\r\n.popupconfirm\r\n{\r\n\t    width: 100%;\r\n    padding: 15px;\r\n    max-width: 325px;\r\n    margin: 0 auto;\r\n    background-color: #fff;\r\n    height: 100%;\r\n    display: flex;\r\n    flex-direction: column;\r\n    align-items: center;\r\n    justify-content: center;\r\n}\r\n\r\n.modal-wrapper{\r\n    background: transparent !important;\r\n}\r\n.about_us p{\r\n\r\nfont-size: 14px !important;\r\n    line-height: 22px !important;\r\n    font-weight: 300 !important;\r\n    color: #adadad !important;\r\n    margin-top: 10px !important;\r\n\t}\r\n.about_us span.left-rf-boc{\r\n   font-weight: 500;\r\n    line-height: 1.2;\r\n\tfont-size: 17px;\r\n}\r\n.privacy_description p{\r\n\t\r\n\tmargin-top: 0px;\r\n    margin-bottom: 7px;\r\n    font-size: 14px;\r\n    line-height: 24px;\r\n    color: #999;\r\n    font-weight: 400;\r\n}\r\n.privacy_description h4 after {\r\n    content: \"\";\r\n    position: absolute;\r\n    left: 0;\r\n    width: 30px;\r\n    height: 30px;\r\n    background: var(--ion-color-softgreen);\r\n    border-radius: 50%;\r\n    z-index: -1;\r\n    top: -6px;\r\n}\r\n.privacy_description ul li {\r\n    display: block;\r\n    margin-bottom: 7px;\r\n    font-size: 14px;\r\n    line-height: 24px;\r\n    color: #999;\r\n    font-weight: 400;\r\n}\r\n.privacy_description h4{\r\n\tmargin: 15px 0px 10px 0px;\r\n    font-size: 18px;\r\n    position: relative;\r\n    z-index: 1;\r\n    padding-left: 7px;\r\n}\r\n.home_page .swiper-pagination\r\n{\r\n\tdisplay:none;\r\n}"]
      }]); // Exports

      module.exports = exports;
      /***/
    },

    /***/
    "./node_modules/css-loader/dist/runtime/api.js":
    /*!*****************************************************!*\
      !*** ./node_modules/css-loader/dist/runtime/api.js ***!
      \*****************************************************/

    /*! no static exports found */

    /***/
    function node_modulesCssLoaderDistRuntimeApiJs(module, exports, __webpack_require__) {
      "use strict";
      /*
        MIT License http://www.opensource.org/licenses/mit-license.php
        Author Tobias Koppers @sokra
      */
      // css base code, injected by the css-loader
      // eslint-disable-next-line func-names

      module.exports = function (useSourceMap) {
        var list = []; // return the list of modules as css string

        list.toString = function toString() {
          return this.map(function (item) {
            var content = cssWithMappingToString(item, useSourceMap);

            if (item[2]) {
              return "@media ".concat(item[2], " {").concat(content, "}");
            }

            return content;
          }).join('');
        }; // import a list of modules into the list
        // eslint-disable-next-line func-names


        list.i = function (modules, mediaQuery, dedupe) {
          if (typeof modules === 'string') {
            // eslint-disable-next-line no-param-reassign
            modules = [[null, modules, '']];
          }

          var alreadyImportedModules = {};

          if (dedupe) {
            for (var i = 0; i < this.length; i++) {
              // eslint-disable-next-line prefer-destructuring
              var id = this[i][0];

              if (id != null) {
                alreadyImportedModules[id] = true;
              }
            }
          }

          for (var _i = 0; _i < modules.length; _i++) {
            var item = [].concat(modules[_i]);

            if (dedupe && alreadyImportedModules[item[0]]) {
              // eslint-disable-next-line no-continue
              continue;
            }

            if (mediaQuery) {
              if (!item[2]) {
                item[2] = mediaQuery;
              } else {
                item[2] = "".concat(mediaQuery, " and ").concat(item[2]);
              }
            }

            list.push(item);
          }
        };

        return list;
      };

      function cssWithMappingToString(item, useSourceMap) {
        var content = item[1] || ''; // eslint-disable-next-line prefer-destructuring

        var cssMapping = item[3];

        if (!cssMapping) {
          return content;
        }

        if (useSourceMap && typeof btoa === 'function') {
          var sourceMapping = toComment(cssMapping);
          var sourceURLs = cssMapping.sources.map(function (source) {
            return "/*# sourceURL=".concat(cssMapping.sourceRoot || '').concat(source, " */");
          });
          return [content].concat(sourceURLs).concat([sourceMapping]).join('\n');
        }

        return [content].join('\n');
      } // Adapted from convert-source-map (MIT)


      function toComment(sourceMap) {
        // eslint-disable-next-line no-undef
        var base64 = btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap))));
        var data = "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(base64);
        return "/*# ".concat(data, " */");
      }
      /***/

    },

    /***/
    "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js":
    /*!****************************************************************************!*\
      !*** ./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js ***!
      \****************************************************************************/

    /*! no static exports found */

    /***/
    function node_modulesStyleLoaderDistRuntimeInjectStylesIntoStyleTagJs(module, exports, __webpack_require__) {
      "use strict";

      var isOldIE = function isOldIE() {
        var memo;
        return function memorize() {
          if (typeof memo === 'undefined') {
            // Test for IE <= 9 as proposed by Browserhacks
            // @see http://browserhacks.com/#hack-e71d8692f65334173fee715c222cb805
            // Tests for existence of standard globals is to allow style-loader
            // to operate correctly into non-standard environments
            // @see https://github.com/webpack-contrib/style-loader/issues/177
            memo = Boolean(window && document && document.all && !window.atob);
          }

          return memo;
        };
      }();

      var getTarget = function getTarget() {
        var memo = {};
        return function memorize(target) {
          if (typeof memo[target] === 'undefined') {
            var styleTarget = document.querySelector(target); // Special case to return head of iframe instead of iframe itself

            if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {
              try {
                // This will throw an exception if access to iframe is blocked
                // due to cross-origin restrictions
                styleTarget = styleTarget.contentDocument.head;
              } catch (e) {
                // istanbul ignore next
                styleTarget = null;
              }
            }

            memo[target] = styleTarget;
          }

          return memo[target];
        };
      }();

      var stylesInDom = [];

      function getIndexByIdentifier(identifier) {
        var result = -1;

        for (var i = 0; i < stylesInDom.length; i++) {
          if (stylesInDom[i].identifier === identifier) {
            result = i;
            break;
          }
        }

        return result;
      }

      function modulesToDom(list, options) {
        var idCountMap = {};
        var identifiers = [];

        for (var i = 0; i < list.length; i++) {
          var item = list[i];
          var id = options.base ? item[0] + options.base : item[0];
          var count = idCountMap[id] || 0;
          var identifier = "".concat(id, " ").concat(count);
          idCountMap[id] = count + 1;
          var index = getIndexByIdentifier(identifier);
          var obj = {
            css: item[1],
            media: item[2],
            sourceMap: item[3]
          };

          if (index !== -1) {
            stylesInDom[index].references++;
            stylesInDom[index].updater(obj);
          } else {
            stylesInDom.push({
              identifier: identifier,
              updater: addStyle(obj, options),
              references: 1
            });
          }

          identifiers.push(identifier);
        }

        return identifiers;
      }

      function insertStyleElement(options) {
        var style = document.createElement('style');
        var attributes = options.attributes || {};

        if (typeof attributes.nonce === 'undefined') {
          var nonce = true ? __webpack_require__.nc : undefined;

          if (nonce) {
            attributes.nonce = nonce;
          }
        }

        Object.keys(attributes).forEach(function (key) {
          style.setAttribute(key, attributes[key]);
        });

        if (typeof options.insert === 'function') {
          options.insert(style);
        } else {
          var target = getTarget(options.insert || 'head');

          if (!target) {
            throw new Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");
          }

          target.appendChild(style);
        }

        return style;
      }

      function removeStyleElement(style) {
        // istanbul ignore if
        if (style.parentNode === null) {
          return false;
        }

        style.parentNode.removeChild(style);
      }
      /* istanbul ignore next  */


      var replaceText = function replaceText() {
        var textStore = [];
        return function replace(index, replacement) {
          textStore[index] = replacement;
          return textStore.filter(Boolean).join('\n');
        };
      }();

      function applyToSingletonTag(style, index, remove, obj) {
        var css = remove ? '' : obj.media ? "@media ".concat(obj.media, " {").concat(obj.css, "}") : obj.css; // For old IE

        /* istanbul ignore if  */

        if (style.styleSheet) {
          style.styleSheet.cssText = replaceText(index, css);
        } else {
          var cssNode = document.createTextNode(css);
          var childNodes = style.childNodes;

          if (childNodes[index]) {
            style.removeChild(childNodes[index]);
          }

          if (childNodes.length) {
            style.insertBefore(cssNode, childNodes[index]);
          } else {
            style.appendChild(cssNode);
          }
        }
      }

      function applyToTag(style, options, obj) {
        var css = obj.css;
        var media = obj.media;
        var sourceMap = obj.sourceMap;

        if (media) {
          style.setAttribute('media', media);
        } else {
          style.removeAttribute('media');
        }

        if (sourceMap && btoa) {
          css += "\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))), " */");
        } // For old IE

        /* istanbul ignore if  */


        if (style.styleSheet) {
          style.styleSheet.cssText = css;
        } else {
          while (style.firstChild) {
            style.removeChild(style.firstChild);
          }

          style.appendChild(document.createTextNode(css));
        }
      }

      var singleton = null;
      var singletonCounter = 0;

      function addStyle(obj, options) {
        var style;
        var update;
        var remove;

        if (options.singleton) {
          var styleIndex = singletonCounter++;
          style = singleton || (singleton = insertStyleElement(options));
          update = applyToSingletonTag.bind(null, style, styleIndex, false);
          remove = applyToSingletonTag.bind(null, style, styleIndex, true);
        } else {
          style = insertStyleElement(options);
          update = applyToTag.bind(null, style, options);

          remove = function remove() {
            removeStyleElement(style);
          };
        }

        update(obj);
        return function updateStyle(newObj) {
          if (newObj) {
            if (newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap) {
              return;
            }

            update(obj = newObj);
          } else {
            remove();
          }
        };
      }

      module.exports = function (list, options) {
        options = options || {}; // Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
        // tags it will allow on a page

        if (!options.singleton && typeof options.singleton !== 'boolean') {
          options.singleton = isOldIE();
        }

        list = list || [];
        var lastIdentifiers = modulesToDom(list, options);
        return function update(newList) {
          newList = newList || [];

          if (Object.prototype.toString.call(newList) !== '[object Array]') {
            return;
          }

          for (var i = 0; i < lastIdentifiers.length; i++) {
            var identifier = lastIdentifiers[i];
            var index = getIndexByIdentifier(identifier);
            stylesInDom[index].references--;
          }

          var newLastIdentifiers = modulesToDom(newList, options);

          for (var _i = 0; _i < lastIdentifiers.length; _i++) {
            var _identifier = lastIdentifiers[_i];

            var _index = getIndexByIdentifier(_identifier);

            if (stylesInDom[_index].references === 0) {
              stylesInDom[_index].updater();

              stylesInDom.splice(_index, 1);
            }
          }

          lastIdentifiers = newLastIdentifiers;
        };
      };
      /***/

    },

    /***/
    "./src/assets/css/style.css":
    /*!**********************************!*\
      !*** ./src/assets/css/style.css ***!
      \**********************************/

    /*! no static exports found */

    /***/
    function srcAssetsCssStyleCss(module, exports, __webpack_require__) {
      var api = __webpack_require__(
      /*! ../../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */
      "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");

      var content = __webpack_require__(
      /*! !../../../node_modules/css-loader/dist/cjs.js??ref--13-1!../../../node_modules/postcss-loader/src??embedded!./style.css */
      "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./src/assets/css/style.css");

      content = content.__esModule ? content["default"] : content;

      if (typeof content === 'string') {
        content = [[module.i, content, '']];
      }

      var options = {};
      options.insert = "head";
      options.singleton = false;
      var update = api(content, options);
      module.exports = content.locals || {};
      /***/
    },

    /***/
    "./src/global.scss":
    /*!*************************!*\
      !*** ./src/global.scss ***!
      \*************************/

    /*! no static exports found */

    /***/
    function srcGlobalScss(module, exports, __webpack_require__) {
      var api = __webpack_require__(
      /*! ../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */
      "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");

      var content = __webpack_require__(
      /*! !../node_modules/css-loader/dist/cjs.js??ref--14-1!../node_modules/postcss-loader/src??embedded!../node_modules/resolve-url-loader??ref--14-3!../node_modules/sass-loader/dist/cjs.js??ref--14-4!./global.scss */
      "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/sass-loader/dist/cjs.js?!./src/global.scss");

      content = content.__esModule ? content["default"] : content;

      if (typeof content === 'string') {
        content = [[module.i, content, '']];
      }

      var options = {};
      options.insert = "head";
      options.singleton = false;
      var update = api(content, options);
      module.exports = content.locals || {};
      /***/
    },

    /***/
    "./src/theme/variables.scss":
    /*!**********************************!*\
      !*** ./src/theme/variables.scss ***!
      \**********************************/

    /*! no static exports found */

    /***/
    function srcThemeVariablesScss(module, exports, __webpack_require__) {
      var api = __webpack_require__(
      /*! ../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */
      "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");

      var content = __webpack_require__(
      /*! !../../node_modules/css-loader/dist/cjs.js??ref--14-1!../../node_modules/postcss-loader/src??embedded!../../node_modules/resolve-url-loader??ref--14-3!../../node_modules/sass-loader/dist/cjs.js??ref--14-4!./variables.scss */
      "./node_modules/css-loader/dist/cjs.js?!./node_modules/postcss-loader/src/index.js?!./node_modules/resolve-url-loader/index.js?!./node_modules/sass-loader/dist/cjs.js?!./src/theme/variables.scss");

      content = content.__esModule ? content["default"] : content;

      if (typeof content === 'string') {
        content = [[module.i, content, '']];
      }

      var options = {};
      options.insert = "head";
      options.singleton = false;
      var update = api(content, options);
      module.exports = content.locals || {};
      /***/
    },

    /***/
    3:
    /*!*************************************************************************************!*\
      !*** multi ./src/theme/variables.scss ./src/assets/css/style.css ./src/global.scss ***!
      \*************************************************************************************/

    /*! no static exports found */

    /***/
    function _(module, exports, __webpack_require__) {
      __webpack_require__(
      /*! E:\foodforlife27apr\src\theme\variables.scss */
      "./src/theme/variables.scss");

      __webpack_require__(
      /*! E:\foodforlife27apr\src\assets\css\style.css */
      "./src/assets/css/style.css");

      module.exports = __webpack_require__(
      /*! E:\foodforlife27apr\src\global.scss */
      "./src/global.scss");
      /***/
    }
  }, [[3, "runtime"]]]);
})();
//# sourceMappingURL=styles-es5.js.map