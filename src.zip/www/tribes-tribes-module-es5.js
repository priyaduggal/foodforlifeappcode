(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tribes-tribes-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/tribes/tribes.page.html":
    /*!*******************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/tribes/tribes.page.html ***!
      \*******************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppTribesTribesPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "   <ion-header>\r\n      <ion-toolbar color=\"primary\">\r\n        <ion-buttons slot=\"start\">\r\n          <ion-menu-button></ion-menu-button>\r\n        </ion-buttons>\r\n        <!--ion-title>Tribes</ion-title-->\r\n        <ion-title>Impact</ion-title>\r\n\t\t<ion-buttons routerLink=\"/searchteam\" slot=\"end\" mr-10>\r\n\t\t<ion-icon name=\"search-outline\"></ion-icon>\r\n\t\t</ion-buttons>\r\n      </ion-toolbar>\r\n\t  </ion-header>\r\n\r\n<ion-content class=\"ion-padding\">\r\n  <ion-segment [(ngModel)]=\"tribetab\">\r\n\t\t<ion-segment-button value=\"projects\">\r\n\t\t Projects\r\n\t\t</ion-segment-button>\r\n\t\t<ion-segment-button value=\"beneficiaries\" *ngIf=\"userdetails?.type==1\">\r\n\t\t   Testimonials\r\n\t\t</ion-segment-button>\r\n\t\t<ion-segment-button value=\"beneficiaries\" *ngIf=\"userdetails?.type==2\">\r\n\t\t   Testimonials\r\n\t\t</ion-segment-button>\r\n\t\t<ion-segment-button value=\"activity\">\r\n\t\t   Activites\r\n\t\t</ion-segment-button>\r\n  </ion-segment>\r\n     <div tribetab [ngSwitch]=\"tribetab\">\r\n\t\r\n\t<ion-list *ngSwitchCase=\"'projects'\">\r\n     <div projects   *ngIf=\"userdetails?.type==2\">\r\n\t<ion-item lines=\"none\"  *ngFor=\"let project of projectlist;let index=index;\" routerLink=\"/charitydetail/{{project?.id}}\" >\r\n\t <ion-thumbnail>\r\n\t   <img src=\"{{IMAGES_URL}}/{{project.image}}\"/>\r\n\t </ion-thumbnail>\r\n\t <ion-label>\r\n\t <h3 >{{project.title}}</h3>\r\n\t\r\n\t </ion-label>\r\n\t</ion-item>\r\n\t   </div>\r\n\t     <div projects   *ngIf=\"userdetails?.type==1\">\r\n\t<ion-item lines=\"none\"  *ngFor=\"let project of projectlist1;let index=index;\" routerLink=\"/charitydetail/{{project?.id}}\" >\r\n\t <ion-thumbnail>\r\n\t   <img src=\"{{IMAGES_URL}}/{{project.image}}\"/>\r\n\t </ion-thumbnail>\r\n\t <ion-label>\r\n\t <h3 >{{project.title}}</h3>\r\n\t\r\n\t </ion-label>\r\n\t</ion-item>\r\n\t   </div>\r\n\t</ion-list>\r\n\t\t<ion-list *ngSwitchCase=\"'beneficiaries'\">\r\n           <div beneficiaries *ngIf=\"userdetails?.type==2\">\r\n\t\t    <div benimg   *ngFor=\"let bene of beneficiaries;let index=index;\">\r\n\t\t\t  <img src=\"{{IMAGES_URL}}/{{bene?.image}}\"/>\r\n\t\t\t <h3>{{bene?.name}} </h3>\r\n\t\t\t<p><span commastop><img src=\"assets/images/quotation-marks.png\"/></span> {{bene?.description}} <span commasbottom><img src=\"assets/images/quotation-marks.png\"/></span></p>\r\n\t\t\t\r\n\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t\t <div beneficiaries *ngIf=\"userdetails?.type==1\">\r\n\t\t    <div benimg   *ngFor=\"let bene of beneficiariesc;let index=index;\">\r\n\t\t\t  <img src=\"{{IMAGES_URL}}/{{bene?.image}}\"/>\r\n\t\t\t <h3>{{bene?.name}} </h3>\r\n\t\t\t<p><span commastop><img src=\"assets/images/quotation-marks.png\"/></span> {{bene?.description}} <span commasbottom><img src=\"assets/images/quotation-marks.png\"/></span></p>\r\n\t\t\t\r\n\t\t\t</div>\r\n\t\t\t</div>\r\n\t\t  \r\n\t   </ion-list>\r\n\t\t<ion-list *ngSwitchCase=\"'activity'\">\r\n\t\t<div activityimg  *ngFor=\"let act of activities\" routerLink=\"/activitydetail/{{act?.id}}\">\r\n\t   <img  src=\"{{IMAGES_URL}}/{{act?.image}}\"/>\r\n\t   <div activitycontent>\r\n\t   <ion-note><ion-icon name=\"calendar-outline\"></ion-icon> {{act?.created_at | date : 'd MMM'}}</ion-note>\r\n\t   <p  routerLink=\"/activitydetail/{{act?.id}}\">{{act?.description}}</p>\r\n\t      <ion-button shape=\"round\" expand=\"full\"  (click)=\"give(act?.id)\">Give Now</ion-button>\r\n\t   </div>\r\n\t   </div>\r\n\t  \r\n\t   \r\n\t</ion-list>\r\n\t</div>\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "./src/app/tribes/tribes-routing.module.ts":
    /*!*************************************************!*\
      !*** ./src/app/tribes/tribes-routing.module.ts ***!
      \*************************************************/

    /*! exports provided: TribesPageRoutingModule */

    /***/
    function srcAppTribesTribesRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TribesPageRoutingModule", function () {
        return TribesPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _tribes_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./tribes.page */
      "./src/app/tribes/tribes.page.ts");

      var routes = [{
        path: '',
        component: _tribes_page__WEBPACK_IMPORTED_MODULE_3__["TribesPage"]
      }];

      var TribesPageRoutingModule = function TribesPageRoutingModule() {
        _classCallCheck(this, TribesPageRoutingModule);
      };

      TribesPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], TribesPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/tribes/tribes.module.ts":
    /*!*****************************************!*\
      !*** ./src/app/tribes/tribes.module.ts ***!
      \*****************************************/

    /*! exports provided: TribesPageModule */

    /***/
    function srcAppTribesTribesModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TribesPageModule", function () {
        return TribesPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _tribes_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./tribes-routing.module */
      "./src/app/tribes/tribes-routing.module.ts");
      /* harmony import */


      var _tribes_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./tribes.page */
      "./src/app/tribes/tribes.page.ts");

      var TribesPageModule = function TribesPageModule() {
        _classCallCheck(this, TribesPageModule);
      };

      TribesPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _tribes_routing_module__WEBPACK_IMPORTED_MODULE_5__["TribesPageRoutingModule"]],
        declarations: [_tribes_page__WEBPACK_IMPORTED_MODULE_6__["TribesPage"]]
      })], TribesPageModule);
      /***/
    },

    /***/
    "./src/app/tribes/tribes.page.scss":
    /*!*****************************************!*\
      !*** ./src/app/tribes/tribes.page.scss ***!
      \*****************************************/

    /*! exports provided: default */

    /***/
    function srcAppTribesTribesPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-header ion-toolbar {\n  --ion-color-base: var(--ion-color-bggradient)!important;\n  --border-width: 0;\n}\nion-header ion-toolbar ion-buttons {\n  font-size: 22px;\n}\nion-header ion-toolbar ion-buttons[mr-10] {\n  margin-right: 10px;\n}\nion-header ion-toolbar ion-title {\n  color: var(--ion-color-white);\n  text-align: center;\n  font-style: normal;\n  font-family: \"Poppins\", sans-serif !important;\n}\nion-header::after {\n  display: none;\n}\nion-content {\n  --background:#f7f7f7;\n}\nion-content ion-segment {\n  background: var(--ion-color-white);\n  border-radius: 30px;\n  padding: 5px;\n}\nion-content ion-segment ion-segment-button {\n  text-transform: capitalize;\n  min-height: 40px !important;\n  height: 30px !important;\n}\nion-content ion-segment ion-segment-button.segment-button-checked {\n  --indicator-color: transparent !important;\n  --indicator-color-checked: transparent !important;\n  background: var(--ion-color-primary);\n  border-radius: 30px;\n  --border-radius: 30px;\n  color: var(--ion-color-white);\n  --color-checked: var(--ion-color-white)!important;\n  font-weight: 500;\n}\nion-content [tribetab] ion-list {\n  margin-top: 15px;\n  padding: 0;\n  background: transparent;\n}\nion-content [tribetab] ion-list [beneficiaries] [benimg] {\n  padding: 16px 8px;\n  border-radius: 10px;\n  background-color: var(--ion-color-white);\n  position: relative;\n  color: var(--ion-color-black);\n  text-align: center;\n  margin-bottom: 15px;\n  position: relative;\n}\nion-content [tribetab] ion-list [beneficiaries] [benimg] [commastop] {\n  position: absolute;\n  left: 8px;\n  top: -3px;\n}\nion-content [tribetab] ion-list [beneficiaries] [benimg] [commastop] img {\n  width: 25px !important;\n  height: 25px !important;\n  border: none !important;\n  opacity: 0.35;\n}\nion-content [tribetab] ion-list [beneficiaries] [benimg] [commasbottom] {\n  position: absolute;\n  right: 8px;\n}\nion-content [tribetab] ion-list [beneficiaries] [benimg] [commasbottom] img {\n  width: 25px !important;\n  height: 25px !important;\n  border: none !important;\n  opacity: 0.35;\n  transform: rotate(180deg);\n}\nion-content [tribetab] ion-list [beneficiaries] [benimg] img {\n  width: 80px;\n  height: 80px;\n  border-radius: 50%;\n  -o-object-fit: cover;\n     object-fit: cover;\n  border: 2px solid var(--ion-color-primary);\n  padding: 3px;\n}\nion-content [tribetab] ion-list [beneficiaries] [benimg] h3 {\n  margin: 10px 0px 0;\n  font-size: 16px;\n}\nion-content [tribetab] ion-list [beneficiaries] [benimg] p {\n  margin: 5px 0px 0;\n  font-size: 13px;\n  line-height: 22px;\n  font-weight: 300;\n  color: #adadad;\n  font-style: italic;\n  position: relative;\n  padding: 0px 30px;\n}\nion-content [tribetab] ion-list [activityimg] {\n  margin-bottom: 15px;\n  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.09);\n  border-radius: 10px;\n  background: var(--ion-color-white);\n}\nion-content [tribetab] ion-list [activityimg] img {\n  height: 190px;\n  -o-object-fit: cover;\n     object-fit: cover;\n  width: 100%;\n  border-radius: 10px;\n}\nion-content [tribetab] ion-list [activityimg] [activitycontent] {\n  padding: 5px 10px 10px;\n  display: inline-block;\n  width: 100%;\n}\nion-content [tribetab] ion-list [activityimg] [activitycontent] ion-note {\n  color: #aaa;\n  font-size: 11px;\n}\nion-content [tribetab] ion-list [activityimg] [activitycontent] p {\n  font-size: 12px;\n  margin-top: 0;\n}\nion-content [tribetab] ion-list [activityimg] [activitycontent] ion-button {\n  --box-shadow: none;\n  font-size: 12px;\n}\nion-content [tribetab] ion-list [projects] ion-item {\n  --padding-start: 12px;\n  margin-bottom: 15px;\n  border-radius: 15px 0 15px;\n  --padding-top: 4px;\n  --padding-bottom: 4px;\n  background: var(--ion-color-white);\n  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);\n  border-left: 2px solid var(--ion-color-primary);\n}\nion-content [tribetab] ion-list [projects] ion-item ion-thumbnail {\n  width: 70px;\n  height: 70px;\n}\nion-content [tribetab] ion-list [projects] ion-item ion-thumbnail img {\n  width: 70px;\n  height: 70px;\n  border-radius: 10px;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\nion-content [tribetab] ion-list [projects] ion-item ion-label {\n  padding-left: 15px;\n  white-space: normal;\n  margin: 5px 0;\n}\nion-content [tribetab] ion-list [projects] ion-item ion-label h3 {\n  font-size: 13px;\n  font-weight: 500;\n  margin-bottom: 2px;\n  text-transform: capitalize;\n}\nion-content [tribetab] ion-list [friends] {\n  border-radius: 15px 0 15px;\n  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);\n  border-left: 2px solid var(--ion-color-primary);\n  background: var(--ion-color-white);\n  text-align: center;\n  padding: 20px;\n}\nion-content [tribetab] ion-list [friends] img {\n  max-width: 250px;\n  margin: 0px auto 10px;\n}\nion-content [tribetab] ion-list [friends] ion-button {\n  min-height: 42px;\n  --background: #3c5a98;\n  --box-shadow: none;\n}\nion-content [tribetab] ion-list [friends] ion-button ion-icon {\n  margin-right: 12px;\n}\nion-content [tribetab] ion-list ion-item {\n  --padding-start: 10px;\n  margin-bottom: 15px;\n  border-radius: 15px 0 15px;\n  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);\n  border-left: 2px solid var(--ion-color-primary);\n  --inner-padding-end: 5px;\n}\nion-content [tribetab] ion-list ion-item ion-thumbnail {\n  width: 70px;\n  height: 70px;\n}\nion-content [tribetab] ion-list ion-item ion-thumbnail img {\n  width: 70px;\n  height: 70px;\n  border-radius: 8px;\n}\nion-content [tribetab] ion-list ion-item ion-label {\n  margin-left: 15px;\n}\nion-content [tribetab] ion-list ion-item ion-label h2 {\n  margin-bottom: 5px;\n}\nion-content [tribetab] ion-list ion-item ion-label p span {\n  margin-right: 10px;\n  font-size: 14px;\n}\nion-content [tribetab] ion-list ion-item ion-label p span ion-icon {\n  margin-right: 3px;\n  color: var(--ion-color-primary);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdHJpYmVzL3RyaWJlcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBR0c7RUFDQyx1REFBQTtFQUNELGlCQUFBO0FBRkg7QUFHRTtFQUVBLGVBQUE7QUFGRjtBQUdFO0VBRUMsa0JBQUE7QUFGSDtBQUtJO0VBQ0EsNkJBQUE7RUFDQSxrQkFBQTtFQUNRLGtCQUFBO0VBQ0EsNkNBQUE7QUFIWjtBQU1DO0VBRUEsYUFBQTtBQUxEO0FBUUE7RUFFQSxvQkFBQTtBQU5BO0FBT0k7RUFDQSxrQ0FBQTtFQUNBLG1CQUFBO0VBQ0gsWUFBQTtBQUxEO0FBTUM7RUFDSywwQkFBQTtFQUNELDJCQUFBO0VBQ0QsdUJBQUE7QUFKSjtBQUtDO0VBQ0cseUNBQUE7RUFDQSxpREFBQTtFQUNBLG9DQUFBO0VBQ0EsbUJBQUE7RUFBb0IscUJBQUE7RUFDcEIsNkJBQUE7RUFDQSxpREFBQTtFQUNBLGdCQUFBO0FBRko7QUFRQTtFQUNDLGdCQUFBO0VBQ0QsVUFBQTtFQUNJLHVCQUFBO0FBTko7QUFTQztFQXVCQyxpQkFBQTtFQUNNLG1CQUFBO0VBQ0Esd0NBQUE7RUFDQSxrQkFBQTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7RUFDTixtQkFBQTtFQUNBLGtCQUFBO0FBN0JGO0FBQUU7RUFDSyxrQkFBQTtFQUNILFNBQUE7RUFDQSxTQUFBO0FBRUo7QUFEQztFQUNHLHNCQUFBO0VBQ0EsdUJBQUE7RUFDQSx1QkFBQTtFQUNBLGFBQUE7QUFHSjtBQURDO0VBQ0Usa0JBQUE7RUFDQyxVQUFBO0FBR0o7QUFGQztFQUNHLHNCQUFBO0VBQ0EsdUJBQUE7RUFDQSx1QkFBQTtFQUNBLGFBQUE7RUFDQSx5QkFBQTtBQUlKO0FBU0M7RUFFUSxXQUFBO0VBQ0wsWUFBQTtFQUVGLGtCQUFBO0VBQ0Esb0JBQUE7S0FBQSxpQkFBQTtFQUNBLDBDQUFBO0VBQ0EsWUFBQTtBQVRGO0FBV0M7RUFDQyxrQkFBQTtFQUNBLGVBQUE7QUFURjtBQVdDO0VBQ0ssaUJBQUE7RUFDRixlQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QUFUSjtBQWVDO0VBQW1CLG1CQUFBO0VBQ2YsNENBQUE7RUFDSixtQkFBQTtFQUNHLGtDQUFBO0FBWko7QUFhQztFQUVHLGFBQUE7RUFDQSxvQkFBQTtLQUFBLGlCQUFBO0VBQ0EsV0FBQTtFQUNBLG1CQUFBO0FBWko7QUFjQztFQUVHLHNCQUFBO0VBQ0EscUJBQUE7RUFDQSxXQUFBO0FBYko7QUFjRztFQUNLLFdBQUE7RUFDTixlQUFBO0FBWkY7QUFjQztFQUVBLGVBQUE7RUFDRyxhQUFBO0FBYko7QUFlQztFQUNHLGtCQUFBO0VBQ0EsZUFBQTtBQWJKO0FBb0JJO0VBQ0MscUJBQUE7RUFDRCxtQkFBQTtFQUNBLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxxQkFBQTtFQUNBLGtDQUFBO0VBQ0EsMkNBQUE7RUFDQSwrQ0FBQTtBQWxCSjtBQW1CRTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FBakJKO0FBa0JBO0VBQ0UsV0FBQTtFQUNFLFlBQUE7RUFDSCxtQkFBQTtFQUNHLG9CQUFBO0tBQUEsaUJBQUE7QUFoQko7QUFtQkM7RUFDQyxrQkFBQTtFQUFtQixtQkFBQTtFQUFtQixhQUFBO0FBZnhDO0FBaUJDO0VBQ0QsZUFBQTtFQUNJLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSwwQkFBQTtBQWZKO0FBc0JDO0VBRUksMEJBQUE7RUFDRCwyQ0FBQTtFQUNBLCtDQUFBO0VBQ0Esa0NBQUE7RUFDSCxrQkFBQTtFQUNHLGFBQUE7QUFyQko7QUFzQkM7RUFFQSxnQkFBQTtFQUNHLHFCQUFBO0FBckJKO0FBdUJDO0VBRUksZ0JBQUE7RUFDRCxxQkFBQTtFQUNBLGtCQUFBO0FBdEJKO0FBdUJDO0VBRUEsa0JBQUE7QUF0QkQ7QUEwQkM7RUFDQyxxQkFBQTtFQUNLLG1CQUFBO0VBQ0gsMEJBQUE7RUFDQSwyQ0FBQTtFQUNBLCtDQUFBO0VBQ0Esd0JBQUE7QUF4Qko7QUF5Qkc7RUFFSSxXQUFBO0VBQ0gsWUFBQTtBQXhCSjtBQXlCQztFQUVJLFdBQUE7RUFDRCxZQUFBO0VBQ0gsa0JBQUE7QUF4QkQ7QUEyQkc7RUFFQyxpQkFBQTtBQTFCSjtBQTJCSTtFQUVBLGtCQUFBO0FBMUJKO0FBOEJJO0VBQ0Msa0JBQUE7RUFDRCxlQUFBO0FBNUJKO0FBNkJJO0VBQ0MsaUJBQUE7RUFDRCwrQkFBQTtBQTNCSiIsImZpbGUiOiJzcmMvYXBwL3RyaWJlcy90cmliZXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWhlYWRlclxyXG57XHJcblxyXG5cdCAgaW9uLXRvb2xiYXJcclxuXHQgIHstLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1pb24tY29sb3ItYmdncmFkaWVudCkhaW1wb3J0YW50O1xyXG5cdCAgLS1ib3JkZXItd2lkdGg6IDA7XHJcblx0IGlvbi1idXR0b25zXHJcblx0IHtcclxuXHQgZm9udC1zaXplOiAyMnB4O1xyXG5cdCAmWyBtci0xMF1cclxuXHQge1xyXG5cdCAgbWFyZ2luLXJpZ2h0OjEwcHg7XHJcblx0IH1cclxuXHQgfVxyXG5cdFx0ICBpb24tdGl0bGV7XHJcblx0XHQgIGNvbG9yOnZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcblx0XHQgIHRleHQtYWxpZ246Y2VudGVyO1xyXG4gICAgICAgICAgICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcclxuICAgICAgICB9XHJcblx0fVxyXG5cdCY6OmFmdGVyXHJcblx0e1xyXG5cdGRpc3BsYXk6bm9uZTtcclxuXHR9XHJcbn1cclxuaW9uLWNvbnRlbnRcclxue1xyXG4tLWJhY2tncm91bmQ6I2Y3ZjdmNztcclxuICAgIGlvbi1zZWdtZW50IHtcclxuICAgIGJhY2tncm91bmQ6dmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDMwcHg7XHJcblx0cGFkZGluZzogNXB4O1xyXG5cdGlvbi1zZWdtZW50LWJ1dHRvblxyXG5cdHsgICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XHJcblx0ICAgIG1pbi1oZWlnaHQ6IDQwcHghaW1wb3J0YW50O1xyXG4gICAgaGVpZ2h0OiAzMHB4IWltcG9ydGFudDtcclxuXHQmLnNlZ21lbnQtYnV0dG9uLWNoZWNrZWR7XHJcbiAgICAtLWluZGljYXRvci1jb2xvcjogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcclxuICAgIC0taW5kaWNhdG9yLWNvbG9yLWNoZWNrZWQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbiAgICBib3JkZXItcmFkaXVzOiAzMHB4Oy0tYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdCAgIC0tY29sb3ItY2hlY2tlZDogdmFyKC0taW9uLWNvbG9yLXdoaXRlKSFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG59XHJcbn1cclxufVxyXG5bdHJpYmV0YWJdXHJcbntcclxuaW9uLWxpc3Rcclxue21hcmdpbi10b3A6MTVweDtcclxucGFkZGluZzogMDtcclxuICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG5cdFtiZW5lZmljaWFyaWVzXVxyXG5cdHtcclxuXHRbYmVuaW1nXVxyXG5cdHtbY29tbWFzdG9wXSBcclxuXHR7ICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBsZWZ0OiA4cHg7XHJcbiAgICB0b3A6IC0zcHg7XHJcblx0aW1nIHtcclxuICAgIHdpZHRoOiAyNXB4IWltcG9ydGFudDtcclxuICAgIGhlaWdodDogMjVweCFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXI6IG5vbmUhaW1wb3J0YW50O1xyXG4gICAgb3BhY2l0eTogMC4zNTtcclxufVxyXG59W2NvbW1hc2JvdHRvbV0gXHJcblx0eyBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICByaWdodDogOHB4O1xyXG5cdGltZyB7XHJcbiAgICB3aWR0aDogMjVweCAhaW1wb3J0YW50O1xyXG4gICAgaGVpZ2h0OiAyNXB4ICFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXI6IG5vbmUgIWltcG9ydGFudDtcclxuICAgIG9wYWNpdHk6IDAuMzU7XHJcbiAgICB0cmFuc2Zvcm06IHJvdGF0ZSgxODBkZWcpO1xyXG4gICBcclxufVxyXG59XHJcblx0IHBhZGRpbmc6MTZweCA4cHg7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czoxMHB4O1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6dmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgICAgICBwb3NpdGlvbjpyZWxhdGl2ZTtcclxuICAgICAgICBjb2xvcjp2YXIoLS1pb24tY29sb3ItYmxhY2spO1xyXG4gICAgICAgIHRleHQtYWxpZ246Y2VudGVyO1xyXG5cdFx0bWFyZ2luLWJvdHRvbToxNXB4O1xyXG5cdFx0cG9zaXRpb246cmVsYXRpdmU7XHJcblx0XHRcclxuXHRpbWdcclxuXHR7XHJcblx0ICAgICAgICB3aWR0aDogODBweDtcclxuICAgIGhlaWdodDogODBweDtcclxuXHJcblx0XHRib3JkZXItcmFkaXVzOiA1MCU7XHJcblx0XHRvYmplY3QtZml0OiBjb3ZlcjtcclxuXHRcdGJvcmRlcjogMnB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuXHRcdHBhZGRpbmc6IDNweDtcclxuXHR9XHJcblx0aDNcclxuXHR7bWFyZ2luOjEwcHggMHB4IDA7XHJcblx0XHRmb250LXNpemU6IDE2cHg7XHJcblx0fVxyXG5cdHBcclxuXHR7ICAgIG1hcmdpbjogNXB4IDBweCAwO1xyXG4gICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDIycHg7XHJcbiAgICBmb250LXdlaWdodDogMzAwO1xyXG4gICAgY29sb3I6ICNhZGFkYWQ7XHJcbiAgICBmb250LXN0eWxlOiBpdGFsaWM7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBwYWRkaW5nOiAwcHggMzBweDtcclxuXHR9XHJcbiAgfVxyXG4gIH1cclxuXHRcclxuXHRcclxuXHRbYWN0aXZpdHlpbWddIHsgICAgbWFyZ2luLWJvdHRvbTogMTVweDtcclxuXHQgICAgYm94LXNoYWRvdzogMHB4IDBweCAxMHB4IHJnYmEoMCwgMCwgMCAsIC4wOSk7XHJcblx0Ym9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcblx0aW1nXHJcblx0e1xyXG4gICAgaGVpZ2h0OiAxOTBweDtcclxuICAgIG9iamVjdC1maXQ6IGNvdmVyO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG5cdH1cclxuXHRbYWN0aXZpdHljb250ZW50XSB7XHJcbiAgIFxyXG4gICAgcGFkZGluZzogNXB4IDEwcHggMTBweDtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIHdpZHRoOiAxMDAlO1xyXG5cdCAgaW9uLW5vdGVcclxuXHQgIHsgICAgY29sb3I6ICNhYWE7XHJcblx0IGZvbnQtc2l6ZTogMTFweDsgXHJcblx0ICB9XHJcblx0cFxyXG5cdHtcclxuXHRmb250LXNpemU6IDEycHg7XHJcbiAgICBtYXJnaW4tdG9wOiAwO1xyXG5cdH1cclxuXHRpb24tYnV0dG9uIHtcclxuICAgIC0tYm94LXNoYWRvdzogbm9uZTtcclxuICAgIGZvbnQtc2l6ZTogMTJweDtcclxufVxyXG59XHJcbn1cclxuW3Byb2plY3RzXVxyXG5cdHtcclxuXHRcclxuXHQgICBpb24taXRlbVxyXG5cdHsgICAtLXBhZGRpbmctc3RhcnQ6IDEycHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxNXB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTVweCAwIDE1cHg7XHJcbiAgICAtLXBhZGRpbmctdG9wOiA0cHg7XHJcbiAgICAtLXBhZGRpbmctYm90dG9tOiA0cHg7XHJcbiAgICBiYWNrZ3JvdW5kOiAgdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgIGJveC1zaGFkb3c6IDBweCAwcHggMTBweCByZ2JhKDAsIDAsIDAsIDAuMSk7XHJcbiAgICBib3JkZXItbGVmdDogMnB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuXHRcdGlvbi10aHVtYm5haWx7XHJcbiAgICB3aWR0aDogNzBweDtcclxuICAgIGhlaWdodDogNzBweDtcclxuaW1nXHJcbnsgd2lkdGg6IDcwcHg7XHJcbiAgICBoZWlnaHQ6IDcwcHg7XHJcblx0Ym9yZGVyLXJhZGl1czoxMHB4O1xyXG4gICAgb2JqZWN0LWZpdDogY292ZXI7XHJcbn1cclxuXHR9XHJcblx0aW9uLWxhYmVsXHJcblx0e3BhZGRpbmctbGVmdDogMTVweDt3aGl0ZS1zcGFjZTpub3JtYWw7bWFyZ2luOiA1cHggMDtcclxuXHRcclxuXHRoM3tcclxuZm9udC1zaXplOiAxM3B4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgIG1hcmdpbi1ib3R0b206IDJweDtcclxuICAgIHRleHQtdHJhbnNmb3JtOiBjYXBpdGFsaXplO1xyXG5cdH1cclxuXHRcclxuXHRcclxuXHR9XHJcbiAgfVxyXG4gIH1cclxuXHRbZnJpZW5kc11cclxuXHR7XHJcblx0ICAgIGJvcmRlci1yYWRpdXM6IDE1cHggMCAxNXB4O1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDBweCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuICAgIGJvcmRlci1sZWZ0OiAycHggc29saWQgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuXHR0ZXh0LWFsaWduOmNlbnRlcjtcclxuICAgIHBhZGRpbmc6IDIwcHg7XHJcblx0aW1nXHJcblx0e1xyXG5cdG1heC13aWR0aDogMjUwcHg7XHJcbiAgICBtYXJnaW46IDBweCBhdXRvIDEwcHg7XHJcblx0fVxyXG5cdGlvbi1idXR0b25cclxuXHR7XHJcblx0ICAgIG1pbi1oZWlnaHQ6IDQycHg7XHJcbiAgICAtLWJhY2tncm91bmQ6ICMzYzVhOTg7XHJcbiAgICAtLWJveC1zaGFkb3c6IG5vbmU7XHJcblx0aW9uLWljb25cclxuXHR7XHJcblx0bWFyZ2luLXJpZ2h0OjEycHg7XHJcblx0fVxyXG5cdH1cclxuXHR9XHJcblx0aW9uLWl0ZW1cclxuXHR7LS1wYWRkaW5nLXN0YXJ0OiAxMHB4O1xyXG4gICAgICAgbWFyZ2luLWJvdHRvbTogMTVweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDE1cHggMCAxNXB4O1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDBweCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuICAgIGJvcmRlci1sZWZ0OiAycHggc29saWQgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG4gICAgLS1pbm5lci1wYWRkaW5nLWVuZDogNXB4O1xyXG5cdCAgaW9uLXRodW1ibmFpbFxyXG5cdCAge1xyXG5cdCAgICAgIHdpZHRoOiA3MHB4O1xyXG4gICAgaGVpZ2h0OiA3MHB4O1xyXG5cdGltZ1xyXG5cdHtcclxuXHQgICAgd2lkdGg6IDcwcHg7XHJcbiAgICBoZWlnaHQ6IDcwcHg7XHJcblx0Ym9yZGVyLXJhZGl1czo4cHg7XHJcblx0fVxyXG5cdCAgfVxyXG5cdCAgaW9uLWxhYmVsXHJcblx0ICB7XHJcblx0ICAgbWFyZ2luLWxlZnQ6IDE1cHg7XHJcblx0ICAgaDJcclxuXHQgICB7XHJcblx0ICAgbWFyZ2luLWJvdHRvbTogNXB4O1xyXG5cdCAgIH1cclxuXHQgICBwXHJcblx0ICAge1xyXG5cdCAgIHNwYW5cclxuXHQgICB7bWFyZ2luLXJpZ2h0OjEwcHg7XHJcblx0ICAgZm9udC1zaXplOjE0cHg7XHJcblx0ICAgaW9uLWljb25cclxuXHQgICB7bWFyZ2luLXJpZ2h0OjNweDtcclxuXHQgICBjb2xvcjp2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcblx0ICAgfVxyXG5cdCAgIH1cclxuXHQgICB9XHJcblx0ICB9XHJcblx0fVxyXG59XHJcbn1cclxufSJdfQ== */";
      /***/
    },

    /***/
    "./src/app/tribes/tribes.page.ts":
    /*!***************************************!*\
      !*** ./src/app/tribes/tribes.page.ts ***!
      \***************************************/

    /*! exports provided: TribesPage */

    /***/
    function srcAppTribesTribesPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TribesPage", function () {
        return TribesPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../services/api/api.service */
      "./src/app/services/api/api.service.ts");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../config */
      "./src/app/config.ts");
      /* harmony import */


      var _common_common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../common/common.service */
      "./src/app/common/common.service.ts");
      /* harmony import */


      var _addamount_addamount_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../addamount/addamount.page */
      "./src/app/addamount/addamount.page.ts");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

      var TribesPage = /*#__PURE__*/function () {
        function TribesPage(modalController, api, router, common) {
          _classCallCheck(this, TribesPage);

          this.modalController = modalController;
          this.api = api;
          this.router = router;
          this.common = common;
          this.tribetab = "projects";
          this.isAndroid = false;
          this.projectlist = [];
          this.projectlist1 = [];
          this.errors = ['', null, undefined];
          this.activities = [];
          this.beneficiaries = [];
          this.beneficiariesc = [];
          this.IMAGES_URL = _config__WEBPACK_IMPORTED_MODULE_4__["config"].IMAGES_URL;
        }

        _createClass(TribesPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "ionViewDidEnter",
          value: function ionViewDidEnter() {
            this.userid = localStorage.getItem('userid');
            this.getuserdetails();
            this.getprojects();
            this.getcompanyprojects();
            this.getbeneficiaries();
            this.getcbeneficiaries();
            this.getactivities();
          }
        }, {
          key: "getuserdetails",
          value: function getuserdetails() {
            var _this = this;

            var dict = {
              id: this.userid
            };
            this.common.presentLoading();

            if (this.errors.indexOf(this.userid) >= 0) {
              this.common.presentToast('Please login first!.', 'danger');
              return false;
            }

            this.api.post('Userdetails', dict, '').subscribe(function (result) {
              _this.common.stopLoading();

              var res;
              res = result;

              if (res.status == 1) {
                _this.userdetails = res.data; //this.donationlist=res.donations;
              } else {
                _this.common.presentToast(res.message, 'danger');
              }
            }, function (err) {
              _this.common.presentToast('Some error occured', 'danger');
            });
          }
        }, {
          key: "give",
          value: function give(id) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this2 = this;

              var modal;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.modalController.create({
                        component: _addamount_addamount_page__WEBPACK_IMPORTED_MODULE_6__["AddamountPage"],
                        cssClass: 'leaveteam',
                        componentProps: {
                          actid: id
                        }
                      });

                    case 2:
                      modal = _context.sent;
                      modal.onDidDismiss().then(function (detail) {
                        if (_this2.errors.indexOf(detail.data) == -1) {//this.team.joins=this.team.joins - 1;
                          //this.getuserteams();
                        }
                      });
                      _context.next = 6;
                      return modal.present();

                    case 6:
                      return _context.abrupt("return", _context.sent);

                    case 7:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "getcompanyprojects",
          value: function getcompanyprojects() {
            var _this3 = this;

            this.api.post('tribesProjectCompany', '', '').subscribe(function (result) {
              var res;
              res = result;

              if (res.status == 1) {
                _this3.projectlist1 = res.data;
              } else {}
            }, function (err) {});
          }
        }, {
          key: "getprojects",
          value: function getprojects() {
            var _this4 = this;

            // this.common.presentLoading();
            this.api.post('tribesProject', '', '').subscribe(function (result) {
              //this.common.stopLoading();
              var res;
              res = result;

              if (res.status == 1) {
                _this4.projectlist = res.data;
              } else {}
            }, function (err) {});
          }
        }, {
          key: "getcbeneficiaries",
          value: function getcbeneficiaries() {
            var _this5 = this;

            this.api.post('companybeneficiaries', '', '').subscribe(function (result) {
              var res;
              res = result;

              if (res.status == 1) {
                _this5.beneficiariesc = res.data;
              } else {}
            }, function (err) {});
          }
        }, {
          key: "getbeneficiaries",
          value: function getbeneficiaries() {
            var _this6 = this;

            //this.common.presentLoading();
            this.api.post('tribesbeneficiaries', '', '').subscribe(function (result) {
              //this.common.stopLoading();
              var res;
              res = result;

              if (res.status == 1) {
                _this6.beneficiaries = res.data;
              } else {}
            }, function (err) {});
          }
        }, {
          key: "getactivities",
          value: function getactivities() {
            var _this7 = this;

            //this.common.presentLoading();
            this.api.post('tribesactivities', '', '').subscribe(function (result) {
              //this.common.stopLoading();
              var res;
              res = result;

              if (res.status == 1) {
                _this7.activities = res.data;
              } else {}
            }, function (err) {});
          }
        }]);

        return TribesPage;
      }();

      TribesPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"]
        }, {
          type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
        }, {
          type: _common_common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"]
        }];
      };

      TribesPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-tribes',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./tribes.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/tribes/tribes.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./tribes.page.scss */
        "./src/app/tribes/tribes.page.scss"))["default"]]
      })], TribesPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=tribes-tribes-module-es5.js.map