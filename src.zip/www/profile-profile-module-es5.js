(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["profile-profile-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/profile/profile.page.html":
    /*!*********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/profile/profile.page.html ***!
      \*********************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppProfileProfilePageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "   <ion-header>\r\n      <ion-toolbar color=\"primary\">\r\n        <ion-buttons slot=\"start\">\r\n          <ion-menu-button></ion-menu-button>\r\n        </ion-buttons>\r\n        <ion-title>Profile</ion-title>\r\n\t\t<ion-buttons routerLink=\"/tabs/settings\"  slot=\"end\">\r\n\t\t<ion-icon name=\"settings-outline\"></ion-icon>\r\n\t\t</ion-buttons>\r\n      </ion-toolbar>\r\n\t  </ion-header>\r\n\r\n<ion-content>\r\n<div profileinfo>\r\n<div profileimg>\r\n  <img src=\"assets/images/paul-feeding.jpg\"/>\r\n  <div userinner>\r\n  <a btnedit    routerLink=\"/editprofile\" >\r\n     <ion-icon name=\"create-outline\"></ion-icon>\r\n  </a>\r\n<img src=\"assets/images/user1.jpg\" *ngIf=\"errors.indexOf(userdetails?.image)>=0\">\r\n<img src=\"{{IMAGES_URL}}/{{userdetails?.image}}\" *ngIf=\"errors.indexOf(userdetails?.image)==-1\">\r\n <!--img *ngIf=\"errors.indexOf(userdetails?.image) == -1 && getimage(userdetails?.image) == false && is_live_image_updated_profile == false\" src=\"{{IMAGES_URL + userdetails?.image}}\">\r\n <img *ngIf=\"errors.indexOf(userdetails?.image) == -1 && getimage(userdetails?.image) == true  && is_live_image_updated_profile == false\" src=\"{{IMAGES_URL}}/{{userdetails?.image}}\">\r\n <img *ngIf=\"image_type == 'profile'  && is_live_image_updated_profile == true\" [src]=\"win.Ionic.WebView.convertFileSrc(live_image_url)\">\r\n <img *ngIf=\"errors.indexOf(userdetails?.image) >= 0 && is_live_image_updated_profile == false\" src=\"assets/images/user1.jpg\"-->\r\n\r\n\r\n</div>\r\n</div>\r\n<div userimg>\r\n\r\n<h2 *ngIf=\"errors.indexOf(userid)>=0\">Together We Can End The Hunger</h2>\r\n<p *ngIf=\"errors.indexOf(userid)>=0\">Sign In or Create an account to kep track of your personal impact</p>\r\n<a btnaccount  routerLink=\"/signup\" href=\"javascript:void(0)\"*ngIf=\"errors.indexOf(userid)>=0\">Create Account or Login</a>\r\n</div>\r\n</div>\r\n<div profileinner *ngIf=\"userdetails?.type==1\">\r\n<p class=\"profile_listing\">First Name <span style=\"float: right;font-weight: 200;\">{{userdetails?.first_name}}</span></p> \r\n<p class=\"profile_listing\">Last Name <span style=\"float: right;font-weight: 200;\">{{userdetails?.last_name}}</span></p> \r\n<p class=\"profile_listing\">Email <span style=\"float: right;font-weight: 200;\">  {{userdetails?.email}}</span></p> \r\n<p class=\"profile_listing\">Address <span style=\"float: right;font-weight: 200;\">{{userdetails?.address}}</span></p> \r\n\r\n</div>\r\n<div profileinner *ngIf=\"userdetails?.type==2\">\r\n<h2 heading>\r\nYour Donations\r\n</h2>\r\n\t\t<p *ngIf=\"donationlist?.length==0\">No Record Found..!</p>\r\n\t\t<ion-item lines=\"none\"  *ngFor=\"let don of donationlist\">\r\n\t\t<ion-thumbnail>\r\n\t\t<img   *ngIf=\"errors.indexOf(don?.charityid)==-1\" src=\"{{IMAGES_URL}}/{{don?.image}}\"/>\r\n\t\t<img   *ngIf=\"errors.indexOf(don?.actid)==-1\" src=\"{{IMAGES_URL}}/{{don?.aimage}}\"/>\r\n\t\t<img   *ngIf=\"errors.indexOf(don?.teamid)==-1\" src=\"{{IMAGES_URL}}/{{don?.timage}}\"/>\r\n\t\t</ion-thumbnail>\r\n\t\t<ion-label>\r\n\t\t\r\n\t\t\r\n\t\t<h3  *ngIf=\"errors.indexOf(don?.actid)==-1\"    routerLink=\"/activitydetail/{{don?.actid}}\">{{don?.atitle}}</h3>\r\n\t\t<h3  *ngIf=\"errors.indexOf(don?.teamid)==-1\"    routerLink=\"/teamdetail/{{don?.teamid}}\">{{don?.ttitle}}</h3>\r\n\t\t<h3  *ngIf=\"errors.indexOf(don?.charityid)==-1\"   routerLink=\"/charitydetail/{{don?.charityid}}\">{{don?.title}}</h3>\r\n\t\t<p *ngIf=\"errors.indexOf(don?.actid)==-1\"><b>${{don?.amount}} </b> given to {{don?.atitle}}</p>\r\n\t\t<p *ngIf=\"errors.indexOf(don?.teamid)==-1\"><b>${{don?.amount}} </b> given to {{don?.ttitle}}</p>\r\n\t\t<p *ngIf=\"errors.indexOf(don?.charityid)==-1\"><b>${{don?.amount}} </b> given to {{don?.title}}</p>\r\n\t\t<p *ngIf=\"errors.indexOf(don?.charityid)>=0 && errors.indexOf(don?.teamid)>=0 &&\r\n\t\terrors.indexOf(don?.actid)>=0 \"><b>${{don?.amount}} </b> given to donation jar</p>\r\n\t\t\r\n\t\t\r\n\t\t<ion-note><ion-icon name=\"calendar-outline\"></ion-icon> {{don?.donated_at | date : 'd MMM yyyy'}}</ion-note>\r\n\t\t</ion-label>\r\n\t\t</ion-item>\r\n\t</div>\r\n<div certficate-sec   *ngIf=\"userdetails?.type==1\">\r\n     <ion-button href=\"https://ffl.org/donate/join-the-10-a-month-club/\" expand=\"full\" shape=\"round\" class=\"btn-losns\">Get Certificate</ion-button>\r\n</div>\r\n</ion-content>\r\n";
      /***/
    },

    /***/
    "./src/app/profile/profile-routing.module.ts":
    /*!***************************************************!*\
      !*** ./src/app/profile/profile-routing.module.ts ***!
      \***************************************************/

    /*! exports provided: ProfilePageRoutingModule */

    /***/
    function srcAppProfileProfileRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ProfilePageRoutingModule", function () {
        return ProfilePageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _profile_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./profile.page */
      "./src/app/profile/profile.page.ts");

      var routes = [{
        path: '',
        component: _profile_page__WEBPACK_IMPORTED_MODULE_3__["ProfilePage"]
      }];

      var ProfilePageRoutingModule = function ProfilePageRoutingModule() {
        _classCallCheck(this, ProfilePageRoutingModule);
      };

      ProfilePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], ProfilePageRoutingModule);
      /***/
    },

    /***/
    "./src/app/profile/profile.module.ts":
    /*!*******************************************!*\
      !*** ./src/app/profile/profile.module.ts ***!
      \*******************************************/

    /*! exports provided: ProfilePageModule */

    /***/
    function srcAppProfileProfileModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ProfilePageModule", function () {
        return ProfilePageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _profile_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./profile-routing.module */
      "./src/app/profile/profile-routing.module.ts");
      /* harmony import */


      var _profile_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./profile.page */
      "./src/app/profile/profile.page.ts");

      var ProfilePageModule = function ProfilePageModule() {
        _classCallCheck(this, ProfilePageModule);
      };

      ProfilePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _profile_routing_module__WEBPACK_IMPORTED_MODULE_5__["ProfilePageRoutingModule"]],
        declarations: [_profile_page__WEBPACK_IMPORTED_MODULE_6__["ProfilePage"]]
      })], ProfilePageModule);
      /***/
    },

    /***/
    "./src/app/profile/profile.page.scss":
    /*!*******************************************!*\
      !*** ./src/app/profile/profile.page.scss ***!
      \*******************************************/

    /*! exports provided: default */

    /***/
    function srcAppProfileProfilePageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-header ion-toolbar {\n  --ion-color-base: var(--ion-color-bggradient)!important;\n  --border-width: 0;\n}\nion-header ion-toolbar ion-buttons {\n  font-size: 22px;\n}\nion-header ion-toolbar ion-title {\n  color: var(--ion-color-white);\n  text-align: center;\n  font-style: normal;\n  font-family: \"Poppins\", sans-serif !important;\n}\nion-header::after {\n  display: none;\n}\nion-content [profileinfo] [userimg] {\n  padding: 60px 15px 0;\n  margin-top: -20px;\n  background: var(--ion-color-white);\n  position: relative;\n  border-radius: 15px 15px 0 0;\n}\nion-content [profileinfo] [userimg] [btnaccount] {\n  display: block;\n  text-align: center;\n  font-size: 13px;\n}\nion-content [profileinfo] [userimg] h2 {\n  margin-top: 5px;\n  margin-bottom: 5px;\n  font-size: 14px;\n  font-weight: 500;\n  text-align: center;\n}\nion-content [profileinfo] [userimg] p {\n  color: #9d9d9d;\n  font-size: 13px;\n  text-align: center;\n  margin: 0 0 5px;\n}\nion-content [profileinfo] [profileimg] {\n  position: relative;\n  height: 160px;\n}\nion-content [profileinfo] [profileimg] img {\n  max-width: 100%;\n  max-height: 100%;\n  width: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n  -o-object-position: bottom;\n     object-position: bottom;\n}\nion-content [profileinfo] [profileimg] [userinner] {\n  position: relative;\n  text-align: center;\n  margin-top: -62px;\n  z-index: 1;\n}\nion-content [profileinfo] [profileimg] [userinner] [btnedit] {\n  margin-left: 45px;\n  width: 30px;\n  height: 30px;\n  background: var(--ion-color-primary);\n  border-radius: 50%;\n  display: inline-block;\n  line-height: 30px;\n  border: 2px solid var(--ion-color-white);\n  position: absolute;\n  bottom: 1px;\n}\nion-content [profileinfo] [profileimg] [userinner] [btnedit] ion-icon {\n  color: var(--ion-color-white);\n}\nion-content [profileinfo] [profileimg] [userinner] img {\n  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.25);\n  width: 80px;\n  height: 80px;\n  border-radius: 50%;\n  border: 2px solid var(--ion-color-white);\n  margin: 0 auto;\n  text-align: center;\n}\nion-content [profileinner] {\n  padding: 15px;\n}\nion-content [profileinner] h2[heading] {\n  font-size: 20px;\n  margin-top: 0px;\n  position: relative;\n  z-index: 1;\n  font-weight: 600;\n}\nion-content [profileinner] h2[heading]:after {\n  /*opacity: .5;*/\n  content: \"\";\n  background: var(--ion-color-softgreen);\n  height: 9px;\n  width: 90px;\n  position: absolute;\n  bottom: 0px;\n  left: 0px;\n  z-index: -1;\n}\nion-content [profileinner] ion-item {\n  --padding-start: 12px;\n  margin-bottom: 15px;\n  border-radius: 15px 0 15px;\n  --padding-top: 4px;\n  --padding-bottom: 4px;\n  background: #fff;\n  box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);\n  border-left: 2px solid var(--ion-color-primary);\n}\nion-content [profileinner] ion-item ion-thumbnail {\n  width: 60px;\n  height: 60px;\n}\nion-content [profileinner] ion-item ion-thumbnail img {\n  width: 60px;\n  height: 60px;\n  border-radius: 10px;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\nion-content [profileinner] ion-item ion-label {\n  padding-left: 15px;\n  white-space: normal;\n  margin: 5px 0;\n}\nion-content [profileinner] ion-item ion-label p {\n  color: var(--ion-color-black3);\n  font-size: 13px;\n  font-weight: 500;\n  white-space: normal;\n  line-height: 16px;\n  margin: 0 0px 5px;\n}\nion-content [profileinner] ion-item ion-label h3 {\n  font-size: 13px;\n  font-weight: 500;\n  margin-bottom: 2px;\n  text-transform: capitalize;\n}\nion-content [profileinner] ion-item ion-label p {\n  color: #9d9d9d;\n  font-size: 12px;\n  font-weight: 500;\n  white-space: normal;\n  line-height: 16px;\n  margin: 0 0px 5px;\n}\nion-content [profileinner] ion-item ion-label p b {\n  color: var(--ion-color-primary);\n}\nion-content [profileinner] ion-item ion-label ion-note {\n  color: #ababab;\n  font-size: 11px;\n  margin: 0;\n  display: flex;\n  align-items: center;\n}\nion-content [profileinner] ion-item ion-label ion-note ion-icon {\n  margin-right: 2px;\n}\nion-content [certficate-sec] {\n  padding: 0px 15px;\n}\nion-content [certficate-sec] .btn-losns {\n  --background:var( --ion-color-primary);\n  margin-top: 5px;\n  --box-shadow: none;\n  min-height: 48px;\n  margin-bottom: 15px;\n  text-transform: uppercase;\n  letter-spacing: 1px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcHJvZmlsZS9wcm9maWxlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHRztFQUNDLHVEQUFBO0VBQ0QsaUJBQUE7QUFGSDtBQUdDO0VBRUMsZUFBQTtBQUZGO0FBSUk7RUFDQSw2QkFBQTtFQUNBLGtCQUFBO0VBQ1Esa0JBQUE7RUFDQSw2Q0FBQTtBQUZaO0FBS0M7RUFFQSxhQUFBO0FBSkQ7QUFXQztFQUNNLG9CQUFBO0VBQ0gsaUJBQUE7RUFDQSxrQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsNEJBQUE7QUFSSjtBQVNDO0VBQ0csY0FBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQVBKO0FBU0M7RUFDSyxlQUFBO0VBQ0Ysa0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBQVBKO0FBU0E7RUFFQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0MsZUFBQTtBQVJEO0FBWUM7RUFDSyxrQkFBQTtFQUVILGFBQUE7QUFYSDtBQVlHO0VBRUUsZUFBQTtFQUNELGdCQUFBO0VBQ0EsV0FBQTtFQUNBLG9CQUFBO0tBQUEsaUJBQUE7RUFDQSwwQkFBQTtLQUFBLHVCQUFBO0FBWEo7QUFhRztFQUVDLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLFVBQUE7QUFaSjtBQWNDO0VBQ0csaUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG9DQUFBO0VBQ0Esa0JBQUE7RUFDQSxxQkFBQTtFQUNBLGlCQUFBO0VBQ0Esd0NBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7QUFaSjtBQWFDO0VBQ0MsNkJBQUE7QUFYRjtBQWNFO0VBQ0csNENBQUE7RUFDRCxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0Esd0NBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7QUFaSjtBQWlCRTtFQUNDLGFBQUE7QUFmSDtBQWtCQTtFQUNDLGVBQUE7RUFDRCxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0EsZ0JBQUE7QUFoQkE7QUFpQkE7RUFDSSxlQUFBO0VBQ0EsV0FBQTtFQUNBLHNDQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxTQUFBO0VBQ0EsV0FBQTtBQWZKO0FBbUJJO0VBQ0MscUJBQUE7RUFDRCxtQkFBQTtFQUNBLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxxQkFBQTtFQUNBLGdCQUFBO0VBQ0EsMkNBQUE7RUFDQSwrQ0FBQTtBQWpCSjtBQWtCRTtFQUNFLFdBQUE7RUFDQSxZQUFBO0FBaEJKO0FBaUJBO0VBQ0UsV0FBQTtFQUNFLFlBQUE7RUFDSCxtQkFBQTtFQUNBLG9CQUFBO0tBQUEsaUJBQUE7QUFmRDtBQWtCQztFQUNDLGtCQUFBO0VBQW1CLG1CQUFBO0VBQW1CLGFBQUE7QUFkeEM7QUFlRTtFQUNBLDhCQUFBO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtFQUNBLGlCQUFBO0FBYko7QUFlQztFQUNELGVBQUE7RUFDSSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsMEJBQUE7QUFiSjtBQWVDO0VBQ0MsY0FBQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtBQWJKO0FBY0M7RUFDRywrQkFBQTtBQVpKO0FBZUM7RUFFRyxjQUFBO0VBQ0YsZUFBQTtFQUNBLFNBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QUFkRjtBQWVFO0VBRUUsaUJBQUE7QUFkSjtBQW9CQztFQUVLLGlCQUFBO0FBbkJOO0FBb0JFO0VBRUMsc0NBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtBQW5CSCIsImZpbGUiOiJzcmMvYXBwL3Byb2ZpbGUvcHJvZmlsZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyXHJcblx0e1xyXG5cdFxyXG5cdCAgaW9uLXRvb2xiYXJcclxuXHQgIHstLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1pb24tY29sb3ItYmdncmFkaWVudCkhaW1wb3J0YW50O1xyXG5cdCAgLS1ib3JkZXItd2lkdGg6IDA7XHJcblx0aW9uLWJ1dHRvbnNcclxuXHQge1xyXG5cdCBmb250LXNpemU6IDIycHg7XHJcblx0IH1cclxuXHRcdCAgaW9uLXRpdGxle1xyXG5cdFx0ICBjb2xvcjp2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdFx0ICB0ZXh0LWFsaWduOmNlbnRlcjtcclxuICAgICAgICAgICAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gICAgICAgICAgICBmb250LWZhbWlseTogJ1BvcHBpbnMnLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgfVxyXG5cdH1cclxuXHQmOjphZnRlclxyXG5cdHtcclxuXHRkaXNwbGF5Om5vbmU7XHJcblx0fVxyXG5cdH1cclxuXHRpb24tY29udGVudFxyXG5cdHtcclxuXHRbcHJvZmlsZWluZm9dXHJcbiB7XHJcbiBbdXNlcmltZ11cclxuIHsgICAgIHBhZGRpbmc6IDYwcHggMTVweCAwO1xyXG4gICAgbWFyZ2luLXRvcDogLTIwcHg7XHJcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itd2hpdGUpO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTVweCAxNXB4IDAgMDtcclxuIFtidG5hY2NvdW50XSB7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMTNweDtcclxufVxyXG5cdGgyIHtcclxuICAgICAgbWFyZ2luLXRvcDogNXB4O1xyXG4gICAgbWFyZ2luLWJvdHRvbTogNXB4O1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxufVxyXG5wXHJcbntcclxuY29sb3I6ICM5ZDlkOWQ7XHJcbmZvbnQtc2l6ZTogMTNweDtcclxudGV4dC1hbGlnbjogY2VudGVyO1xyXG4gbWFyZ2luOiAwIDAgNXB4O1xyXG59XHJcblx0IFxyXG4gfVxyXG4gW3Byb2ZpbGVpbWddXHJcbiB7ICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHJcbiAgIGhlaWdodDoxNjBweDtcclxuICAgaW1nXHJcbiAgIHtcclxuICAgICBtYXgtd2lkdGg6IDEwMCU7XHJcbiAgICBtYXgtaGVpZ2h0OiAxMDAlO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBvYmplY3QtZml0OiBjb3ZlcjtcclxuICAgIG9iamVjdC1wb3NpdGlvbjpib3R0b207XHJcbiAgIH1cclxuICAgW3VzZXJpbm5lcl1cclxuIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIG1hcmdpbi10b3A6IC02MnB4O1xyXG4gICAgei1pbmRleDogMTtcclxuICBcclxuXHRbYnRuZWRpdF0ge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDQ1cHg7XHJcbiAgICB3aWR0aDogMzBweDtcclxuICAgIGhlaWdodDogMzBweDtcclxuICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIGxpbmUtaGVpZ2h0OiAzMHB4O1xyXG4gICAgYm9yZGVyOiAycHggc29saWQgdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGJvdHRvbTogMXB4O1xyXG5cdGlvbi1pY29uXHJcblx0e2NvbG9yOnZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcblx0fVxyXG59XHJcbiAgaW1nXHJcblx0ICAge2JveC1zaGFkb3c6IDBweCAwcHggMTBweCByZ2JhKDAsIDAsIDAsIDAuMjUpO1xyXG5cdCAgIHdpZHRoOiA4MHB4O1xyXG4gICAgaGVpZ2h0OiA4MHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgYm9yZGVyOiAycHggc29saWQgdmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuICAgIG1hcmdpbjogMCBhdXRvO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG5cdCAgIH1cclxufVxyXG4gfVxyXG4gfVxyXG4gIFtwcm9maWxlaW5uZXJdXHJcbiAge3BhZGRpbmc6MTVweDtcclxuICAgaDJcclxue1xyXG4mW2hlYWRpbmddXHJcbntmb250LXNpemU6IDIwcHg7XHJcbm1hcmdpbi10b3A6IDBweDtcclxucG9zaXRpb246cmVsYXRpdmU7XHJcbnotaW5kZXg6IDE7XHJcbmZvbnQtd2VpZ2h0OjYwMDtcclxuJjphZnRlciB7XHJcbiAgICAvKm9wYWNpdHk6IC41OyovXHJcbiAgICBjb250ZW50OiAnJztcclxuICAgIGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1zb2Z0Z3JlZW4pO1xyXG4gICAgaGVpZ2h0OiA5cHg7XHJcbiAgICB3aWR0aDogOTBweDtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGJvdHRvbTogMHB4O1xyXG4gICAgbGVmdDogMHB4O1xyXG4gICAgei1pbmRleDogLTE7XHJcbn1cclxufVxyXG59XHJcbiAgICBpb24taXRlbVxyXG5cdHsgICAtLXBhZGRpbmctc3RhcnQ6IDEycHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiAxNXB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTVweCAwIDE1cHg7XHJcbiAgICAtLXBhZGRpbmctdG9wOiA0cHg7XHJcbiAgICAtLXBhZGRpbmctYm90dG9tOiA0cHg7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDBweCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuICAgIGJvcmRlci1sZWZ0OiAycHggc29saWQgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xyXG5cdFx0aW9uLXRodW1ibmFpbHtcclxuICAgIHdpZHRoOiA2MHB4O1xyXG4gICAgaGVpZ2h0OiA2MHB4O1xyXG5pbWdcclxueyB3aWR0aDogNjBweDtcclxuICAgIGhlaWdodDogNjBweDtcclxuXHRib3JkZXItcmFkaXVzOjEwcHg7XHJcblx0b2JqZWN0LWZpdDpjb3ZlcjtcclxufVxyXG5cdH1cclxuXHRpb24tbGFiZWxcclxuXHR7cGFkZGluZy1sZWZ0OiAxNXB4O3doaXRlLXNwYWNlOm5vcm1hbDttYXJnaW46IDVweCAwO1xyXG5cdFx0cFxyXG5cdHtjb2xvcjogdmFyKC0taW9uLWNvbG9yLWJsYWNrMyk7XHJcbiAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgd2hpdGUtc3BhY2U6IG5vcm1hbDtcclxuICAgIGxpbmUtaGVpZ2h0OiAxNnB4O1xyXG4gICAgbWFyZ2luOiAwIDBweCA1cHg7XHJcblx0fVxyXG5cdGgze1xyXG5mb250LXNpemU6IDEzcHg7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMnB4O1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XHJcblx0fVxyXG5cdHBcclxuXHR7Y29sb3I6ICAjOWQ5ZDlkO1xyXG4gICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgIHdoaXRlLXNwYWNlOiBub3JtYWw7XHJcbiAgICBsaW5lLWhlaWdodDogMTZweDtcclxuICAgIG1hcmdpbjogMCAwcHggNXB4O1xyXG5cdGIge1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxufVxyXG5cdH1cclxuXHRpb24tbm90ZVxyXG5cdHtcclxuXHQgICBjb2xvcjogI2FiYWJhYjtcclxuXHRcdGZvbnQtc2l6ZTogMTFweDtcclxuXHRcdG1hcmdpbjogMDtcclxuXHRcdGRpc3BsYXk6IGZsZXg7XHJcblx0XHRhbGlnbi1pdGVtczogY2VudGVyO1xyXG5cdFx0aW9uLWljb25cclxuXHRcdHtcclxuXHRcdCAgbWFyZ2luLXJpZ2h0OjJweDtcclxuXHRcdH1cclxuXHR9XHJcblx0fVxyXG4gIH1cclxuICB9XHJcblx0W2NlcnRmaWNhdGUtc2VjXVxyXG5cdHtcclxuXHQgICAgIHBhZGRpbmc6IDBweCAxNXB4O1xyXG5cdFx0LmJ0bi1sb3Nuc1xyXG5cdFx0e1xyXG5cdFx0XHQtLWJhY2tncm91bmQ6dmFyKCAtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuXHRcdFx0bWFyZ2luLXRvcDogNXB4O1xyXG5cdFx0XHQtLWJveC1zaGFkb3c6IG5vbmU7XHJcblx0XHRcdG1pbi1oZWlnaHQ6IDQ4cHg7XHJcblx0XHRcdG1hcmdpbi1ib3R0b206IDE1cHg7XHJcblx0XHRcdHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XHJcblx0XHRcdGxldHRlci1zcGFjaW5nOiAxcHg7XHJcblx0XHR9XHJcblx0fSAgXHJcbn0iXX0= */";
      /***/
    },

    /***/
    "./src/app/profile/profile.page.ts":
    /*!*****************************************!*\
      !*** ./src/app/profile/profile.page.ts ***!
      \*****************************************/

    /*! exports provided: ProfilePage */

    /***/
    function srcAppProfileProfilePageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ProfilePage", function () {
        return ProfilePage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../services/api/api.service */
      "./src/app/services/api/api.service.ts");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../config */
      "./src/app/config.ts");
      /* harmony import */


      var _common_common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ../common/common.service */
      "./src/app/common/common.service.ts");
      /* harmony import */


      var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic-native/camera/ngx */
      "./node_modules/@ionic-native/camera/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @ionic-native/file/ngx */
      "./node_modules/@ionic-native/file/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @ionic-native/file-path/ngx */
      "./node_modules/@ionic-native/file-path/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @ionic-native/file-transfer/ngx */
      "./node_modules/@ionic-native/file-transfer/__ivy_ngcc__/ngx/index.js");

      var ProfilePage = /*#__PURE__*/function () {
        function ProfilePage(api, router, common, camera, file, filePath, transfer) {
          _classCallCheck(this, ProfilePage);

          this.api = api;
          this.router = router;
          this.common = common;
          this.camera = camera;
          this.file = file;
          this.filePath = filePath;
          this.transfer = transfer;
          this.win = window;
          this.is_live_image_updated_cover = false;
          this.is_live_image_updated_profile = false;
          this.errors = ['', null, undefined];
          this.donationlist = [];
          this.IMAGES_URL = _config__WEBPACK_IMPORTED_MODULE_4__["config"].IMAGES_URL;
        }

        _createClass(ProfilePage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }, {
          key: "getimage",
          value: function getimage(img) {
            if (this.errors.indexOf(img) == -1) {
              if (img.includes('https') == true) {
                return true;
              } else {
                return false;
              }
            } else {
              return false;
            }
          }
        }, {
          key: "selectImage",
          value: function selectImage(type) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this = this;

              var actionSheet;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      this.image_type = type;
                      _context.next = 3;
                      return this.api.actionSheetController.create({
                        header: "Select Image",
                        buttons: [{
                          text: 'From Gallery',
                          handler: function handler() {
                            _this.takePicture(_this.camera.PictureSourceType.PHOTOLIBRARY, type);
                          }
                        }, {
                          text: 'Use Camera',
                          handler: function handler() {
                            _this.takePicture(_this.camera.PictureSourceType.CAMERA, type);
                          }
                        }, {
                          text: 'Cancel',
                          role: 'cancel'
                        }]
                      });

                    case 3:
                      actionSheet = _context.sent;
                      _context.next = 6;
                      return actionSheet.present();

                    case 6:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "takePicture",
          value: function takePicture(sourceType, type) {
            var _this2 = this;

            var options = {
              quality: 25,
              sourceType: sourceType,
              saveToPhotoAlbum: false,
              correctOrientation: true,
              allowEdit: true
            };
            this.camera.getPicture(options).then(function (imagePath) {
              if (sourceType === _this2.camera.PictureSourceType.PHOTOLIBRARY) {
                if (type == 'profile') {
                  _this2.live_image_url = imagePath;
                  _this2.is_live_image_updated_profile = true;
                }

                if (type == 'cover') {
                  _this2.bgImage = _this2.win.Ionic.WebView.convertFileSrc(imagePath);
                  _this2.is_live_image_updated_cover = true;
                }

                _this2.filePath.resolveNativePath(imagePath).then(function (filePath) {
                  _this2.startUpload(imagePath, type);
                });
              } else {
                if (type == 'profile') {
                  _this2.live_image_url = imagePath;
                  _this2.is_live_image_updated_profile = true;
                }

                if (type == 'cover') {
                  _this2.bgImage = _this2.win.Ionic.WebView.convertFileSrc(imagePath);
                  _this2.is_live_image_updated_cover = true;
                }

                _this2.startUpload(imagePath, type);
              }
            }, function (err) {
              console.log('err');
              console.log(err);
            });
          }
        }, {
          key: "ionViewDidEnter",
          value: function ionViewDidEnter() {
            this.userid = localStorage.getItem('userid');
            this.getuserdetails();
          }
        }, {
          key: "startUpload",
          value: function startUpload(imageData, type) {
            var _this3 = this;

            this.file.resolveLocalFilesystemUrl(imageData).then(function (entry) {
              entry.file(function (file) {
                _this3.readFile(file, type);
              });
            })["catch"](function (err) {
              _this3.common.presentToast('Error while reading file.', 'danger');
            });
          }
        }, {
          key: "readFile",
          value: function readFile(file, type) {
            var self = this;
            var reader = new FileReader();

            reader.onloadend = function () {
              if (type == 'profile') {
                var imgBlobProfile = new Blob([reader.result], {
                  type: file.type
                });
                self.imgBlobProfile = imgBlobProfile;
                self.live_file_name_profile = file.name;
                self.profileImageSubmit(type);
              } else {
                var imgBlobCover = new Blob([reader.result], {
                  type: file.type
                });
                self.imgBlobCover = imgBlobCover;
                self.live_file_name_cover = file.name;
              } // const imgBlob = new Blob([reader.result], {
              //     type: file.type
              // });
              // self.imgBlob = imgBlob;
              // self.live_file_name = file.name;
              //self.profileImageSubmit(type);

            };

            reader.readAsArrayBuffer(file);
          }
        }, {
          key: "profileImageSubmit",
          value: function profileImageSubmit(type) {
            var _this4 = this;

            // this.apiService.presentLoading();
            var frmData = new FormData();
            frmData.append('file', this.imgBlobProfile, this.live_file_name_profile);
            frmData.append("live_image", this.live_file_name_profile.replace(/ /g, "_"));
            frmData.append("userId", localStorage.getItem('userid'));
            frmData.append("type", type);
            this.api.post('update_user_image', frmData, '').subscribe(function (result) {
              var res;
              res = result;

              if (res.status == 1) {
                _this4.userdetails.image = res.data;
                _this4.is_live_image_updated_profile = false;
              } else {
                _this4.common.presentToast('Error while sending request,Please try after some time', 'success');
              }
            }, function (err) {
              _this4.common.presentToast('Technical error,Please try after some time', 'success');
            });
          }
        }, {
          key: "getuserdetails",
          value: function getuserdetails() {
            var _this5 = this;

            var dict = {
              id: this.userid
            };

            if (this.errors.indexOf(this.userid) >= 0) {
              this.common.presentToast('Please login first!.', 'danger');
              return false;
            }

            this.common.presentLoading();
            this.api.post('Userdetails', dict, '').subscribe(function (result) {
              _this5.common.stopLoading();

              var res;
              res = result;

              if (res.status == 1) {
                _this5.userdetails = res.data;
                _this5.donationlist = res.donations;

                _this5.common.presentToast(res.message, 'success');
              } else {
                _this5.common.presentToast(res.message, 'danger');
              }
            }, function (err) {});
          }
        }]);

        return ProfilePage;
      }();

      ProfilePage.ctorParameters = function () {
        return [{
          type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
        }, {
          type: _common_common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"]
        }, {
          type: _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_6__["Camera"]
        }, {
          type: _ionic_native_file_ngx__WEBPACK_IMPORTED_MODULE_7__["File"]
        }, {
          type: _ionic_native_file_path_ngx__WEBPACK_IMPORTED_MODULE_8__["FilePath"]
        }, {
          type: _ionic_native_file_transfer_ngx__WEBPACK_IMPORTED_MODULE_9__["FileTransfer"]
        }];
      };

      ProfilePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-profile',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./profile.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/profile/profile.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./profile.page.scss */
        "./src/app/profile/profile.page.scss"))["default"]]
      })], ProfilePage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=profile-profile-module-es5.js.map