(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["charitydetail-charitydetail-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/charitydetail/charitydetail.page.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/charitydetail/charitydetail.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n\t<ion-back-button defaultHref=\"/tabs/home\" slot=\"start\">\r\n\t</ion-back-button>\r\n\t<ion-title class=\"ion-text-center\">Detail</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n<ion-content>\r\n<div detailbanner>\r\n<img src=\"{{IMAGES_URL}}/{{charity?.image}}\"/>\r\n<h2>{{charity?.title}}</h2>\r\n</div>\r\n<div detailcontent class=\"ion-padding\">\r\n<div badge>\r\n<span *ngFor=\"let tag of tags\">{{tag}}</span>\r\n</div>\r\n<h3>{{charity?.meals}} Meals Distributed</h3>\r\n<h2 heading>\r\nOverview\r\n</h2>\r\n<p>{{charity?.description}}</p>\r\n<h2 heading>\r\nImage Gallery\r\n</h2>\r\n<ion-slides slidetable  #slideWithNav [options]=\"slideOptsOne\"   pager=\"true\" class=\"home-slider\" *ngIf=\"images?.length>0\">\r\n    <ion-slide  hm-slider *ngFor=\"let image of images\">\r\n      <img src=\"{{IMAGES_URL}}/{{image?.image}}\" style=\"width:100%;\"/>\r\n    </ion-slide>\r\n</ion-slides>\r\n<ion-button shape=\"round\" expand=\"full\" (click)=\"give(charity?.id)\">Give Now</ion-button>\r\n</div>\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/charitydetail/charitydetail-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/charitydetail/charitydetail-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: CharitydetailPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CharitydetailPageRoutingModule", function() { return CharitydetailPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _charitydetail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./charitydetail.page */ "./src/app/charitydetail/charitydetail.page.ts");




const routes = [
    {
        path: '',
        component: _charitydetail_page__WEBPACK_IMPORTED_MODULE_3__["CharitydetailPage"]
    }
];
let CharitydetailPageRoutingModule = class CharitydetailPageRoutingModule {
};
CharitydetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CharitydetailPageRoutingModule);



/***/ }),

/***/ "./src/app/charitydetail/charitydetail.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/charitydetail/charitydetail.module.ts ***!
  \*******************************************************/
/*! exports provided: CharitydetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CharitydetailPageModule", function() { return CharitydetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _charitydetail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./charitydetail-routing.module */ "./src/app/charitydetail/charitydetail-routing.module.ts");
/* harmony import */ var _charitydetail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./charitydetail.page */ "./src/app/charitydetail/charitydetail.page.ts");







let CharitydetailPageModule = class CharitydetailPageModule {
};
CharitydetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _charitydetail_routing_module__WEBPACK_IMPORTED_MODULE_5__["CharitydetailPageRoutingModule"]
        ],
        declarations: [_charitydetail_page__WEBPACK_IMPORTED_MODULE_6__["CharitydetailPage"]]
    })
], CharitydetailPageModule);



/***/ }),

/***/ "./src/app/charitydetail/charitydetail.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/charitydetail/charitydetail.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-toolbar {\n  --ion-color-base: var(--ion-color-bggradient)!important;\n  --border-width: 0;\n}\nion-header ion-toolbar ion-title {\n  color: var(--ion-color-white);\n  text-align: center;\n  font-style: normal;\n  font-family: \"Poppins\", sans-serif !important;\n}\nion-header::after {\n  display: none;\n}\nion-content [detailbanner] {\n  position: relative;\n  z-index: 1;\n  height: 225px;\n}\nion-content [detailbanner] img {\n  height: 225px;\n  width: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n  border-radius: 0px 0px 25px 25px;\n}\nion-content [detailbanner]:after {\n  content: \"\";\n  left: 0;\n  right: 0;\n  top: 0;\n  bottom: 0;\n  padding: 0;\n  background: var(--ion-color-black);\n  opacity: 0.5;\n  display: inline-block;\n  position: absolute;\n  z-index: 1;\n  border-radius: 0px 0px 25px 25px;\n}\nion-content [detailbanner] h2 {\n  position: absolute;\n  z-index: 9;\n  bottom: 21px;\n  color: var(--ion-color-white);\n  left: 0;\n  right: 0;\n  margin: 0 auto;\n  text-align: center;\n  font-size: 20px;\n}\nion-content [detailcontent] h2[heading] {\n  font-size: 20px;\n  margin-top: 0px;\n  position: relative;\n  z-index: 1;\n  font-weight: 600;\n}\nion-content [detailcontent] h2[heading]:after {\n  /*opacity: .5;*/\n  content: \"\";\n  background: var(--ion-color-softgreen);\n  height: 9px;\n  width: 70px;\n  position: absolute;\n  bottom: 0px;\n  left: 0px;\n  z-index: -1;\n}\nion-content [detailcontent] p {\n  font-size: 14px;\n  color: #666;\n  font-weight: 300;\n}\nion-content [detailcontent] h3 {\n  font-size: 14px;\n}\nion-content [detailcontent] [badge] span {\n  background: rgba(248, 170, 18, 0.39);\n  border-radius: 30px;\n  padding: 4px 12px;\n  margin-right: 8px;\n  font-size: 14px;\n}\nion-content [detailcontent] ion-button {\n  --box-shadow: none;\n  min-height: 42px;\n}\nion-content [detailcontent] [hm-slider] {\n  margin-bottom: 15px;\n}\nion-content [detailcontent] [hm-slider] img {\n  border-radius: 15px;\n  height: 250px;\n  -o-object-fit: cover;\n     object-fit: cover;\n  width: 100%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY2hhcml0eWRldGFpbC9jaGFyaXR5ZGV0YWlsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHRztFQUNDLHVEQUFBO0VBQ0QsaUJBQUE7QUFGSDtBQUlJO0VBQ0EsNkJBQUE7RUFDQSxrQkFBQTtFQUNRLGtCQUFBO0VBQ0EsNkNBQUE7QUFGWjtBQUtDO0VBRUEsYUFBQTtBQUpEO0FBU0E7RUFFSSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxhQUFBO0FBUEo7QUFRQztFQUNHLGFBQUE7RUFDQSxXQUFBO0VBQ0Esb0JBQUE7S0FBQSxpQkFBQTtFQUNBLGdDQUFBO0FBTko7QUFRRTtFQUNGLFdBQUE7RUFDSSxPQUFBO0VBQ0EsUUFBQTtFQUNBLE1BQUE7RUFDQSxTQUFBO0VBQ0EsVUFBQTtFQUNBLGtDQUFBO0VBQ0EsWUFBQTtFQUNBLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0EsZ0NBQUE7QUFOSjtBQVFBO0VBRUksa0JBQUE7RUFDSCxVQUFBO0VBQ0csWUFBQTtFQUNBLDZCQUFBO0VBQ0EsT0FBQTtFQUNBLFFBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0FBUEo7QUFjRTtFQUNDLGVBQUE7RUFDRCxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0EsZ0JBQUE7QUFaRjtBQWFFO0VBQ0ksZUFBQTtFQUNILFdBQUE7RUFDQSxzQ0FBQTtFQUNBLFdBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7QUFYSDtBQWVFO0VBQ0YsZUFBQTtFQUNJLFdBQUE7RUFDQSxnQkFBQTtBQWJKO0FBZUE7RUFFQSxlQUFBO0FBZEE7QUFrQkE7RUFDSSxvQ0FBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7QUFoQko7QUFrQkM7RUFFSSxrQkFBQTtFQUNELGdCQUFBO0FBakJKO0FBbUJBO0VBQ0UsbUJBQUE7QUFqQkY7QUFrQkU7RUFDRSxtQkFBQTtFQUNBLGFBQUE7RUFDSCxvQkFBQTtLQUFBLGlCQUFBO0VBQ0EsV0FBQTtBQWhCRCIsImZpbGUiOiJzcmMvYXBwL2NoYXJpdHlkZXRhaWwvY2hhcml0eWRldGFpbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyXHJcbntcclxuXHRcclxuXHQgIGlvbi10b29sYmFyXHJcblx0ICB7LS1pb24tY29sb3ItYmFzZTogdmFyKC0taW9uLWNvbG9yLWJnZ3JhZGllbnQpIWltcG9ydGFudDtcclxuXHQgIC0tYm9yZGVyLXdpZHRoOiAwO1xyXG5cdFxyXG5cdFx0ICBpb24tdGl0bGV7XHJcblx0XHQgIGNvbG9yOnZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcblx0XHQgIHRleHQtYWxpZ246Y2VudGVyO1xyXG4gICAgICAgICAgICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcclxuICAgICAgICB9XHJcblx0fVxyXG5cdCY6OmFmdGVyXHJcblx0e1xyXG5cdGRpc3BsYXk6bm9uZTtcclxuXHR9XHJcbn1cclxuaW9uLWNvbnRlbnRcclxue1xyXG5bZGV0YWlsYmFubmVyXVxyXG57XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICB6LWluZGV4OiAxO1xyXG4gICAgaGVpZ2h0OiAyMjVweDtcclxuIGltZyB7XHJcbiAgICBoZWlnaHQ6IDIyNXB4O1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBvYmplY3QtZml0OiBjb3ZlcjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDBweCAwcHggMjVweCAyNXB4O1xyXG59XHJcbiAgJjphZnRlcntcclxuY29udGVudDogXCJcIjtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICByaWdodDogMDtcclxuICAgIHRvcDogMDtcclxuICAgIGJvdHRvbTogMDtcclxuICAgIHBhZGRpbmc6IDA7XHJcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItYmxhY2spO1xyXG4gICAgb3BhY2l0eTogMC41O1xyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgei1pbmRleDogMTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDBweCAwcHggMjVweCAyNXB4O1xyXG4gICAgICAgICAgICAgICAgfVxyXG5oMlxyXG57XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcblx0ei1pbmRleDo5O1xyXG4gICAgYm90dG9tOiAyMXB4O1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcbiAgICBsZWZ0OiAwO1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICBtYXJnaW46IDAgYXV0bztcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxufVxyXG59XHJcbltkZXRhaWxjb250ZW50XVxyXG57XHJcbiAgIGgyXHJcblx0e1xyXG5cdFx0JltoZWFkaW5nXVxyXG5cdFx0e2ZvbnQtc2l6ZTogMjBweDtcclxuXHRcdG1hcmdpbi10b3A6IDBweDtcclxuXHRcdHBvc2l0aW9uOnJlbGF0aXZlO1xyXG5cdFx0ei1pbmRleDogMTtcclxuXHRcdGZvbnQtd2VpZ2h0OjYwMDtcclxuXHRcdCY6YWZ0ZXIge1xyXG5cdFx0ICAgIC8qb3BhY2l0eTogLjU7Ki9cclxuXHRcdFx0Y29udGVudDogJyc7XHJcblx0XHRcdGJhY2tncm91bmQ6IHZhcigtLWlvbi1jb2xvci1zb2Z0Z3JlZW4pO1xyXG5cdFx0XHRoZWlnaHQ6IDlweDtcclxuXHRcdFx0d2lkdGg6IDcwcHg7XHJcblx0XHRcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRcdFx0Ym90dG9tOiAwcHg7XHJcblx0XHRcdGxlZnQ6IDBweDtcclxuXHRcdFx0ei1pbmRleDogLTE7XHJcblx0XHR9XHJcblx0XHR9XHJcblx0XHR9XHJcblx0XHRwIHtcclxuZm9udC1zaXplOiAxNHB4O1xyXG4gICAgY29sb3I6ICM2NjY7XHJcbiAgICBmb250LXdlaWdodDogMzAwO1xyXG59XHJcbmgzXHJcbntcclxuZm9udC1zaXplOjE0cHg7XHJcbn1cclxuW2JhZGdlXVxyXG57XHJcbnNwYW4ge1xyXG4gICAgYmFja2dyb3VuZDogcmdiYSgyNDgsIDE3MCwgMTggLCAuMzkpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgIHBhZGRpbmc6IDRweCAxMnB4O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiA4cHg7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbn1cclxufWlvbi1idXR0b25cclxuXHR7XHJcblx0ICAgIC0tYm94LXNoYWRvdzogbm9uZTtcclxuICAgIG1pbi1oZWlnaHQ6IDQycHg7XHJcblx0fVxyXG5baG0tc2xpZGVyXVxyXG57IG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbiAgaW1nXHJcbiAgeyBib3JkZXItcmFkaXVzOjE1cHg7XHJcbiAgICBoZWlnaHQ6MjUwcHg7XHJcblx0b2JqZWN0LWZpdDpjb3ZlcjtcclxuXHR3aWR0aDoxMDAlO1xyXG4gIH1cclxufVxyXG59XHJcbn0iXX0= */");

/***/ }),

/***/ "./src/app/charitydetail/charitydetail.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/charitydetail/charitydetail.page.ts ***!
  \*****************************************************/
/*! exports provided: CharitydetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CharitydetailPage", function() { return CharitydetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/api/api.service */ "./src/app/services/api/api.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../config */ "./src/app/config.ts");
/* harmony import */ var _common_common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../common/common.service */ "./src/app/common/common.service.ts");
/* harmony import */ var _addamount_addamount_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../addamount/addamount.page */ "./src/app/addamount/addamount.page.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");








let CharitydetailPage = class CharitydetailPage {
    constructor(modalController, activatedRoute, api, router, common) {
        this.modalController = modalController;
        this.activatedRoute = activatedRoute;
        this.api = api;
        this.router = router;
        this.common = common;
        this.IMAGES_URL = _config__WEBPACK_IMPORTED_MODULE_4__["config"].IMAGES_URL;
        this.errors = ['', null, undefined];
        this.charityid = activatedRoute.snapshot.paramMap.get('id');
    }
    ngOnInit() {
    }
    give(id) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _addamount_addamount_page__WEBPACK_IMPORTED_MODULE_6__["AddamountPage"],
                cssClass: 'leaveteam',
                componentProps: {
                    id: id,
                }
            });
            modal.onDidDismiss().then((detail) => {
                if (this.errors.indexOf(detail.data) == -1) {
                    //this.team.joins=this.team.joins - 1;
                    //this.getuserteams();
                }
            });
            return yield modal.present();
        });
    }
    ionViewDidEnter() {
        this.getcharitydetails();
    }
    getcharitydetails() {
        let dict = {
            id: this.charityid,
        };
        this.common.presentLoading();
        this.api.post('charitydetail', dict, '').subscribe((result) => {
            this.common.stopLoading();
            var res;
            res = result;
            if (res.status == 1) {
                var string = res.data.tags;
                var strx = string.split(',');
                var array = [];
                array = array.concat(strx);
                this.tags = array;
                this.charity = res.data;
                this.images = res.images;
            }
            else {
            }
        }, err => {
        });
    }
};
CharitydetailPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _common_common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"] }
];
CharitydetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-charitydetail',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./charitydetail.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/charitydetail/charitydetail.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./charitydetail.page.scss */ "./src/app/charitydetail/charitydetail.page.scss")).default]
    })
], CharitydetailPage);



/***/ })

}]);
//# sourceMappingURL=charitydetail-charitydetail-module-es2015.js.map