(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~activitydetail-activitydetail-module~addamount-addamount-module~charitydetail-charitydetail-~e01b0d79"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/addamount/addamount.page.html":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/addamount/addamount.page.html ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n\t      <ion-buttons (click)=\"dismiss() \" slot=\"end\">\r\n         <ion-icon name=\"close-sharp\"></ion-icon>\r\n        </ion-buttons>\r\n\t<ion-title class=\"ion-text-center\">Your Amount</ion-title>\r\n  </ion-toolbar>\r\n  </ion-header>\r\n\r\n<ion-content class=\"ion-padding\">\r\n<div amountimg class=\"ion-text-center\">\r\n<img src=\"assets/images/mappic6.jpg\"/>\r\n<p>Please enter amount that you would like to donate. Miniumum donation amount is $1 dollar.</p>\r\n<p style=\"color:#1e1e1e;font-weight:500;\" *ngIf=\"errors.indexOf(charityid)==-1\">{{charity?.title}}</p>\r\n<p style=\"color:#1e1e1e;font-weight:500;\" *ngIf=\"errors.indexOf(actid)==-1\">{{act?.title}}</p>\r\n<p style=\"color:#1e1e1e;font-weight:500;\" *ngIf=\"errors.indexOf(teamid)==-1\">{{team?.name}}</p>\r\n</div>\r\n<div formfield dollar-input>\r\n\t\t\t\t<label>Your Amount</label>\r\n\t\t\t\t<ion-item lines=\"none\" class=\"fls\"> \r\n\t\t\t\t\t<img src=\"assets/images/dollar-icon.png\" /><ion-input type=\"number\" placeholder=\"Enter Your Amount\" id=\"amount\" (keyup)=\"search_keyword($event);\"></ion-input>\r\n\t\t\t\t</ion-item>\r\n\t\t\t\t\r\n</div>\r\n<p style=\"padding-top: 9px; margin: 0px; font-size: 12px; padding-left: 20px;\"><span class=\"no_meals\">0</span> meals</p>\r\n<ion-button  expand=\"full\" shape=\"round\" class=\"btn-losns\" (click)=\"confirm();\"\r\n*ngIf=\"errors.indexOf(charityid)==-1\">Confirm</ion-button>\r\n\r\n<ion-button  expand=\"full\" shape=\"round\" class=\"btn-losns\" (click)=\"confirm_in();\"\r\n*ngIf=\"errors.indexOf(charityid)>=0 && errors.indexOf(actid)>=0  && errors.indexOf(teamid)>=0  \" >Confirm</ion-button>\r\n\r\n<ion-button  expand=\"full\" shape=\"round\" class=\"btn-losns\" (click)=\"confirm_act();\"\r\n*ngIf=\"errors.indexOf(actid)==-1\">Confirm</ion-button>\r\n\r\n<ion-button  expand=\"full\" shape=\"round\" class=\"btn-losns\" (click)=\"confirm_team();\"\r\n*ngIf=\"errors.indexOf(teamid)==-1\">Confirm</ion-button>\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/addamount/addamount.page.scss":
/*!***********************************************!*\
  !*** ./src/app/addamount/addamount.page.scss ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-header ion-toolbar {\n  --ion-color-base: var(--ion-color-bggradient)!important;\n  --border-width: 0;\n}\nion-header ion-toolbar ion-title {\n  color: var(--ion-color-white);\n  text-align: center;\n  font-style: normal;\n  font-family: \"Poppins\", sans-serif !important;\n}\nion-header ion-toolbar ion-buttons {\n  font-size: 25px;\n  margin-right: 10px;\n}\nion-header::after {\n  display: none;\n}\nion-content [amountimg] img {\n  height: 120px;\n  width: 120px;\n  -o-object-fit: cover;\n     object-fit: cover;\n  border-radius: 50%;\n  border: 5px solid var(--ion-color-softgreen);\n}\nion-content [amountimg] p {\n  font-size: 14px;\n  line-height: 22px;\n  font-weight: 300;\n  color: #adadad;\n  margin-top: 10px;\n}\nion-content [formfield] {\n  position: relative;\n  border: 1px solid #e8e8e8;\n  height: 52px;\n  border-radius: 50px;\n  background: var(--ion-color-white);\n  padding: 0 16px;\n  margin-top: 20px;\n}\nion-content [formfield] label {\n  position: absolute;\n  top: -10px;\n  z-index: 111;\n  background: var(--ion-color-white);\n  left: 29px;\n  padding: 0 3px;\n  font-size: 12px;\n  font-weight: 700;\n  color: #3a3a3a;\n}\nion-content [formfield] ion-input, ion-content [formfield] ion-datetime {\n  padding: 0px;\n  --padding-start: 0px;\n  --padding-end: 0px;\n  font-size: 14px;\n  --placeholder-color: #9a9a9a;\n  --placeholder-opacity: 1;\n  font-family: \"Poppins\", sans-serif !important;\n  color: #222;\n}\nion-content [formfield][dollar-input] img {\n  max-width: 15px;\n  margin-right: 4px;\n}\nion-content [formfield][dollar-input] ion-item {\n  --padding-start:0px;\n}\nion-content .btn-losns {\n  --background:var( --ion-color-primary);\n  margin-top: 10px;\n  --box-shadow: none;\n  min-height: 48px;\n  margin-bottom: 15px;\n  text-transform: uppercase;\n  letter-spacing: 1px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWRkYW1vdW50L2FkZGFtb3VudC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBR0c7RUFDQyx1REFBQTtFQUNELGlCQUFBO0FBRkg7QUFJSTtFQUNBLDZCQUFBO0VBQ0Esa0JBQUE7RUFDUSxrQkFBQTtFQUNBLDZDQUFBO0FBRlo7QUFJRTtFQUVBLGVBQUE7RUFDRSxrQkFBQTtBQUhKO0FBTUM7RUFFQSxhQUFBO0FBTEQ7QUFXRTtFQUVJLGFBQUE7RUFDQSxZQUFBO0VBQ0Esb0JBQUE7S0FBQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsNENBQUE7QUFUTjtBQVdFO0VBQ0UsZUFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QUFUSjtBQWFBO0VBQ0csa0JBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGtDQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0FBWEg7QUFZRztFQUNDLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxrQ0FBQTtFQUNBLFVBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtBQVZKO0FBWUc7RUFDQyxZQUFBO0VBQ0Esb0JBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSw0QkFBQTtFQUNBLHdCQUFBO0VBQ0EsNkNBQUE7RUFDQSxXQUFBO0FBVko7QUFjTztFQUVLLGVBQUE7RUFDQSxpQkFBQTtBQWJaO0FBZVE7RUFFSyxtQkFBQTtBQWRiO0FBa0JFO0VBQ0Msc0NBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ1MsZ0JBQUE7RUFDVCxtQkFBQTtFQUNBLHlCQUFBO0VBQ0EsbUJBQUE7QUFoQkgiLCJmaWxlIjoic3JjL2FwcC9hZGRhbW91bnQvYWRkYW1vdW50LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbImlvbi1oZWFkZXJcclxue1xyXG5cdFxyXG5cdCAgaW9uLXRvb2xiYXJcclxuXHQgIHstLWlvbi1jb2xvci1iYXNlOiB2YXIoLS1pb24tY29sb3ItYmdncmFkaWVudCkhaW1wb3J0YW50O1xyXG5cdCAgLS1ib3JkZXItd2lkdGg6IDA7XHJcblx0XHJcblx0XHQgIGlvbi10aXRsZXtcclxuXHRcdCAgY29sb3I6dmFyKC0taW9uLWNvbG9yLXdoaXRlKTtcclxuXHRcdCAgdGV4dC1hbGlnbjpjZW50ZXI7XHJcbiAgICAgICAgICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdQb3BwaW5zJywgc2Fucy1zZXJpZiAhaW1wb3J0YW50O1xyXG4gICAgICAgIH1cclxuXHRcdGlvbi1idXR0b25zXHJcblx0XHR7XHJcblx0XHRmb250LXNpemU6IDI1cHg7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcblx0XHR9XHJcblx0fVxyXG5cdCY6OmFmdGVyXHJcblx0e1xyXG5cdGRpc3BsYXk6bm9uZTtcclxuXHR9XHJcbn1cclxuaW9uLWNvbnRlbnRcclxue1thbW91bnRpbWddXHJcbntcclxuICBpbWdcclxuICB7XHJcbiAgICAgIGhlaWdodDogMTIwcHg7XHJcbiAgICAgIHdpZHRoOiAxMjBweDtcclxuICAgICAgb2JqZWN0LWZpdDogY292ZXI7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgYm9yZGVyOiA1cHggc29saWQgdmFyKC0taW9uLWNvbG9yLXNvZnRncmVlbik7XHJcbiAgfVxyXG4gIHBcclxuICB7XHRmb250LXNpemU6IDE0cHg7XHJcblx0XHRcdFx0bGluZS1oZWlnaHQ6IDIycHg7XHJcblx0XHRcdFx0Zm9udC13ZWlnaHQ6IDMwMDtcclxuXHRcdFx0XHRjb2xvcjogI2FkYWRhZDtcclxuXHRcdFx0XHRtYXJnaW4tdG9wOiAxMHB4O1xyXG4gIFxyXG4gIH1cclxufVxyXG5bZm9ybWZpZWxkXSB7XHJcblx0XHRcdHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHRcdFx0Ym9yZGVyOiAxcHggc29saWQgI2U4ZThlODtcclxuXHRcdFx0aGVpZ2h0OiA1MnB4O1xyXG5cdFx0XHRib3JkZXItcmFkaXVzOiA1MHB4O1xyXG5cdFx0XHRiYWNrZ3JvdW5kOnZhciggLS1pb24tY29sb3Itd2hpdGUpO1xyXG5cdFx0XHRwYWRkaW5nOiAwIDE2cHg7XHJcblx0XHRcdG1hcmdpbi10b3A6MjBweDtcclxuXHRcdFx0bGFiZWwge1xyXG5cdFx0XHRcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuXHRcdFx0XHR0b3A6IC0xMHB4O1xyXG5cdFx0XHRcdHotaW5kZXg6IDExMTtcclxuXHRcdFx0XHRiYWNrZ3JvdW5kOiB2YXIoIC0taW9uLWNvbG9yLXdoaXRlKTtcclxuXHRcdFx0XHRsZWZ0OiAyOXB4O1xyXG5cdFx0XHRcdHBhZGRpbmc6IDAgM3B4O1xyXG5cdFx0XHRcdGZvbnQtc2l6ZTogMTJweDtcclxuXHRcdFx0XHRmb250LXdlaWdodDogNzAwO1xyXG5cdFx0XHRcdGNvbG9yOiAjM2EzYTNhO1xyXG5cdFx0XHR9XHJcblx0XHRcdGlvbi1pbnB1dCAsIGlvbi1kYXRldGltZSAge1xyXG5cdFx0XHRcdHBhZGRpbmc6IDBweDtcclxuXHRcdFx0XHQtLXBhZGRpbmctc3RhcnQ6IDBweDtcclxuXHRcdFx0XHQtLXBhZGRpbmctZW5kOiAwcHg7XHJcblx0XHRcdFx0Zm9udC1zaXplOiAxNHB4O1xyXG5cdFx0XHRcdC0tcGxhY2Vob2xkZXItY29sb3I6ICM5YTlhOWE7XHJcblx0XHRcdFx0LS1wbGFjZWhvbGRlci1vcGFjaXR5OiAxO1xyXG5cdFx0XHRcdGZvbnQtZmFtaWx5OiAnUG9wcGlucycsIHNhbnMtc2VyaWYgIWltcG9ydGFudDtcclxuXHRcdFx0XHRjb2xvcjogIzIyMjtcclxuXHRcdFx0fVxyXG5cdFx0XHQmW2RvbGxhci1pbnB1dF1cclxuXHRcdFx0e1xyXG5cdFx0XHQgICAgaW1nXHJcblx0XHRcdCAgICB7XHJcblx0XHRcdCAgICAgICAgIG1heC13aWR0aDoxNXB4O1xyXG5cdFx0XHQgICAgICAgICBtYXJnaW4tcmlnaHQ6IDRweDtcclxuXHRcdFx0ICAgIH1cclxuXHRcdFx0ICAgICBpb24taXRlbVxyXG5cdFx0XHQgICAgIHtcclxuXHRcdFx0ICAgICAgICAgIC0tcGFkZGluZy1zdGFydDowcHg7XHJcblx0XHRcdCAgICAgfVxyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0XHQuYnRuLWxvc25ze1xyXG5cdFx0XHQtLWJhY2tncm91bmQ6dmFyKCAtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuXHRcdFx0bWFyZ2luLXRvcDogMTBweDtcclxuXHRcdFx0LS1ib3gtc2hhZG93OiBub25lO1xyXG4gICAgICAgICAgICBtaW4taGVpZ2h0OiA0OHB4O1xyXG5cdFx0XHRtYXJnaW4tYm90dG9tOiAxNXB4O1xyXG5cdFx0XHR0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xyXG5cdFx0XHRsZXR0ZXItc3BhY2luZzogMXB4O1xyXG5cdFx0fVxyXG59Il19 */");

/***/ }),

/***/ "./src/app/addamount/addamount.page.ts":
/*!*********************************************!*\
  !*** ./src/app/addamount/addamount.page.ts ***!
  \*********************************************/
/*! exports provided: AddamountPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AddamountPage", function() { return AddamountPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/api/api.service */ "./src/app/services/api/api.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../config */ "./src/app/config.ts");
/* harmony import */ var _common_common_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../common/common.service */ "./src/app/common/common.service.ts");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _paymentlistmodal_paymentlistmodal_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../paymentlistmodal/paymentlistmodal.page */ "./src/app/paymentlistmodal/paymentlistmodal.page.ts");









let AddamountPage = class AddamountPage {
    constructor(navParams, api, router, common, modalController) {
        this.navParams = navParams;
        this.api = api;
        this.router = router;
        this.common = common;
        this.modalController = modalController;
        this.IMAGES_URL = _config__WEBPACK_IMPORTED_MODULE_4__["config"].IMAGES_URL;
        this.errors = ['', null, undefined];
        this.timeout = null;
        this.charityid = navParams.get('id');
        this.actid = navParams.get('actid');
        this.teamid = navParams.get('teamid');
        //alert(this.charityid);
    }
    ngOnInit() {
    }
    search_keyword(event) {
        clearTimeout(this.timeout);
        var self = this;
        this.timeout = setTimeout(function () {
            if (self.errors.indexOf(event.target.value) == -1) {
                self.search_text = event.target.value;
                self.minimum = 1;
                if (self.search_text < self.minimum) {
                    self.common.presentToast('Minimum donation is 1 dollar !.', 'danger');
                    self.search_text = '';
                    jquery__WEBPACK_IMPORTED_MODULE_6__('#amount').val('');
                }
                var tot = self.search_text % self.minimum;
                if (tot == 0) {
                }
                else {
                    var min = self.search_text - tot;
                    jquery__WEBPACK_IMPORTED_MODULE_6__('#amount').val(min);
                    self.common.presentToast('We have rounded the amount entered to the nearest number of meals', 'success');
                }
                var val = jquery__WEBPACK_IMPORTED_MODULE_6__('#amount').val();
                var tot1 = val * 4;
                jquery__WEBPACK_IMPORTED_MODULE_6__('.no_meals').text(tot1);
                console.log(self.search_text);
            }
            else {
                self.search_text = event.target.value;
                jquery__WEBPACK_IMPORTED_MODULE_6__('.no_meals').text('0');
                //self.save1();  
            }
        }, 500);
    }
    dismiss() {
        this.modalController.dismiss({
            'dismissed': true
        });
    }
    ionViewDidEnter() {
        if (this.errors.indexOf(this.charityid) == -1) {
            this.Charitydetail();
        }
        if (this.errors.indexOf(this.teamid) == -1) {
            this.teamdetails();
        }
        if (this.errors.indexOf(this.actid) == -1) {
            this.actdetail();
        }
        this.userid = localStorage.getItem('userid');
    }
    confirm_act() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (this.errors.indexOf(jquery__WEBPACK_IMPORTED_MODULE_6__('#amount').val()) >= 0) {
                this.common.presentToast('Please enter amount !', 'danger');
                return false;
            }
            this.dismiss();
            const modal = yield this.modalController.create({
                component: _paymentlistmodal_paymentlistmodal_page__WEBPACK_IMPORTED_MODULE_8__["PaymentlistmodalPage"],
                cssClass: 'leaveteam',
                componentProps: {
                    actid: this.actid,
                    amount: jquery__WEBPACK_IMPORTED_MODULE_6__('#amount').val(),
                    userid: this.userid
                }
            });
            modal.onDidDismiss().then((detail) => {
                if (this.errors.indexOf(detail.data) == -1) {
                }
            });
            return yield modal.present();
        });
    }
    confirm_team() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (this.errors.indexOf(jquery__WEBPACK_IMPORTED_MODULE_6__('#amount').val()) >= 0) {
                this.common.presentToast('Please enter amount !', 'danger');
                return false;
            }
            this.dismiss();
            const modal = yield this.modalController.create({
                component: _paymentlistmodal_paymentlistmodal_page__WEBPACK_IMPORTED_MODULE_8__["PaymentlistmodalPage"],
                cssClass: 'leaveteam',
                componentProps: {
                    teamid: this.teamid,
                    amount: jquery__WEBPACK_IMPORTED_MODULE_6__('#amount').val(),
                    userid: this.userid
                }
            });
            modal.onDidDismiss().then((detail) => {
                if (this.errors.indexOf(detail.data) == -1) {
                }
            });
            return yield modal.present();
        });
    }
    confirm_in() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (this.errors.indexOf(jquery__WEBPACK_IMPORTED_MODULE_6__('#amount').val()) >= 0) {
                this.common.presentToast('Please enter amount !', 'danger');
                return false;
            }
            this.dismiss();
            const modal = yield this.modalController.create({
                component: _paymentlistmodal_paymentlistmodal_page__WEBPACK_IMPORTED_MODULE_8__["PaymentlistmodalPage"],
                cssClass: 'leaveteam',
                componentProps: {
                    amount: jquery__WEBPACK_IMPORTED_MODULE_6__('#amount').val(),
                    userid: this.userid
                }
            });
            modal.onDidDismiss().then((detail) => {
                if (this.errors.indexOf(detail.data) == -1) {
                }
            });
            return yield modal.present();
        });
    }
    confirm() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (this.errors.indexOf(jquery__WEBPACK_IMPORTED_MODULE_6__('#amount').val()) >= 0) {
                this.common.presentToast('Please enter amount !', 'danger');
                return false;
            }
            this.dismiss();
            const modal = yield this.modalController.create({
                component: _paymentlistmodal_paymentlistmodal_page__WEBPACK_IMPORTED_MODULE_8__["PaymentlistmodalPage"],
                cssClass: 'leaveteam',
                componentProps: {
                    charityid: this.charityid,
                    amount: jquery__WEBPACK_IMPORTED_MODULE_6__('#amount').val(),
                    userid: this.userid
                }
            });
            modal.onDidDismiss().then((detail) => {
                if (this.errors.indexOf(detail.data) == -1) {
                    //this.team.joins=this.team.joins - 1;
                    //this.getuserteams();
                }
            });
            return yield modal.present();
        });
    }
    teamdetails() {
        let dict = {
            id: this.teamid,
        };
        //this.common.presentLoading();
        this.api.post('teamdetail', dict, '').subscribe((result) => {
            //this.common.stopLoading();
            var res;
            res = result;
            if (res.status == 1) {
                this.team = res.data;
            }
            else {
            }
        }, err => {
        });
    }
    actdetail() {
        let dict = {
            id: this.actid,
        };
        //this.common.presentLoading();
        this.api.post('activitydetail', dict, '').subscribe((result) => {
            //this.common.stopLoading();
            var res;
            res = result;
            if (res.status == 1) {
                this.act = res.data;
            }
            else {
            }
        }, err => {
        });
    }
    Charitydetail() {
        let dict = {
            id: this.charityid,
        };
        //this.common.presentLoading();
        this.api.post('charitydetail', dict, '').subscribe((result) => {
            //this.common.stopLoading();
            var res;
            res = result;
            if (res.status == 1) {
                this.charity = res.data;
                //this.images=res.images;
            }
            else {
            }
        }, err => {
        });
    }
};
AddamountPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["NavParams"] },
    { type: _services_api_api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _common_common_service__WEBPACK_IMPORTED_MODULE_5__["CommonService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"] }
];
AddamountPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-addamount',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./addamount.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/addamount/addamount.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./addamount.page.scss */ "./src/app/addamount/addamount.page.scss")).default]
    })
], AddamountPage);



/***/ })

}]);
//# sourceMappingURL=default~activitydetail-activitydetail-module~addamount-addamount-module~charitydetail-charitydetail-~e01b0d79-es2015.js.map