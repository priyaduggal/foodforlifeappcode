import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teamdetails',
  templateUrl: './teamdetails.page.html',
  styleUrls: ['./teamdetails.page.scss'],
})
export class TeamdetailsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
