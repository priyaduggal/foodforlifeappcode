import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thetable',
  templateUrl: './thetable.page.html',
  styleUrls: ['./thetable.page.scss'],
})
export class ThetablePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
